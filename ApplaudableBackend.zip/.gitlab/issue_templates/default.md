<!-- no need for a problem subtitle, as the title goes right above it -->

A summary of the problem itself. May even replace the *Problem Section* below.

### Deadline
2021-10-27

***

### Problem

Describe the problem here

### Proposals

Describe possible details you think may solve the issue at hand

### Tasks

* [ ] Solve urgent database-level issues;
* [ ] Set the website online.

### Files Involved

File paths possibly related to the issue.

***

### Dependencies/References

+ All issues with the database label should be closed

### Useful urls

+ [Google](http://www.google.com)

<!-- More detailed information -->
### Possible Cause

No description added to this section.
