A brief summary of what's happening, optionally?

### Added

What did you add to the project? Some new feature?

### Fixed

Any important fixes? Related to some issues, maybe?

### Changed

- So, other than fixes... what did you change? 

### Removed

- Some removed or deprecated behaviours and/or functionalities, or files (although git tracks that, so...)

### Related Issues

- A list of issues

### Notes

Some added notes, TODOs...