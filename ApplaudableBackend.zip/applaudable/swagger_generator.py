from drf_yasg.generators import OpenAPISchemaGenerator
from drf_yasg.openapi import IN_PATH, TYPE_STRING


class BothHttpAndHttpsSchemaGenerator(OpenAPISchemaGenerator):
    def get_schema(self, request=None, public=False):
        schema = super().get_schema(request, public)
        schema.schemes = ["https", "http"]
        return schema

    def get_path_parameters(self, path, view_cls):
        """
        Set path parameters as type string as default.
        """

        parameters = super().get_path_parameters(path, view_cls)
        for p in parameters:
            if p.in_ == IN_PATH:
                p.type = getattr(view_cls, f'path_type_{p.name}', TYPE_STRING)
        return parameters
