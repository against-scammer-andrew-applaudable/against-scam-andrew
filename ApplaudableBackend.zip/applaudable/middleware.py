import logging
from datetime import datetime

from django.conf import settings
from pytz import timezone, all_timezones

from apps.core.services import RedisContextManager


class UserTimezoneMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        try:
            user = request.user
            if not user.is_authenticated:
                return response
            date = request.headers.get('date')
            formatted_date = datetime.strptime(date, settings.TIMEZONE_MIDDLEWARE_DATE_FORMAT)
            utc_offset = str(formatted_date.tzinfo.utcoffset(formatted_date))
            with RedisContextManager() as redis:
                offset_exists = redis.exists('utc_offsets')
                if not offset_exists:
                    timezone_offset_dict = {
                        str(formatted_date.astimezone(tz).utcoffset()): tz.zone for tz in map(timezone, all_timezones)
                    }
                    redis.hmset('utc_offsets', timezone_offset_dict)
                    redis.expire('utc_offsets', settings.UTC_OFFSET_REDIS_TTL)
                tzname = redis.hget('utc_offsets', utc_offset)
            if tzname and user.timezone != tzname:
                user.timezone = tzname
                user.save()
        except (AttributeError, TypeError, ValueError) as e:
            logging.exception(e)
            pass
        return response
