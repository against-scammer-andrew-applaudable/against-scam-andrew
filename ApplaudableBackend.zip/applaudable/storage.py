"""
Django storage settings.
"""
