"""
Celery settings and task scheduler.
"""

from celery import Celery
from django.conf import settings
from django.utils import timezone

app = Celery("applaudable")

# Using a string here means the worker doesn't have to serialize
# the configuration object to child processes.
# - namespace='CELERY' means all celery-related configuration keys
#   should have a `CELERY_` prefix.
app.config_from_object("django.conf:settings", namespace="CELERY")

# setup celery_once
app.conf.ONCE = {
    "backend": "celery_once.backends.Redis",
    "settings": {
        "url": f"{settings.REDIS_ADDRESS}/{settings.REDIS_CACHE_DB}",
        "default_timeout": 60,
    },
}

app.conf.beat_schedule = {
    "unsuspend-users": {
        "task": "apps.users.tasks.unsuspend_users",
        "schedule": timezone.timedelta(days=1),
    },
    "send-notification-story-not-made": {
        "task": "apps.notifications.tasks.send_notification_story_not_made",
        "schedule": timezone.timedelta(hours=1),
    },
    "delete-old-notifications": {
        "task": "apps.notifications.tasks.delete_old_notifications",
        "schedule": timezone.timedelta(days=1),
    },
}

# Load task modules from all registered Django app configs.
app.autodiscover_tasks()
