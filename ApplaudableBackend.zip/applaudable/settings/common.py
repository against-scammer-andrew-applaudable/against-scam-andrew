"""
Django common settings for applaudable project.
"""

import logging
import os
import sys
from pathlib import Path

from django.utils import timezone
from firebase_admin import initialize_app

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent.parent

TRUE_VALUES = ["true", "True", "1", "y", "yes", True]

# Sets to True if running tests
TESTING = os.getenv("TESTING", len(sys.argv) > 1 and sys.argv[1] == "test") in TRUE_VALUES

SITE_ID = 1
SITE_NAME = "applaudable"

# Main Settings
# ADMINS = (("Dengun Backend Entry Point", "backend@dengun.com"),)

# MANAGERS = ADMINS

SECRET_KEY = os.environ.get("SECRET_KEY", "m!p=rfot1^)s(i$%k6%!l3+d$q%a$e&(b)d+zardxl#u_io7vl")

# SECURITY WARNING: don't run with debug turned on in production!
# SECURITY WARNING: keep the secret key used in production secret!
DEBUG = False
ENABLE_API_DOCS = False

PREPEND_WWW = False
APPEND_SLASH = False

ALLOWED_HOSTS = []

PROJECT_DOMAIN_NAME = "applaudable.com"
PROJECT_URL = os.environ.get("PROJECT_DOMAIN_NAME")
PROJECT_CLIENT_URL = PROJECT_URL

# SALT FOR ENCODING/DECODING HASH KEYS
HASHID_FIELD_SALT = os.environ.get("HASHID_FIELD_SALT", "%k6%!l2+c$q%a$d&(h)")
HASHID_FIELD_ALLOW_INT_LOOKUP = True

# SECURITY
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
SECURE_SSL_REDIRECT = True

# CORS Config
# see https://github.com/adamchainz/django-cors-headers
CORS_ORIGIN_ALLOW_ALL = False
CORS_ORIGIN_REGEX_WHITELIST = []

CORS_ALLOW_HEADERS = (
    "accept",
    "accept-encoding",
    "authorization",
    "content-type",
    "cache-control",
    "origin",
    "user-agent",
    "x-csrftoken",
    "x-requested-with",
    "www-authenticate",
)

# Application definition
INSTALLED_APPS = [
    # Django Apps
    "django.contrib.auth",
    "django.contrib.gis",
    "django.contrib.postgres",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "django.contrib.sites",
    # Third-Party Integrations
    "rest_framework",
    "rest_framework_simplejwt.token_blacklist",
    "drf_yasg",
    "django_celery_beat",
    "django_filters",
    "fcm_django",
    "phonenumber_field",
    "cloudinary",
    "import_export",
    "django_countries",
    "secured_fields",
    # Main Apps
    "apps.api",
    "apps.collection",
    "apps.content",
    "apps.core",
    "apps.email",
    "apps.life_story",
    "apps.notifications",
    "apps.onboarding",
    "apps.posts",
    "apps.user_auth",
    "apps.users",
    "apps.nupp",
    "apps.mention",
    "apps.influence",
    "apps.experience",
    "apps.autocomplete",
    "apps.version",
    "apps.location",
    "apps.prompt",
    "apps.circle",
    "apps.highlights"
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

X_FRAME_OPTIONS = "SAMEORIGIN"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [
            os.path.join(BASE_DIR, "applaudable/templates"),
        ],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "applaudable.wsgi.default.application"

# Database
# https://docs.djangoproject.com/en/4.1/ref/settings/#databases
DATABASES = {
    "default": {
        "ENGINE": "django.contrib.gis.db.backends.postgis",
        "NAME": os.environ.get("POSTGRES_DB", "applaudable_db"),
        "USER": os.environ.get("POSTGRES_USER", "applaudable_user"),
        "PASSWORD": os.environ.get("POSTGRES_PASSWORD", "weakpass"),
        "HOST": os.environ.get("DB_HOST", "172.20.0.2"),
        "PORT": "5432",
    }
}

# Password validation
# https://docs.djangoproject.com/en/4.1/ref/settings/#auth-password-validators
AUTH_PASSWORD_VALIDATORS = [
    {
        "NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
        "OPTIONS": {
            "min_length": 9,
        },
    },
    {
        "NAME": "django.contrib.auth.password_validation.CommonPasswordValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.NumericPasswordValidator",
    },
]


# Internationalization
# https://docs.djangoproject.com/en/4.1/topics/i18n/

LANGUAGE_CODE = "en-us"

# Languages
LANGUAGES = (("en", "English"),)

TIME_ZONE = "UTC"

USE_I18N = True

USE_TZ = True

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/4.1/howto/static-files/
MEDIA_ROOT = os.path.join(BASE_DIR, "uploads")

MEDIA_URL = PROJECT_URL + "/uploads/"

STATIC_ROOT = os.path.join(BASE_DIR, "static")

STATIC_URL = "/static/"

STATICFILES_DIRS = (os.path.join(BASE_DIR, "applaudable/assets"),)

STATICFILES_FINDERS = (
    "django.contrib.staticfiles.finders.FileSystemFinder",
    "django.contrib.staticfiles.finders.AppDirectoriesFinder",
)

# Default primary key field type
# https://docs.djangoproject.com/en/4.1/ref/settings/#default-auto-field

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

DATETIME_FORMAT = "%Y-%m-%dT%H:%M:%S.%f%z"

# REDIS CONFIG
REDIS_HOSTNAME = os.environ.get("REDIS_HOSTNAME", "redis")
REDIS_READ_HOSTNAME = os.environ.get("REDIS_READ_HOSTNAME", REDIS_HOSTNAME)
REDIS_PORT = os.environ.get("REDIS_PORT", "6379")
REDIS_CACHE_DB = os.environ.get("REDIS_CACHE_DB", "0")
REDIS_BROKER_DB = os.environ.get("REDIS_BROKER_DB", "1")
REDIS_ADDRESS = f"redis://{REDIS_HOSTNAME}:{REDIS_PORT}"
REDIS_READ_ADDRESS = f"redis://{REDIS_READ_HOSTNAME}:{REDIS_PORT}"

CELERY_BROKER_URL = f"{REDIS_ADDRESS}/{REDIS_BROKER_DB}"
CELERY_TASK_IGNORE_RESULT = True
CELERY_WORKER_DISABLE_RATE_LIMITS = True
CELERY_TASK_ALWAYS_EAGER = False
CELERY_TASK_EAGER_PROPAGATES = False
CELERY_TASK_DEFAULT_QUEUE = "default"

# CACHES
CACHES = {
    "default": {
        "BACKEND": "django_redis.cache.RedisCache",
        "LOCATION": f"{REDIS_ADDRESS}/{REDIS_CACHE_DB}",
        "OPTIONS": {
            "CLIENT_CLASS": "django_redis.client.DefaultClient",
        },
        "KEY_PREFIX": "applaudable",
    },
    "read": {
        "BACKEND": "django_redis.cache.RedisCache",
        "LOCATION": [
            f"{REDIS_READ_ADDRESS}/{REDIS_CACHE_DB}",
        ],
        "OPTIONS": {
            "CLIENT_CLASS": "django_redis.client.DefaultClient",
            "CONNECTION_POOL_KWARGS": {"max_connections": 20},
            "SOCKET_CONNECT_TIMEOUT": 10,  # in seconds
            "SOCKET_TIMEOUT": 10,  # in seconds
        },
        "KEY_PREFIX": "applaudable",
    },
}

# Cache time to live is 15 minutes.
CACHE_TTL = 60 * 15

# REST API SETTINGS
REST_FRAMEWORK = {
    # Use Django's standard `django.contrib.auth` permissions,
    # or allow read-only access for unauthenticated users.
    "DEFAULT_PERMISSION_CLASSES": [
        "rest_framework.permissions.DjangoModelPermissionsOrAnonReadOnly",
        "rest_framework.permissions.IsAuthenticatedOrReadOnly",
    ],
    "DEFAULT_AUTHENTICATION_CLASSES": ("rest_framework_simplejwt.authentication.JWTAuthentication",),
    "DEFAULT_RENDERER_CLASSES": ("rest_framework.renderers.JSONRenderer",),
    # Since 3.10 it's necessary to re-enable CoreApi, because now DRF uses OpenApi
    "DEFAULT_SCHEMA_CLASS": "rest_framework.schemas.coreapi.AutoSchema",
    "DEFAULT_PAGINATION_CLASS": "apps.api.pagination.LimitOffsetPagination",
    "PAGE_SIZE": os.environ.get("PAGE_SIZE", 10),
    "DEFAULT_FILTER_BACKENDS": [
        "django_filters.rest_framework.DjangoFilterBackend",
    ],
    "TEST_REQUEST_DEFAULT_FORMAT": "json",
    "DATETIME_FORMAT": DATETIME_FORMAT,
    "EXCEPTION_HANDLER": "apps.api.utils.api_exception_handler",
}

SIMPLE_JWT = {
    "ACCESS_TOKEN_LIFETIME": timezone.timedelta(days=360),
    "REFRESH_TOKEN_LIFETIME": timezone.timedelta(days=7),
    "ROTATE_REFRESH_TOKENS": True,
    "BLACKLIST_AFTER_ROTATION": True,
    "AUTH_HEADER_TYPES": ("Bearer", "token"),
    "UPDATE_LAST_LOGIN": True,
}

# AUTH SETTINGS
AUTH_USER_MODEL = "users.User"

AUTHENTICATION_BACKENDS = ("apps.users.backends.ModelBackend",)

# EMAIL CONFIG
EMAIL_HOST = os.environ.get("EMAIL_HOST", "mail.privateemail.hostemail")
EMAIL_HOST_USER = os.environ.get("EMAIL_HOST_USER", f"admin@{PROJECT_DOMAIN_NAME}")
EMAIL_HOST_PASSWORD = os.environ.get("EMAIL_HOST_PASSWORD", "DengunWasHere!")
EMAIL_PORT = os.environ.get("EMAIL_PORT", 587)
EMAIL_USE_TLS = os.environ.get("EMAIL_USE_TLS", False) in TRUE_VALUES

DEFAULT_FROM_EMAIL = os.environ.get("DEFAULT_FROM_EMAIL", f"admin@{PROJECT_DOMAIN_NAME}")
EMAIL = {
    "from_email": DEFAULT_FROM_EMAIL,
    "recipients": [],
    "cc_recipients": [],
    "bcc_recipients": [],
}

# PHONE NUNBERS FIELD CONFIG
PHONENUMBER_DB_FORMAT = "E164"
PHONENUMBER_DEFAULT_REGION = "US"

# SENTRY SETTINGS
try:
    from sentry_sdk.integrations.celery import CeleryIntegration
    from sentry_sdk.integrations.django import DjangoIntegration
    from sentry_sdk.integrations.logging import LoggingIntegration, ignore_logger
    from sentry_sdk.integrations.redis import RedisIntegration

    ignore_logger("django.security.DisallowedHost")

    SENTRY_SETTINGS = {
        "dsn": os.environ.get("SENTRY_DSN", None),
        "integrations": [
            LoggingIntegration(level=logging.ERROR, event_level=logging.ERROR),
            DjangoIntegration(),
            CeleryIntegration(),
            RedisIntegration(),
        ],
        "environment": os.environ.get("SENTRY_ENV", ""),
        "release": os.environ.get("SENTRY_RELEASE", SITE_NAME),
        "traces_sample_rate": os.environ.get("SENTRY_TRACES_SAMPLE_RATE", SITE_NAME),
        "send_default_pii": os.environ.get("SEND_DEFAULT_PII", SITE_NAME),
    }
except ImportError:
    pass

# Twilio
TWILIO_ACCOUNT_SID = os.environ.get("TWILIO_ACCOUNT_SID", "")
TWILIO_AUTH_TOKEN = os.environ.get("TWILIO_AUTH_TOKEN", "")
TWILIO_VERIFY_SERVICE_SID = os.environ.get("TWILIO_VERIFY_SERVICE_SID", "")
TWILIO_MESSAGING_SID = os.environ.get("TWILIO_MESSAGING_SID", "")

# FCM Settings
FIREBASE_APP = initialize_app()
FCM_DJANGO_SETTINGS = {
    "APP_VERBOSE_NAME": "Applaudable FCM",
    "ONE_DEVICE_PER_USER": False,
    "DELETE_INACTIVE_DEVICES": True,
    "UPDATE_ON_DUPLICATE_REG_ID": True,
}

# Firebase Integration and Dynamic Links
GOOGLE_APPLICATION_CREDENTIALS = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS", "")
FIREBASE_API_KEY = os.environ.get("FIREBASE_API_KEY", "")

FIREBASE_DYNAMIC_LINK = {
    'API_KEY': FIREBASE_API_KEY,
    'DOMAIN_URI': os.environ.get("FIREBASE_PROJECT_URL", "https://example.link"),
    'ANDROID_PACKAGE_NAME': os.environ.get("ANDROID_APP_PACKAGE_NAME", "lo.example.id"),
    'IOS_BUNDLE_ID': os.environ.get("IOS_APP_BUNDLE_ID", "lo.example.id"),
}

# Google
GOOGLE_PLACES_API = os.environ.get("GOOGLE_PLACES_API", "")
GOOGLE_SEARCH_API = os.environ.get("GOOGLE_SEARCH_API", "")
GOOGLE_SEARCH_CX = os.environ.get("GOOGLE_SEARCH_CX", "")

# Cloudinary
CLOUDINARY_KEY = os.environ.get("CLOUDINARY_KEY", "")
CLOUDINARY_SECRET = os.environ.get("CLOUDINARY_SECRET", "")
CLOUDINARY_CLOUD_NAME = os.environ.get("CLOUDINARY_CLOUD_NAME", "")
CLOUDINARY_DEFAULT_FOLDER = os.environ.get("CLOUDINARY_DEFAULT_FOLDER", "applaudable")
CLOUDINARY_DEFAULT_BACKGROUND = os.environ.get("CLOUDINARY_DEFAULT_BACKGROUND", "applaudable/background_u6cfsu")
CLOUDINARY_URL = f"cloudinary://{CLOUDINARY_KEY}:{CLOUDINARY_SECRET}@{CLOUDINARY_CLOUD_NAME}"

try:
    import cloudinary

    cloudinary.config(
        cloud_name=CLOUDINARY_CLOUD_NAME,
        api_key=CLOUDINARY_KEY,
        api_secret=CLOUDINARY_SECRET,
        secure=True,
    )

except ImportError:
    pass


# OpenAI KEY
OPENAPI_API_KEY = os.environ.get("OPENAPI_API_KEY", "")
OPENAPI_ORG_KEY = os.environ.get("OPENAPI_ORG_KEY", "")

# OpenAI improve text token limit
# refs:
# - https://help.openai.com/en/articles/4936856-what-are-tokens-and-how-to-count-them
# - https://platform.openai.com/docs/guides/gpt/managing-tokens
OPENAPI_MAX_RESPONSE_LENGTH = int(os.environ.get("OPENAPI_MAX_RESPONSE_LENGTH", "50"))

# Which hour users that did not post a story should receive a push notification
STORY_PUSH_NOTIFICATION_HOUR = 12

UTC_OFFSET_REDIS_TTL = 604800  # 1 week

NOTIFICATION_TTL = os.environ.get('NOTIFICATION_TTL', 7)  # 7 days

TIMEZONE_MIDDLEWARE_DATE_FORMAT = "%Y-%m-%dT%H:%M:%S.%fZ%z"


DISAPPEAR_NOTIFICATION_TTL = os.environ.get('DISAPPEAR_NOTIFICATION_TTL', 23)  # 23 hours

# SECURED_FIELDS
SECURED_FIELDS_KEY = 'TtY8MAeXuhdKDd1HfGUwim-vQ8H7fXyRQ9J8pTi_-lg='
SECURED_FIELDS_HASH_SALT = '500d492e'