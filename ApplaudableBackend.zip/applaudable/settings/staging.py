"""
Django configuration for local settings.
"""

from .common import *

# --- DEBUG-RELATED SETTINGS ---
PREPEND_WWW = False
DEBUG = False
ENABLE_API_DOCS = True

ENV_PREFIX='STAG'

PROJECT_URL = "https://api-dev.applaudable.com"
PROJECT_CLIENT_URL = PROJECT_URL

ALLOWED_HOSTS = [
    "*",
]

# DISABLE SECURITY
CORS_ORIGIN_ALLOW_ALL = True
SECURE_PROXY_SSL_HEADER = None
SECURE_SSL_REDIRECT = False

INSTALLED_APPS += ["django_extensions"]


# Template debug
TEMPLATES[0]["OPTIONS"]["debug"] = True
TEMPLATES[0]["DIRS"] = [
    os.path.join(BASE_DIR, "applaudable/templates"),
]

MEDIA_URL = PROJECT_URL + "/uploads/"
STATIC_URL = "/static/"

DATABASE_ROUTERS = []


def show_toolbar(request):
    return True


DEBUG_TOOLBAR_CONFIG = {
    "SHOW_TOOLBAR_CALLBACK": show_toolbar,
}

# TRAP ALL MY OUTGOING MAILS
# see https://mailtrap.io/inboxes for mailtrap instructions
EMAIL_HOST = os.environ.get("EMAIL_HOST", "smtp.mailtrap.io")
EMAIL_HOST_USER = os.environ.get("EMAIL_HOST_USER", "set-in-.env")
EMAIL_HOST_PASSWORD = os.environ.get("EMAIL_HOST_PASSWORD", "set-in-.env")
EMAIL_PORT = os.environ.get("EMAIL_PORT", 2525)
EMAIL_USE_TLS = os.environ.get("EMAIL_USE_TLS", False) in TRUE_VALUES

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
        },
    },
    "root": {
        "handlers": ["console"],
        "level": "INFO",
    },
}

try:
    import sentry_sdk

    sentry_sdk.init(**SENTRY_SETTINGS)
except ImportError:
    pass

STATICFILES_STORAGE = 'storages.backends.s3boto3.S3StaticStorage'
AWS_STORAGE_BUCKET_NAME = os.environ.get("AWS_STORAGE_BUCKET_NAME", "")
AWS_ACCESS_KEY_ID = os.environ.get("AWS_ACCESS_KEY_ID", "")
AWS_SECRET_ACCESS_KEY = os.environ.get("AWS_SECRET_ACCESS_KEY", "")
