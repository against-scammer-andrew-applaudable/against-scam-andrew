"""
Django configuration for testing environment.
"""

from .common import *

PROJECT_URL = f"https://testing.{PROJECT_DOMAIN_NAME}"
PROJECT_CLIENT_URL = PROJECT_URL

ALLOWED_HOSTS = [
    "*",
]

# SECURITY
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
# SECURE_PROXY_SSL_HEADER = None
SECURE_SSL_REDIRECT = False

DATABASES = {
    "default": {
        "ENGINE": "django.contrib.gis.db.backends.postgis",
        "NAME": os.environ.get("POSTGRES_DB", "applaudable_db"),
        "USER": os.environ.get("POSTGRES_USER", "applaudable_user"),
        "PASSWORD": os.environ.get("POSTGRES_PASSWORD", "weakpass"),
        "HOST": os.environ.get("DB_HOST", "172.20.0.2"),
        "PORT": "5432",
    }
}

# REDIS CONFIG
REDIS_HOSTNAME = "redis"
REDIS_PORT = 6379
REDIS_ADDRESS = f"redis://{REDIS_HOSTNAME}:{REDIS_PORT}"

CELERY_BROKER_URL = f"{REDIS_ADDRESS}/{REDIS_BROKER_DB}"
CELERY_TASK_ALWAYS_EAGER = True
CELERY_TASK_EAGER_PROPAGATES = True

TESTING = True

EMAIL_HOST = None
EMAIL_HOST_USER = None
EMAIL_HOST_PASSWORD = None

# CACHES
CACHES = {
    "default": {
        "BACKEND": "django_redis.cache.RedisCache",
        "LOCATION": f"{REDIS_ADDRESS}/{REDIS_CACHE_DB}",
        "OPTIONS": {
            "CLIENT_CLASS": "django_redis.client.DefaultClient",
        },
        "KEY_PREFIX": "applaudable",
    },
    "read": {
        "BACKEND": "django_redis.cache.RedisCache",
        "LOCATION": f"{REDIS_ADDRESS}/{REDIS_CACHE_DB}",
        "OPTIONS": {
            "CLIENT_CLASS": "django_redis.client.DefaultClient",
        },
        "KEY_PREFIX": "applaudable",
    },
}

ROOT_URLCONF = "applaudable.api_urls"

LOGGING = {
    "version": 1,
    "disable_existing_loggers": True,
    "handlers": {
        "null": {
            "level": "DEBUG",
            "class": "logging.NullHandler",
        },
    },
    "root": {
        "handlers": ["null"],
        "level": "INFO",
        "propagate": True,
    },
}
