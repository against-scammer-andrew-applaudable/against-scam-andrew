"""
Django configuration for the API docker container. (Django 4.0)
"""

from .production import *

MIDDLEWARE = ["corsheaders.middleware.CorsMiddleware", "django.middleware.common.CommonMiddleware", "applaudable.middleware.UserTimezoneMiddleware"]

INSTALLED_APPS += [
    # Security
    "corsheaders",
]

ROOT_URLCONF = "applaudable.api_urls"

SWAGGER_SETTINGS = {
    'SECURITY_DEFINITIONS': {'Bearer': {'type': 'apiKey', 'in': 'header', 'name': 'Authorization'}},
    'USE_SESSION_AUTH': False,
    'JSON_EDITOR': True,
}
