"""
Django configuration for the Admin docker container. (Django 3.2)
"""

from .local import *

PROJECT_URL = "http://localhost:9000"
PROJECT_CLIENT_URL = PROJECT_URL

USE_X_FORWARDED_HOST = True

ALLOWED_HOSTS = ["admin.applaudable.com", "*"]

INSTALLED_APPS += [
    # Django admin
    #'django_admin_kubi',
    "django.contrib.admin",
    "contrib.admin_relation",
]

ROOT_URLCONF = "applaudable.admin_urls"

LOGIN_URL = "admin:login"

MIDDLEWARE += [
    # "kolo.middleware.KoloMiddleware",
]
