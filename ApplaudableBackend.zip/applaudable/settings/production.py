"""
Django configuration for production environment.
"""

from .common import *

# --- DEBUG-RELATED SETTINGS ---
PREPEND_WWW = False
DEBUG = False
ENABLE_API_DOCS = True

ENV_PREFIX='PROD'

PROJECT_URL = "https://api.applaudable.com"
PROJECT_CLIENT_URL = PROJECT_URL

ALLOWED_HOSTS = [
    "*",
]

# DISABLE SECURITY
CORS_ORIGIN_ALLOW_ALL = True
SECURE_PROXY_SSL_HEADER = None
SECURE_SSL_REDIRECT = False

INSTALLED_APPS += ["django_extensions"]


# Template debug
TEMPLATES[0]["OPTIONS"]["debug"] = True
TEMPLATES[0]["DIRS"] = [
    os.path.join(BASE_DIR, "applaudable/templates"),
]

MEDIA_URL = PROJECT_URL + "/uploads/"
STATIC_URL = "/static/"

DATABASE_ROUTERS = []


def show_toolbar(request):
    return True


DEBUG_TOOLBAR_CONFIG = {
    "SHOW_TOOLBAR_CALLBACK": show_toolbar,
}

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
        },
    },
    "root": {
        "handlers": ["console"],
        "level": "INFO",
    },
}

try:
    import sentry_sdk

    sentry_sdk.init(**SENTRY_SETTINGS)
except ImportError:
    pass

STATICFILES_STORAGE = 'storages.backends.s3boto3.S3StaticStorage'
AWS_STORAGE_BUCKET_NAME = os.environ.get("AWS_STORAGE_BUCKET_NAME", "")
AWS_ACCESS_KEY_ID = os.environ.get("AWS_ACCESS_KEY_ID", "")
AWS_SECRET_ACCESS_KEY = os.environ.get("AWS_SECRET_ACCESS_KEY", "")