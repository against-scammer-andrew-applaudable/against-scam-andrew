"""
Django configuration for local settings.
"""

from .common import *

# --- DEBUG-RELATED SETTINGS ---
PREPEND_WWW = False
DEBUG = True
ENABLE_API_DOCS = True

ENV_PREFIX='LOCAL'

PROJECT_URL = "http://localhost:8000"
PROJECT_CLIENT_URL = PROJECT_URL

ALLOWED_HOSTS = [
    "*",
]

# DISABLE SECURITY
CORS_ORIGIN_ALLOW_ALL = True
SECURE_PROXY_SSL_HEADER = None
SECURE_SSL_REDIRECT = False

INSTALLED_APPS += [
    "django_extensions",
    "silk",
]

if "silk" in INSTALLED_APPS and not TESTING:
    MIDDLEWARE += [
        "silk.middleware.SilkyMiddleware",
    ]

# Template debug
TEMPLATES[0]["OPTIONS"]["debug"] = True
TEMPLATES[0]["DIRS"] = [
    os.path.join(BASE_DIR, "applaudable/templates"),
]

MEDIA_URL = PROJECT_URL + "/uploads/"
STATIC_URL = "/static/"

DATABASE_ROUTERS = []


def show_toolbar(request):
    return True


DEBUG_TOOLBAR_CONFIG = {
    "SHOW_TOOLBAR_CALLBACK": show_toolbar,
}

# TRAP ALL MY OUTGOING MAILS
# see https://mailtrap.io/inboxes for mailtrap instructions
EMAIL_HOST = os.environ.get("EMAIL_HOST", "smtp.mailtrap.io")
EMAIL_HOST_USER = os.environ.get("EMAIL_HOST_USER", "set-in-.env")
EMAIL_HOST_PASSWORD = os.environ.get("EMAIL_HOST_PASSWORD", "set-in-.env")
EMAIL_PORT = os.environ.get("EMAIL_PORT", 2525)
EMAIL_USE_TLS = os.environ.get("EMAIL_USE_TLS", False) in TRUE_VALUES

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
        },
    },
    "root": {
        "handlers": ["console"],
        "level": "INFO",
    },
}
