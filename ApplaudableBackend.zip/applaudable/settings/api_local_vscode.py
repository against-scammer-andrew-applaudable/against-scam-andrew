from .api_local import *

MIDDLEWARE = [
    "kolo.middleware.KoloMiddleware",
    "django.middleware.common.CommonMiddleware",
    "applaudable.middleware.UserTimezoneMiddleware",
]
