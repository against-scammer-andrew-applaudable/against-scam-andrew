"""
Base URLs for Admin container (Django 3.2)
"""


from django.contrib import admin
from django.contrib.auth.views import PasswordResetCompleteView, PasswordResetDoneView
from django.urls import include, path

from applaudable import views
from apps.users.views import AdminPasswordResetConfirmView, RequestAdminPasswordResetView
from django.conf import settings
from django.views.generic.base import RedirectView
from django.contrib.staticfiles.storage import staticfiles_storage

ENV_PREFIX = getattr(settings, "ENV_PREFIX", "local")

urlpatterns = [
    path("admin/", admin.site.urls),
    path("deeplink/", views.DeepLinkView.as_view(), name="web-deeplink"),

    path(
        "accounts/admin-password-change/",
        RequestAdminPasswordResetView.as_view(),
        name="admin_password_reset",
    ),
    path(
        "accounts/admin-password-change/done/",
        PasswordResetDoneView.as_view(),
        name="password_reset_done",
    ),
    path(
        "accounts/admin-password-change/reset/done/",
        PasswordResetCompleteView.as_view(),
        name="password_reset_complete",
    ),
    path(
        "accounts/admin-password-change/reset/<str:uidb64>/<str:token>/",
        AdminPasswordResetConfirmView.as_view(),
        name="password_reset_confirm",
    ),
    path("users/", include("apps.users.urls", namespace="users")),
    path('favicon.png', RedirectView.as_view(url=staticfiles_storage.url('assets/local-local.svg'))),

    path("", views.index, name="index"),

]

admin.site.site_header = f"Applaudable Administration [{ENV_PREFIX}]"
admin.site.site_title = "Applaudable Administration [{ENV_PREFIX}]"
admin.site.index_title = "Applaudable Administration [{ENV_PREFIX}]"
admin.site.site_url = ""