def highlights_notify(highlight):
    # TODO: Need to define this later
    print(highlight)

def highlights_mention_notify(highlight):
    # TODO: Need to define this later
    print(highlight)
    
def highlights_visible_user_notify(highlight):
    # TODO: Need to define this later
    print(highlight)
    
def highlights_applaud_notify(highlight):
    # TODO: Need to define this later
    print(highlight)
    
def flagged_highlights_succesfully_notify(highlight):
    # TODO: Need to define this later
    print(highlight)