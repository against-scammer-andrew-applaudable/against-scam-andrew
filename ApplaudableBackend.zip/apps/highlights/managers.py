from django.db.models import Manager


class HighlightsManager(Manager):
    def get_enabled_highlights(self):
        queryset = super().get_queryset()
        return queryset.filter(is_disabled=False)