import logging
from django.db import models
from django.contrib.auth import get_user_model
# Create your models here.
from apps.core.models import (
    AbstractCreatedDateMixin,
    AbstractCreatedUpdatedDateMixin,
    AbstractMetadata,
    AbstractUniqueBigHashIDMixin,
)
from apps.media.models import AbstractMedia
from apps.mention.models import AbstractMention
from apps.experience.models import ExperienceElement, Experience
from apps.experience.constant import ExperienceDataType
from apps.posts.models import Post
from apps.highlights.managers import HighlightsManager

from apps.highlights.notify import (
    highlights_notify,
    highlights_mention_notify,
    highlights_visible_user_notify,
    highlights_applaud_notify,
    flagged_highlights_succesfully_notify
)

User = get_user_model()

class HighlightsBase(
    AbstractUniqueBigHashIDMixin,
    AbstractCreatedUpdatedDateMixin,
    AbstractMetadata,
):
    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name="owned_%(class)ss")
    text = models.TextField(null=True, blank=True)
    layout_type = models.CharField(blank=True, null=True, max_length=255)
    likes = models.PositiveIntegerField(default=0)
    shares = models.PositiveIntegerField(default=0)
    influences = models.PositiveIntegerField(default=0)
    related_highlight = models.ForeignKey("self", on_delete=models.SET_NULL, related_name="related_%(class)ss", null=True, blank=True)
    is_disabled = models.BooleanField(default=False)
    title = models.TextField(null=True, blank=True)
    view_count = models.PositiveIntegerField(default=1)
    
    objects = HighlightsManager()

    class Meta:
        abstract = True

    def __str__(self):
        return str(self.id)
    
class Highlights(HighlightsBase):
    class Meta:
        verbose_name = "Highlights"
        verbose_name_plural = "Highlights"
        indexes = [*AbstractUniqueBigHashIDMixin.Meta.indexes, *AbstractMetadata.Meta.indexes]

    def notify(self):
        highlights_notify(self)

    def get_icon(self):
        try:
            return self.media.first().cloudinary_resource.url
        except Exception as e:
            logging.exception(e)
            return ''
        
class HighlightsGlimpse(AbstractCreatedDateMixin):
    highlight = models.ForeignKey(Highlights, related_name="glimpses", on_delete=models.CASCADE)
    glimpse = models.ForeignKey(Post, on_delete=models.CASCADE, related_name="highlight_glimpse")
    order  = models.PositiveIntegerField(default=0)
    layout_template = models.JSONField(blank=True, default=dict)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["highlight", "glimpse"], name="unique_highlight_glimpse")]
        db_table = "highlights_glimpses"
        ordering = ['order']

    def __str__(self):
        return str(self.highlight_id)
        
class HighlightsVisibleUsers(AbstractCreatedDateMixin):
    highlight = models.ForeignKey(Highlights, related_name="highlight_visible_users", on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="highlight_visible_user")
    class Meta:
        constraints = [models.UniqueConstraint(fields=["highlight", "user"], name="unique_highlight_visible_users")]
        db_table = "highlights_visible_users"

    def __str__(self):
        return str(self.highlight_id)

    def notify(self):
        highlights_visible_user_notify(self)


class HighlightsMedia(AbstractMedia):
    highlight = models.ForeignKey(Highlights, on_delete=models.CASCADE, related_name="media", null=True)
    order = models.PositiveIntegerField(default=0)
    class Meta:
        verbose_name = "HighlightsMedia"
        verbose_name_plural = "HighlightsMedia"
        ordering = ['order']
        indexes = [
            *AbstractMedia.Meta.indexes,
        ]


class HighlightsBookmark(AbstractCreatedDateMixin):
    highlight = models.ForeignKey(Highlights, on_delete=models.CASCADE, related_name="highlight_bookmarked")
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="highlight_bookmarks")

    class Meta:
        constraints = [models.UniqueConstraint(fields=["highlight", "user"], name="unique_highlight_bookmark")]


class HighlightsApplauds(AbstractCreatedDateMixin):
    highlight = models.ForeignKey(Highlights, on_delete=models.CASCADE, related_name="highlights_applauds")
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="highlights_user_applauds")
    type = models.CharField(max_length=45, blank=True, null=True, default="applaud")

    class Meta:
        verbose_name = "HighlightsApplauds"
        verbose_name_plural = "HighlightsApplauds"
    def __str__(self):
        return f"{self.highlight} - {self.user}"

    def notify(self):
        highlights_applaud_notify(self)


class HighlightsFlag(models.Model):
    highlight = models.ForeignKey(Highlights, on_delete=models.CASCADE, related_name="highlights_%(class)ss")
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="highlight_flags")

    def __str__(self):
        return f"{self.highlight} - {self.user}"

    def notify(self):
        flagged_highlights_succesfully_notify(self.user, self.highlight)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["highlight", "user"], name="unique_highlight_flag")]


class HighlightsElement(models.Model):    
    highlight = models.ForeignKey(Highlights, on_delete=models.CASCADE, related_name="highlight_elements")
    experience = models.ForeignKey(Experience, on_delete=models.CASCADE, null=True)
    element = models.ForeignKey(ExperienceElement, on_delete=models.CASCADE, null=True)
    data_type = models.CharField(max_length=60, blank=False, choices=ExperienceDataType.choices(), default=ExperienceDataType.FREEFORM)
    content = models.TextField()
    metadata = models.JSONField(blank=True, null=True, default=dict)
    class Meta:
        db_table = "highlights_elements"
        
class HighlightsMention(AbstractCreatedDateMixin):
    highlight = models.ForeignKey(Highlights, related_name="highlight_mentions", on_delete=models.CASCADE)
    mentioner = models.ForeignKey(User, related_name="highlight_mentioners", on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    user_invite = models.ForeignKey("users.UserInvite", on_delete=models.CASCADE, null=True)
    
    def __str__(self):
        return str(self.highlight_id)

    @classmethod
    def mention_field_name(cls) -> str:
        return "highlight"

    def notify(self):
        highlights_mention_notify(self)