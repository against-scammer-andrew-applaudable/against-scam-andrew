from django.urls import path
from rest_framework.routers import DefaultRouter

from apps.highlights.api.view import (
    HighlightsViewSet, HighlightFeedListViewSet
)

app_name = "highlights"

router = DefaultRouter()
router.register(r"", HighlightsViewSet, basename="highlights")

urlpatterns = [
    path("feeds/", HighlightFeedListViewSet.as_view(), name="highlights_feed_list"),
] + router.urls
