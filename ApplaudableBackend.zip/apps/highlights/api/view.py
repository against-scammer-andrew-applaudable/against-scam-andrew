from django.contrib.auth import get_user_model
from django.http import Http404
from drf_yasg.utils import swagger_auto_schema
from rest_framework import status
from rest_framework.generics import ListAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet
from apps.users.api.authentication import JWTAuthenticationIgnoreIsActive
from apps.highlights.api.serializers import HighlightsSerializer, HighlightCreationSerializer
from apps.highlights.models import Highlights
from apps.api.v1.serializers import SuccessIndicatorSerializer

User = get_user_model()

class HighlightFeedListViewSet(ListAPIView):
    serializer_class = HighlightsSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)

    def get_queryset(self):
        user = self.request.user
        return Highlights.objects.get_enabled_highlights().order_by("-created_at")
    
    
class HighlightsViewSet(ModelViewSet):
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)
    serializer_class = HighlightsSerializer
    lookup_field = "id"
    http_method_names = ("get", "post", "delete", "patch")

    def get_queryset(self):
        return Highlights.objects.get_enabled_highlights()


    def get_object(self):
        extra_kwargs = {}
        if self.request.method in ["PATCH", "DELETE"]:
            extra_kwargs = {"owner": self.request.user}
        try:
            return (
                Highlights.objects.get_enabled_highlights().get(id=self.kwargs["id"], **extra_kwargs)
            )
        except Highlights.DoesNotExist:
            raise Http404

    def get_serializer_context(self):
        return super().get_serializer_context()
    
    # Need to keep this function https://github.com/axnsan12/drf-yasg/issues/503
    def get_parsers(self):
        if getattr(self, 'swagger_fake_view', False):
            return []
        return super().get_parsers()
    
    @swagger_auto_schema(
        request_body=HighlightCreationSerializer,
        responses={status.HTTP_201_CREATED: HighlightsSerializer()},
    )
    def create(self, request: Request):

        serializer = HighlightCreationSerializer(data=request.data, context=self.get_serializer_context())
        serializer.is_valid(raise_exception=True)
        highlight = serializer.save()
        response_serializer = HighlightsSerializer(highlight, context=self.get_serializer_context())
        return Response(status=status.HTTP_201_CREATED, data=response_serializer.data)



