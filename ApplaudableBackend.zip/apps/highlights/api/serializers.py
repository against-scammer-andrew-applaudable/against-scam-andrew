from django.conf import settings
from django.contrib.auth import get_user_model
from django.db import IntegrityError, transaction
from django.db.models import Count, F
from drf_yasg.utils import swagger_serializer_method
from hashid_field.rest import HashidSerializerCharField
from rest_framework import serializers

from django.utils import timezone

from apps.posts.models import Post
from apps.posts.api.serializers import PostSimpleSerializer
from apps.experience.models import Experience, ExperienceElement
from apps.users.api.serializers import SimpleUserSerializer
from apps.experience.api.serializers import ExperienceSimpleSerializer, ExperienceElementSimpleSerializer, ElementLocationSerializer

from apps.highlights.models import (
    Highlights, HighlightsGlimpse, HighlightsElement
)

User = get_user_model()


class HighlightEngagementSerializer(serializers.Serializer):
    applauds = serializers.BooleanField()
    bookmarked = serializers.BooleanField()


class HighlightCounterSerializer(serializers.Serializer):
    applauds = serializers.IntegerField()
    shares = serializers.IntegerField()
    influences = serializers.IntegerField()


class HighlightEngagementMixin(metaclass=serializers.SerializerMetaclass):
    engagement = serializers.SerializerMethodField(read_only=True)

    @swagger_serializer_method(serializer_or_field=HighlightEngagementSerializer)
    def get_engagement(self, obj) -> dict:
        data = {
            "applauds": obj.highlights_applauds.filter(user=self.context['request'].user).exists(),
            "bookmarked": obj.highlight_bookmarked.filter(user=self.context['request'].user).exists(),
        }
        return HighlightEngagementSerializer(data).data
    
class HighlightLikesMixin(metaclass=serializers.SerializerMetaclass):
    applaud_users = serializers.SerializerMethodField(read_only=True)

    @swagger_serializer_method(serializer_or_field=SimpleUserSerializer)
    def get_applaud_users(self, obj) -> dict:
        data = obj.highlights_applauds.all()[:6]
        applaud_users = []
        for user in data:
            applaud_users.append(SimpleUserSerializer(user.user).data)
        return applaud_users


class HighlightCounterMixin(metaclass=serializers.SerializerMetaclass):
    counters = serializers.SerializerMethodField(read_only=True)

    @swagger_serializer_method(serializer_or_field=HighlightCounterSerializer)
    def get_counters(self, obj) -> dict:
        print(obj)
        data = {
            "applauds": obj.highlights_applauds.count(),
            "shares": obj.shares,
            "influences": obj.influences,
        }
        return HighlightCounterSerializer(data).data

class HighlightElementSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    experience = ExperienceSimpleSerializer(read_only=True)
    element = ExperienceElementSimpleSerializer(read_only=True)
    class Meta:
        model = HighlightsElement
        fields = ("id", "experience", "element", "content", "metadata" , "data_type")

class HighlightGlimpseSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    glimpse = PostSimpleSerializer(read_only=True)
    class Meta:
        model = HighlightsGlimpse
        fields = ("id", "glimpse", "order", "layout_template")     
        
class HighlightsSerializer(HighlightEngagementMixin, HighlightCounterMixin, HighlightLikesMixin, serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)
    owner = SimpleUserSerializer()
    related_highlight_id = serializers.CharField(source="related_highlight.id", read_only=True, allow_null=True)
    highlight_elements = HighlightElementSerializer(many=True)
    glimpses = HighlightGlimpseSerializer(many=True)
            

    class Meta:
        model = Highlights
        fields = (
            "id",
            "owner",
            "created_at",
            "counters",
            "applaud_users",
            "title",
            "text",
            "highlight_elements",
            "engagement",
            "is_disabled",
            "glimpses",
            "related_highlight_id",
            "layout_type"
        )


# Creation serializer
class HighlightGlimpseCreateSerializer(serializers.ModelSerializer):
    id = serializers.CharField()
    layout_template = serializers.JSONField()
    order = serializers.IntegerField()
    
    class Meta:
        model = HighlightsGlimpse
        fields = (
            "id",
            "layout_template",
            "order"
        )
        
    def validate(self, attrs):
        glimpse_id = attrs["id"]
        if not Post.objects.filter(id=glimpse_id).exists():
            raise serializers.ValidationError("Glimpse doesn't exist")
        return super().validate(attrs)
    
    def save(self, highlight_id):
        glimpse_id = self.validated_data.pop('id')
        create_data = {
            "glimpse_id": glimpse_id,
            "layout_template": self.validated_data.get("layout_template", {}),
            "order": self.validated_data.get("order", 0),
            "highlight_id": highlight_id
        }
        return super().save(**create_data)
    
class HighlightElementCreateSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    experience_id = serializers.CharField(allow_null=False, required=True)
    element_id = serializers.CharField(allow_null=True, required=False)
    content = serializers.CharField()
    metadata = serializers.JSONField(required=False)
    data_type = serializers.CharField()
    
    class Meta:
        model = HighlightsElement
        fields = ("id", "experience_id", "element_id", "data_type", "content", "metadata")

    def validate(self, attrs):
        experience_id = attrs.get('experience_id', None)
        if experience_id is None:
            raise serializers.ValidationError({"experience_id": "This field is required."})
        if not Experience.objects.filter(id=experience_id).exists():
            raise serializers.ValidationError({"experience_id": "Experience doesn't exist."})
        element_id = attrs.get('element_id', None)
        if element_id and not ExperienceElement.objects.filter(id=element_id).exists():
            raise serializers.ValidationError({"element_id": "Element doesn't exist."})
        
        return attrs
        

    def save(self, highlight_id):
        validated_data = self.validated_data
        if highlight_id: 
            validated_data['highlight_id'] = highlight_id
        else:
            raise serializers.ValidationError("Highlight doesn't exist.")
        return super().create(validated_data)
class HighlightCreationSerializer(serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)
    owner = serializers.HiddenField(default=serializers.CurrentUserDefault())
    related_highlight_id = serializers.PrimaryKeyRelatedField(queryset=Highlights.objects.get_enabled_highlights(), allow_null=True, required=False)
    glimpses = serializers.ListField(
        child=HighlightGlimpseCreateSerializer(required=True),
        required=True,
        allow_empty=False
    )
    elements = serializers.ListField(
        child=HighlightElementCreateSerializer(required=False),
        required=False,
        allow_empty=True
    )
    class Meta:
        model = Highlights
        fields = (
            "id",
            "owner",
            "text",
            "title",
            "is_disabled",
            "view_count",
            "related_highlight_id",
            # Additional params. Need to pop below params
            "glimpses",
            "elements",
            "layout_type"
        )
        extra_kwargs = {
            "created_at": {"read_only": True},
        }

    def validate(self, attrs):
        glimpses = attrs['glimpses']
        if not glimpses:
            raise serializers.ValidationError("Glimpses doesn't exist")
        return super().validate(attrs)

    def save(self, **kwargs):
        validated_data = self.validated_data
        related_highlight = validated_data.pop("related_highlight_id", None)
        if related_highlight:
            validated_data["related_highlight"] = related_highlight
        # Pop glimpses
        glimpses = validated_data.pop("glimpses", None)
        # Pop elements
        elements = validated_data.pop("elements", None)

        highlight = Highlights.objects.create(**validated_data)
        if glimpses:
            for glimpse_data in glimpses:
                highlight_glimpse_serializer = HighlightGlimpseCreateSerializer(data=glimpse_data)
                highlight_glimpse_serializer.is_valid()
                highlight_glimpse_serializer.save(highlight_id=highlight.id)
        if elements:
            for element_data in elements:
                highlight_element_serializer = HighlightElementCreateSerializer(data=element_data)
                highlight_element_serializer.is_valid()
                highlight_element_serializer.save(highlight_id=highlight.id)
        return highlight
    
class UserHighlightEngagementSerializer(HighlightCounterMixin, HighlightEngagementMixin, serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)

    class Meta:
        model = Highlights
        fields = ("id", "counters", "engagement")