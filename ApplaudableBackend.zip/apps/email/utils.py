"""
Email utils.
"""

from typing import Type

from django.conf import settings
from django.core.files import File
from apps.core.email import send_email


def send(email_definition: Type, context: dict, recipients: list, attachments: File = None, **options) -> None:
    """
    Send email with given options.

    :param email_definition: EmailDefinition based function
    :param context: dictionary with email context
    :param recipients: list of recipient email addresses
    :param options: other options for email sending

    :return: None
    """
    email = email_definition(context=context)

    # do not send emails during testing
    if settings.TESTING:
        return

    if email.allow_send(recipients):
        send_email(
            **options,
            subject=email.get_subject(),
            text_content=email.get_text_content(),
            html_content=email.get_html_content(),
            recipients=recipients,
            attachments=attachments
        )
