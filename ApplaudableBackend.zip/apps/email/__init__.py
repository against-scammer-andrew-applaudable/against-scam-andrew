from apps.email.decorators import register
from apps.email.options import AlreadyRegistered, EmailDefinition, definitions
from apps.email.utils import send
