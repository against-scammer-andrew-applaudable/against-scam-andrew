import re
from io import BytesIO

import cloudinary
import requests
from django.conf import settings
from hashid_field import BigHashidAutoField, HashidAutoField
from PIL import Image

from apps.media.constants import MediaType
from apps.media.utils import cloudinary_resource_to_dict
from apps.posts.constants import Segment
from services.google.place import GooglePlaceClient


def get_possible_meta_keys(segment, category, tags) -> list:
    keys = set()
    if segment == Segment.SOMEONE:
        pass
    elif segment == Segment.SOMETHING:
        pass
    elif segment == Segment.ACTIVITIES:
        pass
    elif segment == Segment.SOMEWHERE:
        keys.add("address")

    if category and category.source_tags:
        keys.update(category.source_tags)

    for tag in tags:
        keys.update(tag.source_tags)
    return keys


def get_text_from_nupp_metadata(nupp) -> str:
    value = nupp.metadata.get("detail_text", "")
    for key in get_possible_meta_keys(nupp.segment, nupp.category, nupp.tags.all()):
        value = nupp.metadata.get(key, "")
        if value:
            break
    return f"{value}"


def build_nupp_descriptive_texts(nupp_object, process_texts=False):
    from apps.nupp.models import Nupp

    main_text = ""
    secondary_text = ""
    if isinstance(nupp_object, Nupp):
        main_text = nupp_object.name
        if process_texts:
            secondary_text = get_text_from_nupp_metadata(nupp_object)
        else:
            secondary_text = nupp_object.metadata.get('detail_text', nupp_object.detail_text)
    elif isinstance(nupp_object, dict):
        main_text = nupp_object.get("main_text")
        secondary_text = nupp_object.get("secondary_text", "")

    # build texts
    texts = []
    texts.append(main_text)
    if secondary_text and main_text.lower() != secondary_text.lower():
        texts.append(secondary_text)

    return ", ".join(texts), main_text, secondary_text


def build_query_pattern(query: str) -> str:
    if query:
        return re.compile("|".join([re.escape(w) for w in query.split()]), re.IGNORECASE)
    return ""


def structured_formatting_from_string(main_text: str, secondary_text: str, query_pattern: str) -> dict:
    main_text_matched_substrings = []
    if query_pattern:
        for str_search in re.finditer(query_pattern, main_text):
            main_text_matched_substrings.append({"length": str_search.end(), "offset": str_search.start()})
    return {
        "main_text": main_text,
        "main_text_matched_substrings": main_text_matched_substrings,
        "secondary_text": secondary_text,
    }


def handle_hashid(value, big_hash=False):
    HashField = HashidAutoField() if not big_hash else BigHashidAutoField()
    return HashField.encode_id(value) if isinstance(value, int) else value


def handle_hashid_ids_list(items, big_hash=False):
    """
    Exclude None values, and convert ints to hashids
    """
    HashField = HashidAutoField() if not big_hash else BigHashidAutoField()
    return [HashField.encode_id(item) if isinstance(item, int) else item for item in items if item is not None]


def compose_nupp_search_terms(nupp):
    or_terms = set()
    and_terms = set()

    if nupp.category:
        and_terms.add(nupp.category.label)
    tags = [tag.label for tag in nupp.tags.all()]
    or_terms.update(tags)

    # add detail_text, to try and funnel the results
    if nupp.detail_text:
        and_terms.add(nupp.detail_text)

    return ','.join(or_terms), ','.join(and_terms)


def get_location_details(location_point):
    import reverse_geocoder as rg

    results = rg.search((location_point.y, location_point.x), mode=1)
    if results:
        return results[0]
    return None


def get_country_code_from_nupp(nupp):
    country_code = None
    if nupp.location:
        location_details = get_location_details(nupp.location)
        if location_details:
            country_code = location_details.get('cc').lower()

    return country_code


def download_image_url(image_url) -> Image:
    try:
        resp = requests.get(image_url)
    except ConnectionError:
        return None

    # try to identify an image file
    try:
        img = Image.open(BytesIO(resp.content))
    except Exception:
        return None

    return img


def download_photo_reference(reference) -> Image:
    return GooglePlaceClient().photo(reference['photo_reference'], reference['width'])


def create_nupp_media(nupp, img, min_size=280):
    from apps.nupp.models import NuppMedia

    # verify image size
    if img.size[0] < min_size or img.size[1] < min_size:
        return None

    basewidth = getattr(settings, 'METADATA_IMAGE_BASE_WIDTH', 1200)

    # resize images larger than
    if img.size[0] > basewidth:
        wpercent = basewidth / float(img.size[0])
        hsize = int((float(img.size[1]) * float(wpercent)))
        img = img.resize((basewidth, hsize), Image.ANTIALIAS)

    # save Image
    tmp_file = BytesIO()

    # remove image alpha channels
    if img.mode != 'RGB':
        new_image = Image.new("RGB", img.size, (255, 255, 255, 255))
        try:
            new_image.paste(img, mask=img)
        except ValueError:
            new_image.paste(img)
    else:
        new_image = img

    new_image.convert("RGB")

    # save new tmp file
    new_image.save(
        tmp_file,
        "JPEG",
        quality=getattr(settings, 'METADATA_IMAGE_QUALITY', 90),
        optimize=True,
        progressive=True,
    )

    # upload to cloudinary
    image_source = cloudinary.uploader.upload_resource(tmp_file.getvalue(), **{"folder": settings.CLOUDINARY_DEFAULT_FOLDER, "tags": ['nupp']})

    # save media object
    return NuppMedia.objects.create(nupp=nupp, image_source=image_source, type=MediaType.IMAGE)


def get_prediction_media(predictions):
    from apps.nupp.models import NuppMedia
    from apps.users.models import Profile

    nupp_ids = set()
    user_ids = set()
    for prediction in predictions:
        if 'is_user' in prediction and prediction['is_user']:
            user_ids.add(prediction['id'])
        else:
            nupp_ids.add(prediction['id'])

    user_profile_qs = Profile.objects.filter(user_id__in=user_ids, avatar__isnull=False).values_list(
        'user_id', 'avatar__image_source', 'avatar__metadata'
    )

    nupp_media_qs = (
        NuppMedia.objects.filter(nupp_id__in=nupp_ids, type=MediaType.IMAGE, image_source__isnull=False)
        .values_list('nupp_id', 'image_source', 'metadata')
        .order_by('nupp_id')
    )

    media_by_user_id = {p[0]: cloudinary_resource_to_dict(p[1], metadata=p[2]) for p in user_profile_qs}
    media_by_nupp_id = {m[0]: cloudinary_resource_to_dict(m[1], metadata=m[2]) for m in nupp_media_qs}
    return media_by_nupp_id, media_by_user_id
