from django.contrib.gis.geos import Point

from apps.nupp.utils import get_location_details
from apps.nupp.metadata.utils import sanitize_value, get_metadata_from_url
from apps.posts.constants import Segment
from services.google.place import GooglePlaceClient


def handle_google_place_result(data):
    valid_fields = GooglePlaceClient.BASE_FIELDS
    new_data = {k: sanitize_value(v) for k, v in data.items() if k in valid_fields}
    return new_data


def handle_somewhere_data(nupp):
    from apps.posts.models import Category, Tag
    from apps.nupp.tasks import task_search_nupp_metadata

    """
    Tries to handle nupp data, and convert it to useful metadata and field data
    """
    if nupp.private_metadata:
        # extract location
        geometry = nupp.get_value_from_private_metadata('geometry', {})
        location = geometry.get('location')
        if location:
            nupp.location = Point(location.get('lng'), location.get('lat'))
            nupp.store_value_in_metadata({'location': get_location_details(nupp.location)})

        # extract address
        formatted_address = nupp.get_value_from_private_metadata('formatted_address', '')
        if formatted_address:
            nupp.store_value_in_metadata({'address': formatted_address})

        # extract category
        matched_category = Category.objects.filter(segment=Segment.SOMEWHERE, api_tags__overlap=nupp.private_metadata.get('types', [])).first()
        if matched_category:
            nupp.category = matched_category

        # extract tags
        matched_tags = Tag.objects.filter(category__segment=Segment.SOMEWHERE, api_tags__overlap=nupp.private_metadata.get('types', []))
        nupp.tags.set(matched_tags)

        # extract metadata from website
        url = nupp.get_value_from_private_metadata('website', None)
        if url:
            metadata = get_metadata_from_url(url)
            nupp.store_value_in_private_metadata(metadata)

        # fallback to places image
        description = nupp.get_value_from_private_metadata('description', None)
        image = nupp.get_value_from_private_metadata('image', None)
        if not all([image, description, url]):
            task_search_nupp_metadata.apply_async(args=(str(nupp.id),), countdown=8)
