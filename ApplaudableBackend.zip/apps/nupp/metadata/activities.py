def handle_activities_data(nupp):
    pass
