import logging

from apps.nupp.metadata.parser import BotHeaders, MetadataParser, NotParsable


def sanitize_value(value):
    # remove all html_attributions
    if isinstance(value, (list, tuple)):
        value = [sanitize_value(v) for v in value]
    elif isinstance(value, dict):
        value.pop('html_attributions', None)
    return value


def get_metadata_from_url(url):
    # TODO: make this variable, by the url domain.
    metadata_parser_options = {'search_head_only': False, 'ssl_verify': False, 'url_headers': BotHeaders()}

    try:
        page = MetadataParser(url=url, **metadata_parser_options)
    except NotParsable as e:
        logging.exception(e)
    except ConnectionError:
        pass

    try:
        title = page.get_metadatas('title')[0]
    except Exception:
        title = None

    try:
        description = page.get_metadatas('description')[0]
    except Exception:
        description = None

    return {'title': title, 'description': description, 'image': page.get_metadata_link('image')}
