from apps.nupp.constants import SOURCE_SEARCH_TAG


def handle_someone_data(nupp):
    from apps.nupp.tasks import task_search_nupp_metadata

    if SOURCE_SEARCH_TAG not in nupp.category.source_tags:
        return

    if not nupp.private_metadata:
        task_search_nupp_metadata(str(nupp.id))
