def handle_something_data(nupp):
    pass
