from django.contrib.auth import get_user_model
from django.contrib.gis.db import models
from django.contrib.postgres.indexes import GinIndex

from apps.core.models import AbstractCreatedUpdatedDateMixin, AbstractMetadata, AbstractUniqueBigHashIDMixin
from apps.media.models import AbstractMedia
from apps.posts.constants import Segment
from apps.posts.models import Category, Tag

from .constants import SourceType

User = get_user_model()


class SearchTerm(AbstractCreatedUpdatedDateMixin):
    text = models.CharField(max_length=255, unique=True)
    segment = models.CharField(max_length=25, choices=Segment.choices(), db_index=True)
    hits = models.PositiveIntegerField(default=1)

    def __str__(self) -> str:
        return self.text


class Nupp(AbstractUniqueBigHashIDMixin, AbstractCreatedUpdatedDateMixin, AbstractMetadata):
    name = models.CharField(max_length=255)
    text = models.TextField("Short description", blank=True)
    detail_text = models.CharField(max_length=255, default="", blank=True)
    search_text = models.TextField(blank=True)
    segment = models.CharField(max_length=25, choices=Segment.choices(), db_index=True)
    category = models.ForeignKey(Category, blank=True, null=True, on_delete=models.SET_NULL)
    tags = models.ManyToManyField(Tag, related_name="nupps", blank=True)
    creator = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)
    source_ref = models.CharField(max_length=255, null=True, editable=False, db_index=True)
    source = models.CharField(max_length=255, null=True, editable=False, db_index=True, choices=SourceType.choices())
    is_validated = models.BooleanField(default=False)
    is_public = models.BooleanField(default=False)
    location = models.PointField(blank=True, null=True)

    class Meta:
        indexes = [
            *AbstractUniqueBigHashIDMixin.Meta.indexes,
            *AbstractMetadata.Meta.indexes,
            GinIndex(
                name="nupp_search_gin",
                # `opclasses` and `fields` should be the same length
                fields=["search_text"],
                opclasses=["gin_trgm_ops"],
            ),
        ]

    def __str__(self) -> str:
        return self.name

    def get_mention_label(self):
        return self.name

    @property
    def thumbnail_url(self):
        media = self.media.all()
        first_image = media[0] if media else None
        return first_image.admin_thumbnail_url if first_image else None

    @classmethod
    def mention_field_name(cls) -> str:
        return "nupp"


class NuppMedia(AbstractMedia):
    nupp = models.ForeignKey(Nupp, on_delete=models.CASCADE, related_name="media")

    class Meta:
        verbose_name = "Media"
        verbose_name_plural = "Media"
        indexes = [
            *AbstractMedia.Meta.indexes,
        ]
