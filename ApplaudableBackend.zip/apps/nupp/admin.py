from functools import partial

from django.contrib import admin, messages
from django.utils.safestring import mark_safe
from django.utils.translation import ngettext
from import_export.fields import Field
from import_export.widgets import ForeignKeyWidget, ManyToManyWidget

from apps.core.admin import FIELDSET_METADATA
from apps.core.import_export.admin import ImportExportAdminMixin
from apps.core.import_export.resources import ModelResource
from apps.core.import_export.widgets import LocationWidget
from apps.media.admin import MediaAdmin, MediaInline
from apps.posts.models import Category, Tag

from .models import Nupp, NuppMedia, SearchTerm
from .tasks import task_find_nupp_metadata, task_process_nupp_metadata, task_process_nupp_texts
from .utils import build_nupp_descriptive_texts


class NuppResource(ModelResource):
    category = Field(column_name='category', attribute='category', widget=ForeignKeyWidget(Category, 'label'))
    tags = Field(column_name='tags', attribute='tags', widget=ManyToManyWidget(Tag, field='label'))
    location = Field(column_name='location', attribute='location', widget=LocationWidget())

    class Meta:
        model = Nupp
        skip_unchanged = True
        report_skipped = False
        fields = ('id', 'name', 'text', 'segment', 'category', 'tags', 'source', 'source_ref', 'location', 'is_public', 'is_validated', 'creator')
        export_order = (
            'id',
            'name',
            'text',
            'segment',
            'category',
            'tags',
            'source',
            'source_ref',
            'location',
            'is_public',
            'is_validated',
            'creator',
        )


@admin.register(SearchTerm)
class SearchTermAdmin(admin.ModelAdmin):
    list_filter = ('segment',)
    list_display = ('text', 'segment', 'hits', 'updated_at', 'created_at')

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


@admin.action(description='Find Metadata for selected Nupp(s)')
def action_find_nupp_metadata(modeladmin, request, queryset):
    processing = 0
    for obj in queryset:
        task_find_nupp_metadata.delay(str(obj.id))
        processing += 1

    modeladmin.message_user(
        request,
        ngettext(
            'finding metadata for %d nupp.',
            'looking for metadata for %d nupp(s).',
            processing,
        )
        % processing,
        messages.SUCCESS,
    )


@admin.action(description='Process Metadata for selected Nupp(s)')
def action_process_nupp_metadata(modeladmin, request, queryset):
    processing = 0
    for obj in queryset:
        task_process_nupp_metadata.delay(str(obj.id))
        processing += 1

    modeladmin.message_user(
        request,
        ngettext(
            '%d nupp is processing metadata.',
            '%d nupp(s) processing metadata.',
            processing,
        )
        % processing,
        messages.SUCCESS,
    )


@admin.action(description='Process Texts for selected Nupp(s)')
def action_process_nupp_texts(modeladmin, request, queryset):
    processing = 0
    for obj in queryset:
        task_process_nupp_texts.delay(str(obj.id))
        processing += 1

    modeladmin.message_user(
        request,
        ngettext(
            '%d nupp is processing texts.',
            '%d nupp(s) processing texts.',
            processing,
        )
        % processing,
        messages.SUCCESS,
    )


class NuppMediaAdminInline(MediaInline):
    model = NuppMedia


@admin.register(Nupp)
class NuppAdmin(ImportExportAdminMixin, admin.ModelAdmin):
    list_filter = (
        'is_public',
        'is_validated',
        'segment',
        'category',
        'tags',
    )
    search_fields = (
        'id',
        'search_text',
    )
    list_display = (
        'id',
        'admin_thumbnail',
        'description',
        'segment',
        'is_public',
        'is_validated',
        'created_at',
    )
    autocomplete_fields = ('creator',)
    filter_horizontal = ('tags',)
    actions = [
        action_find_nupp_metadata,
        action_process_nupp_texts,
        action_process_nupp_metadata,
    ]

    add_fieldsets = (
        (
            None,
            {
                "fields": (
                    'name',
                    'text',
                    'segment',
                ),
            },
        ),
    )
    fieldsets = (
        (
            None,
            {
                "fields": (
                    'name',
                    'text',
                    'segment',
                    'category',
                    'tags',
                    'creator',
                    (
                        'source',
                        'source_ref',
                    ),
                    'location',
                    'is_validated',
                    'is_public',
                ),
            },
        ),
        FIELDSET_METADATA,
    )
    inlines = [
        NuppMediaAdminInline,
    ]
    resource_class = NuppResource

    def admin_thumbnail(self, obj):
        if obj and obj.thumbnail_url:
            return mark_safe(f'<img src="{obj.thumbnail_url}" alt="{obj.id}" />')
        return ''

    admin_thumbnail.short_description = "Thumbnail"

    def description(self, obj):
        description, main_text, secondary_text = build_nupp_descriptive_texts(obj)
        return description

    def get_form(self, request, obj=None, **kwargs):
        kwargs['formfield_callback'] = partial(self.formfield_for_dbfield, request=request, obj=obj)
        return super().get_form(request, obj, **kwargs)

    def formfield_for_dbfield(self, db_field, **kwargs):
        obj = kwargs.pop('obj', None)
        if obj and db_field.name == "category":
            kwargs["queryset"] = Category.objects.filter(segment=obj.segment)
        return super().formfield_for_dbfield(db_field, **kwargs)

    def get_fieldsets(self, request, obj=None):
        if not obj:
            return self.add_fieldsets
        return self.fieldsets

    def get_readonly_fields(self, request, obj=None):
        if obj:
            return (
                'segment',
                'source',
                'source_ref',
                'location',
                'detail_text',
                'private_metadata',
            )
        return self.readonly_fields

    def save_model(self, request, obj, form, change):
        obj.save()
        if change and not obj.private_metadata:
            task_find_nupp_metadata(str(obj.id))
