from django.urls import path
from rest_framework.routers import DefaultRouter

from .views import AutocompleteAPIView, NuppAPIViewSet

router = DefaultRouter()
router.register(r"", NuppAPIViewSet, "nupps")

app_name = "nupp"

urlpatterns = [
    path("autocomplete/", AutocompleteAPIView.as_view(), name="autocomplete"),
] + router.urls
