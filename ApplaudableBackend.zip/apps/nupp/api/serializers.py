from drf_yasg.utils import swagger_serializer_method
from hashid_field.rest import HashidSerializerCharField
from rest_framework import serializers

from apps.media.serializers import MediaSerializer, BJSONMediaSerializer
from apps.posts.models import Category, Tag

from ..models import Nupp, NuppMedia


class SimpleTagSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)

    class Meta:
        model = Tag
        fields = ("id", "label")


class SimpleCategorySerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)

    class Meta:
        model = Category
        fields = ("id", "label", "segment", "icon_slug")


class NuppMediaSerializer(BJSONMediaSerializer):
    id = serializers.CharField(read_only=True)
    text = serializers.CharField(read_only=True)


class NuppSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    media = serializers.SerializerMethodField()
    category = SimpleCategorySerializer()
    tags = SimpleTagSerializer(many=True)

    class Meta:
        model = Nupp
        fields = ("id", "name", "text", "media", "segment", "category", "tags", "is_public", "is_validated", "metadata")

    @swagger_serializer_method(serializer_or_field=NuppMediaSerializer)
    def get_media(self, obj):
        source = obj.image_source
        if source:
            media = NuppMediaSerializer(source).data
            return [media]
        else:
            return list()


class AutocompleteSerializer(serializers.Serializer):
    description = serializers.CharField()
    nupp_id = HashidSerializerCharField()
    media = MediaSerializer()
    source_ref = serializers.CharField()
    source = serializers.CharField()
    category_id = HashidSerializerCharField()
    tags = serializers.ListField(child=HashidSerializerCharField())
    structured_formatting = serializers.JSONField()
    metadata = serializers.JSONField()
