import coreapi
from django.contrib.auth import get_user_model
from django.contrib.postgres.aggregates import ArrayAgg
from django.contrib.postgres.search import TrigramWordSimilarity
from django.db.models import F, Q, OuterRef, Value
from django.db.models.functions import JSONObject, Coalesce
from rest_framework import serializers, viewsets
from rest_framework.filters import BaseFilterBackend
from rest_framework.generics import GenericAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from apps.core.models import ToJSONB
from apps.posts.constants import Segment
from apps.posts.models import Category, Post, Media
from services.google.place import GooglePlaceClient

from ..constants import SourceType
from ..models import Nupp, NuppMedia
from ..tasks import task_process_search_term
from ..utils import (
    build_nupp_descriptive_texts,
    build_query_pattern,
    get_prediction_media,
    handle_hashid,
    handle_hashid_ids_list,
    structured_formatting_from_string,
)
from .serializers import AutocompleteSerializer, NuppSerializer

User = get_user_model()


class AutocompleteFilterBackend(BaseFilterBackend):
    def get_schema_fields(self, view):
        return [
            coreapi.Field(name='q', location='query', required=True, type='string'),
            coreapi.Field(name='location', location='query', required=True, type='string'),
            coreapi.Field(name='segment', location='query', required=True, type='string'),
            coreapi.Field(name='category', location='query', required=False, type='string'),
        ]


class NuppAPIViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = (IsAuthenticated,)
    serializer_class = NuppSerializer

    def get_queryset(self):
        nupp_media_source = NuppMedia.objects.filter(type="image", nupp=OuterRef('pk'))[:1]
        post_media_source = Media.objects.filter(type="image", post__nupp=OuterRef('pk'))[:1]

        nupps = (
            Nupp.objects.filter(is_public=True)
            .prefetch_related('media', 'nupp_posts')
            .annotate(image_source=Coalesce(ToJSONB(nupp_media_source), ToJSONB(post_media_source)))
        )

        return nupps


class AutocompleteAPIView(GenericAPIView):
    filter_backends = (AutocompleteFilterBackend,)
    permission_classes = (IsAuthenticated,)
    serializer_class = AutocompleteSerializer

    def get_queryset(self):
        # access all public nupp and user created nupp.
        return Nupp.objects.filter(Q(creator=self.request.user) | Q(is_public=True))

    def user_prediction_qs(self, query: str, requesting_user):
        prediction_qs = (
            User.active_objects.filter(Q(name__icontains=query) | Q(name__trigram_similar=query) | Q(username__trigram_similar=query))
            .exclude(Q(pk=requesting_user.pk) | Q(pk__in=(self.request.user.blocked_users.values_list("blocked_user", flat=True))))
            .annotate(
                main_text=F('username'),
                secondary_text=F('name'),
                is_user=Value(True),
                cat_id=Value(0),
                tag_list=Value('{}'),
                data=JSONObject(username=F('username'), name=F('name')),
                similarity=TrigramWordSimilarity(query, 'username'),
            )
            .values('id', 'main_text', 'secondary_text', 'is_user', 'cat_id', 'tag_list', 'data', 'similarity')
        )
        return prediction_qs

    def nupp_prediction_qs(self, query: str, segment: str, category: Category = None):
        filter_options = {'segment': segment}
        if category:
            filter_options['category'] = category
        prediction_qs = (
            self.get_queryset()
            .filter(**filter_options)
            .filter(Q(search_text__icontains=query) | Q(search_text__trigram_similar=query))
            .annotate(
                main_text=F('name'),
                secondary_text=F('detail_text'),
                is_user=Value(False),
                cat_id=F('category_id'),
                tag_list=ArrayAgg('tags'),
                data=F('metadata'),
                similarity=TrigramWordSimilarity(query, 'search_text'),
            )
            .values('id', 'main_text', 'secondary_text', 'is_user', 'cat_id', 'tag_list', 'data', 'similarity')
        )
        return prediction_qs

    def get(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        response_data = []

        query = request.GET.get('q')
        location = request.GET.get('location')
        segment = request.GET.get('segment')
        category = request.GET.get('category')
        limit_results = 30

        if Segment.older_values().get(segment):
            segment = Segment.older_values()[segment]

        if not query:
            raise serializers.ValidationError({"query": "provide a valid query."})

        query_pattern = build_query_pattern(query)

        if category:
            try:
                category = Category.objects.get(pk=category)
                segment = category.segment
            except Category.DoesNotExist:
                raise serializers.ValidationError({"category": "category is invalid."})
        elif segment not in [s[0] for s in Segment.choices()]:
            raise serializers.ValidationError({"segment": "segment is invalid."})

        if segment == Segment.SOMEONE:
            user_predictions = self.user_prediction_qs(query, request.user)
            nupp_predictions = self.nupp_prediction_qs(query, segment, category)
            predictions = user_predictions.union(nupp_predictions).order_by('-similarity')[:limit_results]

            # prefetch media items
            media_by_nupp_id, media_by_user_id = get_prediction_media(predictions)

            for prediction in predictions:
                description, main_text, secondary_text = build_nupp_descriptive_texts(prediction)
                media = media_by_user_id.get(prediction['id']) if prediction['is_user'] else media_by_nupp_id.get(prediction['id'])
                data = {
                    'description': description,
                    'source_ref': prediction['id'] if prediction['is_user'] else None,
                    'source': SourceType.USER if prediction['is_user'] else None,
                    'structured_formatting': structured_formatting_from_string(main_text, secondary_text, query_pattern),
                    'nupp_id': prediction['id'] if not prediction['is_user'] else None,
                    'media': media if media and media.get('type') else None,
                    'category_id': handle_hashid(prediction['cat_id']) if prediction['cat_id'] else None,
                    'tags': handle_hashid_ids_list(prediction['tag_list']),
                    'metadata': prediction['data'],
                }
                response_data.append(data)

        elif segment == Segment.SOMETHING:
            predictions = self.nupp_prediction_qs(query, segment, category).filter(similarity__gt=0.3).order_by('-similarity')[:limit_results]
            # prefetch media items
            media_by_nupp_id, media_by_user_id = get_prediction_media(predictions)
            for prediction in predictions:
                description, main_text, secondary_text = build_nupp_descriptive_texts(prediction)

                data = {
                    'description': description,
                    'source_ref': None,
                    'source': None,
                    'structured_formatting': structured_formatting_from_string(main_text, secondary_text, query_pattern),
                    'nupp_id': prediction['id'],
                    'media': media_by_nupp_id.get(prediction['id']),
                    'category_id': handle_hashid(prediction['cat_id']),
                    'tags': handle_hashid_ids_list(prediction['tag_list']),
                    'metadata': prediction['data'],
                }
                response_data.append(data)

        elif segment == Segment.ACTIVITIES:
            predictions = self.nupp_prediction_qs(query, segment, category).filter(similarity__gt=0.3).order_by('-similarity')[:limit_results]
            # prefetch media items
            media_by_nupp_id, media_by_user_id = get_prediction_media(predictions)
            for prediction in predictions:
                description, main_text, secondary_text = build_nupp_descriptive_texts(prediction)

                data = {
                    'description': description,
                    'source_ref': None,
                    'source': None,
                    'structured_formatting': structured_formatting_from_string(main_text, secondary_text, query_pattern),
                    'nupp_id': prediction['id'],
                    'media': media_by_nupp_id.get(prediction['id']),
                    'category_id': handle_hashid(prediction['cat_id']),
                    'tags': handle_hashid_ids_list(prediction['tag_list']),
                    'metadata': prediction['data'],
                }
                response_data.append(data)

        elif segment == Segment.SOMEWHERE:
            result = GooglePlaceClient().autocomplete(query, location)
            place_ids = [x['place_id'] for x in result['predictions']]
            nupp_qs = queryset.filter(source_ref__in=place_ids, source=SourceType.PLACE, segment=Segment.SOMEWHERE).annotate(
                tag_list=ArrayAgg('tags')
            )
            nupp_by_place_id = {n.source_ref: n for n in nupp_qs}
            # prefetch media items
            media_by_nupp_id, media_by_user_id = get_prediction_media([{'id': n.id} for n in nupp_qs])
            for prediction in result['predictions']:
                data = {
                    'description': prediction['description'],
                    'source_ref': prediction['place_id'],
                    'source': SourceType.PLACE,
                    'structured_formatting': prediction['structured_formatting'],
                    'nupp_id': None,
                    'media': None,
                    'category_id': None,
                    'tags': [],
                    'metadata': {},
                }
                nupp = nupp_by_place_id.get(prediction['place_id'])
                if nupp:
                    description, main_text, secondary_text = build_nupp_descriptive_texts(nupp)
                    data.update(
                        {
                            'description': description,
                            'nupp_id': nupp.id,
                            'media': media_by_nupp_id.get(nupp.id),
                            'structured_formatting': structured_formatting_from_string(main_text, secondary_text, query_pattern),
                            'category_id': handle_hashid(nupp.category_id),
                            'tags': handle_hashid_ids_list(nupp.tag_list),
                            'metadata': nupp.metadata,
                        }
                    )

                response_data.append(data)

        # process search term
        task_process_search_term.delay(query, segment)

        page = self.paginate_queryset(response_data)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(response_data, many=True)
        return Response(serializer.data)
