from celery import shared_task

from apps.posts.constants import Segment
from services.google.place import GooglePlaceClient
from services.google.search import GoogleSearchClient

from .constants import SourceType
from .metadata.activities import handle_activities_data
from .metadata.someone import handle_someone_data
from .metadata.something import handle_something_data
from .metadata.somewhere import handle_google_place_result, handle_somewhere_data
from .metadata.utils import get_metadata_from_url
from .utils import (
    build_nupp_descriptive_texts,
    compose_nupp_search_terms,
    create_nupp_media,
    download_image_url,
    download_photo_reference,
    get_country_code_from_nupp,
)


@shared_task
def task_process_search_term(query: str, segment: str):
    from apps.nupp.models import SearchTerm

    # to lower
    query = query.lower()

    # discard small query terms
    if not all([len(x) > 2 for x in query.split()]):
        return

    search_term, created = SearchTerm.objects.get_or_create(text__iexact=query, segment=segment, defaults={"text": query, "segment": segment})
    if not created:
        search_term.hits += 1
        search_term.save()


@shared_task
def task_process_nupp_texts(nupp_id: str):
    from apps.nupp.models import Nupp

    """
    Grab nupps metadata, and process search_text and detail_text
    """

    nupp = Nupp.objects.get(id=nupp_id)

    description, _main_text, secondary_text = build_nupp_descriptive_texts(nupp, process_texts=True)

    nupp.search_text = description
    nupp.detail_text = secondary_text

    nupp.save(update_fields=['search_text', 'detail_text'])


@shared_task
def task_find_nupp_metadata(nupp_id: str):
    from apps.nupp.models import Nupp

    """
    Find nupp metadata using specific API's.
    """

    nupp = Nupp.objects.get(id=nupp_id)

    if nupp.segment == Segment.SOMEONE:
        handle_someone_data(nupp)
    elif nupp.segment == Segment.SOMETHING:
        handle_something_data(nupp)
    elif nupp.segment in Segment.ACTIVITIES:
        handle_activities_data(nupp)
    elif nupp.segment == Segment.SOMEWHERE:
        if nupp.source == SourceType.PLACE and nupp.source_ref:
            result = GooglePlaceClient().details(nupp.source_ref)
            nupp.store_value_in_private_metadata(handle_google_place_result(result['result']))
            nupp.is_public = True
        else:
            result = GooglePlaceClient().text_search(nupp.name)
            nupp.store_value_in_private_metadata(handle_google_place_result(result['results'][0]) if result['results'] else {})

        handle_somewhere_data(nupp)

    # save nupp changes
    nupp.save()

    # handle nupp texts
    task_process_nupp_texts.delay(nupp_id)


@shared_task
def task_search_nupp_metadata(nupp_id: str):
    from apps.nupp.models import Nupp

    """
    Search nupp metadata using goolge custom search.
    """

    nupp = Nupp.objects.get(id=nupp_id)
    or_terms, and_terms = compose_nupp_search_terms(nupp)
    country_code = get_country_code_from_nupp(nupp)
    result = GoogleSearchClient().website(nupp.name, num=4, or_terms=or_terms, and_terms=and_terms, country_code=country_code)
    items = result.get('items', [])
    # TODO: for now we just select the first result, this might need more selective criteria
    # TODO: implement a domain exclusion
    item = items[0] if items else None
    if item:
        nupp.store_value_in_private_metadata(dict(link=item['link']))
        metatags = item.get('pagemap', {}).get('metatags', [])
        nupp.store_value_in_private_metadata(dict(metatags=metatags[0] if metatags else {}))
        cse_image = item.get('pagemap', {}).get('cse_image', [])
        nupp.store_value_in_private_metadata(dict(cse_image=cse_image[0].get('src') if cse_image else None))
        if item['link']:
            metadata = get_metadata_from_url(item['link'])
            nupp.store_value_in_private_metadata(dict(search=metadata))

    nupp.save()


@shared_task
def task_process_nupp_metadata(nupp_id: str):
    from apps.nupp.models import Nupp

    """
    Grab nupps metadata, and process images and descriptions
    """

    nupp = Nupp.objects.get(id=nupp_id)

    # TODO read private metadata and fetch media, and text description for this nupp.

    image = nupp.get_value_from_private_metadata('image', None)
    description = nupp.get_value_from_private_metadata('description', None)
    search = nupp.get_value_from_private_metadata('search', {})

    fallback_photo_reference = None
    if nupp.segment == Segment.SOMEWHERE:
        photos = nupp.get_value_from_private_metadata('photos', [])
        if photos:
            fallback_photo_reference = photos[0]

    if not image:
        image = search.get('image', None)

    if not image:
        image = nupp.get_value_from_private_metadata('cse_image', None)

    if not description:
        description = search.get('description', None)

    # image download
    nupp_media = None
    has_media = bool(nupp.media.all())
    if image and not has_media:
        img = download_image_url(image)
        if img:
            nupp_media = create_nupp_media(nupp, img)

    if not nupp_media and fallback_photo_reference and not has_media:
        img = download_photo_reference(fallback_photo_reference)
        if img:
            nupp_media = create_nupp_media(nupp, img)

    if description and not nupp.text:
        # TODO: add some sanitization and sentiment check.
        nupp.text = description

    nupp.save()
