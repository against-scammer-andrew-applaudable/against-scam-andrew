"""
Nupp's test factories.
"""

import random

import factory

from apps.nupp.models import Nupp
from apps.nupp.tests.base import faker
from apps.posts.constants import Segment


class NuppModelFactory(factory.django.DjangoModelFactory):
    """
    Nupp instance factory.
    """

    name = factory.LazyAttribute(lambda _: "".join(faker.random_letters(5)))
    segment = factory.LazyAttribute(lambda _: random.choice(Segment.choices())[0])

    class Meta:
        model = Nupp
