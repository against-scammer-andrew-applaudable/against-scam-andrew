import cloudinary
from rest_framework import serializers


class MediaField(serializers.Field):
    def to_representation(self, value):
        return {"type": value.resource_type, "public_id": value.public_id, "version": value.version}


class BJSONMediaField(serializers.Field):
    """
    Use this for BJSON Media instances (such as in Nupp and Post API views)
    """

    def to_representation(self, value):
        if value:
            return {"type": value['resource_type'], "public_id": value['public_id'], "version": value['version']}
        else:
            return {}


class CloudinaryField(serializers.ImageField):
    def to_representation(self, value):
        if not value:
            return None

        return value.url

    def to_internal_value(self, data):
        try:
            # `UploadedFile` objects should have name and size attributes.
            file_name = data.name
            file_size = data.size
        except AttributeError:
            if not isinstance(data, cloudinary.CloudinaryResource):
                self.fail('invalid')
        return data
