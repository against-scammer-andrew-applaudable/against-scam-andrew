"""
Core tests.
"""

from django.contrib.sites.models import Site
from django.test import TestCase

from apps.core.services import RedisContextManager
from apps.core.utils import domain_with_proto


class RedisServiceTestCase(TestCase):
    """
    Tests for Redis service.
    """

    def test_redis_connection(self) -> None:
        """
        Test Redis context manager operation.
        """

        with RedisContextManager() as redis_connection:
            redis_connection.set("foo", "bar")
            stored_value = redis_connection.get("foo")
        self.assertEqual("bar", stored_value)
        with RedisContextManager() as redis_connection:
            redis_connection.delete("foo")


class DomainWithProtoTestCase(TestCase):
    """
    Tests for domain_with_proto function.
    """

    def test_project_url_domain_with_proto(self) -> None:
        """
        Test domain_with_proto function using Project URL constant.
        """

        with self.settings(PROJECT_URL="https://applaudable.com/"):
            self.assertEqual("https://applaudable.com/test", domain_with_proto("test"))

    def test_https_domain_with_proto(self) -> None:
        """
        Test domain_with_proto function fallback to HTTPS/HTTP Site instance.
        """

        site = Site.objects.get_current()
        site.domain = "https://applaudable.com/"
        site.save()

        with self.settings(PROJECT_URL=None):
            self.assertEqual("https://applaudable.com/test", domain_with_proto("test"))

    def test_missing__domain_with_proto(self) -> None:
        """
        Test domain_with_proto function fallback to HTTP Site instance.
        """

        site = Site.objects.get_current()
        site.domain = "applaudable.com/"
        site.save()

        with self.settings(PROJECT_URL=None):
            self.assertEqual("https://applaudable.com/test", domain_with_proto("test"))
