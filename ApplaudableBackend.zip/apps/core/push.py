def get_devices_for_notification_qs(user_id_list):
    from fcm_django.models import FCMDevice

    # TODO: this can be used to validate if a user can receive a push notification
    # we will filter out the ids before passing to the device query
    devices_qs = FCMDevice.objects.filter(user_id__in=user_id_list)
    return devices_qs


def send_push(message, recipients=[]):
    devices = get_devices_for_notification_qs(recipients)
    response = devices.send_message(message)
    return bool(response.registration_ids_sent)
