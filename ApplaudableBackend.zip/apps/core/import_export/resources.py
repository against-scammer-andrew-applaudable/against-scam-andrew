from hashid_field import BigHashidAutoField, HashidAutoField
from import_export import resources
from import_export.widgets import Widget

from apps.core.import_export.widgets import BigHashidWidget, HashidWidget


class Diff(resources.Diff):
    def _export_resource_fields(self, resource, instance):
        exported_fields = []
        for f in resource.get_user_visible_fields():
            # ignore this fields because deepcopy breaks hashids
            if instance and isinstance(f.widget, (HashidWidget, BigHashidWidget)):
                result = "-"
            elif instance:
                result = resource.export_field(f, instance)
            else:
                result = ""
            exported_fields.append(result)
        return exported_fields


class ModelResource(resources.ModelResource):
    @classmethod
    def widget_from_django_field(cls, f, default=Widget):
        if isinstance(f, BigHashidAutoField):
            return BigHashidWidget
        elif isinstance(f, HashidAutoField):
            return HashidWidget
        return super().widget_from_django_field(f, default=default)

    @classmethod
    def get_diff_class(self):
        """
        Returns the class used to display the diff for an imported instance.
        """
        return Diff
