from django.contrib.gis.geos import Point
from hashid_field import BigHashidAutoField, HashidAutoField
from import_export.widgets import Widget


class LocationWidget(Widget):
    def clean(self, value, row=None, *args, **kwargs):
        if not value:
            return None
        try:
            lat, lng = value.split(',')
            return Point(float(lng), float(lat))
        except (ValueError, TypeError):
            pass
        return ValueError("Enter a valid Location")

    def render(self, value, obj=None):
        return f"{value.y},{value.x}" if value else ""


class HashidWidget(Widget):
    HASHID_FIELD = HashidAutoField

    def is_empty(self, value):
        if isinstance(value, str):
            value = value.strip()
        # 0 is not empty
        return value is None or value == ""

    def clean(self, value, row=None, *args, **kwargs):
        if self.is_empty(value):
            return None
        return self.HASHID_FIELD().to_python(value)

    def render(self, value, obj=None):
        return str(value)


class BigHashidWidget(HashidWidget):
    HASHID_FIELD = BigHashidAutoField
