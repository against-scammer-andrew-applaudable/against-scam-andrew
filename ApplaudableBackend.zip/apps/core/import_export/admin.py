from import_export.admin import ImportMixin, ExportActionMixin
from import_export.formats.base_formats import CSV, XLSX, ODS

AVAILABLE_FORMATS = [CSV, XLSX, ODS]


class ImportExportAdminMixin(ImportMixin, ExportActionMixin):
    formats = AVAILABLE_FORMATS
