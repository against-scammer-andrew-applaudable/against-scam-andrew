"""
Core decorators.
"""

from typing import Callable

from django.contrib.admin import ModelAdmin
from django.core.handlers.wsgi import WSGIRequest
from django.db.models import QuerySet
from django.template.response import TemplateResponse


def require_confirmation(template: str) -> Callable:
    """
    This decorator enforces a redirect to admin confirmation page.
    """

    def decorator(func: Callable) -> Callable:
        def wrapper(modeladmin: ModelAdmin, request: WSGIRequest, queryset: QuerySet):
            if request.POST.get("confirmation") is None:
                request.current_app = modeladmin.admin_site.name
                context = {"action": request.POST.get("action", ""), "queryset": queryset}
                return TemplateResponse(request, template, context)
            return func(modeladmin, request, queryset)

        wrapper.__name__ = func.__name__
        return wrapper

    return decorator
