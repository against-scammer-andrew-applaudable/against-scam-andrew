from services.twilio.client import TwilioClient


def send_sms(message, recipients=[]):
    client = TwilioClient()
    results = []
    for phone_number in recipients:
        # TODO: validate if phone_number is PhoneNumber
        response = client.create_message(phone_number.as_e164, message)
        results.append(response.date_created)
    return any(results)
