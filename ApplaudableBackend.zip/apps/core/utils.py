"""
Core utils.
"""

from random import randint
from typing import Optional, Type
from uuid import uuid4

from django.conf import settings
from django.core.cache import cache
from django.urls import reverse


def domain_with_proto(url: str = "") -> str:
    """
    Return URL prefixed with project base URL.

    :param url: Optional URL to be prefixed with project url

    :return: Formatted URL
    """

    from django.contrib.sites.models import Site

    project_url = getattr(settings, "PROJECT_URL", None)
    if project_url is not None:
        return f"{project_url}{url}"

    # fallback using sites
    current_site = Site.objects.get_current()
    domain = current_site.domain
    if domain.startswith("http"):
        return f"{domain}{url}"

    # fallback to https
    proto = "https://"
    return f"{proto}{domain}{url}"


def clear_api_page_cache() -> None:
    """
    Clear cache from Redis.

    :return: None
    """

    for cache_key in cache.keys("*api_page*"):
        cache.delete(cache_key)


def generate_random_validation_code() -> str:
    """
    Generate a random 6 digit validation code.
    """

    return str(f"{randint(0, 999999):06d}")


def generate_unique_code(length: int = 8) -> str:
    return uuid4().hex[:length].upper()


def get_dynamic_link_default_url() -> str:
    return domain_with_proto(reverse(getattr(settings, "DYNAMIC_LINK_DEFAULT_URL_NAME", "web-deeplink")))


def get_or_create_model_object(data: dict, model: type[Type], create: bool = False) -> Optional[Type]:
    """
    Find or create model object.

    :param data: data
    :param model: Django's ORM model class
    :para create: create pre-registered user if not found

    :return: Model class object or None
    """

    if create:
        model_class_object, _ = model.objects.get_or_create(**data)
    else:
        model_class_object = model.objects.filter(**data).first()
    return model_class_object
