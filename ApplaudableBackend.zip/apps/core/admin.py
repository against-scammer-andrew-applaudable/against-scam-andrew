FIELDSET_METADATA = ("Metadata", {"fields": ('metadata', 'private_metadata'), 'classes': ('collapse',)})
