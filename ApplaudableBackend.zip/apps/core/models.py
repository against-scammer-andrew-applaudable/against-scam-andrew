"""
Core models.
"""
from typing import Any

from django.contrib.postgres.indexes import GinIndex, HashIndex
from django.db import models
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from hashid_field import BigHashidAutoField, HashidAutoField

from apps.core.utils import generate_random_validation_code


class AbstractCreatedDateMixin(models.Model):
    """
    Abstract model with created_at field.
    """

    created_at = models.DateTimeField(_("created"), auto_now_add=True)

    class Meta:
        abstract = True


class AbstractUpdatedDateMixin(models.Model):
    """
    Abstract model with updated_at field.
    """

    updated_at = models.DateTimeField(_("updated"), auto_now=True, blank=True)

    class Meta:
        abstract = True


class AbstractCreatedUpdatedDateMixin(AbstractCreatedDateMixin, AbstractUpdatedDateMixin):
    """
    Abstract model with created_at and updated_at fields.
    """

    class Meta:
        abstract = True


class AbstractValidation(AbstractCreatedUpdatedDateMixin):
    """
    Abstract validation model.
    """

    code = models.CharField(max_length=6, default=generate_random_validation_code)

    def is_expired(self) -> bool:
        """
        Check if the validation code is expired (expire time = 1 day).
        """

        if self.updated_at + timezone.timedelta(days=1) < timezone.now():
            return True

    def is_valid(self, code) -> bool:
        """
        Check if given validation code is valid.

        :param code: code to be validated.

        :return: True if code is valid, False otherwise.
        """

        if self.code == code and not self.is_expired():
            return True

    def save(self, *args, **kwargs):
        """
        Save instance and generate a new code.

        [Overrides AbstractCreatedUpdatedDateMixin.save]
        """

        self.code = generate_random_validation_code()
        super().save(*args, **kwargs)

    class Meta:
        abstract = True


class AbstractUniqueHashIDMixin(models.Model):
    id = HashidAutoField(primary_key=True)

    class Meta:
        indexes = [
            HashIndex(fields=["id"], name="%(class)s_hashid_idx"),
        ]
        abstract = True


class AbstractUniqueBigHashIDMixin(models.Model):
    id = BigHashidAutoField(primary_key=True)

    class Meta:
        indexes = [
            HashIndex(fields=["id"], name="%(class)s_bighashid_idx"),
        ]
        abstract = True


class AbstractMetadata(models.Model):
    private_metadata = models.JSONField(blank=True, null=True, default=dict)
    metadata = models.JSONField(blank=True, null=True, default=dict)

    class Meta:
        indexes = [
            GinIndex(fields=["private_metadata"], name="%(class)s_p_meta_idx"),
            GinIndex(fields=["metadata"], name="%(class)s_meta_idx"),
        ]
        abstract = True

    def get_value_from_private_metadata(self, key: str, default: Any = None) -> Any:
        return self.private_metadata.get(key, default)

    def store_value_in_private_metadata(self, items: dict):
        if not self.private_metadata:
            self.private_metadata = {}
        self.private_metadata.update(items)

    def clear_private_metadata(self):
        self.private_metadata = {}

    def delete_value_from_private_metadata(self, key: str):
        if key in self.private_metadata:
            del self.private_metadata[key]

    def get_value_from_metadata(self, key: str, default: Any = None) -> Any:
        return self.metadata.get(key, default)

    def store_value_in_metadata(self, items: dict):
        if not self.metadata:
            self.metadata = {}
        self.metadata.update(items)

    def clear_metadata(self):
        self.metadata = {}

    def delete_value_from_metadata(self, key: str):
        if key in self.metadata:
            del self.metadata[key]


class ToJSONB(models.Subquery):
    template = '(SELECT to_jsonb("row") FROM (%(subquery)s) "row")'
    output_field = models.JSONField()
