from django.contrib.auth import get_user_model
from django.utils.functional import cached_property
from rest_framework import serializers

from .utils import parse_element

User = get_user_model()


RICH_TEXT_ELEMENT = 'rich_text'
TEXT_ELEMENT = 'text'
USER_ELEMENT = 'user'
EMOJI_ELEMENT = 'emoji'
NUPP_ELEMENT = 'nupp'
INVITE_ELEMENT = 'invite'


class ElementSerializer(serializers.Serializer):
    type = serializers.CharField()

    def to_text(self) -> str:
        return ""

    def mentioned_user_ids(self) -> list:
        return []

    def mentioned_nupp_ids(self) -> list:
        return []

    def mentioned_invite_ids(self) -> list:
        return []

    def validate(self, attrs):
        super().validate(attrs)
        if 'elements' in attrs:
            attrs['elements'] = [parse_element(element) for element in attrs.get('elements', [])]
        return attrs


class RichTextElementSerializer(ElementSerializer):
    elements = serializers.ListField()

    def to_text(self) -> str:
        return "".join([e.to_text() for e in self.data.get('elements')])

    @cached_property
    def get_mentioned(self) -> dict:
        mentions = dict(user_ids=[], nupp_ids=[], invite_ids=[])
        for element in self.data.get('elements'):
            mentions['user_ids'] += element.mentioned_user_ids()
            mentions['nupp_ids'] += element.mentioned_nupp_ids()
            mentions['invite_ids'] += element.mentioned_invite_ids()

        return mentions

    def mentioned_user_ids(self) -> list:
        return self.get_mentioned['user_ids']

    def mentioned_nupp_ids(self) -> list:
        return self.get_mentioned['nupp_ids']

    def mentioned_invite_ids(self) -> list:
        return self.get_mentioned['invite_ids']


class TextElementSerializer(ElementSerializer):
    text = serializers.CharField(trim_whitespace=False)

    def to_text(self) -> str:
        return self.data.get('text')


class UserElementSerializer(ElementSerializer):
    user_id = serializers.CharField()

    def to_text(self) -> str:
        return f"<@{self.data.get('user_id')}>"

    def mentioned_user_ids(self) -> list:
        return [
            self.data.get('user_id'),
        ]


class EmojiElementSerializer(ElementSerializer):
    name = serializers.CharField()
    unicode = serializers.CharField(required=False)

    def to_text(self) -> str:
        return f":{self.data.get('name')}:"


class NuppElementSerializer(ElementSerializer):
    nupp_id = serializers.CharField()

    def to_text(self) -> str:
        return f"<#{self.data.get('nupp_id')}>"

    def mentioned_nupp_ids(self) -> list:
        return [
            self.data.get('nupp_id'),
        ]


class InviteElementSerializer(ElementSerializer):
    invite_id = serializers.CharField()

    def to_text(self) -> str:
        return f"<${self.data.get('invite_id')}>"

    def mentioned_invite_ids(self) -> list:
        return [
            self.data.get('invite_id'),
        ]


ELEMENTS_MAP = {
    RICH_TEXT_ELEMENT: RichTextElementSerializer,
    TEXT_ELEMENT: TextElementSerializer,
    USER_ELEMENT: UserElementSerializer,
    EMOJI_ELEMENT: EmojiElementSerializer,
    NUPP_ELEMENT: NuppElementSerializer,
    INVITE_ELEMENT: InviteElementSerializer,
}


class ElementsSerializerMixin(serializers.ModelSerializer):
    text = serializers.CharField(required=False, allow_blank=True)
    elements = serializers.ListField()
    _elements = []
    _elements_validated = False

    def handle_mentioned_bulk_objects(self, model_class, mentioned_ids, instance) -> list:
        # get the mentions model from the instance.
        MentionModel = instance.mentions.model
        if not hasattr(MentionModel, 'mention_field_name'):
            raise Exception(f"{MentionModel} does not have a mention_field_name method")

        default_mention_data = dict(mentioner=self.context['mentioner'])
        default_mention_data[MentionModel.mention_field_name()] = instance

        bulk_create_mentioned_objects = list()
        obj_field_name = model_class.mention_field_name()
        for obj in model_class.objects.filter(id__in=mentioned_ids):
            mention_data = {**default_mention_data}
            mention_data[obj_field_name] = obj
            bulk_create_mentioned_objects.append(MentionModel(**mention_data))

        return bulk_create_mentioned_objects

    def save(self, **kwargs):
        from apps.nupp.models import Nupp
        from apps.users.models import UserInvite
        from apps.mention.tasks import notify_mentions_task

        instance = super().save(**kwargs)

        # skip if we dont have elements.
        if not self._elements_validated:
            return instance

        MentionModel = instance.mentions.model

        bulk_create_objects = list()
        if self.mentioned_user_ids:
            bulk_create_objects += self.handle_mentioned_bulk_objects(User, self.mentioned_user_ids, instance)
        if self.mentioned_nupp_ids:
            bulk_create_objects += self.handle_mentioned_bulk_objects(Nupp, self.mentioned_nupp_ids, instance)
        if self.mentioned_invite_ids:
            bulk_create_objects += self.handle_mentioned_bulk_objects(UserInvite, self.mentioned_invite_ids, instance)

        # clear mentions.
        # TODO: this should not delete all, in the future is best to filter this out.
        instance.mentions.all().delete()

        # save mentions.
        created_mentions = MentionModel.objects.bulk_create(bulk_create_objects)

        # notify mentions.
        if created_mentions:
            notify_mentions_task.apply_async(args=([m.id for m in created_mentions], MentionModel.__name__), countdown=1)

        return instance

    def validate(self, attrs):
        super().validate(attrs)
        # Don't need to clear the text in new version
        # if self._elements_validated:
            # attrs['text'] = ""
        self.mentioned_user_ids = set()
        self.mentioned_nupp_ids = set()
        self.mentioned_invite_ids = set()
        for element in self._elements:
            self.mentioned_user_ids.update(element.mentioned_user_ids())
            self.mentioned_nupp_ids.update(element.mentioned_nupp_ids())
            self.mentioned_invite_ids.update(element.mentioned_invite_ids())
            # Don't need to update the text in new version
            # attrs['text'] += element.to_text()
        return attrs

    def validate_elements(self, elements) -> list:
        self._elements_validated = True
        self._elements = [parse_element(element) for element in elements]
        return elements
