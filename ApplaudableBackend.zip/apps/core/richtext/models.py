from django.db import models


class AbstractRichTextModel(models.Model):
    text = models.TextField(blank=True, null=True)
    elements = models.JSONField(blank=True, default=list)

    class Meta:
        abstract = True
