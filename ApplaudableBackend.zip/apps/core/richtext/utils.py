from rest_framework import serializers


def parse_element(element: dict):
    from apps.core.richtext.serializers import ELEMENTS_MAP

    element_type = element.get('type', None)

    element_serializer = ELEMENTS_MAP.get(element_type, None)
    if not element_serializer:
        raise serializers.ValidationError(f'element type `{element_type}` is invalid.')

    serializer = element_serializer(data=element)
    serializer.is_valid(raise_exception=True)

    return serializer
