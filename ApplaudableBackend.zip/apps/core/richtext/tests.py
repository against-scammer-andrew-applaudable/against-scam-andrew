from django.test import TestCase

from apps.core.richtext.utils import parse_element
from apps.core.richtext import serializers


class TestRichTextParsing(TestCase):
    def setUp(self):
        self.text_element = {"type": "text", "text": "lorem  ipsum"}
        self.user_element = {"type": "user", "user_id": "abc123"}
        self.emoji_element = {"type": "emoji", "name": "robot", "unicode": "U+1F916"}
        self.emoji_element_custom = {"type": "emoji", "name": "emojicon"}
        self.nupp_element = {"type": "nupp", "nupp_id": "xyz987"}
        self.rich_text_element = {
            "type": "rich_text",
            "elements": [
                {"type": "text", "text": "I am mentioning "},
                {"type": "user", "user_id": "abc123"},
                {"type": "text", "text": " and "},
                {"type": "nupp", "nupp_id": "xyz987"},
                {"type": "text", "text": " "},
                {"type": "emoji", "name": "robot", "unicode": "U+1F916"},
            ],
        }
        self.rich_text_mention_element = {
            "type": "rich_text",
            "elements": [
                {"type": "text", "text": "Test "},
                {"type": "user", "user_id": "abc123"},
                {"type": "text", "text": " "},
                {"type": "user", "user_id": "abc123"},
                {"type": "text", "text": " "},
                {"type": "user", "user_id": "abc333"},
                {"type": "text", "text": " "},
                {"type": "user", "user_id": "abc444"},
                {"type": "text", "text": " "},
                {"type": "user", "user_id": "abc555"},
            ],
        }

    def test_parse_rich_text_element(self):
        serializer = parse_element(self.rich_text_element)
        self.assertTrue(isinstance(serializer, serializers.RichTextElementSerializer))
        self.assertEqual("I am mentioning <@abc123> and <#xyz987> :robot:", serializer.to_text())
        self.assertEqual(["abc123"], serializer.mentioned_user_ids())

    def test_mentioned_user_ids(self):
        serializer = parse_element(self.rich_text_mention_element)
        self.assertEqual("Test <@abc123> <@abc123> <@abc333> <@abc444> <@abc555>", serializer.to_text())
        self.assertEqual(['abc123', 'abc123', 'abc333', 'abc444', 'abc555'], serializer.mentioned_user_ids())

    def test_parse_text_element(self):
        serializer = parse_element(self.text_element)
        self.assertTrue(isinstance(serializer, serializers.TextElementSerializer))

    def test_parse_user_element(self):
        serializer = parse_element(self.user_element)
        self.assertTrue(isinstance(serializer, serializers.UserElementSerializer))

    def test_parse_emoji_element(self):
        serializer = parse_element(self.emoji_element)
        self.assertTrue(isinstance(serializer, serializers.EmojiElementSerializer))

    def test_parse_nupp_element(self):
        serializer = parse_element(self.nupp_element)
        self.assertTrue(isinstance(serializer, serializers.NuppElementSerializer))
