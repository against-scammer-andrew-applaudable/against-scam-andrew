"""
Email base config.
"""

import logging
from email.header import Header
from email.utils import formataddr
from typing import Optional, List, Tuple

from django.conf import settings
from django.core.mail import EmailMultiAlternatives

EMAIL_SETTINGS = {
    "from_email": getattr(settings, "EMAIL", {}).get("from_email", "localhost@localhost.com"),
    "recipients": getattr(settings, "EMAIL", {}).get("recipients", []),
    "cc_recipients": getattr(settings, "EMAIL", {}).get("cc_recipients", []),
    "bcc_recipients": getattr(settings, "EMAIL", {}).get("bcc_recipients", []),
}


def send_email(
    subject: str = "",
    text_content: str = "",
    html_content: str = None,
    from_email: str = EMAIL_SETTINGS["from_email"],
    recipients: list = EMAIL_SETTINGS["recipients"],
    cc_recipients: list = EMAIL_SETTINGS["cc_recipients"],
    bcc_recipients: list = EMAIL_SETTINGS["bcc_recipients"],
    fail_silently: bool = False,
    attachments: List[Tuple[str, bytes, str]] = None,  # (filename, file content, MIME type)
) -> Optional[int]:
    """

    :param subject: email subject
    :param text_content: email text content
    :param html_content: email HTML content
    :param from_email: sender email address
    :param recipients: recipients email addresses list
    :param cc_recipients: cc recipients email addresses list
    :param bcc_recipients: bcc recipients email addresses list
    :param fail_silently: boolean indicating if exception will not be called after failing

    :return: None if there's no recipients or integer indicating success or failure.
    """

    from_email = formataddr((str(Header(settings.SITE_NAME, "utf-8")), from_email))
    email = EmailMultiAlternatives(subject, text_content, from_email, recipients, cc=cc_recipients, bcc=bcc_recipients)

    if html_content:
        email.attach_alternative(html_content, "text/html")

    # Attach files if attachments are provided
    if attachments:
        for attachment in attachments:
            email.attach(*attachment)

    try:
        return email.send(fail_silently=fail_silently)
    except Exception as e:
        logging.error(e, exc_info=True)
        return None
