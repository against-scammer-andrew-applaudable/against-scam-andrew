from django import forms


class DateInputWidget(forms.DateInput):
    input_type = "date"
