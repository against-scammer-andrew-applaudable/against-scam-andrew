from django.contrib import admin

from apps.onboarding.models import Category, Interest, LifeMakeUp


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    """
    Category Admin.
    """

    list_display = ("id", "name", "created_at")
    search_fields = ("id", "name")
    list_filter = ("created_at",)
    readonly_fields = ("id", "created_at")
    fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": (
                    "id",
                    "name",
                    "created_at",
                ),
            },
        ),
    )


@admin.register(Interest)
class InterestAdmin(admin.ModelAdmin):
    """
    Interest Admin.
    """

    list_display = ("id", "name", "category", "created_at")
    search_fields = ("id", "name", "category__name")
    list_filter = ("created_at", "category")
    readonly_fields = ("id", "created_at")
    list_select_related = ("category",)

    fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": (
                    "id",
                    "name",
                    "category",
                    "created_at",
                ),
            },
        ),
    )


@admin.register(LifeMakeUp)
class LifeMakeUpAdmin(admin.ModelAdmin):
    """
    LifeMakeUp Admin.
    """

    list_display = ("id", "name", "created_at")
    search_fields = ("id", "name")
    list_filter = ("created_at",)
    readonly_fields = ("id", "created_at")
    fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": (
                    "id",
                    "name",
                    "created_at",
                ),
            },
        ),
    )
