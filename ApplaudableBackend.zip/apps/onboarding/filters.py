from django.db.models import Subquery, OuterRef, F, Value
from django.contrib.postgres.search import TrigramSimilarity

from django_filters import rest_framework as filters

from apps.media.constants import MediaType
from apps.nupp.models import Nupp, NuppMedia
from apps.onboarding.models import Interest
from apps.users.models import User, ProfileAvatar


class InterestFilter(filters.FilterSet):
    name = filters.CharFilter(lookup_expr="istartswith", help_text="Filter by name")
    category = filters.CharFilter(field_name="category__id", help_text="Category ID")

    class Meta:
        model = Interest
        fields = ["category", "name"]


class SearchAPIFilter(filters.FilterSet):
    q = filters.CharFilter(method='q_filter')

    def q_filter(self, queryset, name, value):
        if value == '':
            return queryset

        nupp_images = NuppMedia.objects.filter(nupp_id=OuterRef('id'), type=MediaType.IMAGE).values_list('image_source', flat=True)[:1]
        nupp = (
            Nupp.objects.annotate(type=Value('nupp'), value=F('name'), photo=Subquery(nupp_images), similarity=TrigramSimilarity('name', value))
            .filter(name__icontains=value, is_public=True)
            .values('id', 'type', 'value', 'photo', 'similarity')
        )

        user_images = ProfileAvatar.objects.filter(profile__user_id=OuterRef('id')).values_list('image_source', flat=True)[:1]
        users = (
            User.objects.annotate(type=Value('user'), value=F('name'), photo=Subquery(user_images), similarity=TrigramSimilarity('name', value))
            .filter(name__icontains=value, is_active=True)
            .values('id', 'type', 'value', 'photo', 'similarity')
        )

        query = nupp.union(users).order_by('-similarity')

        return query
