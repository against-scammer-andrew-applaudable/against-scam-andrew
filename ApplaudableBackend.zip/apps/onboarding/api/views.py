from django.contrib.auth import get_user_model
from django.db.models import Count
from django_filters.rest_framework import DjangoFilterBackend
from drf_yasg.utils import swagger_auto_schema

from rest_framework import serializers
from rest_framework import status
from rest_framework.generics import GenericAPIView, ListAPIView, RetrieveUpdateAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.request import Request

from apps.onboarding.api.serializers import (
    CategorySerializer,
    InterestSerializer,
    LifeMakeUpSerializer,
    UserInterestsSerializer,
    UserLifeMakeUpSerializer,
    SearchAPISerializer,
)
from apps.onboarding.filters import InterestFilter, SearchAPIFilter
from apps.onboarding.models import Category, Interest, LifeMakeUp

from apps.users.api.serializers import UserProfileSerializer
from apps.users.models import Profile

User = get_user_model()


class CategoryListAPIView(ListAPIView):
    permission_classes = (IsAuthenticated,)
    queryset = Category.objects.all()
    serializer_class = CategorySerializer


class InterestListAPIView(ListAPIView):
    permission_classes = (IsAuthenticated,)
    queryset = Interest.objects.annotate(count=Count("users")).order_by("-count")
    serializer_class = InterestSerializer
    filter_backends = (DjangoFilterBackend,)
    filterset_class = InterestFilter
    filterset_fields = ("category__id", "category__name", "name")


class LifeMakeUpListAPIView(ListAPIView):
    permission_classes = (IsAuthenticated,)
    queryset = LifeMakeUp.objects.annotate(count=Count("users")).order_by("-count")
    serializer_class = LifeMakeUpSerializer


class ProfileInterestsAPIView(GenericAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = InterestSerializer

    def get_queryset(self):
        return Interest.objects.filter(users=self.request.user)

    def get(self, request: Request, *args, **kwargs):
        """
        Get user's interesets
        """

        queryset = self.get_queryset()
        page = self.paginate_queryset(queryset)
        serializer = self.get_serializer(page, many=True)
        return self.paginator.get_paginated_response(serializer.data)

    @swagger_auto_schema(
        request_body=UserInterestsSerializer,
        responses={status.HTTP_200_OK: InterestSerializer()},
    )
    def patch(self, request: Request, *args, **kwargs):
        """
        Update user's interests
        """

        user = request.user
        serializer = UserInterestsSerializer(data=request.data, context={"user": user})
        serializer.is_valid(raise_exception=True)
        serializer.save()
        queryset = Interest.objects.filter(id__in=serializer.data["interests"])
        response_serializer = self.get_serializer(queryset, many=True)
        page = self.paginate_queryset(response_serializer.data)
        return self.paginator.get_paginated_response(page)

    @swagger_auto_schema(
        request_body=UserInterestsSerializer,
        responses={status.HTTP_202_ACCEPTED: InterestSerializer()},
    )
    def delete(self, request: Request, *args, **kwargs):
        """
        Delete user's interests
        """

        user = request.user
        serializer = UserInterestsSerializer(data=request.data, context={"user": user})
        serializer.is_valid(raise_exception=True)
        serializer.delete()
        queryset = Interest.objects.filter(id__in=serializer.data["interests"])
        response_serializer = self.get_serializer(queryset, many=True)
        page = self.paginate_queryset(response_serializer.data)
        response = self.paginator.get_paginated_response(page)
        response.status_code = status.HTTP_202_ACCEPTED
        return response


class ProfileLifeMakeUpAPIView(GenericAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = LifeMakeUpSerializer

    def get_queryset(self):
        return LifeMakeUp.objects.filter(users=self.request.user)

    def get(self, request: Request, *args, **kwargs):
        """
        Get user's life makeup
        """

        queryset = self.get_queryset()
        page = self.paginate_queryset(queryset)
        serializer = self.get_serializer(page, many=True)
        return self.paginator.get_paginated_response(serializer.data)

    @swagger_auto_schema(
        request_body=UserLifeMakeUpSerializer,
        responses={status.HTTP_200_OK: LifeMakeUpSerializer()},
    )
    def patch(self, request: Request, *args, **kwargs):
        """
        Update user's interests
        """

        user = request.user
        serializer = UserLifeMakeUpSerializer(data=request.data, context={"user": user})
        serializer.is_valid(raise_exception=True)
        serializer.save()
        queryset = LifeMakeUp.objects.filter(id__in=serializer.data["life_makeups"])
        response_serializer = self.get_serializer(queryset, many=True)
        page = self.paginate_queryset(response_serializer.data)
        return self.paginator.get_paginated_response(page)

    @swagger_auto_schema(
        request_body=UserLifeMakeUpSerializer,
        responses={status.HTTP_202_ACCEPTED: LifeMakeUpSerializer()},
    )
    def delete(self, request: Request, *args, **kwargs):
        """
        Delete user's interests
        """

        user = request.user
        serializer = UserLifeMakeUpSerializer(data=request.data, context={"user": user})
        serializer.is_valid(raise_exception=True)
        serializer.delete()
        queryset = LifeMakeUp.objects.filter(id__in=serializer.data["life_makeups"])
        response_serializer = self.get_serializer(queryset, many=True)
        page = self.paginate_queryset(response_serializer.data)
        response = self.paginator.get_paginated_response(page)
        response.status_code = status.HTTP_202_ACCEPTED
        return response


class ProfileRetriveUpdateAPIView(RetrieveUpdateAPIView):
    permission_classes = (IsAuthenticated,)
    http_method_names = ['get', 'put', 'patch', 'head', 'options', 'trace']
    queryset = User.objects.filter(is_active=True)
    serializer_class = UserProfileSerializer

    def get_object(self):
        user = self.request.user
        try:
            user.profile_data
        except User.profile_data.RelatedObjectDoesNotExist:
            raise serializers.ValidationError({"error": "Please do the onboarding"})
        return user


class SearchAPIView(ListAPIView):
    permission_classes = (IsAuthenticated,)
    queryset = User.objects.none()
    serializer_class = SearchAPISerializer
    filter_backends = (DjangoFilterBackend, )
    filterset_class = SearchAPIFilter
