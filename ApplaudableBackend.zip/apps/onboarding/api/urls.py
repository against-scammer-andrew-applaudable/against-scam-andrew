from django.urls import path
from rest_framework.routers import DefaultRouter

from apps.onboarding.api.views import (
    CategoryListAPIView,
    InterestListAPIView,
    LifeMakeUpListAPIView,
    ProfileInterestsAPIView,
    ProfileLifeMakeUpAPIView,
    ProfileRetriveUpdateAPIView,
    SearchAPIView,
)

router = DefaultRouter()
app_name = "onboarding"

urlpatterns = [
    path("interest/category/", CategoryListAPIView.as_view(), name="category-list"),
    path("interest/interest/", InterestListAPIView.as_view(), name="interest-list"),
    path("life-makeup/", LifeMakeUpListAPIView.as_view(), name="life-makeup-list"),
    path(
        "profile/interests/",
        ProfileInterestsAPIView.as_view(),
        name="profile-interests",
    ),
    path(
        "profile/life-makeup/",
        ProfileLifeMakeUpAPIView.as_view(),
        name="profile-life-makeups",
    ),
    path("profile/", ProfileRetriveUpdateAPIView.as_view(), name="profile-update"),
    path("search/", SearchAPIView.as_view(), name="search-list"),
] + router.urls
