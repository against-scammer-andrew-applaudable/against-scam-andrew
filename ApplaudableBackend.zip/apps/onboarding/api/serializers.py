from django.contrib.auth import get_user_model
from rest_framework import serializers

from apps.onboarding.models import Category, Interest, LifeMakeUp

User = get_user_model()


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ("id", "name")


class InterestSerializer(serializers.ModelSerializer):
    category = CategorySerializer()

    class Meta:
        model = Interest
        fields = ("id", "name", "category")
        extra_kwargs = {"name": {"required": False}, "category": {"required": False}}


class UserInterestsSerializer(serializers.Serializer):
    interests = serializers.ListField(child=serializers.IntegerField())

    def validate_interests(self, interests):
        valid_interests = list(Interest.objects.filter(id__in=interests).values_list("id", flat=True))
        return valid_interests

    def save(self, **kwargs):
        user = self.context["user"]
        interests = self.validated_data["interests"]
        user.has_interest.add(*interests)
        return user

    def delete(self, **kwargs):
        user = self.context["user"]
        interests = self.validated_data["interests"]
        user.has_interest.remove(*interests)
        return user


class LifeMakeUpSerializer(serializers.ModelSerializer):
    class Meta:
        model = LifeMakeUp
        fields = ("id", "name")
        extra_kwargs = {"name": {"required": False}}


class UserLifeMakeUpSerializer(serializers.Serializer):
    life_makeups = serializers.ListField(child=serializers.IntegerField())

    def validate_life_makeups(self, life_makeups):
        valid_life_makeups = list(LifeMakeUp.objects.filter(id__in=life_makeups).values_list("id", flat=True))
        return valid_life_makeups

    def save(self, **kwargs):
        user = self.context["user"]
        life_makeups = self.validated_data["life_makeups"]
        user.has_lifemakeup.add(*life_makeups)
        return life_makeups

    def delete(self, **kwargs):
        user = self.context["user"]
        life_makeups = self.validated_data["life_makeups"]
        user.has_lifemakeup.remove(*life_makeups)
        return life_makeups


class SearchAPISerializer(serializers.Serializer):
    type = serializers.CharField()
    value = serializers.CharField()
    id = serializers.CharField()
    photo = serializers.SerializerMethodField()

    def get_photo(self, obj):
        if obj['photo'] is None:
            return ''
        return obj['photo'].url
