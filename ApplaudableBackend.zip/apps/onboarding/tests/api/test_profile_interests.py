"""
Interest API Tests.
"""

from django.contrib.auth import get_user_model
from rest_framework.test import APIRequestFactory, APITestCase, force_authenticate

from apps.onboarding.api.views import ProfileInterestsAPIView
from apps.onboarding.models import Category, Interest
from apps.users.tests.factories import UserFactory

User = get_user_model()
factory = APIRequestFactory()


class InterestViewSetTestCase(APITestCase):
    """
    Tests for Category List API View.
    """

    def setUp(self):
        """
        Set up test data.

        [Overrides APITestCase.setUp]
        """

        self.user = UserFactory()
        self.category = Category.objects.create(name="Test Category")
        self.interest = Interest.objects.create(name="Test Interest", category=self.category)
        self.user.has_interest.add(self.interest)

    def test_list(self):
        """
        Test list response.
        """

        request = factory.get(path="api/v1/profile/interests/")
        force_authenticate(request, user=self.user)
        response = ProfileInterestsAPIView.as_view()(request)
        results = response.data["results"]
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.interest.name, results[0]["name"])
        self.assertEqual(self.interest.id, results[0]["id"])
        self.assertEqual(self.interest.category.name, results[0]["category"]["name"])
        self.assertEqual(self.interest.category.id, results[0]["category"]["id"])

    def test_delete(self):
        """
        Test delete response.
        """

        request = factory.delete(
            path="api/v1/profile/interests/",
            data={"interests": [self.interest.id]},
        )
        force_authenticate(request, user=self.user)
        response = ProfileInterestsAPIView.as_view()(request)
        results = response.data["results"]
        self.assertEqual(response.status_code, 202)
        self.assertEqual(len(self.user.has_interest.all()), 0)
        self.assertEqual(self.interest.name, results[0]["name"])
        self.assertEqual(self.interest.id, results[0]["id"])
        self.assertEqual(self.interest.category.name, results[0]["category"]["name"])
        self.assertEqual(self.interest.category.id, results[0]["category"]["id"])

    def test_patch(self):
        """
        Test patch response.
        """

        self.user.has_interest.remove(self.interest)
        self.assertEqual(len(self.user.has_interest.all()), 0)

        request = factory.patch(
            path="api/v1/profile/interests/",
            data={"interests": [self.interest.id]},
        )
        force_authenticate(request, user=self.user)
        response = ProfileInterestsAPIView.as_view()(request)
        results = response.data["results"]
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(self.user.has_interest.all()), 1)
        self.assertEqual(self.interest.name, results[0]["name"])
        self.assertEqual(self.interest.id, results[0]["id"])
        self.assertEqual(self.interest.category.name, results[0]["category"]["name"])
        self.assertEqual(self.interest.category.id, results[0]["category"]["id"])
