"""
Interest API Tests.
"""

from django.contrib.auth import get_user_model
from rest_framework.test import APIRequestFactory, APITestCase, force_authenticate

from apps.onboarding.api.views import ProfileLifeMakeUpAPIView
from apps.onboarding.models import LifeMakeUp
from apps.users.tests.factories import UserFactory

User = get_user_model()
factory = APIRequestFactory()


class InterestViewSetTestCase(APITestCase):
    """
    Tests for Category List API View.
    """

    def setUp(self):
        """
        Set up test data.

        [Overrides APITestCase.setUp]
        """

        self.user = UserFactory()
        self.makeup = LifeMakeUp.objects.create(name="Test LifeMakeUp")
        self.user.has_lifemakeup.add(self.makeup)

    def test_list(self):
        """
        Test list response.
        """

        request = factory.get(path="api/v1/profile/life-makeup/")
        force_authenticate(request, user=self.user)
        response = ProfileLifeMakeUpAPIView.as_view()(request)
        results = response.data["results"]
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.makeup.name, results[0]["name"])
        self.assertEqual(self.makeup.id, results[0]["id"])

    def test_delete(self):
        """
        Test delete response.
        """

        request = factory.delete(
            path="api/v1/profile/life-makeup/",
            data={"life_makeups": [self.makeup.id]},
        )
        force_authenticate(request, user=self.user)
        response = ProfileLifeMakeUpAPIView.as_view()(request)
        results = response.data["results"]
        self.assertEqual(response.status_code, 202)
        self.assertEqual(len(self.user.has_lifemakeup.all()), 0)
        self.assertEqual(self.makeup.name, results[0]["name"])
        self.assertEqual(self.makeup.id, results[0]["id"])

    def test_patch(self):
        """
        Test patch response.
        """

        self.user.has_lifemakeup.remove(self.makeup)
        self.assertEqual(len(self.user.has_lifemakeup.all()), 0)

        request = factory.patch(
            path="api/v1/profile/life-makeup/",
            data={"life_makeups": [self.makeup.id]},
        )
        force_authenticate(request, user=self.user)
        response = ProfileLifeMakeUpAPIView.as_view()(request)
        results = response.data["results"]
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(self.user.has_lifemakeup.all()), 1)
        self.assertEqual(self.makeup.name, results[0]["name"])
        self.assertEqual(self.makeup.id, results[0]["id"])
