"""
Search API Tests.
"""
from rest_framework.test import APIRequestFactory, APITestCase, force_authenticate

from apps.onboarding.api.views import SearchAPIView
from apps.users.tests.factories import UserFactory
from apps.nupp.models import Nupp

factory = APIRequestFactory()


class SearchAPITestCase(APITestCase):
    """
    Tests for Search List API View.
    """

    def setUp(self):
        """
        Set up test data.

        [Overrides APITestCase.setUp]
        """

        self.user = UserFactory(name='Test User')
        self.nupp = Nupp.objects.create(name='Test Nupp')

    def test_list(self):
        """
        Test list response for the string 'test'.
        """

        request = factory.get(path="api/v1/search/?q=test")
        force_authenticate(request, user=self.user)
        response = SearchAPIView.as_view()(request)
        results = response.data["results"]
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(results), 2)

    def test_user(self):
        """
        Test list response for the string 'user'.
        """

        request = factory.get(path="api/v1/search/?q=user")
        force_authenticate(request, user=self.user)
        response = SearchAPIView.as_view()(request)
        results = response.data["results"]
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(results), 1)

    def test_nupp(self):
        """
        Test list response for the string 'nupp'.
        """

        request = factory.get(path="api/v1/search/?q=nupp")
        force_authenticate(request, user=self.user)
        response = SearchAPIView.as_view()(request)
        results = response.data["results"]
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(results), 1)
