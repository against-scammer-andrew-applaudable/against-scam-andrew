import json

from django.contrib.auth import get_user_model
from rest_framework.test import APIRequestFactory, APITestCase, force_authenticate

from apps.onboarding.api.views import ProfileRetriveUpdateAPIView
from apps.users.tests.factories import APIProfileSignupSerializerFactory, ProfileFactory

User = get_user_model()
factory = APIRequestFactory()


class ProfileRetriveUpdateAPIViewTestCase(APITestCase):
    def setUp(self):
        self.profile = ProfileFactory()

    def test_get_profile(self):
        request = factory.get(path="api/v1/profile/")
        force_authenticate(request, user=self.profile.user)
        response = ProfileRetriveUpdateAPIView.as_view()(request)
        self.assertEqual(response.status_code, 200)

    def test_put_profile(self):
        data = APIProfileSignupSerializerFactory()
        request = factory.put(path="api/v1/profile/", data=data)
        force_authenticate(request, user=self.profile.user)
        response = ProfileRetriveUpdateAPIView.as_view()(request)
        response.render()
        response_data = json.loads(response.content)
        data['avatar'] = response_data['avatar']
        self.assertEqual(response.status_code, 200)

    def test_patch_profile(self):
        request = factory.patch(path="api/v1/profile/", data={"birth_date": "1982-01-08"})
        force_authenticate(request, user=self.profile.user)
        response = ProfileRetriveUpdateAPIView.as_view()(request)
        response.render()
        response_data = json.loads(response.content)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response_data['birth_date'], "1982-01-08")
