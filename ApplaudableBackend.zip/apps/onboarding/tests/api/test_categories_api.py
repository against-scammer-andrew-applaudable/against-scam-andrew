"""
Login API View Tests.
"""

from django.contrib.auth import get_user_model
from rest_framework.test import APIRequestFactory, APITestCase, force_authenticate

from apps.onboarding.api.views import CategoryListAPIView
from apps.onboarding.models import Category
from apps.users.tests.factories import UserFactory

User = get_user_model()
factory = APIRequestFactory()


class CategoryListAPIViewTestCase(APITestCase):
    """
    Tests for Category List API View.
    """

    def setUp(self):
        """
        Set up test data.

        [Overrides APITestCase.setUp]
        """

        self.user = UserFactory()
        self.category = Category.objects.create(name="Test Category")

    def test_get(self):
        """
        Test get response.
        """

        request = factory.get(path="api/v1/interest/categories/")
        force_authenticate(request, user=self.user)
        response = CategoryListAPIView.as_view()(request)
        results = response.data["results"]
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.category.name, results[0]["name"])
        self.assertEqual(self.category.id, results[0]["id"])
