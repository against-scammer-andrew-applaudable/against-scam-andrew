from django.test import TestCase

from apps.onboarding.models import Category


class TestCategoryModel(TestCase):
    """
    Category Model Tests.
    """

    def setUp(self):
        self.category = Category.objects.create(name="Category")

    def test_category_name(self):
        self.assertEqual(self.category.name, "Category")
        self.assertEqual(str(self.category), "Category")
