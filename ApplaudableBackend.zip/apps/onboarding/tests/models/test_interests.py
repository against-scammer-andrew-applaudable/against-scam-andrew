from django.test import TestCase

from apps.onboarding.models import Category, Interest
from apps.users.tests.factories import UserFactory


class InterestTestCase(TestCase):
    """
    Interest Model Tests.
    """

    def setUp(self):
        self.user = UserFactory()
        self.category = Category.objects.create(name="Category")
        self.interest = Interest.objects.create(name="Interest", category=self.category)

    def test_interest_name(self):
        self.assertEqual(self.interest.name, "Interest")
        self.assertEqual(str(self.interest), "Interest")

    def test_interest_category(self):
        self.assertEqual(self.interest.category, self.category)

    def test_interest_users(self):
        self.interest.users.add(self.user)
        self.assertEqual(self.interest.users.first(), self.user)
        self.assertEqual(self.interest.users.count(), 1)
        self.assertEqual(self.user.has_interest.first().category, self.category)

    def test_interest_users_remove(self):
        self.interest.users.add(self.user)
        self.assertEqual(self.interest.users.first(), self.user)
        self.assertEqual(self.interest.users.count(), 1)
        self.interest.users.remove(self.user)
        self.assertEqual(self.interest.users.count(), 0)
        self.assertEqual(self.user.has_interest.count(), 0)
