from django.test import TestCase

from apps.onboarding.models import LifeMakeUp
from apps.users.tests.factories import UserFactory


class LifeMakeUpTestCase(TestCase):
    """
    LifeMakeUp Model Tests.
    """

    def setUp(self):
        self.user = UserFactory()
        self.makeup = LifeMakeUp.objects.create(name="Life Make Up")

    def test_makeup_name(self):
        self.assertEqual(self.makeup.name, "Life Make Up")
        self.assertEqual(str(self.makeup), "Life Make Up")

    def test_makeup_users(self):
        self.makeup.users.add(self.user)
        self.assertEqual(self.makeup.users.first(), self.user)
        self.assertEqual(self.makeup.users.count(), 1)

    def test_makeup_users_remove(self):
        self.makeup.users.add(self.user)
        self.assertEqual(self.makeup.users.first(), self.user)
        self.assertEqual(self.makeup.users.count(), 1)
        self.makeup.users.remove(self.user)
        self.assertEqual(self.makeup.users.count(), 0)
        self.assertEqual(self.user.has_lifemakeup.count(), 0)
