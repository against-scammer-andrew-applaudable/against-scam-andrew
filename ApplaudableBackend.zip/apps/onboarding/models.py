from django.contrib.auth import get_user_model
from django.db import models

from apps.core.models import AbstractCreatedDateMixin

User = get_user_model()


class BaseInterestModel(models.Model):
    name = models.CharField(max_length=100, unique=True)

    class Meta:
        abstract = True

    def __str__(self):
        return self.name


class Category(AbstractCreatedDateMixin, BaseInterestModel):
    class Meta:
        verbose_name = "Category"
        verbose_name_plural = "Categories"


class Interest(AbstractCreatedDateMixin, BaseInterestModel):
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    users = models.ManyToManyField(User, related_name="has_interest", blank=True)


class LifeMakeUp(AbstractCreatedDateMixin, BaseInterestModel):
    users = models.ManyToManyField(User, related_name="has_lifemakeup", blank=True)

    def __str__(self):
        return self.name
