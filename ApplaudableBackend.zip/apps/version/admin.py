from django.contrib import admin
from .models import AppVersion

class AppVersionAdmin(admin.ModelAdmin):
    list_display = ('android_version', 'android_min_version', 'ios_version', 'ios_min_version')
    list_filter = ('android_version', 'ios_version')
    search_fields = ('android_version', 'ios_version')

admin.site.register(AppVersion, AppVersionAdmin)
