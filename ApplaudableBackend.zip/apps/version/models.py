from django.db import models

class AppVersion(models.Model):
    """
    App Version model.
    """
        
    android_version = models.CharField(max_length=10, unique=True, default='1.0.0')
    android_min_version = models.CharField(max_length=10, default='1.0.0')
    ios_version = models.CharField(max_length=10, unique=True, default='1.0.0')
    ios_min_version = models.CharField(max_length=10, default='1.0.0')

    def __str__(self):
        return f"Android: {self.android_version} (Min: {self.android_min_version}), iOS: {self.ios_version} (Min: {self.ios_min_version})"
