from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import viewsets
from drf_yasg.utils import no_body, swagger_auto_schema
from rest_framework.decorators import action

from apps.version.models import AppVersion
from apps.version.api.serializers import AppVersionSerializer

class VersionAPIView(viewsets.GenericViewSet):
    serializer_class = AppVersionSerializer
    pagination_class = None
    queryset = AppVersion.objects.all()

    @swagger_auto_schema(
        request_body=no_body,
        responses={200: AppVersionSerializer()},
    )
    @action(detail=False, methods=['get'])
    def latest(self, request, *args, **kwargs):
        try:
            app_version = AppVersion.objects.get()
        except (AppVersion.DoesNotExist) as e:
            return Response({"error": "Required information is missing."}, status=404)

        data = AppVersionSerializer(app_version).data
        return Response(data)
        