from django.urls import include, path
from rest_framework.routers import DefaultRouter
from apps.version.api.views import VersionAPIView

app_name = "version"

router = DefaultRouter()
router.register(r"", VersionAPIView, "version")

urlpatterns = [] + router.urls
