from rest_framework import serializers

class AppVersionSerializer(serializers.Serializer):
    android_version = serializers.CharField(max_length=10)
    android_min_version = serializers.CharField(max_length=10)
    ios_version = serializers.CharField(max_length=10)
    ios_min_version = serializers.CharField(max_length=10)