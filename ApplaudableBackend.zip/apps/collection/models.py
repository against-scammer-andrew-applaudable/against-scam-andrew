from email.policy import default
from random import choices
from django.contrib.auth import get_user_model
from django.db import models

from apps.core.models import AbstractUniqueHashIDMixin
from .constant import VisualType, Type

User = get_user_model()


class BaseCollection(AbstractUniqueHashIDMixin):
    name = models.CharField(max_length=60)
    order = models.IntegerField(blank=False, default=0)
    visual = models.CharField(max_length=20, blank=False, choices=VisualType.choices(), default=VisualType.POST)
    type = models.CharField(max_length=20, blank=False, choices=Type.choices(), default=Type.COLLECTION)

    class Meta:
        abstract = True

    def __str__(self):
        return f"{self.id} - {self.name}"


class BaseCollectionType(AbstractUniqueHashIDMixin):
    name = models.CharField(max_length=60)
    is_custom = models.BooleanField(default=False)
    order = models.IntegerField(blank=False, default=0)
    visual = models.CharField(max_length=20, blank=False, choices=VisualType.choices(), default=VisualType.TAB)

    class Meta:
        abstract = True

    def __str__(self):
        return f"{self.id} - {self.name}"


class CollectionTypeTemplate(BaseCollectionType):
    """
    Collection Type template
    """


class CollectionTemplate(BaseCollection):
    collection_type = models.ForeignKey(
        CollectionTypeTemplate,
        on_delete=models.CASCADE,
        related_name="collection_templates",
    )
    collection_group = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="collections_item",
    )


class CollectionType(BaseCollectionType):
    """
    Collection Type
    """

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="collections_type", default=1)


class Collection(BaseCollection):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="collections",
    )
    collection_type = models.ForeignKey(
        CollectionType,
        on_delete=models.CASCADE,
        related_name="collections",
    )
    collection_template = models.ForeignKey(
        CollectionTemplate,
        on_delete=models.CASCADE,
        related_name="collections",
        blank=True,
        null=True,
    )
    collection_group = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="collections_item",
    )

    class Meta:
        ordering = ['order']
