from django.contrib import admin
from django.db.models import Count, OuterRef, Subquery

from apps.collection.models import Collection, CollectionTemplate, CollectionType, CollectionTypeTemplate

from apps.collection.tasks import create_collection


@admin.register(CollectionTypeTemplate)
class CollectionTypeTemplateAdmin(admin.ModelAdmin):
    """
    Collection Type Template admin
    """

    list_display = ("name", "visual", "order", "is_custom")
    fields = ["name", "is_custom", "order"]
    list_filter = ('is_custom',)

    def save_model(self, request, obj: CollectionTypeTemplate, form, change) -> CollectionTypeTemplate:
        if form.cleaned_data.get('is_custom'):
            CollectionTypeTemplate.objects.filter(is_custom=True).update(is_custom=False)
        return super().save_model(request, obj, form, change)


@admin.register(CollectionTemplate)
class CollectionTemplateAdmin(admin.ModelAdmin):
    """
    Collection Template admin
    """

    list_display = ("name", "collection_type", "collection_group", "order")
    fields = ["name", "order", "collection_type"]
    list_filter = ('collection_type__is_custom',)

    def get_readonly_fields(self, request, obj=None):
        if obj:
            return self.readonly_fields + ('collection_type',)
        return self.readonly_fields

    def save_model(self, request, obj, form, change):
        super().save_model(request, obj, form, change)
        if not change:
            create_collection.delay(str(obj.id))

    """
    Not for now. But it has some issues
    def save_model(self, request, obj, form, change):
        super().save_model(request, obj, form, change)
        if change:
            update_users_collection.delay(str(obj.id), False)
        else:
            update_users_collection.delay(str(obj.id), True)
    """


class UserCollectionSettings(admin.ModelAdmin):
    list_filter = ('collection_type__is_custom',)

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    @admin.display(description="posts", ordering="num_posts")
    def num_posts(self, obj):
        return obj.num_posts


@admin.register(CollectionType)
class CollectionTypeAdmin(UserCollectionSettings):
    """
    Collection Type admin
    """

    search_fields = ['collections__user__username__exact']
    list_display = ('id', 'name', 'num_posts', 'num_collections', 'user')
    fields = ["name", "is_custom", "order", "user"]
    list_filter = ('is_custom',)


    def get_queryset(self, request):
        qs = super().get_queryset(request)
        qs = qs.annotate(num_posts=Count('collections__posts', distinct=True), num_collections=Count('collections'))
        return qs

    @admin.display(description="collections", ordering="num_collections")
    def num_collections(self, obj):
        return obj.num_collections


@admin.register(Collection)
class CollectionAdmin(UserCollectionSettings):
    """
    Collection admin
    """

    search_fields = ['user__username__exact']
    list_display = ("name", "collection_type", "collection_group", "order", 'user', 'num_posts')
    fields = ["name", "order", "user", "collection_type", "collection_template"]

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        qs = qs.annotate(num_posts=Count('posts'))
        return qs
