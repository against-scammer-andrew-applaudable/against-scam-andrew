from celery import shared_task
from django.contrib.auth import get_user_model
from django.forms.models import model_to_dict
from django.db import transaction

from apps.collection.models import Collection, CollectionType, CollectionTypeTemplate, CollectionTemplate

User = get_user_model()


@shared_task
def create_user_collections(user_id: str):
    """
    Create user collections.

    :param user_id: user id
    """

    def field_dict_copy(object):
        return model_to_dict(
            object,
            fields=[field.name for field in object._meta.concrete_fields if not (field.primary_key or field.is_relation)],
        )

    try:
        user = User.objects.get(id=user_id)
    except User.DoesNotExist:
        return
    collection_type_templates = CollectionTypeTemplate.objects.prefetch_related('collection_templates')
    with transaction.atomic():
        for collection_type_template in collection_type_templates:
            fields_copy = field_dict_copy(collection_type_template)
            fields_copy.update({'user': user})
            collection_type = CollectionType.objects.create(**fields_copy)
            for collection_template in collection_type_template.collection_templates.filter(collection_group__isnull=True):
                fields_copy = field_dict_copy(collection_template)
                fields_copy.update({"user": user, "collection_type": collection_type, "collection_template": collection_template})
                group_collection = Collection.objects.create(**fields_copy)
                for collection_template_child in collection_template.collections_item.all():
                    fields_copy = field_dict_copy(collection_template_child)
                    fields_copy.update(
                        {
                            'user': user,
                            'collection_type': collection_type,
                            "collection_group": group_collection,
                            "collection_template": collection_template,
                        }
                    )
                    collection = Collection.objects.create(**fields_copy)


@shared_task
def create_collection(collection_template_id):
    def field_dict_copy(object):
        return model_to_dict(
            object,
            fields=[field.name for field in object._meta.concrete_fields if not (field.primary_key or field.is_relation)],
        )

    try:
        collection_template = CollectionTemplate.objects.get(id=collection_template_id)
        collection_type_template = collection_template.collection_type
        collection_template_field_copy = field_dict_copy(collection_template)
        collection_type_template_field_copy = field_dict_copy(collection_type_template)
    except CollectionTemplate.DoesNotExist:
        return
    with transaction.atomic():
        for user in User.objects.exclude(collections__collection_template=collection_template):

            collection_type = CollectionType.objects.filter(
                user=user, collections__collection_template__collection_type=collection_type_template
            ).first()
            if not collection_type:
                fields_copy_template = collection_type_template_field_copy
                fields_copy_template['user'] = user
                collection_type = CollectionType.objects.create(**fields_copy_template)

            if collection_template.collection_group:
                collection_group = Collection.objects.filter(user=user, collection_template=collection_template.collection_group).first()
                if not collection_group:
                    collection_type_group = CollectionType.objects.filter(
                        user=user, collections__collection_template__collection_type=collection_template.collection_group.collection_type_template
                    ).first()
                    if not collection_type_group:
                        collection_type_group_field_copy = field_dict_copy(collection_template.collection_group.collection_type_template)
                        collection_type_group_field_copy['user'] = user
                        collection_type_group = CollectionType.objects.create(**collection_type_group_field_copy)
                    collection_group_field_copy = field_dict_copy(collection_template.collection_group)
                    collection_group_field_copy['user'] = user
                    collection_group_field_copy['collection_type'] = collection_type_group
                    collection_group = Collection.objects.create(**collection_group_field_copy)

            else:
                collection_group = None
            fields_copy = collection_template_field_copy
            fields_copy.update(
                {
                    'user': user,
                    'collection_type': collection_type,
                    "collection_group": collection_group,
                    "collection_template": collection_template,
                }
            )
            Collection.objects.create(**fields_copy)


"""
This will not be apply at this version
@shared_task
def update_users_collection(collection_template_id: str, is_new: bool):
    try:
        collection_template = CollectionTemplate.objects.get(id=collection_template_id)
    except CollectionTemplate.DoesNotExist:
        return

    if is_new:
        collection_type_template = collection_template.collection_type
        try:
            collection_type = CollectionType.objects.get(id=collection_type_template.id)
        except CollectionType.DoesNotExist:
            collection_type = CollectionType.objects.create(
                name=collection_type_template.name,
                is_custom=collection_type_template.is_custom,
            )
        user_list = User.objects.all()
        collections = []
        for user in user_list:
            collections.append(
                Collection(name=collection_template.name, collection_template=collection_template, collection_type=collection_type, user=user)
            )
        Collection.objects.bulk_create(collections)
        return
    Collection.objects.filter(collection_template=collection_template).update(name=collection_template.name)
"""
