"""
Posts' test factories.
"""

import factory

from apps.collection.models import Collection, CollectionTemplate, CollectionType, CollectionTypeTemplate
from apps.collection.tests.base import faker


class CollectionTypeTemplateModelFactory(factory.django.DjangoModelFactory):
    """
    Collection Type instance factory.
    """

    name = factory.LazyAttribute(lambda _: "".join(faker.random_letters(5)))

    class Meta:
        model = CollectionTypeTemplate


class CollectionTypeModelFactory(factory.django.DjangoModelFactory):
    """
    Collection Type instance factory.
    """

    name = factory.LazyAttribute(lambda _: "".join(faker.random_letters(5)))

    class Meta:
        model = CollectionType


class CollectionAPIFactory(factory.DictFactory):
    """
    Collection serializer factory.
    """

    name = factory.LazyAttribute(lambda _: "".join(faker.random_letters(5)))


class CollectionTemplateModelFactory(factory.django.DjangoModelFactory):
    """
    Collection instance factory.
    """

    name = factory.LazyAttribute(lambda _: "".join(faker.random_letters(5)))
    collection_type = factory.SubFactory(CollectionTypeTemplateModelFactory)

    class Meta:
        model = CollectionTemplate


class CollectionModelFactory(factory.django.DjangoModelFactory):
    """
    Collection instance factory.
    """

    name = factory.LazyAttribute(lambda _: "".join(faker.random_letters(5)))
    collection_type = factory.SubFactory(CollectionTypeModelFactory)
    collection_template = factory.SubFactory(CollectionTemplateModelFactory)

    class Meta:
        model = Collection
