from rest_framework.test import APIRequestFactory, APITestCase, force_authenticate

from apps.collection.api.views import CollectionViewSet
from apps.collection.models import Collection, CollectionTemplate, CollectionType
from apps.collection.tests.factories import CollectionTypeTemplateModelFactory
from apps.users.tests.factories import UserFactory

factory = APIRequestFactory()


class CollectionTypeViewSetTestCase(APITestCase):
    def setUp(self):
        self.user = UserFactory()

        collection_type_template = CollectionTypeTemplateModelFactory()
        collection_template = CollectionTemplate.objects.create(name='test', collection_type=collection_type_template)
        collection_type = CollectionType.objects.create(
            user=self.user,
            name=collection_type_template.name,
            is_custom=collection_type_template.is_custom,
        )
        self.collection = Collection.objects.create(
            name=collection_template.name, collection_template=collection_template, collection_type=collection_type, user=self.user
        )

    def test_list(self):
        request = factory.get("/api/v1/collections/")
        force_authenticate(request, user=self.user)
        response = CollectionViewSet.as_view({"get": "list"})(request)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["count"], 1)

    def test_update(self):
        request = factory.put(f"/api/v1/collections/{self.collection.id}/", data={"name": "new_name"})
        force_authenticate(request, user=self.user)
        view = CollectionViewSet.as_view({"put": "update"})
        response = view(request, id=str(self.collection.id))
        self.assertEqual(response.status_code, 202)
