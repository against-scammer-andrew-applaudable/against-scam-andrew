from rest_framework.test import APIRequestFactory, APITestCase, force_authenticate

from apps.collection.api.views import CollectionPostsViewSet
from apps.collection.tests.factories import CollectionModelFactory
from apps.posts.tests.factories import PostModelFactory
from apps.users.tests.factories import UserFactory

factory = APIRequestFactory()


class CollectionTypeViewSetTestCase(APITestCase):
    def setUp(self):
        self.user = UserFactory()
        self.collection = CollectionModelFactory(user=self.user)
        self.post = PostModelFactory(owner=self.user)

    def test_update_custom_type(self):
        self.assertFalse(self.collection.posts.all())
        request = factory.patch(f"/api/v1/collections/{self.collection.id}/posts/", data={"posts": [str(self.post.id)]})
        force_authenticate(request, user=self.user)
        response = CollectionPostsViewSet.as_view()(request, id=str(self.collection.id))
        self.assertEqual(response.status_code, 202)
        self.assertEqual(self.collection.posts.all().count(), 1)

    def test_update_not_custom_type(self):
        self.collection.posts.add(self.post)
        self.assertEqual(self.collection.posts.all().count(), 1)
        request = factory.delete(f"/api/v1/collections/{self.collection.id}/posts/", data={"posts": [str(self.post.id)]})
        force_authenticate(request, user=self.user)
        response = CollectionPostsViewSet.as_view()(request, id=str(self.collection.id))
        self.assertEqual(response.status_code, 202)
        self.assertEqual(self.collection.posts.all().count(), 0)
