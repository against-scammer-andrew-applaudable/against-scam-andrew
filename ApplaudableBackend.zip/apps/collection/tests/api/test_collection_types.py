from rest_framework.test import APIRequestFactory, APITestCase, force_authenticate

from apps.collection.api.views import CollectionTypeViewSet
from apps.collection.models import Collection, CollectionTemplate, CollectionType
from apps.collection.tests.factories import CollectionTypeTemplateModelFactory
from apps.users.tests.factories import UserFactory

factory = APIRequestFactory()


class CollectionTypeViewSetTestCase(APITestCase):
    def setUp(self):
        self.user = UserFactory()

        collection_type = CollectionTypeTemplateModelFactory()
        collection_template = CollectionTemplate.objects.create(name='test', collection_type=collection_type)
        self.collection_type = CollectionType.objects.create(
            user=self.user,
            name=collection_type.name,
            is_custom=collection_type.is_custom,
        )
        self.collection = Collection.objects.create(
            name=collection_template.name, collection_template=collection_template, collection_type=self.collection_type, user=self.user
        )

        custom_collection_type = CollectionTypeTemplateModelFactory()
        custom_collection_type.is_custom = True
        custom_collection_type.save()

        custom_collection = CollectionTemplate.objects.create(name='test-custom', collection_type=custom_collection_type)
        self.custom_collection_type = CollectionType.objects.create(
            user=self.user,
            name=custom_collection_type.name,
            is_custom=custom_collection_type.is_custom,
        )
        self.custom_collection = Collection.objects.create(
            name='test_custom', collection_template=custom_collection, collection_type=self.custom_collection_type, user=self.user
        )

    def test_list(self):
        request = factory.get("/api/v1/collections/types/")
        force_authenticate(request, user=self.user)
        response = CollectionTypeViewSet.as_view({"get": "list"})(request)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["count"], 2)

    def test_update_custom_type(self):
        request = factory.put(f"/api/v1/collections/types/{self.custom_collection_type.id}/", data={"name": "new_name"})
        force_authenticate(request, user=self.user)
        view = CollectionTypeViewSet.as_view({"put": "update"})
        response = view(request, id=str(self.custom_collection_type.id))
        self.assertEqual(response.status_code, 202)

    def test_update_not_custom_type(self):
        request = factory.put(f"/api/v1/collections/types/{self.collection_type.id}/", data={"name": "new_name"})
        force_authenticate(request, user=self.user)
        view = CollectionTypeViewSet.as_view({"put": "update"})
        response = view(request, id=str(self.collection_type.id))
        self.assertEqual(response.status_code, 404)
