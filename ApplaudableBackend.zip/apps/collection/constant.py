from django.utils.translation import gettext_lazy as _


class VisualType:
    TAB = "tab"
    POST = "post"
    BUBBLE = "bubble"
    CLUSTER = "cluster"
    MAP = "map"

    @classmethod
    def choices(cls):
        return (
            (cls.TAB, _("Tab")),
            (cls.POST, _("Post")),
            (cls.BUBBLE, _("Bubble")),
            (cls.CLUSTER, _("Cluster")),
            (cls.MAP, _("Map")),
        )


class Type:
    COLLECTION = "collection"
    GROUP = "group"
    ITEM = "item"

    @classmethod
    def choices(cls):
        return (
            (cls.COLLECTION, _("Collection")),
            (cls.GROUP, _("Group")),
            (cls.ITEM, _("Item")),
        )
