from django.db import transaction
from .models import CollectionTemplate, CollectionTypeTemplate, Collection, CollectionType


def create_collection_into_user(user, collection_template):
    collection = user.collections.filter(collection_template=collection_template).first()
    if collection:
        return collection

    with transaction.atomic():
        collection_type_template = collection_template.collection_type
        collection_type = CollectionType.objects.filter(name=collection_type_template.name).first()
        if not collection_type:
            collection_type = CollectionType.objects.create(
                name=collection_type_template.name,
                is_custom=collection_type_template.is_custom,
                order=collection_type_template.order,
                visual=collection_type_template.visual,
            )
        collection = user.collections.create(
            collection_template=collection_template,
            collection_type=collection_type,
            name=collection_template.name,
            order=collection_template.order,
            visual=collection_template.visual,
            type=collection_template.type,
        )
    return collection
