from django.db.models import Q
from rest_framework import serializers
from drf_yasg.utils import swagger_serializer_method

from apps.collection.models import Collection, CollectionType, CollectionTypeTemplate
from apps.posts.models import Post


class BaseCollectionSerializer(serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)
    user = serializers.HiddenField(default=serializers.CurrentUserDefault())

    class Meta:
        model = Collection
        fields = ("id", "name", "user")


class BaseCollectionTypeSerializer(serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)

    class Meta:
        model = CollectionType
        fields = ("id", "name", "is_custom")


class CollectionSerializer(BaseCollectionSerializer):
    type = serializers.SerializerMethodField(read_only=True)
    posts = serializers.ListField(child=serializers.CharField(), write_only=True, required=False, allow_empty=True, help_text="List of post ids")

    @swagger_serializer_method(serializer_or_field=BaseCollectionTypeSerializer)
    def get_type(self, obj):
        return BaseCollectionTypeSerializer(obj.collection_type).data

    class Meta:
        model = Collection
        fields = BaseCollectionSerializer.Meta.fields + ("type", "posts")

    def validate_posts(self, value):
        posts = Post.objects.get_enabled_posts().filter(id__in=value, owner=self.context["request"].user)
        return posts

    def save(self, **kwargs):
        post_list = self.validated_data.pop("posts", None)
        if not self.instance:
            collection_type = CollectionType.objects.filter(user=self.validated_data['user'], is_custom=True).first()
            if not collection_type:
                custom_collection_type_template = CollectionTypeTemplate.objects.filter(is_custom=True).first()
                if not custom_collection_type_template:
                    raise serializers.ValidationError({"collection-type": "Custom collection type does not exist"})
                collection_type = CollectionType.objects.create(
                    name=custom_collection_type_template.name, is_custom=True, user=self.validated_data['user']
                )
            self.validated_data["collection_type"] = collection_type
        instance = super().save(**kwargs)
        if post_list:
            instance.posts.add(*post_list)

        return instance


class PatchCollectionSerializer(CollectionSerializer):
    deleted_posts = serializers.ListField(
        child=serializers.CharField(), write_only=True, required=False, allow_empty=True, help_text="List of post ids"
    )

    class Meta:
        model = Collection
        fields = CollectionSerializer.Meta.fields + ("deleted_posts",)

    def validate_deleted_posts(self, value):
        posts = Post.objects.filter(id__in=value, owner=self.context["request"].user)
        return posts

    def save(self, **kwargs):
        deleted_post_list = self.validated_data.pop("deleted_posts", None)
        instance = super().save(**kwargs)
        if deleted_post_list:
            instance.posts.remove(*deleted_post_list)

        return instance


class CollectionTypeSerializer(BaseCollectionTypeSerializer):
    id = serializers.CharField(read_only=True)
    collections = BaseCollectionSerializer(many=True, read_only=True)

    class Meta:
        model = CollectionType
        ref_name = None  # fix for drf-yasg (for more info check https://github.com/axnsan12/drf-yasg/issues/239#issuecomment-569653916)
        fields = ("id", "name", "is_custom", "collections")


class PostListSerializer(serializers.Serializer):
    posts = serializers.ListField(child=serializers.CharField(), required=True, help_text="List of post ids")

    def validate_posts(self, posts):
        return Post.objects.get_enabled_posts().filter(id__in=posts, owner=self.context["request"].user)


class CustomCollectionSerializer(serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)
    image = serializers.SerializerMethodField()

    @swagger_serializer_method(serializer_or_field=serializers.URLField)
    def get_image(self, obj):
        try:
            return obj.posts.filter(~Q(media=None)).first().media.first().cloudinary_resource.url
        except AttributeError:
            return None

    class Meta:
        model = Collection
        fields = ("id", "name", "image")
