from django.urls import path
from rest_framework.routers import DefaultRouter

from apps.collection.api.views import CollectionPostsViewSet, CollectionTypeViewSet, CollectionViewSet

app_name = "collections"

router = DefaultRouter()
router.register(r"types", CollectionTypeViewSet, "collection-types")
router.register(r"", CollectionViewSet, "collections")

urlpatterns = [
    path("<str:id>/posts/", CollectionPostsViewSet.as_view(), name="collection-posts"),
] + router.urls
