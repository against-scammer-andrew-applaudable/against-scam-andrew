from django.shortcuts import get_object_or_404
from django.db.models import Prefetch
from django_filters.rest_framework import DjangoFilterBackend
from drf_yasg.utils import swagger_auto_schema
from rest_framework import status
from rest_framework.generics import GenericAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet

from apps.collection.api.serializers import CollectionSerializer, CollectionTypeSerializer, PatchCollectionSerializer, PostListSerializer
from apps.collection.constant import Type
from apps.collection.filters import CollectionTypeFilter, CollectionFilter
from apps.collection.models import Collection, CollectionType
from apps.users.api.authentication import JWTAuthenticationIgnoreIsActive


class CollectionViewSet(ModelViewSet):
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)
    serializer_class = CollectionSerializer
    http_method_names = ("get", "patch", "post", "put", "delete")
    lookup_field = "id"
    filter_backends = (DjangoFilterBackend,)
    filterset_class = CollectionFilter

    def get_queryset(self):
        return Collection.objects.filter(user=self.request.user).exclude(type=Type.GROUP)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        if not instance.collection_type.is_custom:
            return Response(status=status.HTTP_403_FORBIDDEN)
        response = super().destroy(request, *args, **kwargs)
        response.status_code = status.HTTP_202_ACCEPTED
        return response

    def base_update(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = PatchCollectionSerializer(instance, data=request.data, context=self.get_serializer_context(), partial=kwargs["partial"])
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)

        if getattr(instance, '_prefetched_objects_cache', None):
            instance._prefetched_objects_cache = {}

        return Response(status=status.HTTP_202_ACCEPTED, data=serializer.data)

    @swagger_auto_schema(request_body=PatchCollectionSerializer, responses={status.HTTP_202_ACCEPTED: PatchCollectionSerializer()})
    def update(self, request, *args, **kwargs):
        return self.base_update(request, *args, **kwargs, partial=False)

    @swagger_auto_schema(request_body=PatchCollectionSerializer, responses={status.HTTP_202_ACCEPTED: PatchCollectionSerializer()})
    def partial_update(self, request, *args, **kwargs):
        return self.base_update(request, *args, **kwargs, partial=True)


class CollectionTypeViewSet(ModelViewSet):
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)
    serializer_class = CollectionTypeSerializer
    http_method_names = ("get", "put")
    lookup_field = "id"
    filter_backends = (DjangoFilterBackend,)
    filterset_class = CollectionTypeFilter

    def get_queryset(self):
        collections = Collection.objects.exclude(type=Type.GROUP).order_by("order")
        return (
            CollectionType.objects.filter(user=self.request.user)
            .prefetch_related(Prefetch("collections", queryset=collections))
            .distinct()
            .order_by("order")
        )

    def update(self, request, *args, **kwargs):
        object = get_object_or_404(self.get_queryset().filter(is_custom=True), id=kwargs["id"])
        serializer = self.get_serializer(object, data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(status=status.HTTP_202_ACCEPTED, data=serializer.data)


class CollectionPostsViewSet(GenericAPIView):
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)
    http_method_names = ("patch", "delete")
    lookup_field = "id"
    serializer_class = PostListSerializer

    @swagger_auto_schema(responses={status.HTTP_202_ACCEPTED: ""})
    def patch(self, request, *args, **kwargs):
        collection = get_object_or_404(Collection, id=kwargs["id"], user=request.user)
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        collection.posts.add(*serializer.validated_data["posts"])
        return Response(status=status.HTTP_202_ACCEPTED)

    @swagger_auto_schema(request_body=PostListSerializer, responses={status.HTTP_202_ACCEPTED: ""})
    def delete(self, request, *args, **kwargs):
        collection = get_object_or_404(Collection, id=kwargs["id"], user=request.user)
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        collection.posts.remove(*serializer.validated_data["posts"])
        return Response(status=status.HTTP_202_ACCEPTED)
