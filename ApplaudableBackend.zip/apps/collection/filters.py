from .models import Collection, CollectionType
from django_filters import rest_framework as filters


class CollectionFilter(filters.FilterSet):
    collection_type = filters.CharFilter(field_name='collection_type')
    is_custom = filters.BooleanFilter(field_name='collection_type__is_custom')

    class Meta:
        model = Collection
        fields = ("collection_type", "is_custom")


class CollectionTypeFilter(filters.FilterSet):
    is_custom = filters.BooleanFilter(field_name='is_custom')

    class Meta:
        model = CollectionType
        fields = ("is_custom",)
