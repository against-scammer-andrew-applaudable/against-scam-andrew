from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import viewsets
from drf_yasg.utils import swagger_auto_schema
from rest_framework import status

from apps.autocomplete.api.serializers import AutocompleteAPISerializer, AutocompleteInfoAPISerializer
from apps.users.api.authentication import JWTAuthenticationIgnoreIsActive
from services.google.place import GooglePlaceClient



class AutocompleteAPIView(viewsets.GenericViewSet):
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)
    serializer_class = AutocompleteAPISerializer

    @swagger_auto_schema(
        query_serializer=AutocompleteAPISerializer,
        responses={200: AutocompleteInfoAPISerializer()},
    )
    
    def list(self, *args, **kwargs):
        serializer = self.get_serializer(data=self.request.GET)
        serializer.is_valid(raise_exception=True)
        query = serializer.data["query"]
        if query is None:
            return Response({"error": "Query parameter is missing."}, status=400)
        place_ids = GooglePlaceClient().autocomplete(query)
        return Response(data=place_ids)
    