from rest_framework import serializers

class AutocompleteAPISerializer(serializers.Serializer):
    query = serializers.CharField(max_length=100)

class AutocompleteInfoAPISerializer(serializers.Serializer):
    place_ids = serializers.ListField()