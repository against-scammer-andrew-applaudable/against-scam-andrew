from django.urls import path
from rest_framework.routers import DefaultRouter

from apps.autocomplete.api.views import AutocompleteAPIView

app_name = "autocomplete"

router = DefaultRouter()
router.register(r"", AutocompleteAPIView, "autocomplete")

urlpatterns = [] + router.urls
