from celery import shared_task
from django.contrib.auth import get_user_model

User = get_user_model()

@shared_task
def notify_circle_invite_task(id: str):
    from apps.circle.models import CircleMember
    
    """
    Send circle invite notification.
    """

    circle_member = CircleMember.objects.filter(id=id).first()
    if circle_member:
        circle_member.notify()
        
@shared_task
def notify_circle_member_request_task(id: str):
    from apps.circle.models import CircleMemberRequest
    
    """
    Send circle member request notification.
    """

    circle_member_request = CircleMemberRequest.objects.filter(id=id).first()
    if circle_member_request:
        circle_member_request.notify()
        
        
@shared_task
def notify_circle_question_task(id: str):
    from apps.circle.models import CircleQuestion
    
    """
    Send circle question notification.
    """

    circle_question = CircleQuestion.objects.filter(id=id).first()
    if circle_question:
        circle_question.notify()
            