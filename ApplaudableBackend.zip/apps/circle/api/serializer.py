import cloudinary
import logging
from django.conf import settings
from rest_framework import serializers
from apps.core.serializers import CloudinaryField
from apps.media.constants import MediaType
from apps.circle.models import CircleMedia, Circle, CircleMember, CirclePost, CircleMemberRequest, CircleQuestion
from apps.core.serializers import MediaField
from hashid_field.rest import HashidSerializerCharField
from django.contrib.auth import get_user_model
from apps.users.models import UserInvite
from apps.posts.models import Post
from apps.posts.api.serializers import PostSimpleSerializer, PostSerializer
from apps.circle.constants import CIRCLE_DEFAULT_SETTING, CIRCLE_DEFAULT_CREATOR_SETTING, CircleMembershipType
from apps.users.api.serializers import SimpleUserSerializer
from drf_yasg.utils import swagger_serializer_method
from django.db import IntegrityError, transaction
from django.utils import timezone
from apps.users.models import BannedUsername
from apps.posts.constants import PostType, Visibility

from apps.circle.tasks import notify_circle_invite_task, notify_circle_member_request_task, notify_circle_question_task
User = get_user_model()

class CircleFromContext:
    requires_context = True

    def __call__(self, serializer_field):
        try:
            return Circle.objects.get(id=serializer_field.context["circle"])
        except Circle.DoesNotExist:
            raise serializers.ValidationError("Circle not found.")

    def __repr__(self):
        return f"{self.__class__.__name__}()"

class CircleSettingsSerializer(serializers.Serializer):
    admin = serializers.BooleanField(allow_null=True, required=False)
    can_post = serializers.BooleanField(allow_null=True, required=False)
    can_invite = serializers.BooleanField(allow_null=True, required=False)
    can_edit = serializers.BooleanField(allow_null=True, required=False)
    
    def validate(self, attrs):
        attrs = super().validate(attrs)
        attrs['admin'] = attrs.get('admin', CIRCLE_DEFAULT_SETTING['admin'])
        attrs['can_post'] = attrs.get('can_post', CIRCLE_DEFAULT_SETTING['can_post'])
        attrs['can_invite'] = attrs.get('can_invite', CIRCLE_DEFAULT_SETTING['can_invite'])
        attrs['can_edit'] = attrs.get('can_edit', CIRCLE_DEFAULT_SETTING['can_edit'])
        return attrs

    

class CircleMediaResponseSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    media = serializers.URLField(source="media_source")
    media_detail = MediaField(source="image_source")

    class Meta:
        model = CircleMedia
        fields = ('id', 'media', 'media_detail')

class CircleMediaUploadSerializer(serializers.Serializer):
    media = CloudinaryField()
    
    def upload_media(self):
        media = self.validated_data["media"]
        cloudinary_resource = cloudinary.uploader.upload_resource(
            media, **{"folder": settings.CLOUDINARY_DEFAULT_FOLDER, "tags": ['circle'], "context": {"user": self.context['request'].user.id}}
        )
        circle_media = {
            "image_source": cloudinary_resource,
            "type": MediaType.IMAGE,
            "metadata": getattr(cloudinary_resource, "metadata", {}),            
        }
        return circle_media

    def save(self, **kwargs):
        circle_media = self.upload_media()
        return CircleMedia.objects.create(**circle_media)
    
    def update(self, id):
        circle_media = self.upload_media()
        return CircleMedia.objects.filter(id=id).update(**circle_media)
    
class CircleMemberSerializer(serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)
    member_id = serializers.SerializerMethodField()
    user = serializers.SerializerMethodField()
    label = serializers.SerializerMethodField()
    type = serializers.SerializerMethodField()
    avatar = serializers.SerializerMethodField()
    inviter = serializers.SerializerMethodField()
    
    def get_member_id(self, obj):
        return str(obj.member_object.id)
    
    def get_user(self, obj):
        user = obj.member_object
        return SimpleUserSerializer(user).data if user else None
    
    def get_inviter(self, obj):
        inviter = obj.member_inviter
        return SimpleUserSerializer(inviter).data if inviter else None
    
    def get_label(self, obj):
        return str(obj.member_object.get_mention_label())
    
    def get_type(self, obj):
        return obj.object_type
        
    def get_avatar(self, obj):
        try:
            return str(obj.member_object.get_icon())
        except AttributeError:
            return None
    
    class Meta:
        model = CircleMember
        fields = ('id', 'member_id', 'user', 'avatar', 'type', 'label', 'inviter', 'setting', 'accepted_at')
    
class CircleMemberCreateSerializer(serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)
    user_id = serializers.CharField(required=False, allow_null=True)
    user_invite_id = serializers.CharField(required=False, allow_null=True)
    setting = CircleSettingsSerializer(required=False)
    accepted_at = serializers.DateTimeField(required=False)
    class Meta:
        model = CircleMember
        fields = ('id', 'user_id', 'user_invite_id', 'setting', 'accepted_at')
        
    def validate(self, attrs, segment_options=[]):
        attrs = super().validate(attrs)
        user_id = attrs.get("user_id")
        user_invite_id = attrs.get("user_invite_id")
        if user_id is None and user_invite_id is None:
            raise serializers.ValidationError("Required userId or inviteId.")
        if user_id and not User.objects.filter(id=user_id, is_active=True).exists():
            raise serializers.ValidationError("User is invalid.")
        if user_invite_id and not UserInvite.objects.filter(id=user_invite_id).exists():
            raise serializers.ValidationError("UserInvite is invalid.")
        return attrs
        
    def save(self, circle, inviter):
        data = self.validated_data
        settings = self.validated_data.pop('setting', None)
        if settings:
            settings_serializer = CircleSettingsSerializer(data=settings)
            settings_serializer.is_valid()
            data['setting'] = settings_serializer.data
        else:
            data['setting'] = CIRCLE_DEFAULT_SETTING
        data["circle_id"] = circle
        if inviter:
            data['inviter_id'] = inviter
        circle_member = super().save(**data)
        # Send notification
        notify_circle_invite_task.apply_async(args=(str(circle_member.id),), countdown=10)
        return circle_member
    
class CircleMemberUpdateSerializer(serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)
    user_id = serializers.CharField(required=False, allow_null=True)
    setting = CircleSettingsSerializer(required=False)
    class Meta:
        model = CircleMember
        fields = ('id', 'user_id', 'setting', )
        
    def validate(self, attrs):
        attrs = super().validate(attrs)
        user_id = attrs.get("user_id")
        if user_id and not User.objects.filter(id=user_id, is_active=True).exists():
            raise serializers.ValidationError("User is invalid.")
        return attrs
        
    def save(self, circle):
        data = self.validated_data
        settings = self.validated_data.pop('setting', None)
        user_id = self.validated_data.pop('user_id', None)
        if settings:
            settings_serializer = CircleSettingsSerializer(data=settings)
            settings_serializer.is_valid()
            data['setting'] = settings_serializer.data
        else:
            data['setting'] = CIRCLE_DEFAULT_SETTING
        return CircleMember.objects.filter(circle_id=circle, user_id=user_id).update(**data)     
    
class CircleMemberEditSerializer(serializers.Serializer):
    circle = serializers.HiddenField(default=CircleFromContext())
    remove=serializers.ListField(
        child=serializers.CharField(required=True),
        required=False,
        allow_empty=True
    ) 
    add=serializers.ListField(
        child=CircleMemberCreateSerializer(required=True),
        required=False,
        allow_empty=True
    )
    
    update=serializers.ListField(
        child=CircleMemberUpdateSerializer(required=True),
        required=False,
        allow_empty=True
    )
    
    def validate(self, attrs):
        attrs = super().validate(attrs)
        circle = attrs['circle']
        user_id = self.context['request'].user.id
        member = CircleMember.objects.filter(user_id=user_id, circle_id=circle.id, accepted_at__isnull=False).first()
        if not member:
            raise serializers.ValidationError("Circle member doesn't exist.")
        can_invite = member.setting.get('can_invite', False)
        admin = member.setting.get('admin', False)
        if not can_invite and not admin:
            raise serializers.ValidationError("You don't have permission to perform.")
        return attrs
    
    def save(self):
        circle = self.validated_data["circle"]
        member_add_list = self.validated_data.get("add", None)
        member_update_list = self.validated_data.get("update", None)
        circle_member_id_remove_list = self.validated_data.get('remove', None)
        if member_add_list:
            inviter = self.context['request'].user
            for member_data in member_add_list:
                try:
                    serializer = CircleMemberCreateSerializer(data=member_data)
                    serializer.is_valid()
                    # Need to implement notify
                    serializer.save(circle=circle.id, inviter=inviter.id)
                except Exception as e:
                    print(e)
                    pass
        if circle_member_id_remove_list:
            for circle_member_id in circle_member_id_remove_list:
                if CircleMember.objects.filter(id=circle_member_id).exists():
                    CircleMember.objects.filter(id=circle_member_id).delete()
        if member_update_list:
            for member_data in member_update_list:
                try:
                    serializer = CircleMemberUpdateSerializer(data=member_data)
                    serializer.is_valid()
                    serializer.save(circle=circle.id)
                except Exception as e:
                    print(e)
                    pass
        return None;
    
class CircleMemberInviteAcceptSerializer(serializers.Serializer):
    circle = serializers.HiddenField(default=CircleFromContext())
    accepted = serializers.BooleanField(default=True)
    class Meta:
        model = CircleMember
        field=('circle', 'accepted')
        
    def validate(self, attrs):
        attrs = super().validate(attrs)
        circle = attrs["circle"]
        user_id = self.context['request'].user.id
        if not CircleMember.objects.filter(circle_id=circle.id, user_id=user_id).exists():
            raise serializers.ValidationError("You are not member in this circle")
        return attrs
        
    def save(self):
        circle = self.validated_data["circle"]
        accepted = self.validated_data["accepted"]
        user_id = self.context['request'].user.id
        circle_member = CircleMember.objects.filter(circle_id=circle.id, user_id=user_id).first()
        circle_member.delete_notify(user_id=user_id)
        if accepted:
            CircleMember.objects.filter(circle_id=circle.id, user_id=user_id).update(accepted_at=timezone.now())
            # When accept the invite, we should add the user to parent circle as well
            if circle.related_circle and not CircleMember.objects.filter(circle_id=circle.related_circle.id, user_id=user_id).exists():
                data = {
                    "user_id": str(user_id),
                    "accepted_at": timezone.now()
                }
                try:
                    serializer = CircleMemberCreateSerializer(data=data)
                    serializer.is_valid(raise_exception=True)
                    serializer.save(circle=circle.related_circle.id, inviter=circle.related_circle.creator.id)
                except Exception as e:
                    print(e)
                    pass
        else: 
            CircleMember.objects.filter(circle_id=circle.id, user_id=user_id).delete()
        return None;
    
class CircleMemberLeaveSerializer(serializers.Serializer):
    circle = serializers.HiddenField(default=CircleFromContext())
    class Meta:
        model = CircleMember
        field=('circle')
        
    def validate(self, attrs):
        attrs = super().validate(attrs)
        user_id = self.context['request'].user.id
        circle = attrs["circle"]
        member_query_set = CircleMember.objects.filter(circle_id=circle.id, user_id=user_id, accepted_at__isnull=False)
        if not member_query_set.exists():
            raise serializers.ValidationError("Circle member doesn't exist or didn't accept the invitation.")
        # Need to check the permission so can leave the circle
        # Need to keep one admin at least
        circle_member = member_query_set.first()        
        is_admin = circle_member.setting.get("admin", False)
        if is_admin:
            remaining_admins = CircleMember.objects.filter(circle_id=circle.id, accepted_at__isnull=False, setting__admin=True).count()
            if remaining_admins <= 1:
                raise serializers.ValidationError("Please make another member an admin before leaving this circle")
        return attrs
        
    def save(self):
        circle = self.validated_data["circle"]
        user_id = self.context['request'].user.id
        # If user is in child circle, will leave from there
        if circle.related_circle:
            return CircleMember.objects.filter(circle_id=circle.id, user_id=user_id).delete()
        else:
            # If user leaves in parent circle, will leave from all child circles
            child_circles = Circle.objects.filter(related_circle_id=circle.id).values_list('id')
            CircleMember.objects.filter(circle_id=circle.id, user_id=user_id).delete()
            return CircleMember.objects.filter(circle_id__in=child_circles, user_id=user_id).delete()


class CircleMemberRequestJoinSerializer(serializers.Serializer):
    circle = serializers.HiddenField(default=CircleFromContext())
    class Meta:
        model = CircleMemberRequest
        field=('circle')
        
    def validate(self, attrs):
        attrs = super().validate(attrs)
        user_id = self.context['request'].user.id
        circle = attrs["circle"]
        if CircleMember.objects.filter(circle_id=circle.id, user_id=user_id).exists():
                raise serializers.ValidationError("You already invited to this circle")
        if CircleMemberRequest.objects.filter(circle_id=circle.id, user_id=user_id).exists():
            raise serializers.ValidationError("You already requested to join.")
        return attrs
        
    def save(self):
        circle = self.validated_data["circle"]
        user_id = self.context['request'].user.id
        data = {"user_id": user_id, "circle_id": circle.id}
        circle_member_request = CircleMemberRequest.objects.create(**data)
        notify_circle_member_request_task.apply_async(args=(str(circle_member_request.id),), countdown=10)
        return circle_member_request
    
class CircleMemberRequestApproveSerializer(serializers.Serializer):
    circle = serializers.HiddenField(default=CircleFromContext())
    user_id = serializers.CharField()
    accept = serializers.BooleanField()
    class Meta:
        model = CircleMemberRequest
        field=('circle', 'user_id', 'accept')
        
    def validate(self, attrs):
        attrs = super().validate(attrs)
        user_id = attrs['user_id']
        circle = attrs["circle"]
        
        # Need to validate the admin
        if not CircleMemberRequest.objects.filter(circle_id=circle.id, user_id=user_id).exists():
            raise serializers.ValidationError("Doesn't exist the request")
        
        self_user_id = self.context['request'].user.id
        member = CircleMember.objects.filter(user_id=self_user_id, circle_id=circle.id, accepted_at__isnull=False).first()
        if not member:
            raise serializers.ValidationError("You are not member in this circle or please accept the invitation")
        is_admin = member.setting.get('admin', False)
        if not is_admin:
            raise serializers.ValidationError("Please check your permission in this circle. Admin can perform this action.")

        return attrs
        
    def save(self):
        self_user_id = self.context['request'].user.id
        circle = self.validated_data["circle"]
        user_id = self.validated_data["user_id"]
        accept = self.validated_data['accept']
        if accept:
            circle_member_data = { 
                "user_id": user_id, 
                "user_invite_id": None, 
                "setting": CIRCLE_DEFAULT_SETTING,
                "accepted_at": timezone.now()
            }
            
            serializer = CircleMemberCreateSerializer(data=circle_member_data)
            serializer.is_valid(raise_exception=True)
            serializer.save(circle=circle.id, inviter=None)
            
            # When approve the join request in sub-circle, we should add the user to parent circle as well
            if circle.related_circle and not CircleMember.objects.filter(circle_id=circle.related_circle.id, user_id=user_id).exists():
                data = {
                    "user_id": user_id, 
                    "user_invite_id": None,
                    "setting": CIRCLE_DEFAULT_SETTING,
                    "accepted_at": timezone.now()
                }
                try:
                    serializer = CircleMemberCreateSerializer(data=data)
                    serializer.is_valid(raise_exception=True)
                    serializer.save(circle=circle.related_circle.id, inviter=None)
                except Exception as e:
                    print(e)
                    pass
        member_request = CircleMemberRequest.objects.filter(circle_id=circle.id, user_id=user_id).first()
        member_request.delete_notify(user_id=self_user_id)
        CircleMemberRequest.objects.filter(circle_id=circle.id, user_id=user_id).delete()
        return None
class CirclePostCreateSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    circle_id = serializers.CharField(required=True)
    post_id = serializers.CharField(required=True)
    class Meta:
        model = CirclePost
        fields = ('id', 'circle_id', 'post_id')
        
    def validate(self, attrs, segment_options=[]):
        attrs = super().validate(attrs)
        post_id = attrs.get("post_id")
        if not Post.objects.filter(id=post_id).exists():
            raise serializers.ValidationError("Post is invalid.")
        return attrs
        
    def save(self, **kwargs):
        data = self.validated_data
        return super().save(**data)
    
class CirclePostEditSerializer(serializers.Serializer):
    circle = serializers.HiddenField(default=CircleFromContext())
    remove=serializers.ListField(
        child=serializers.CharField(required=True),
        required=False,
        allow_empty=True
    ) 
    add=serializers.ListField(
        child=serializers.CharField(required=True),
        required=False,
        allow_empty=True
    )
    # Need to validate can_post
    def validate(self, attrs):
        attrs = super().validate(attrs)
        circle = attrs['circle']
        user_id = self.context['request'].user.id
        member = CircleMember.objects.filter(user_id=user_id, circle_id=circle.id, accepted_at__isnull=False).first()
        if not member:
            raise serializers.ValidationError("You are not in member in this circle or please accept the invitation.")
        can_post = member.setting.get('can_post', False)
        admin = member.setting.get('admin', False)
        if not can_post and not admin:
            raise serializers.ValidationError("You don't have permission to add the post.")
        return attrs
    
    def save(self):
        circle = self.validated_data["circle"]
        post_id_add_list = self.validated_data.get("add", None)
        circle_post_id_remove_list = self.validated_data.get('remove', None)
        if post_id_add_list:
            for post_id in post_id_add_list:
                data = {"post_id": post_id, "circle_id": str(circle.id) }
                try:
                    serializer = CirclePostCreateSerializer(data=data)
                    serializer.is_valid()
                    # Need to implement notify
                    serializer.save(circle=circle.id)
                except Exception as e:
                    pass
        if circle_post_id_remove_list:
            for circle_post_id in circle_post_id_remove_list:
                if CirclePost.objects.filter(id=circle_post_id).exists():
                    CirclePost.objects.filter(id=circle_post_id).delete()
        return None;
    
class NestedCircleEditSerializer(serializers.Serializer):
    circle = serializers.HiddenField(default=CircleFromContext())
    remove=serializers.ListField(
        child=serializers.CharField(required=True),
        required=False,
        allow_empty=True
    ) 
    add=serializers.ListField(
        child=serializers.CharField(required=True),
        required=False,
        allow_empty=True
    )
    
    
    def validate(self, attrs):
        attrs = super().validate(attrs)
        circle = attrs['circle']
        user_id = self.context['request'].user.id
        member = CircleMember.objects.filter(user_id=user_id, circle_id=circle.id, accepted_at__isnull=False).first()
        if not member:
            raise serializers.ValidationError("You are not member in this circle.")
        is_admin = member.setting.get('admin', False)
        if not is_admin:
            raise serializers.ValidationError("You don't have permission to add sub circles.")
        return attrs
    
    def save(self):
        circle = self.validated_data["circle"]
        circle_id_add_list = self.validated_data.get("add", None)
        circle_id_remove_list = self.validated_data.get('remove', None)
        if circle_id_add_list:
            for child_circle_id in circle_id_add_list:
                Circle.objects.filter(id=child_circle_id).update(related_circle_id=circle.id, is_active=True)                
        if circle_id_remove_list:
            for child_circle_id in circle_id_remove_list:
                if Circle.objects.filter(id=child_circle_id).exists():
                    Circle.objects.filter(id=child_circle_id).update(is_active=False)
        return None;
    
class CirclePostSimpleSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    post = PostSimpleSerializer(read_only=True)
    class Meta:
        model = CirclePost
        fields = ("id", "post")
        
class CirclePostDetailSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    post = PostSerializer(read_only=True)
    class Meta:
        model = CirclePost
        fields = ("id", "post")
    
class CircleCreateSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    name = serializers.CharField(required=True)
    description = serializers.CharField(allow_null=True, required=False)
    creator = serializers.HiddenField(default=serializers.CurrentUserDefault())
    related_circles = serializers.ListField(
        child=serializers.CharField(allow_null=True, required=False),
        required=False,
        allow_empty=True
    )
    members = serializers.ListField(
        child=CircleMemberCreateSerializer(required=True),
        required=False,
        allow_empty=True
    )
    media_id = serializers.CharField(allow_null=True, required=False)
    is_muted = serializers.BooleanField(required=False)
    setting = CircleSettingsSerializer(required=False)

    
    class Meta:
        model = Circle
        fields = ('id', 'name', 'description', 'creator', 'related_circles', 'members', 'media_id', 'is_muted', 'is_public', 'setting')
        extra_kwargs = {
            "created_at": {"read_only": True},
        }
        
    def validate(self, attrs):
        attrs = super().validate(attrs)
        name = attrs['name']
        if name and BannedUsername.objects.filter(username=name).exists():
            raise serializers.ValidationError("Circle name restricted")
        return attrs
        
    def add_admin_self_user(self, circle):
        self_user = self.context['request'].user
        circle_creator_data = { 
            "user_id": str(self_user.id), 
            "user_invite_id": None, 
            "setting": CIRCLE_DEFAULT_CREATOR_SETTING,
            "accepted_at": timezone.now()
        }
        serializer = CircleMemberCreateSerializer(data=circle_creator_data)
        serializer.is_valid(raise_exception=True)
        serializer.save(circle=circle.id, inviter=None)
        
    def save(self, **kwargs):
        creator = self.validated_data['creator']   
        members = self.validated_data.pop('members', None)
        media_id = self.validated_data.pop('media_id', None)        
        related_circles = self.validated_data.pop('related_circles', None)
        settings = self.validated_data.pop('setting', None)
        if settings:
            settings_serializer = CircleSettingsSerializer(data=settings)
            settings_serializer.is_valid()
            self.validated_data['setting'] = settings_serializer.data
        else:
            self.validated_data['setting'] = CIRCLE_DEFAULT_SETTING
        circle_data = self.validated_data
        circle = super().save(**circle_data)
        
        self.add_admin_self_user(circle=circle)
        
        if members:
            for circle_member in members:
                serializer = CircleMemberCreateSerializer(data=circle_member)
                serializer.is_valid()
                serializer.save(circle=circle.id, inviter=creator.id)
        if media_id:
            CircleMedia.objects.filter(id=media_id).update(circle_id=circle.id)
        if related_circles:
            for child_circle_id in related_circles:
                Circle.objects.filter(id=child_circle_id).update(related_circle_id=circle.id)
        return circle
    
class CircleEditSerializer(serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)
    circle = serializers.HiddenField(default=CircleFromContext())
    name = serializers.CharField(required=False)
    media_id = serializers.CharField(required=False)
    description = serializers.CharField(required=False)
    is_muted = serializers.BooleanField(required=False)
    setting = CircleSettingsSerializer(required=False)
    
    class Meta:
        model = Circle
        fields = ('id', 'name', 'circle', 'description', 'is_muted', 'setting', 'media_id')
        
    def validate(self, attrs):
        attrs = super().validate(attrs)
        circle = attrs['circle']
        user_id = self.context['request'].user.id
        member = CircleMember.objects.filter(user_id=user_id, circle_id=circle.id, accepted_at__isnull=False).first()
        if not member:
            raise serializers.ValidationError("You are not member in this circle.")
        is_admin = member.setting.get('admin', False)
        can_edit = member.setting.get('can_edit', False)
        if not is_admin and not can_edit:
            raise serializers.ValidationError("You don't have permission to edit the circle.")
        media_id = attrs.get('media_id', None)
        if media_id and not CircleMedia.objects.filter(id=media_id).exists():
            raise serializers.ValidationError("Invalid media")
        if media_id and CircleMedia.objects.filter(id=media_id, circle_id=circle.id).exists():
            raise serializers.ValidationError("Duplicated media")
        return attrs
        
    def save(self, **kwargs):
        circle = self.validated_data["circle"]
        name = self.validated_data.get("name", None)
        description = self.validated_data.get("description", None)
        is_muted = self.validated_data.get("is_muted", None)
        setting = self.validated_data.get("setting", None)
        media_id =self.validated_data.get("media_id", None)
        with transaction.atomic():
            try:
                if name:
                    circle.name = name
                if description:
                    circle.description = description
                if is_muted:
                    circle.is_muted=is_muted
                if setting:
                    circle.setting = {**circle.setting, **setting}
                circle.save()
                circle.refresh_from_db()
            except IntegrityError:
                pass
        if media_id:
            if CircleMedia.objects.filter(circle_id=circle.id).exists():
                CircleMedia.objects.filter(circle_id=circle.id).delete()
            CircleMedia.objects.filter(id=media_id).update(circle_id=circle.id)
        return None
            
    


class CircleMembershipMixin(metaclass=serializers.SerializerMetaclass):
    membership = serializers.SerializerMethodField(read_only=True)
    inviter = serializers.SerializerMethodField(read_only=True)
    
    @swagger_serializer_method(serializer_or_field=SimpleUserSerializer)
    def get_inviter(self, obj):
        user = self.context['request'].user
        member = obj.members.filter(user_id=user.id).first()
        if member:
            return SimpleUserSerializer(member.inviter).data if member.inviter else None
        return None

    def get_membership(self, obj):
        membership = CircleMembershipType.NOT_YET
        user = self.context['request'].user
        member = obj.members.filter(user_id=user.id).first()
        member_request = obj.member_requests.filter(user_id=user.id).first()
        if member:
            accepted_at = member.accepted_at
            if accepted_at:
                member_setting = member.setting
                if member_setting and member_setting.get('admin', False) == True:
                    membership = CircleMembershipType.ADMIN
                else:
                    membership = CircleMembershipType.MEMBER
            else:
                membership = CircleMembershipType.INVITED
        elif member_request:
            membership = CircleMembershipType.REQUESTED        
        return membership

class CircleCounterSerializer(serializers.Serializer):
    posts_count = serializers.IntegerField()
    total_members_count = serializers.IntegerField()
    nested_count = serializers.IntegerField()
    joined_members_count = serializers.IntegerField()
    requested_members_count = serializers.IntegerField()
class CircleCounterMixin(metaclass=serializers.SerializerMetaclass):
    counters = serializers.SerializerMethodField(read_only=True)

    @swagger_serializer_method(serializer_or_field=CircleCounterSerializer)
    def get_counters(self, obj):
        data = {
            "posts_count": obj.posts.all().count(),
            "total_members_count": obj.members.all().count(),
            "joined_members_count": obj.members.filter(accepted_at__isnull=True).count(),
            "requested_members_count": obj.member_requests.all().count(),
            "nested_count": Circle.objects.filter(related_circle=obj).count()
        }
        return CircleCounterSerializer(data).data
    
# Need to check the permission to can see the post
# Child user can access to all circles

class CircleSimpleSerializer(CircleMembershipMixin, serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    name = serializers.CharField()
    description = serializers.CharField()
    media = serializers.CharField(source="media.media_source")
    created_at = serializers.DateTimeField()
    class Meta:
        model = Circle
        fields = ('id', 'name', 'description', 'media', 'created_at', 'membership')
class CircleBaseSerializer(CircleCounterMixin, CircleMembershipMixin, serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    creator = SimpleUserSerializer()
    media = CircleMediaResponseSerializer()
    
    class Meta:
        model = Circle
        fields = (
            'id', 
            'name', 
            'description', 
            'creator', 
            'media',
            'setting',
            'created_at',
            'is_muted',
            'is_active',
            'is_public',
            'is_verified',
            'counters',
            'membership',
            'inviter'
            )

class CircleSerializer(CircleBaseSerializer):
    parent_circle = serializers.SerializerMethodField()
    child_circles = serializers.SerializerMethodField()
    
    # TODO: Need to enable this later
    # members = CircleMemberSerializer(many=True)
    # posts = CirclePostSimpleSerializer(many=True)
    
    @swagger_serializer_method(serializer_or_field=CircleBaseSerializer(many=True))
    def get_child_circles(self, obj):
        circles = Circle.objects.filter(related_circle=obj)
        data = []
        for circle in circles:
            serializer = CircleBaseSerializer(circle, context=self.context)
            data.append(serializer.data)
        return data
    
    @swagger_serializer_method(serializer_or_field=CircleBaseSerializer)
    def get_parent_circle(self, obj):
        if obj.related_circle:
            circle = obj.related_circle
            simple_serializer = CircleBaseSerializer(circle, context=self.context)
            return simple_serializer.data
        return None
    
    class Meta:
        model = Circle
        fields = (
            'id', 
            'name', 
            'description', 
            'creator', 
            'media', 
            # TODO: Need to enable this later
            # 'members',
            # 'posts', 
            'setting',
            'parent_circle',
            'child_circles', 
            'created_at',
            'is_muted',
            'is_active',
            'is_public',
            'is_verified',
            'counters',
            'membership',
            'inviter'
            )
    

class CircleMemberRequestSerializer(serializers.Serializer):
    id = HashidSerializerCharField()
    circle = CircleSimpleSerializer()
    user = SimpleUserSerializer()
    created_at = serializers.DateTimeField()
    class Meta:
        model = CircleMemberRequest
        field=('id', 'circle', 'user', 'created_at')
        
class CircleQuestionPostCreateSerializer(serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)
    owner = serializers.HiddenField(default=serializers.CurrentUserDefault())
    text = serializers.CharField()
    title = serializers.CharField()
    class Meta:
        model = Post
        fields = (
            "id",
            "owner",
            "text",
            "title",
        )
        
    def validate(self, attrs):
        attrs = super().validate(attrs)
        if not attrs.get('text'):
            raise serializers.ValidationError({"text": "This field is required."})
        if not attrs.get('title'):
            raise serializers.ValidationError({"title": "This field is required."})
        return attrs
    
    def save(self, **kwargs):
        validate_data = self.validated_data
        validate_data["ranking"] = 5
        validate_data["visibility"] = Visibility.PUBLIC
        validate_data["type"] = PostType.CIRCLE_QUESTION
        return super().save(**validate_data)

class CircleQuestionCreateSerializer(serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)
    creator = serializers.HiddenField(default=serializers.CurrentUserDefault())
    circle = serializers.HiddenField(default=CircleFromContext())
    title = serializers.CharField(required=False)
    content = serializers.CharField(required=True)
    
    class Meta:
        model = CircleQuestion
        fields = ('id', 'creator', 'circle', 'title', 'content')
        
    def validate(self, attrs):
        attrs = super().validate(attrs)
        circle = attrs['circle']
        user_id = self.context['request'].user.id
        member = CircleMember.objects.filter(user_id=user_id, circle_id=circle.id, accepted_at__isnull=False).first()
        if not member:
            raise serializers.ValidationError("You are not member in this circle.")
        if not attrs.get('content'):
            raise serializers.ValidationError({"content": "This field is required."})
        return attrs

        
    def create_question_post(self):
        circle_name = self.validated_data.get("circle").name
        title = self.validated_data.get('title', None)
        text = self.validated_data.get("content")
        if not title:
            title = "New question in a circle " + circle_name
        data = {
            "title": title,
            "text": text
        }
        serializer = CircleQuestionPostCreateSerializer(data=data, context=self.context)
        serializer.is_valid()
        return serializer.save()
    
    def link_post_circle(self, post):
        circle = self.validated_data.get("circle")
        data = {
            "circle_id": str(circle.id),
            "post_id": str(post.id)
        }
        serializer = CirclePostCreateSerializer(data=data)
        serializer.is_valid()
        return serializer.save()
    
    def link_circle_post_question(self, question, post):
        CircleQuestion.objects.filter(id=question).update(post_id=post)
    
    def active_circle_question(self, question):
        CircleQuestion.objects.filter(id=question).update(is_active=True)
        
    def save(self, **kwargs):        
        data = self.validated_data
        circle_name = data.get("circle").name
        if not data.get("title"):
            data["title"] = circle_name + " Circle message"
        circle_question = super().save(**data)
        circle_question_post = self.create_question_post()
        self.link_post_circle(post=circle_question_post)
        self.link_circle_post_question(question=circle_question.id, post=circle_question_post.id)
        self.active_circle_question(question=circle_question.id)
        notify_circle_question_task.apply_async(args=(str(circle_question.id),), countdown=10)
        return circle_question