from django.urls import path
from rest_framework.routers import DefaultRouter

from apps.circle.api.view import (
    CircleMediaViewSet, 
    CircleViewSet, 
    CircleListViewSet, 
    CirclePostListViewSet, 
    SubCircleListViewSet, 
    CircleMemberListViewSet,
    CircleMemberRequestListViewSet
)

app_name = "circles"

router = DefaultRouter()

router.register(r"", CircleViewSet, "circles")
router.register(r"media", CircleMediaViewSet, "medias")

urlpatterns = [ 
    path("lists/", CircleListViewSet.as_view(), name="circle_user_list"),
    path('posts/<str:id>/', CirclePostListViewSet.as_view(), name="circle_post_list"),
    path('sub-circles/<str:id>/', SubCircleListViewSet.as_view(), name="sub_circle_list"),
    path('members/<str:id>/', CircleMemberListViewSet.as_view(), name="circle_member_list"),
    path('requests/<str:id>/', CircleMemberRequestListViewSet.as_view(), name="circle_member_list"),    
] +router.urls
