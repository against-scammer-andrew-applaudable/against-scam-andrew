"""
Circles API views.
"""

from django.db.models import  Q, Exists, OuterRef
from drf_yasg.utils import no_body, swagger_auto_schema
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.viewsets import ModelViewSet
from rest_framework.generics import ListAPIView, RetrieveAPIView
from rest_framework.parsers import FormParser, MultiPartParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.request import Request
from rest_framework.response import Response
from apps.users.api.authentication import JWTAuthenticationIgnoreIsActive
from apps.circle.models import Circle, CircleMedia, CircleMember, CirclePost, CircleMemberRequest, CircleQuestion
from apps.api.v1.serializers import SuccessIndicatorSerializer
from apps.posts.api.serializers import PostSerializer
from apps.posts.models import Post, Flag
from apps.posts.constants import PostType
from apps.circle.api.serializer import  (
    CircleMediaUploadSerializer, 
    CircleMediaResponseSerializer, 
    CircleSerializer, 
    CircleCreateSerializer, 
    CircleEditSerializer,
    CircleMemberEditSerializer,
    CirclePostEditSerializer,
    NestedCircleEditSerializer,
    CircleMemberInviteAcceptSerializer,
    CircleMemberLeaveSerializer,
    CircleMemberRequestJoinSerializer,
    CircleMemberRequestApproveSerializer,
    CircleSimpleSerializer,
    CircleMemberSerializer,
    CircleMemberRequestSerializer,
    CircleQuestionCreateSerializer
)
class CircleMediaViewSet(ModelViewSet):
    """
    View to handle circle's media upload
    """
    http_method_names=("post", "patch", "delete")
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)
    lookup_field = "id"
    parser_classes = (FormParser, MultiPartParser)
    serializer_class = CircleMediaUploadSerializer
    queryset = CircleMedia.objects.all()

    @swagger_auto_schema(
        request_body=CircleMediaUploadSerializer,
        responses={status.HTTP_201_CREATED: CircleMediaResponseSerializer()},
    )
    @action(detail=False, methods=("post",))
    def upload(self, request: Request):
        """
        Upload circle's media.
        """

        context = self.get_serializer_context()
        serializer = self.get_serializer(data=request.data, context=context)
        serializer.is_valid(raise_exception=True)
        instance = serializer.save()
        media_serializer = CircleMediaResponseSerializer(instance)
        return Response(status=status.HTTP_201_CREATED, data={**media_serializer.data})
    
    @swagger_auto_schema(
        request_body=CircleMediaUploadSerializer,
        responses={status.HTTP_200_OK: CircleMediaResponseSerializer()},
    )
    def partial_update(self, request: Request, *args, **kwargs):
        """
        Update circle's media.
        """
        id=kwargs['id']
        context = self.get_serializer_context()
        serializer = self.get_serializer(data=request.data, context=context)
        serializer.is_valid(raise_exception=True)
        serializer.update(id=id)
        media = CircleMedia.objects.get(id=id)
        media_serializer = CircleMediaResponseSerializer(media)
        return Response(status=status.HTTP_200_OK, data={**media_serializer.data})
    
    def destroy(self, request, *args, **kwargs):
        return super().destroy(request, *args, **kwargs)
    
    
class CircleListViewSet(ListAPIView):
    serializer_class = CircleSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)

    def get_queryset(self):
        user = self.request.user
        circle_ids = []
        circles_belonging_member = Circle.objects.filter(members__user_id=user.id)
        for circle in circles_belonging_member:
            if circle.related_circle_id:
                circle_ids.append(circle.related_circle_id)
            else:
                circle_ids.append(circle.id)
        queryset = Circle.objects.filter(id__in=circle_ids, is_active=True)
        return queryset

class CirclePostListViewSet(ListAPIView):
    serializer_class = PostSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)

    def get_queryset(self):
        id=self.kwargs["id"]
        posts_belonging_circle = CirclePost.objects.filter(circle_id=id).values('post_id')
        inactive_question_posts = CircleQuestion.objects.filter(circle_id=id, is_active=False).values('post_id')
        post_list = (
            Post.objects.get_enabled_posts()
            .filter(id__in=posts_belonging_circle)
            .exclude(
                Q(type=PostType.CIRCLE_QUESTION_REPLY) |
                Q(id__in=inactive_question_posts) |
                Q(id__in=(Flag.objects.filter(user=self.request.user).values_list("post", flat=True))) |
                Q(owner__id__in=(self.request.user.blocked_users.values_list("blocked_user", flat=True)))
            )
            .prefetch_related("media", "nupp", "owner", "visible_users", "mentions", "related_post")
            .order_by("-created_at")
        )
        return post_list
    
    
class SubCircleListViewSet(ListAPIView):
    serializer_class = CircleSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)

    def get_queryset(self):
        id=self.kwargs["id"]
        return Circle.objects.filter(is_active=True, related_circle_id=id)
    
class CircleMemberListViewSet(ListAPIView):
    serializer_class = CircleMemberSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)

    def get_queryset(self):
        id=self.kwargs["id"]
        return CircleMember.objects.filter(circle_id=id)
    
class CircleMemberRequestListViewSet(ListAPIView):
    serializer_class = CircleMemberRequestSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)

    def get_queryset(self):
        id=self.kwargs["id"]
        return CircleMemberRequest.objects.filter(circle_id=id)
class CircleViewSet(ModelViewSet):
    """
    View to handle circle update
    """
    http_method_names=('post', 'get', 'patch', )
    lookup_field = "id"
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)
    serializer_class = CircleSerializer
    queryset = Circle.objects.filter(is_active=True)
    
    @swagger_auto_schema(
        request_body=CircleCreateSerializer,
        responses={status.HTTP_201_CREATED: CircleSerializer()},
    )
    def create(self, request: Request):
        serializer = CircleCreateSerializer(data=request.data, context=self.get_serializer_context())
        serializer.is_valid(raise_exception=True)
        serializer.save()        
        response_serializer = CircleSerializer(serializer.instance, context=self.get_serializer_context())
        return Response(status=status.HTTP_201_CREATED, data=response_serializer.data)
    
    @swagger_auto_schema(
    request_body=no_body,
        responses={status.HTTP_200_OK: CircleSerializer()},
    )
    def retrieve(self, request, id: str = None, *args, **kwargs):
        circle = Circle.objects.filter(id=id).first()
        # Need to check the permission later
        serializer = CircleSerializer(circle, context=self.get_serializer_context())
        return Response(status=status.HTTP_200_OK, data=serializer.data)
        # user = self.request.user

        # if CircleMember.objects.filter(circle_id=circle.id, user_id=user.id, accepted_at__isnull=False).exists():
        #     serializer = CircleSerializer(circle, context=self.get_serializer_context())
        #     return Response(status=status.HTTP_200_OK, data=serializer.data)
        # return Response(status=status.HTTP_406_NOT_ACCEPTABLE, data={"message": "User doesn't exist or have the permission"})
    
    @swagger_auto_schema(
        request_body=CircleEditSerializer,
        responses={status.HTTP_200_OK: CircleSerializer()},
    )
    def partial_update(self, request: Request, id: str = None, *args, **kwargs):
        context = self.get_serializer_context()
        context["circle"] = id
        serializer = CircleEditSerializer(data=request.data, context=context)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        circle = Circle.objects.filter(id=id).first()
        response_serializer = CircleSerializer(circle, context=self.get_serializer_context())
        return Response(status=status.HTTP_201_CREATED, data=response_serializer.data)
    
    # Admin actions
    @swagger_auto_schema(
        request_body=CircleMemberEditSerializer,
        responses={status.HTTP_200_OK: SuccessIndicatorSerializer()},
    )
    @action(detail=True, methods=("patch",))
    def members(self, request: Request, id: str = None, *args, **kwargs):
        context = self.get_serializer_context()
        context["circle"] = id
        serializer = CircleMemberEditSerializer(data=request.data, context=context)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(status=status.HTTP_200_OK, data={"success": True})
    
    # Admin actions
    @swagger_auto_schema(
        request_body=NestedCircleEditSerializer,
        responses={status.HTTP_200_OK: SuccessIndicatorSerializer()},
    )
    @action(detail=True, methods=("patch",))
    def nested(self, request: Request, id: str = None, *args, **kwargs):
        context = self.get_serializer_context()
        context["circle"] = id
        serializer = NestedCircleEditSerializer(data=request.data, context=context)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(status=status.HTTP_200_OK, data={"success": True})
    
    # Admin actions
    @swagger_auto_schema(
        request_body=CirclePostEditSerializer,
        responses={status.HTTP_200_OK: SuccessIndicatorSerializer()},
    )
    @action(detail=True, methods=("patch",))
    def posts(self, request: Request, id: str = None, *args, **kwargs):
        context = self.get_serializer_context()
        context["circle"] = id
        serializer = CirclePostEditSerializer(data=request.data, context=context)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(status=status.HTTP_200_OK, data={"success": True})
    # User action
    # Need to add the one record to parent circle when accept
    @swagger_auto_schema(
        request_body=CircleMemberInviteAcceptSerializer,
        responses={status.HTTP_202_ACCEPTED: SuccessIndicatorSerializer()},
    )
    @action(detail=True, methods=("patch",))
    def accept(self, request: Request, id: str = None, *args, **kwargs):
        context = self.get_serializer_context()
        context["circle"] = id
        serializer = CircleMemberInviteAcceptSerializer(data=request.data, context=context)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(status=status.HTTP_202_ACCEPTED, data={"success": True})
    
    @swagger_auto_schema(
        request_body=no_body,
        responses={status.HTTP_202_ACCEPTED: SuccessIndicatorSerializer()},
    )
    @action(detail=True, methods=("patch",))
    def join(self, request: Request, id: str = None, *args, **kwargs):
        context = self.get_serializer_context()
        context["circle"] = id
        serializer = CircleMemberRequestJoinSerializer(data=request.data, context=context)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(status=status.HTTP_202_ACCEPTED, data={"success": True})
    
    @swagger_auto_schema(
        request_body=no_body,
        responses={status.HTTP_202_ACCEPTED: SuccessIndicatorSerializer()},
    )
    @action(detail=True, methods=("patch",))
    def leave(self, request: Request, id: str = None, *args, **kwargs):
        context = self.get_serializer_context()
        context["circle"] = id
        serializer = CircleMemberLeaveSerializer(data=request.data, context=context)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(status=status.HTTP_202_ACCEPTED, data={"success": True})
    
    
    # Admin actions
    @swagger_auto_schema(
        request_body=CircleMemberRequestApproveSerializer,
        responses={status.HTTP_202_ACCEPTED: SuccessIndicatorSerializer()},
    )
    @action(detail=True, methods=("patch",))
    def approve(self, request: Request, id: str = None, *args, **kwargs):
        context = self.get_serializer_context()
        context["circle"] = id
        serializer = CircleMemberRequestApproveSerializer(data=request.data, context=context)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(status=status.HTTP_202_ACCEPTED, data={"success": True})
    
    
    # Admin actions
    @swagger_auto_schema(
        request_body=CircleQuestionCreateSerializer,
        responses={status.HTTP_201_CREATED: SuccessIndicatorSerializer()},
    )
    @action(detail=True, methods=("post",))
    def question(self, request: Request, id: str = None, *args, **kwargs):
        context = self.get_serializer_context()
        context["circle"] = id
        serializer = CircleQuestionCreateSerializer(data=request.data, context=context)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(status=status.HTTP_201_CREATED, data={"success": True})
    
    @swagger_auto_schema(
        request_body=no_body,
        responses={status.HTTP_200_OK: CircleSimpleSerializer(many=True)},
    )
    @action(detail=False, methods=("get",))
    def simples(self, request: Request, id: str = None, *args, **kwargs):
        user = self.request.user
        circles = Circle.objects.filter(members__user_id=user.id, members__accepted_at__isnull=False, members__setting__can_post=True)
        data = []
        for circle in circles:
            serializer = CircleSimpleSerializer(circle, context=self.get_serializer_context())
            data.append(serializer.data)
        return Response(status=status.HTTP_200_OK, data=data)


