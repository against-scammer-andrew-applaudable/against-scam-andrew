from django.utils.translation import gettext_lazy as _

# Setting should be like this
# admin=False
# can_post=True
# can_invite=True
# can_edit=False
# Need to initialize these values when create circle
CIRCLE_DEFAULT_SETTING = {
    "admin": False,
    "can_post": True,
    "can_invite": True,
    "can_edit": False
}

CIRCLE_DEFAULT_CREATOR_SETTING = {
    "admin": True,
    "can_post": True,
    "can_invite": True,
    "can_edit": True
}


class CircleMemberType:
    USER = "user"
    INVITE = "invite"

    @classmethod
    def choices(cls):
        return (
            (cls.USER, _("user")),
            (cls.INVITE, _("invite")),
        )
        
class CircleMembershipType:
    ADMIN = "admin"
    MEMBER = "member"
    INVITED = "invited"
    REQUESTED = "requested"
    NOT_YET = "not_yet"

    @classmethod
    def choices(cls):
        return (
            (cls.ADMIN, _("admin")),
            (cls.MEMBER, _("member")),
            (cls.INVITED, _("invited")),
            (cls.REQUESTED, _("requested")),
            (cls.NOT_YET, _("not_yet")),
        )
        
class CircleNotificationType:
    MEMBER_REQUEST = "circle_user_request"
    INVITE = "circle_invite_user"
    QUESTION = "circle_question"