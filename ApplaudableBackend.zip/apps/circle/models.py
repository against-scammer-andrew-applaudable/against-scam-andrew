from django.contrib.auth import get_user_model
from django.db import models
import cloudinary
from apps.media.models import AbstractMedia
from apps.users.models import UserInvite, UserCreationInvite
from .constants import CircleMemberType
from apps.core.models import AbstractCreatedUpdatedDateMixin, AbstractMetadata, AbstractUniqueHashIDMixin, AbstractCreatedDateMixin
from apps.posts.models import Post
from apps.media.constants import MediaType
from apps.circle.notify import (
    circle_member_invite_notify,
    delete_circle_member_invite_notify,
    circle_member_request_notify, 
    delete_circle_member_request_notify,
    circle_question_notify,
    delete_circle_question_notify,
)

User = get_user_model()

# https://www.notion.so/Circles-Feature-Proposal-13110e6458fc460383409a5719e3b145

class Circle(AbstractUniqueHashIDMixin, AbstractCreatedUpdatedDateMixin):
    name = models.CharField(null=False, blank=False, max_length=255)
    description = models.TextField(null=True, blank=True, default="")
    creator = models.ForeignKey(User, on_delete=models.CASCADE, null=False)
    # Should be 1 level hierarchy
    related_circle = models.ForeignKey("self", on_delete=models.SET_NULL, related_name="related_%(class)ss", null=True, blank=True)
    is_active = models.BooleanField(default=True)
    is_public = models.BooleanField(default=False)
    is_muted = models.BooleanField(default=False)
    is_verified = models.BooleanField(default=False)
    setting = models.JSONField(blank=True, null=True, default=dict)
    

    class Meta:
        db_table = "circles"
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.id} - {self.name}"
    
    def get_icon(self):
        try:
            return self.media.media_source
        except Exception as e:
            return ''
    
    
class CircleMedia(AbstractMedia):
    """
    Circle Media model
    """
    circle = models.OneToOneField(Circle, on_delete=models.CASCADE, related_name="media", blank=True, null=True)

    class Meta:
        db_table = "circles_media"
        verbose_name = "Media"
        verbose_name_plural = "Media"
        indexes = [
            *AbstractMedia.Meta.indexes,
        ]
        
    def save(self, *args, **kwargs):
        self.type = MediaType.IMAGE
        super().save(*args, **kwargs)

class CircleMember(AbstractUniqueHashIDMixin, AbstractCreatedDateMixin):
    circle = models.ForeignKey(Circle, related_name="members", on_delete=models.CASCADE)
    inviter = models.ForeignKey(User, related_name="members_inviter", on_delete=models.CASCADE, null=True, blank=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    user_invite = models.ForeignKey(UserInvite, on_delete=models.CASCADE, null=True, blank=True)
    setting = models.JSONField(blank=True, null=True, default=dict)
    accepted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "circles_member"
        ordering = ['-created_at']
        constraints = [
            models.UniqueConstraint(fields=["circle", "user"], name="unique_circle_user"), 
            models.UniqueConstraint(fields=["circle", "user_invite"], name="unique_circle_user_invite")
        ]


    def __str__(self):
        return "circles_member"

    @property
    def object_type(self):
        if self.user_id:
            return CircleMemberType.USER
        elif self.user_invite_id:
            user = self.get_user_from_invite()
            if user:
                return CircleMemberType.USER
            return CircleMemberType.INVITE
        return None

    @property
    def member_object(self):
        if self.user_id:
            return self.user
        elif self.user_invite_id:
            user = self.get_user_from_invite()
            if user:
                return user
            return self.user_invite
        return None
    
    @property
    def member_inviter(self):
        if self.inviter_id:
            return self.inviter
        return None
    
    def get_user_from_invite(self):
        if self.user_invite_id:
            user_creation_invite = UserCreationInvite.objects.filter(invite_id=self.user_invite_id).first()
            if user_creation_invite:
                return user_creation_invite.user
            else:
                user_invite = UserInvite.objects.filter(id=self.user_invite_id, user__isnull=False).first()
                if user_invite:
                    return user_invite.user                
        return None
    
    def notify(self):
        circle_member_invite_notify(self)
        
    def delete_notify(self, user_id):
        delete_circle_member_invite_notify(self, user_id=user_id)
    
class CircleMemberRequest(AbstractUniqueHashIDMixin, AbstractCreatedDateMixin):
    circle = models.ForeignKey(Circle, related_name="member_requests", on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    class Meta:
        db_table = "circles_member_requests"
        ordering = ['-created_at']
        constraints = [
            models.UniqueConstraint(fields=["circle", "user"], name="unique_circle_user_request"), 
        ]


    def __str__(self):
        return "circles_member_requests"
    
    def notify(self):
        circle_member_request_notify(self)
    
    def delete_notify(self, user_id):
        delete_circle_member_request_notify(self, user_id=user_id)
    
class CirclePost(AbstractUniqueHashIDMixin, AbstractCreatedDateMixin):
    circle = models.ForeignKey(Circle, related_name="posts", on_delete=models.CASCADE)
    post = models.ForeignKey(Post, on_delete=models.CASCADE, null=False)
    
    class Meta:
        db_table = "circles_post"
        ordering = ['-created_at']
        constraints = [
            models.UniqueConstraint(fields=["circle", "post"], name="unique_circle_post"), 
        ]

class CircleQuestion(AbstractUniqueHashIDMixin, AbstractCreatedUpdatedDateMixin):
    circle = models.ForeignKey(Circle, related_name="questions", on_delete=models.CASCADE)
    post = models.ForeignKey(Post, related_name="posts", on_delete=models.CASCADE, null=True, blank=True)
    title = models.CharField(null=False, blank=False, max_length=255)
    content = models.TextField(null=False, blank=False, default="")
    creator = models.ForeignKey(User, on_delete=models.CASCADE, null=False)
    is_active = models.BooleanField(default=False)    
    
    class Meta:
        db_table = "circles_question"
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.title}"
    
    def notify(self):
        circle_question_notify(self)
        
    def delete_notify(self, user_id):
        delete_circle_question_notify(self, user_id=user_id)
        
    def get_icon(self):
        try:
            profile = self.creator.profile_data
            avatar = profile.avatar
            if avatar:
                return avatar.cloudinary_resource.url
            else:
                return ''
        except Exception as e:
            return ''
        
    @property
    def short_content(self):
        if len(self.content) > 80:
            return self.content[:80] + "..."
        return self.content
        
        
    @property
    def replies(self):
        result = []
        if self.post:
            reply_posts = Post.objects.filter(related_post_id=self.post.id)
            for x in reply_posts:
                result.append(str(x.id))
        return result
    
    @property
    def reply_count(self):
        if self.post:
            return Post.objects.filter(related_post_id=self.post.id).count()
        return 0


