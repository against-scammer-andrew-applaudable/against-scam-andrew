from django.contrib import admin, messages
from django.utils.translation import ngettext
from apps.circle.models import Circle, CircleMedia, CirclePost, CircleMember, CircleMemberRequest, CircleQuestion
from apps.posts.models import Post
from import_export.fields import Field
from django.contrib.auth import get_user_model
from import_export.widgets import ManyToManyWidget
from apps.core.import_export.resources import ModelResource
from import_export.widgets import DateTimeWidget, ForeignKeyWidget, ManyToManyWidget
from apps.media.admin import MediaAdmin, MediaInline
from django.db.models import F

User = get_user_model()

class CircleMediaInline(MediaInline):
    model = CircleMedia
    extra = 0
    
class CirclePostInline(admin.TabularInline):
    model = CirclePost
    extra = 0

class CircleMemberInline(admin.TabularInline):
    model = CircleMember
    extra = 0

class CircleMemberRequestInline(admin.TabularInline):
    model = CircleMemberRequest
    extra = 0
class CircleResource(ModelResource):
    creator = Field(column_name='creator', attribute='creator', widget=ForeignKeyWidget(User))
    class Meta:
        model = Circle
        fields = (
            "id",
            "name",
            "description",
            "creator",
        )

        report_skipped = False
        skip_unchanged = True
        # clean_model_instances = True

# Register your models here.
class CircleAdmin(admin.ModelAdmin):
    readonly_fields = ('related_circle',)
    list_display = ('id', 'name', 'description', 'member_count', "creator", 'related_circle', 'is_active', 'is_public', 'is_muted', 'is_verified', 'setting')
    
    ordering = ['members',]
    
    search_fields = (
        'id',
        'name',
        'description',
    )

    fieldsets = (
        (
            None,
            {
                "fields": (
                    'name',
                    'description',
                    'related_circle',
                    'is_active',
                    'is_public',
                    'is_muted',
                    'is_verified',
                    'setting',
                    "creator",
                    'member_count'
                ),
            },
        ),
    )
    resource_class = CircleResource
    inlines = [
        CircleMediaInline,
        CirclePostInline,
        CircleMemberInline,
        CircleMemberRequestInline
    ]
    
    def member_count(self, obj):
        if obj.members:
            return obj.members.count()
        return 0
    
    member_count.admin_order_field = 'members'

admin.site.register(Circle, CircleAdmin)

class CircleQuestionResource(ModelResource):
    creator = Field(column_name='creator', attribute='creator', widget=ForeignKeyWidget(User))
    post = Field(column_name='post', attribute='post', widget=ForeignKeyWidget(Post))
    circle = Field(column_name='circle', attribute='circle', widget=ForeignKeyWidget(Circle))
    class Meta:
        model = Circle
        fields = (
            "id",
            "title",
            "content",
            "creator",
            'post',
            'circle'
        )

        report_skipped = False
        skip_unchanged = True
        # clean_model_instances = True
class CircleQuestionAdmin(admin.ModelAdmin):
    readonly_fields = ('circle', 'post', 'creator', 'replies', 'reply_count')
    list_display = ('id', 'title', 'content', 'circle', 'post', 'creator', 'is_active', 'reply_count', 'created_at')
    search_fields = (
        'id',
        'title',
        'content',
    )

    fieldsets = (
        (
            None,
            {
                "fields": (
                    'title',
                    'content',
                    'circle',
                    'post',
                    'is_active',
                    'creator',
                    'replies',
                    'reply_count'
                ),
            },
        ),
    )
    resource_class = CircleQuestionResource
    # inlines = [
    #     CircleQuestionReplyInline,
    # ]

admin.site.register(CircleQuestion, CircleQuestionAdmin)