"""
Post's app notifications.
"""

from django import forms

from apps.notifications import AppNotificationDefinition, PushNotificationDefinition, register
from apps.circle.constants import CircleNotificationType
    
@register("Circle Invite User")
class CircleInviteUserPushNotification(PushNotificationDefinition):
    TYPE = CircleNotificationType.INVITE
    
    title = forms.CharField(initial="You have been invited to a circle")
    text = forms.CharField(initial="{{ actor.name }} invited you to {{scope.name}}")


@register("Circle Invite User")
class CircleInviteUserAppNotification(AppNotificationDefinition):
    TYPE = CircleNotificationType.INVITE

    title = forms.CharField(initial="You have been invited to a circle")
    text = forms.CharField(initial="{{ actor.name }} invited you to {{scope.name}}")

@register("Circle User Request")
class CircleUserRequestPushNotification(PushNotificationDefinition):
    TYPE = CircleNotificationType.MEMBER_REQUEST
    
    title = forms.CharField(initial="{{ actor.name }} wants to join your circle")
    text = forms.CharField(initial="")


@register("Circle User Request")
class CircleUserRequestAppNotification(AppNotificationDefinition):
    TYPE = CircleNotificationType.MEMBER_REQUEST

    title = forms.CharField(initial="{{ actor.name }} wants to join your circle")
    text = forms.CharField(initial="")
    
    
@register("Circle Question")
class CircleQuestionPushNotification(PushNotificationDefinition):
    TYPE = CircleNotificationType.QUESTION
    
    title = forms.CharField(initial="{{ scope.title }}")
    text = forms.CharField(initial="@{{ actor.name }} has asked: '{{ scope.short_content }}' Share your answer!")

@register("Circle Question")
class CircleQuestionAppNotification(AppNotificationDefinition):
    TYPE = CircleNotificationType.QUESTION

    title = forms.CharField(initial="{{ scope.title }}")
    text = forms.CharField(initial="@{{ actor.name }} has asked: '{{ scope.short_content }}' Share your answer!")