from apps.circle import notifications
from apps.circle.constants import CircleNotificationType

def circle_member_invite_notify(circle_member):
    from apps.notifications.utils import create_and_send_notification
    from apps.circle.constants import CircleMemberType
    
    target_type = circle_member.object_type
    target = circle_member.member_object
    actor = circle_member.member_inviter if circle_member.member_inviter else circle_member.circle.creator
    scope = circle_member.circle
    
    delivery_definitions = [notifications.CircleInviteUserAppNotification, notifications.CircleInviteUserPushNotification]

    for delivery_definition in delivery_definitions:        
        # special rule for invites
        if target_type == CircleMemberType.INVITE:
            continue

        # handle notification
        create_and_send_notification(
            delivery_definition,
            actors=[
                actor,
            ],
            scope=scope,
            target=target,
        )
        
def delete_circle_member_invite_notify(circle_member, user_id):
    from apps.notifications.utils import delete_user_notification    
    scope = circle_member.circle
    
    delete_user_notification(target_user_id=user_id, scope_model=scope, notification_type=CircleNotificationType.INVITE)
        
        
def circle_member_request_notify(circle_member_request):
    from apps.notifications.utils import create_and_send_notification

    target = circle_member_request.circle.creator
    scope = circle_member_request.circle
    actor = circle_member_request.user
    delivery_definitions = [notifications.CircleUserRequestAppNotification, notifications.CircleUserRequestPushNotification]

    for delivery_definition in delivery_definitions:        
        # handle notification
        create_and_send_notification(
            delivery_definition,
            actors=[
                actor
            ],
            scope=scope,
            target=target,
        )
        
def delete_circle_member_request_notify(circle_member_request, user_id):
    from apps.notifications.utils import delete_user_notification
    scope = circle_member_request.circle
    delete_user_notification(target_user_id=user_id, scope_model=scope, notification_type=CircleNotificationType.MEMBER_REQUEST)

        
def circle_question_notify(circle_question):
    from apps.notifications.utils import create_and_send_notification
    from apps.circle.models import CircleMember
    from apps.circle.constants import CircleMemberType
    
    
    circle_members = CircleMember.objects.filter(circle_id=circle_question.circle.id)    
    scope = circle_question
    actor = circle_question.creator
    delivery_definitions = [notifications.CircleQuestionAppNotification, notifications.CircleQuestionPushNotification]

    for circle_member in circle_members:
        if circle_member.object_type == CircleMemberType.INVITE:
            continue
        target = circle_member.member_object
        for delivery_definition in delivery_definitions:        
            # handle notification
            create_and_send_notification(
                delivery_definition,
                actors=[
                    actor
                ],
                scope=scope,
                target=target,
                metadata={
                    "circle_id": str(scope.circle_id),
                    "post_id": str(scope.post_id),
                    "question": scope.content
                },
            )
            
def delete_circle_question_notify(circle_question, user_id):
    from apps.notifications.utils import delete_user_notification
    scope = circle_question
    delete_user_notification(target_user_id=user_id, scope_model=scope, notification_type=CircleNotificationType.QUESTION)
