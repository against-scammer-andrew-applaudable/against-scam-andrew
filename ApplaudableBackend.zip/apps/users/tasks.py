import logging
from celery import shared_task
from django.contrib.auth import get_user_model
from django.db import transaction
from django.utils import timezone

from apps.users.models import EmailValidation, UserInvite, UserCreationInvite, UserCredit, PreFollow, Follow
from apps.users.utils import send_email_validation_code, allow_auth_with_test_phone
from services.twilio.client import TwilioClient
from apps.users.constants import UserCreditReferenceType

User = get_user_model()

logger = logging.getLogger(__name__)

@shared_task
def task_send_email_validation_code(user_id: str):
    """
    Send email validation code to user.

    :param user_id: user id
    """

    user = User.objects.filter(id=user_id).first()
    if not user:
        return

    email_validation, _ = EmailValidation.objects.get_or_create(user=user)
    if email_validation.is_expired():
        email_validation.save()

    send_email_validation_code(user.email, email_validation.code)


@shared_task
def task_send_sms_validation_code(phone_number: str, code: str = None):
    """
    Send SMS validation code to user.

    :param phone_number: user phone number
    :param code: validation code
    """
    is_allow_test_auth = allow_auth_with_test_phone(phone_number=phone_number, code=code)
    if not is_allow_test_auth:
        TwilioClient().send(phone_number, code)


@shared_task
def unsuspend_users():
    """
    Unsuspend users.
    """

    User.objects.filter(is_suspend=True, end_date_suspension__lte=timezone.now()).update(
        is_suspend=False,
        start_date_suspension=None,
        end_date_suspension=None,
    )


@shared_task
def task_handle_account_invites(user_id: str, invite_code: str):
    """
    Find user_invites and bind them to the created account
    """
    user = User.objects.get(id=user_id)

    UserInvite.objects.filter(user__isnull=True, email=user.email).update(user=user)
    UserInvite.objects.filter(user__isnull=True, phone_number=user.phone_number).update(user=user)

    if invite_code:
        with transaction.atomic():
            invite = UserInvite.objects.filter(invite_code=invite_code).first()
            if invite:
                UserCreationInvite.objects.create(user=user, invite=invite)
                if UserInvite.objects.filter(invite_code=invite_code, user__isnull=True).first():
                    UserInvite.objects.filter(invite_code=invite_code).update(user=user)
            else:
                invited_by = User.objects.filter(invite_code=invite_code).first()
                invite = UserInvite.objects.create(user=user, invite_code=invite_code, invited_by=invited_by)
    # Need impact the invitation
    handle_user_credit_for_invite(user_id=user_id)
    
    # handle pre-follow user
    handle_pre_follow_user(user=user)


def handle_user_credit_for_invite(user_id: str):
    """
    Find user_invites and bind them to the created account
    """
    user = User.objects.get(id=user_id)
    credit_init_point = 1
    increase_point = 1
    step = 0
    all_invites = []
    init_all_inviters = []
    # Credit reference should be phone number or email
    # For now it should be hashed string 
    credit_reference = user.phone_number
    created_at = timezone.now()
    # Need to get init inviters

    if user.phone_number:
        credit_reference = user.phone_number
        all_invites = UserInvite.objects.filter(user__isnull=False, phone_number=user.phone_number)
    elif user.email:
        credit_reference = user.email
        all_invites = UserInvite.objects.filter(user__isnull=False, email=user.email)

    for invite in all_invites:
        init_all_inviters.append(invite)
        credit_point = credit_init_point + (increase_point * step)
        UserCredit.objects.create(sender=user, receiver=invite.invited_by, reference_type=UserCreditReferenceType.USER_INVITE, reference_id=credit_reference, credit_point=credit_point, created_at=created_at)
        step = step + 1
    parent_inviters = init_all_inviters

    # Give the credit point to the inviters until no inviters
    while True:
        if parent_inviters:
            temp_inviters = []
            for inviter in parent_inviters:
                if inviter.invited_by:
                    invites = UserInvite.objects.filter(user=inviter.invited_by)
                    for invite in invites:
                        if invite.invited_by:
                            temp_inviters.append(invite)
                            # Calc the credit point based on the step 
                            credit_point = credit_init_point + (increase_point * step)
                            UserCredit.objects.create(sender=user, receiver=invite.invited_by, reference_type=UserCreditReferenceType.USER_INVITE, reference_id=credit_reference, credit_point=credit_point, created_at=created_at)
                # Increase the step
                step + 1
            parent_inviters = temp_inviters
        else:
            return
        
def handle_pre_follow_user(user):
    user_invite = UserInvite.objects.filter(phone_number=user.phone_number).first()
    if user_invite:        
        pre_follow = PreFollow.objects.filter(user_invite=user_invite).first()
        if pre_follow:
            if not Follow.objects.filter(following=user, follower=pre_follow.follower).exists():
                follow = Follow.objects.create(following=user, follower=pre_follow.follower, created_at=timezone.now())
                follow.notify()

@shared_task
def task_delete_user(user_id: str):
    """
    Delete user asynchronously.
    """

    user = User.objects.get(id=user_id)
    user.collections_type.all().delete()
    user.applauds.all().delete()
    user.nupp_set.all().update(creator=None)
    user.mentioned_posts.all().update(user=None)
    user.owned_posts.all().delete()
    user.delete()
