"""
User app utils
"""

from uuid import uuid4
import os
import requests

from django.contrib.auth import get_user_model
from django.urls import reverse
from django.utils import timezone
from phonenumber_field.serializerfields import PhoneNumberField

from apps.core.utils import domain_with_proto, generate_random_validation_code
from apps.email.utils import send
from apps.users.constants import PRE_SIGNUP_USER_FIELDS
from apps.users.emails import AdminPasswordEmail, UserEmailValidationEmail
from services.firebase.utils import generate_dynamic_link
from django.conf import settings

ENV_PREFIX = getattr(settings, "ENV_PREFIX", "local")

User = get_user_model()


def send_email_validation_code(user_email: str, code: str):
    """
    Send email validation code to user.

    :param user_email: user email address
    """

    context = {"code": code}

    send(
        UserEmailValidationEmail,
        context,
        [
            user_email,
        ],
    )


def terminate_user(user: User):
    """
    Terminate user (alters terminate status and frees its username).

    :param user: User instance
    """

    user.is_terminated = True
    user.is_active = False
    user.username = f"__terminated__{uuid4().hex}__{user.username}__{timezone.now():%Y%m%d%H%M%S}"
    user.save()


def send_admin_password_email(user_email: str, uid: str, token: str):
    """
    Send admin password email to user.

    :param user_email: user email address
    :param uid: Hashed user id (base64)
    :param token: validation token
    """

    url = reverse("password_reset_confirm", kwargs={"uidb64": uid, "token": token})
    password_reset_url = domain_with_proto(url=url)
    context = {"passwd_reset_url": password_reset_url}

    send(
        AdminPasswordEmail,
        context,
        [
            user_email,
        ],
    )


def allow_username_if_reserved(presign_user: User, username: str, phone_number: str, email: str):
    """
    Allow username if reserved username.

    :param presign_user: presign user
    :param username: username
    :param phone_number: phone number
    :param email: email
    """

    phone_number = PhoneNumberField().to_internal_value(phone_number).as_e164

    if presign_user.phone_number and presign_user.phone_number.as_e164 == phone_number:
        return True
    elif presign_user.email == email:
        return True
    return False


def acquire_invite_user_dynamic_link(user_invite):
    invite_link = domain_with_proto("/invite")
    link_url = f"{invite_link}?code={user_invite.invite_code}"
    if user_invite.email:
        link_url += f"&email={user_invite.email}"
    if user_invite.phone_number:
        link_url += f"&phone_number={user_invite.phone_number}"
    return generate_dynamic_link(link_url)


def unprocessed_user_response_data(pre_signup_user) -> dict:
    user_fields = dict()
    signup_code = ""
    missing_fields = list()
    signup_code = generate_random_validation_code()
    pre_signup_user.signup_code = signup_code
    pre_signup_user.save()

    for field in PRE_SIGNUP_USER_FIELDS:
        try:
            attr = getattr(pre_signup_user, field)
            if attr:
                if field == "phone_number":
                    user_fields[field] = attr.as_e164
                else:
                    user_fields[field] = attr
            else:
                missing_fields.append(field)
        except AttributeError:
            continue
    return {"fields": user_fields, "missing_fields": missing_fields, "code": signup_code}


def allow_auth_with_test_phone(phone_number: str, code: str = None):
    if ENV_PREFIX != 'PROD':
        test_pattern = phone_number[5: 9]
        if test_pattern == "5555":
            if code:
                return code == '543210'
            else: 
                return True
    return False