"""
User's app emails.
"""

from django import forms

from apps.email import EmailDefinition, register


@register("User Email Validation")
class UserEmailValidationEmail(EmailDefinition):
    html_template = "email/user_base_validation.html"
    text_template = "email/user_base_validation.txt"

    subject = forms.CharField(initial="{{ site.name }} - Email validation")
    title = forms.CharField(initial="Email validation")
    sub_title = forms.CharField(initial="Your validation code is {{ code }}.")
    message = forms.CharField(initial="The {{ site.name }} team", widget=forms.Textarea)

    @classmethod
    def sample_context(cls, bank):
        return {
            "code": "000000",
        }


@register("Admin Password Email")
class AdminPasswordEmail(EmailDefinition):
    html_template = "email/admin_password.html"
    text_template = "email/admin_password.txt"

    subject = forms.CharField(initial="{{ site.name }} - Set your password")
    title = forms.CharField(initial="Set your password")
    sub_title = forms.CharField(initial='Set your password using the <a href="{{ passwd_reset_url }}">following link</a>')
    message = forms.CharField(initial="The {{ site.name }} team", widget=forms.Textarea)

    @classmethod
    def sample_context(cls, bank):
        return {
            "passwd_reset_url": "https://www.applaudable.com/",
        }


@register("User Invite")
class UserInviteEmail(EmailDefinition):
    html_template = "email/user_invite.html"
    text_template = "email/user_invite.txt"

    subject = forms.CharField(initial="{{ site.name }} - Invite")
    title = forms.CharField(initial="You have been invited")
    sub_title = forms.CharField(initial='Create your account using the <a href="{{ target.invite_url }}">invite link</a>')
    message = forms.CharField(initial="The {{ site.name }} team", widget=forms.Textarea)

    @classmethod
    def sample_context(cls, bank):
        return {
            "target": {"invite_url": "https://www.applaudable.com/"},
        }
