from django.utils.translation import gettext_lazy as _

CUSTOM_USER_FORM_FIELDSET = (
    (
        None,
        {
            "fields": (
                ("id",),
                "username",
                "name",
                "email",
                "invite_code",
                "number_invites",
                "flag_count"
            )
        },
    ),
    (
        "Personal info",
        {"fields": ("phone_number",)},
    ),
    (
        "Validations",
        {
            "fields": (
                (
                    "verify",
                    "is_email_validated",
                ),
                (
                    "is_suspend",
                    "is_disabled",
                    "is_terminated",
                ),
                (
                    "start_date_suspension",
                    "end_date_suspension",
                ),
            )
        },
    ),
    (
        _("Permissions"),
        {
            "fields": (
                "is_active",
                "is_staff",
                "is_superuser",
                "groups",
                "user_permissions",
                "password",
            ),
        },
    ),
    (_("Important dates"), {"fields": ("last_login", "date_joined")}),
)
