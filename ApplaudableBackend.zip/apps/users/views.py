from django.contrib.auth import get_user_model
from django.contrib.auth.views import PasswordResetConfirmView, PasswordResetView
from django.contrib import admin

from apps.users.forms import AdminResetForm, SetAdminPasswordForm

User = get_user_model()


class RequestAdminPasswordResetView(PasswordResetView):
    email_template_name = "email/admin_password.html"
    form_class = AdminResetForm

    def get_context_data(self, **kw):
        context = super().get_context_data(**kw)
        context['site_header'] = getattr(
            admin.site, 'site_header'
        )  # get site header text. For django 2.X it should be getattr(admin.sites.AdminSite, 'site_header')
        return context


class AdminPasswordResetConfirmView(PasswordResetConfirmView):
    form_class = SetAdminPasswordForm
