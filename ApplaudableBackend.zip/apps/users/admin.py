import logging
from typing import Any, Dict, List, Optional, Tuple

from cloudinary import api
from cloudinary.exceptions import NotFound
from cloudinary.uploader import upload_resource
from django.conf import settings
from django.contrib import admin
from django.contrib.auth.admin import GroupAdmin as DjangoGroupAdmin
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin
from django.contrib.auth.models import Group as DjangoGroup
from django.http.request import HttpRequest
from django.utils.html import format_html
from rest_framework_simplejwt import token_blacklist
from import_export import resources
from import_export.admin import ImportExportModelAdmin
from import_export.widgets import ForeignKeyWidget
from apps.core.import_export.admin import ImportExportAdminMixin
from apps.core.import_export.resources import ModelResource
from import_export.fields import Field

from apps.collection.tasks import create_user_collections
from apps.users.actions import bulk_manage_user_functions
from apps.users.fieldsets import CUSTOM_USER_FORM_FIELDSET
from apps.users.forms import AdminResetForm, SubAdminAddForm, SubAdminChangeForm, UserChangeAdminForm, UserCreationAdminForm
from apps.users.models import BlockedUser, EmailValidation, Group, NonStaffUser, PreSignUpUser, Profile, ProfileAvatar, SubAdmin, User, UserInvite, BannedUsername

# Unregister Group on Django Contrib and Register here for Models Apps groups
admin.site.unregister(DjangoGroup)


@admin.register(Group)
class GroupAdmin(DjangoGroupAdmin):
    pass


class InlineInterests(admin.StackedInline):
    model = User.has_interest.through
    extra = 1


class InlineLifeMakeUp(admin.StackedInline):
    model = User.has_lifemakeup.through
    extra = 1


@admin.register(User)
class UserAdmin(DjangoUserAdmin):
    list_display = ("id", "username", "name", "e_mail", "is_active", "verify", "created_at")
    search_fields = (
        "name",
        "username",
        "email",
        "phone_number",
        "id",
    )
    readonly_fields = ["id", "last_login", "date_joined", "invite_code", "flag_count"]
    list_display_links = ("username",)
    inlines = [InlineInterests, InlineLifeMakeUp]

    form = UserChangeAdminForm
    add_form = UserCreationAdminForm
    fieldsets = CUSTOM_USER_FORM_FIELDSET
    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": (
                    "username",
                    "email",
                    "name",
                    "phone_number",
                    "password1",
                    "password2",
                ),
            },
        ),
    )

    def e_mail(self, obj):
        return obj.email

    e_mail.short_description = "E-mail"

    def flag_count(self, obj):
        return BlockedUser.objects.filter(blocked_user=obj).count()

    flag_count.short_description = "Flag count"

    @staticmethod
    def created_at(obj):
        return f"{obj.date_joined:%Y-%m-%d %H:%M:%S}"

    def get_inline_instances(self, request, obj=None):
        if not obj:
            return list()
        return super().get_inline_instances(request, obj)

    def has_change_permission(self, request, obj=None):
        if request.user.is_superuser:
            return True
        return False

    def save_model(self, request, obj, form, change):
        response = super().save_model(request, obj, form, change)
        if not change:
            create_user_collections.apply_async((str(obj.id),), countdown=3)
        return response


class EmailValidationAdmin(admin.ModelAdmin):
    list_display = ("user", "updated_at", "is_expired")
    search_fields = ("user__username", "user__email", "user__phone_number", "id")
    readonly_fields = ("id", "created_at")
    list_display_links = ("user",)
    list_select_related = ("user",)

    fieldsets = (
        (
            None,
            {
                "fields": (
                    "user",
                    "code",
                ),
            },
        ),
    )


class PreSignUpUserResource(ModelResource):
    id = Field(attribute="id", readonly=True)
    phone_number = Field(attribute="phone_number", default='')
    email = Field(attribute="email", default='')

    class Meta:
        model = PreSignUpUser

        # Although we're not importing the id field, we need to include it. The import will autoincrement it.
        # the CSV header must follow the order of the fields
        fields = ("id", "email", "username", "name", "phone_number")

        report_skipped = False
        skip_unchanged = True


@admin.register(PreSignUpUser)
class PreSignUpUserAdmin(ImportExportAdminMixin, admin.ModelAdmin):
    list_display = ("id", "name", "username", "email", "phone_number", "created_at")
    search_fields = ("name", "email", "username", "phone_number", "id")
    readonly_fields = ["id", "created_at"]
    if not settings.DEBUG:
        readonly_fields.append("signup_code")
    list_display_links = ("id", "name", "username", "email", "phone_number")

    fieldsets = (
        (
            None,
            {
                "fields": (
                    "id",
                    "name",
                    "username",
                    "email",
                    "phone_number",
                    "signup_code",
                ),
            },
        ),
    )

    # Although django-import-export docs states that resource_class is deprecated
    # (https://django-import-export.readthedocs.io/en/latest/getting_started.html?highlight=resource_class#customize-admin-import-forms),
    # its substitute resource_classes has a bug which ignores the fields declared in the resource class.
    # For now we must use the resource_class attribute.
    resource_class = PreSignUpUserResource


class OutstandingTokenAdmin(token_blacklist.admin.OutstandingTokenAdmin):
    @staticmethod
    def has_delete_permission(*args, **kwargs):
        return True


class UserResource(ModelResource):
    profile_data__location = Field(column_name="profile_data__location", attribute="profile_data__location")
    profile_data__applaudable = Field(column_name="profile_data__applaudable", attribute="profile_data__applaudable")
    profile_data__instagram_handler = Field(column_name="profile_data__instagram_handler", attribute="profile_data__instagram_handler")
    profile_data__birth_date = Field(column_name="profile_data__birth_date", attribute="profile_data__birth_date")
    profile_data__bio = Field(column_name="profile_data__bio", attribute="profile_data__bio")

    def after_save_instance(self, instance, using_transactions, dry_run):
        Profile.objects.get_or_create(
            user=instance,
            defaults={
                "location": self.profile_location,
                "applaudable": self.applaudable,
                "instagram_handler": self.instagram_handler,
                "birth_date": self.birth_date,
                "bio": self.bio,
            },
        )

    def before_import_row(self, row, **kwargs):
        username = row.get("username", '')
        self.profile_location = row.pop("profile_data__location", '')
        self.applaudable = row.pop("profile_data__applaudable", 0)
        self.instagram_handler = row.pop('profile_data__instagram_handler', '')
        self.birth_date = row.pop('profile_data__birth_date', '')
        self.bio = row.pop('profile_data__bio', '')
        user = User.objects.filter(username=username).first()
        if user:
            row['id'] = str(user.id)

    def save_instance(self, instance, is_create, using_transactions=True, dry_run=False):
        super().save_instance(instance, is_create, using_transactions, dry_run)
        if not dry_run and is_create:
            create_user_collections.apply_async((str(instance.id),), countdown=3)

    class Meta:
        model = User

        fields = (
            'id',
            'username',
            'name',
            'email',
            'phone_number',
            'verify',
            'is_email_validated',
            'is_suspend',
            'is_disabled',
            'is_terminated',
            'profile_data__location',
            'profile_data__applaudable',
            'profile_data__instagram_handler',
            'profile_data__birth_date',
            'profile_data__bio',
            'profile_data__year_only'
        )

        export_order = (
            'id',
            'username',
            'name',
            'email',
            'phone_number',
            'verify',
            'is_email_validated',
            'is_suspend',
            'is_disabled',
            'is_terminated',
            'profile_data__location',
            'profile_data__applaudable',
            'profile_data__instagram_handler',
            'profile_data__birth_date',
            'profile_data__bio',
            'profile_data__year_only'
        )

        report_skipped = False
        skip_unchanged = True


class ProfileInline(admin.StackedInline):
    readonly_fields = ("id", "created_at")
    fieldsets = (
        (
            None,
            {
                "fields": ("user", "bio", "birth_date", "location", "instagram_handler"),
            },
        ),
    )
    model = Profile


@admin.register(NonStaffUser)
class NonStaffUserAdmin(ImportExportAdminMixin, DjangoUserAdmin):
    list_display = (
        "id",
        "avatar_user",
        "username",
        "name",
        "email",
        "is_active",
        "verify",
        "is_suspend",
        "is_disabled",
        "is_terminated",
        "date_joined",
    )
    list_filter = (
        "date_joined",
        "is_active",
        "verify",
        "is_suspend",
        "is_disabled",
        "is_terminated",
    )
    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": (
                    "username",
                    "email",
                    "name",
                    "phone_number",
                    "password1",
                    "password2",
                ),
            },
        ),
    )
    fieldsets = (
        (
            None,
            {
                "fields": (
                    ("id",),
                    "avatar_user",
                    "username",
                    "name",
                    "email",
                    "invite_code",
                    "number_invites",
                    "flag_count",
                )
            },
        ),
        (
            "Personal info",
            {"fields": ("phone_number",)},
        ),
        (
            "Validations",
            {
                "fields": (
                    (
                        "verify",
                        "is_email_validated",
                    ),
                    (
                        "is_suspend",
                        "is_disabled",
                        "is_terminated",
                    ),
                    (
                        "start_date_suspension",
                        "end_date_suspension",
                    ),
                )
            },
        ),
        (
            "Permissions",
            {
                "fields": (
                    "is_active",
                    "is_staff",
                    "is_superuser",
                    "groups",
                    "user_permissions",
                    "password",
                ),
            },
        ),
        ("Important dates", {"fields": ("last_login", "date_joined")}),
    )
    readonly_fields = ["id", "last_login", "date_joined", "avatar_user", "invite_code", "flag_count"]
    list_display_links = ("username",)
    inlines = [ProfileInline]
    form = UserChangeAdminForm
    add_form = UserCreationAdminForm

    resource_class = UserResource

    def get_actions(self, request):
        actions = super().get_actions(request)
        custom_actions = {
            "bulk_suspend_users": [
                bulk_manage_user_functions,
                "bulk_suspend_users",
                "Bulk Suspend Users",
            ],
            "bulk_activate_users": [
                bulk_manage_user_functions,
                "bulk_activate_users",
                "Bulk Activate Users",
            ],
            "bulk_deactivate_users": [
                bulk_manage_user_functions,
                "bulk_deactivate_users",
                "Bulk Deactivate Users",
            ],
        }
        actions.update(custom_actions)
        return actions

    def save_model(self, request, obj, form, change):
        response = super().save_model(request, obj, form, change)
        if not change:
            create_user_collections.apply_async((str(obj.id),), countdown=3)
        return response

    def get_queryset(self, request):
        return User.objects.filter(is_staff=False, is_superuser=False)

    @admin.display(description="Avatar")
    def avatar_user(self, obj):
        if obj.profile_data:
            if obj.profile_data.avatar and obj.profile_data.avatar.image_source:
                return format_html('<img src={} width="70" height="70">', obj.profile_data.avatar.image_source.url)

    def flag_count(self, obj):
        return BlockedUser.objects.filter(blocked_user=obj).count()

    flag_count.short_description = "Flag count"


@admin.register(SubAdmin)
class SubAdminUserAdmin(DjangoUserAdmin):

    list_display = ("username", "name", "email", "is_active")
    list_filter = (
        "date_joined",
        "is_active",
        "is_disabled",
    )
    fieldsets = (
        (
            None,
            {
                "fields": (
                    ("id",),
                    "name",
                    "email",
                    "invite_code",
                    "number_invites",
                    "is_active",
                    'flag_count'
                )
            },
        ),
        ("Important dates", {"fields": ("last_login", "date_joined")}),
    )
    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": ("name", "email"),
            },
        ),
    )
    readonly_fields = ["id", "last_login", "date_joined", "invite_code", 'flag_count']
    list_display_links = ("username",)
    form = SubAdminChangeForm
    add_form = SubAdminAddForm

    def get_queryset(self, request):
        return User.objects.filter(is_staff=True, is_superuser=False)

    def response_add(self, request, obj, post_url_continue=None):
        password_form = AdminResetForm({"email": obj.email})
        if password_form.is_valid():
            password_form.save(user_change=True)
        return super().response_add(request, obj, post_url_continue)

    def response_change(self, request, obj):
        if not obj.is_email_validated:
            password_form = AdminResetForm({"email": obj.email})
            if password_form.is_valid():
                password_form.save(user_change=True)
        return super().response_change(request, obj)

    def flag_count(self, obj):
        return BlockedUser.objects.filter(blocked_user=obj).count()

    flag_count.short_description = "Flag count"


@admin.register(UserInvite)
class UserInviteAdmin(admin.ModelAdmin):
    list_display = ('__str__', 'notified_at', 'created_at')

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


admin.site.unregister(token_blacklist.models.OutstandingToken)
admin.site.register(token_blacklist.models.OutstandingToken, OutstandingTokenAdmin)

if settings.DEBUG:
    admin.site.register(EmailValidation, EmailValidationAdmin)


@admin.register(BlockedUser)
class BlockedUserAdmin(admin.ModelAdmin):
    list_display = ("user", "blocked_user", "created_at")

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    list_filter = ("created_at",)

    search_fields = (
        "user__username",
        "user__email",
        "user__phone_number",
        "blocked_user__username",
        "blocked_user__email",
        "blocked_user__phone_number",
    )


@admin.register(BannedUsername)
class BannedUsernameAdmin(admin.ModelAdmin):
    list_display = ('username', 'created_at')
    search_fields = ('username',)
    readonly_fields = ('created_at',)
