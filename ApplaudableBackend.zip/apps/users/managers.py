from django.db import models
from django.db.models import OuterRef, Exists


class ActiveUserManager(models.Manager):
    def get_queryset(self):
        return (
            super()
            .get_queryset()
            .filter(
                verify=True,
                is_terminated=False,
                is_disabled=False,
                is_suspend=False,
            )
        )


class FollowUserManager(models.Manager):
    def is_following(self, user):
        following_qs = user.following.filter(following=OuterRef('pk'))
        return self.annotate(
            is_following=Exists(following_qs)
        )

    def is_follower(self, user):
        follower_qs = user.followers.filter(follower=OuterRef('pk'))
        return self.annotate(
            is_follower=Exists(follower_qs)
        )