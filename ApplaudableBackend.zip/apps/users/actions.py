import json

from django.contrib import messages
from django.template.response import TemplateResponse

from apps.users.forms import SuspendUserForm


def suspend_users(request, data, queryset):
    form = SuspendUserForm(data)
    if not form.is_valid():
        for error in json.loads(form.errors.as_json()).get("__all__"):
            messages.error(request, error["message"])
        return

    start_date = form.cleaned_data["start_date_suspension"]
    end_date = form.cleaned_data["end_date_suspension"]
    queryset.update(
        is_suspend=True,
        start_date_suspension=start_date,
        end_date_suspension=end_date,
    )
    messages.success(
        request,
        f"{queryset.count()} users suspended successfully from \
            {start_date:%d/%m/%Y} to {end_date:%d/%m/%Y}",
    )


def bulk_manage_user_functions(modeladmin, request, queryset):
    action = request.POST["action"]

    action_descripition_mapper = {
        "bulk_activate_users": "activate",
        "bulk_deactivate_users": "deactivate",
        "bulk_suspend_users": "suspend",
    }

    action_form_mapper = {
        "bulk_suspend_users": SuspendUserForm,
    }

    action_description = action_descripition_mapper[action]
    user_info_dict = queryset.values("id", "email")

    action_context = {
        "site": modeladmin.admin_site,
        "action": action,
        "title": f"{action_description.capitalize()} Users",
        "action_description": action_description,
        "user_info_dict": user_info_dict,
        "confirmation": request.POST.get("confirmation", ""),
    }

    if action_form_mapper.get(action):
        form = action_form_mapper[action]
        action_context["form"] = form

    if request.POST.get("confirmation") is None:
        return TemplateResponse(request, "admin/base_bulk_users_management.html", action_context)

    if action == "bulk_activate_users":
        queryset.update(is_active=True)
        messages.success(request, f"{queryset.count()} users activated successfully")
    elif action == "bulk_deactivate_users":
        queryset.update(is_active=False)
        messages.success(request, f"{queryset.count()} users deactivated successfully")
    elif action == "bulk_suspend_users":
        suspend_users(request, request.POST, queryset)
