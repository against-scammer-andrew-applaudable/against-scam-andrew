from apps.users import notifications
from apps.users import emails

USER_FOLLOW = 'user_follow'
USER_INVITE = 'user_invite'
USER_DID_NOT_POST_STORY = 'user_did_not_post_story'
USER_GET_NEW_INVITES = 'user_get_new_invites'

USER_DELIVERY_NOTIFICATION_MAP = {
    USER_FOLLOW: [notifications.UserFollowPushNotification, notifications.UserFollowAppNotification],
    USER_INVITE: [notifications.UserInviteSmsNotification, emails.UserInviteEmail],
    USER_DID_NOT_POST_STORY: [notifications.UserDidNotPostStoryPushNotification],
    USER_GET_NEW_INVITES: [notifications.UserGotNewInvites],
}


def user_notify_did_not_post_story_push(user):
    from apps.notifications.utils import create_and_send_notification

    delivery_definitions = USER_DELIVERY_NOTIFICATION_MAP.get(USER_DID_NOT_POST_STORY, [])

    for delivery_definition in delivery_definitions:
        # handle notification
        create_and_send_notification(
            delivery_definition,
            actors=[],
            target=user,
            allow_duplicated=True,
        )


def user_notify_new_invites_push(user):
    from apps.notifications.utils import create_and_send_notification

    delivery_definitions = USER_DELIVERY_NOTIFICATION_MAP.get(USER_GET_NEW_INVITES, [])

    for delivery_definition in delivery_definitions:
        # handle notification
        create_and_send_notification(
            delivery_definition,
            actors=[],
            target=user,
            allow_duplicated=True,
        )


def user_follow_notify(follow):
    from apps.notifications.utils import create_and_send_notification

    delivery_definitions = USER_DELIVERY_NOTIFICATION_MAP.get(USER_FOLLOW, [])

    for delivery_definition in delivery_definitions:
        # handle notification
        create_and_send_notification(
            delivery_definition,
            actors=[
                follow.follower,
            ],
            target=follow.following,
        )


def user_invite_notify(invite):
    from apps.notifications.utils import create_and_send_notification

    if invite.user:
        return None

    delivery_definitions = USER_DELIVERY_NOTIFICATION_MAP.get(USER_INVITE, [])

    for delivery_definition in delivery_definitions:
        delivery_method = delivery_definition.delivery_method()

        # special rule for invites
        if delivery_method not in invite.allowed_delivery_methods():
            continue

        # handle notification
        create_and_send_notification(
            delivery_definition,
            actors=[
                invite.invited_by,
            ],
            target=invite,
        )
