"""
User's app notifications.
"""

from django import forms

from apps.notifications import AppNotificationDefinition, SmsNotificationDefinition, PushNotificationDefinition, register


@register("User Follow")
class UserFollowPushNotification(PushNotificationDefinition):
    TYPE = 'user_follow'

    title = forms.CharField(initial="{{ actor.name }} started following you")
    # TODO: need to update the text
    text = forms.CharField(initial="")


@register("User Follow")
class UserFollowAppNotification(AppNotificationDefinition):
    TYPE = 'user_follow'

    title = forms.CharField(initial="{{ actor.name }} started following you")
    # TODO: need to update the text
    text = forms.CharField(initial="")


@register("User Invite")
class UserInviteSmsNotification(SmsNotificationDefinition):
    TYPE = 'user_invite'

    title = forms.CharField(initial="You have been invited to join {{ site.name }}")
    text = forms.CharField(initial="Create your account using the following link {{ target.invite_url }}")


@register("Didn't Post a Story")
class UserDidNotPostStoryPushNotification(PushNotificationDefinition):
    TYPE = 'user_did_not_post_story'

    title = forms.CharField(initial="{{ target.name }} you didn't post a story today.")


@register("Got new invites")
class UserGotNewInvites(PushNotificationDefinition):
    TYPE = 'user_get_new_invites'

    title = forms.CharField(initial="{{ target.name }}, you got 3 new invites!")
