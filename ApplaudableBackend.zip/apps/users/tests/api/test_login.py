"""
Login API View Tests.
"""

from unittest.mock import MagicMock, patch

from django.contrib.auth import get_user_model
from rest_framework.test import APIRequestFactory, APITestCase

from apps.users.api.views import LoginViewSet
from apps.users.tests.factories import UserFactory

User = get_user_model()
factory = APIRequestFactory()


class LoginTestCase(APITestCase):
    """
    Tests for Login API View.
    """

    def setUp(self):
        """
        Set up test data.

        [Overrides APITestCase.setUp]
        """

        self.user = UserFactory()
        password = "Dengun2022"
        self.user.verify = True
        self.user.set_password(password)
        self.user.save()
        self.data = {"email": self.user.email, "password": password}
        self.sms_data = {"phone_number": self.user.phone_number.as_e164, "pin_code": "000000"}

    def test_email_login_verified_user(self):
        """
        Test email login response for valid and verified user.
        """

        request = factory.post(path="api/v1/login/email/", data=self.data)
        response = LoginViewSet.as_view({"post": "email"})(request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.user.id, response.data["user"]["id"])
        self.assertEqual(self.user.username, response.data["user"]["username"])
        self.assertEqual(self.user.name, response.data["user"]["name"])
        self.assertEqual(self.user.email, response.data["user"]["email"])
        self.assertEqual(2, len(response.data["token"]))

    def test_email_login_unverified_user(self):
        """
        Test email login response for valid and unverified user.
        """

        self.user.verify = False
        self.user.save()

        request = factory.post(path="api/v1/login/email/", data=self.data)
        response = LoginViewSet.as_view({"post": "email"})(request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.user.id, response.data["user"]["id"])
        self.assertEqual(self.user.username, response.data["user"]["username"])
        self.assertEqual(self.user.name, response.data["user"]["name"])
        self.assertEqual(self.user.email, response.data["user"]["email"])
        self.assertIsNone(response.data["token"])

    def test_email_login_wrong_password(self):
        """
        Test email login response for valid user but wrong password.
        """

        self.data["password"] = "2202nugneD"
        request = factory.post(path="api/v1/login/email/", data=self.data)
        response = LoginViewSet.as_view({"post": "email"})(request)

        self.assertEqual(response.status_code, 401)

    def test_email_login_wrong_user(self):
        """
        Test email login response for invalid user.
        """

        self.data["email"] = "invalid_" + self.data["email"]
        request = factory.post(path="api/v1/login/email/", data=self.data)
        response = LoginViewSet.as_view({"post": "email"})(request)

        self.assertEqual(response.status_code, 422)

    def test_email_login_missing_data(self):
        """
        Test email login response with missing request data.
        """

        self.data.pop("email")
        request = factory.post(path="api/v1/login/email/", data=self.data)
        response = LoginViewSet.as_view({"post": "email"})(request)

        self.assertEqual(response.status_code, 400)

    @patch("services.twilio.client.TwilioClient.validate")
    def test_sms_login_verified_user(self, mock_validate: MagicMock):
        """
        Test SMS login response for valid and verified user.
        """

        mock_validate.return_value = True
        request = factory.post(path="api/v1/login/sms/", data=self.sms_data)
        response = LoginViewSet.as_view({"post": "sms"})(request)

        self.assertEqual(response.status_code, 200)

    def test_sms_login_unverified_user(self):
        """
        Test SMS login response for valid and unverified user.
        """

        self.user.is_active = False
        self.user.save()

        request = factory.post(path="api/v1/login/sms/", data=self.sms_data)
        response = LoginViewSet.as_view({"post": "sms"})(request)

        self.assertEqual(response.status_code, 401)

    def test_sms_login_invalid_user(self):
        """
        Test SMS login response for invalid user.
        """

        data = self.sms_data.copy()
        phone_number = data.pop("phone_number")
        # Changing phone number state code.
        phone_number = phone_number[:3] + "3" + phone_number[4:]
        data["phone_number"] = phone_number

        request = factory.post(path="api/v1/login/sms/", data=data)
        response = LoginViewSet.as_view({"post": "sms"})(request)

        self.assertEqual(response.status_code, 422)

    @patch("services.twilio.client.TwilioClient.validate")
    def test_sms_invalid_pincode(self, mock_validate: MagicMock):
        """
        Test SMS login response for invalid pincode.
        """

        mock_validate.return_value = False
        request = factory.post(path="api/v1/login/sms/", data=self.sms_data)
        response = LoginViewSet.as_view({"post": "sms"})(request)

        self.assertEqual(response.status_code, 401)

    def test_pincode_request(self):
        """
        Test pincode request response.
        """

        data = self.sms_data.copy()
        data.pop("pin_code")
        request = factory.post(path="api/v1/login/sms/request/", data=data)
        response = LoginViewSet.as_view({"post": "pincode_request"})(request)

        self.assertEqual(response.status_code, 200)

    def test_pincode_request_missing_data(self):
        """
        Test pincode request response with missing request data.
        """

        data = {}
        request = factory.post(path="api/v1/login/sms/request/", data=data)
        response = LoginViewSet.as_view({"post": "pincode_request"})(request)

        self.assertEqual(response.status_code, 400)
