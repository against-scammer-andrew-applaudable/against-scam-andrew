"""
SearchUsersAPIView Tests.
"""

from django.contrib.auth import get_user_model
from rest_framework.test import APIRequestFactory, APITestCase, force_authenticate

from apps.users.api.views import SearchUsersAPIView
from apps.users.tests.factories import UserFactory

User = get_user_model()
factory = APIRequestFactory()


class SearchUsersAPIViewTestCase(APITestCase):
    """
    Tests for Search Users API View.
    """

    def setUp(self):
        """
        Set up test data.

        [Overrides APITestCase.setUp]
        """

        self.user = UserFactory()
        if len(self.user.username) <= 3:
            self.user.username = self.user.username + "abcd"
        self.user.verify = True
        self.user.is_active = True
        self.user.save()

    def test_search_user_valid_query(self):
        """
        Test valid search response.
        """

        username = self.user.username[:4]
        request = factory.get("api/v1/user/", {"username": username})
        force_authenticate(request, user=self.user)
        response = SearchUsersAPIView.as_view()(request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["count"], 1)
        self.assertEqual(response.data["results"][0]["id"], str(self.user.id))
        self.assertEqual(response.data["results"][0]["name"], self.user.name)

    def test_search_user_invalid_query(self):
        """
        Test empty response if username does not match.
        """

        request = factory.get("api/v1/user/", {"username": 1234})
        force_authenticate(request, user=self.user)
        response = SearchUsersAPIView.as_view()(request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["count"], 0)

    def test_empty_response_if_no_queryparam(self):
        """
        Test empty response if there's no query parameter.
        """

        request = factory.get("api/v1/user/")
        force_authenticate(request, user=self.user)
        response = SearchUsersAPIView.as_view()(request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["count"], 0)
