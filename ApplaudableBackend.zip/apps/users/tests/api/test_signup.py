from unittest.mock import MagicMock, patch

from django.contrib.auth import get_user_model
from django.utils import timezone
from rest_framework.test import APIRequestFactory, APITestCase

from apps.users.api.views import SignUpViewSet
from apps.users.models import PreSignUpUser
from apps.users.tests.factories import APIProfileSignupSerializerFactory, APIUserSerializerFactory

User = get_user_model()
factory = APIRequestFactory()


class UserSignupTestCase(APITestCase):
    def setUp(self):
        self.data = APIUserSerializerFactory()

    def test_signup(self):
        request = factory.post(path="api/v1/signup/", data=self.data)
        response = SignUpViewSet.as_view({"post": "create"})(request)

        self.assertEqual(response.status_code, 201)

        created_user = User.objects.first()

        self.assertEqual(created_user.id, response.data["user"]["id"])
        self.assertEqual(created_user.username, response.data["user"]["username"])
        self.assertEqual(created_user.name, response.data["user"]["name"])
        self.assertEqual(created_user.email, response.data["user"]["email"])
        self.assertFalse(created_user.is_active)
        self.assertFalse(created_user.verify)
        self.assertTrue(created_user.password)

    @patch("services.twilio.client.TwilioClient.validate")
    def test_validate_phone_number(self, mock_validate: MagicMock):
        mock_validate.return_value = True

        create_user_request = factory.post(path="api/v1/signup/", data=self.data)
        create_user_response = SignUpViewSet.as_view({"post": "create"})(create_user_request)

        data = {
            "phone_number": create_user_response.data["user"]["phone_number"],
            "pin_code": "000000",
        }

        user_id = create_user_response.data["user"]["id"]
        request = factory.post(path=f"api/v1/signup/{user_id}/activate/", data=data)
        response = SignUpViewSet.as_view({"post": "sms_validate"})(request, id=user_id)

        user = User.objects.first()

        self.assertEqual(response.status_code, 200)
        self.assertEqual(user.id, response.data["user"]["id"])
        self.assertEqual(user.username, response.data["user"]["username"])
        self.assertEqual(user.name, response.data["user"]["name"])
        self.assertEqual(user.email, response.data["user"]["email"])
        self.assertTrue(user.password)
        self.assertTrue(user.is_active)
        self.assertTrue(user.verify)
        self.assertEqual(2, len(response.data["token"]))

    @patch("services.twilio.client.TwilioClient.validate")
    def test_validate_invalid_pincode(self, mock_validate: MagicMock):
        mock_validate.return_value = False

        create_user_request = factory.post(path="api/v1/signup/", data=self.data)
        create_user_response = SignUpViewSet.as_view({"post": "create"})(create_user_request)

        data = {
            "phone_number": create_user_response.data["user"]["phone_number"],
            "pin_code": "000000",
        }

        user_id = create_user_response.data["user"]["id"]
        request = factory.post(path=f"api/v1/signup/{user_id}/activate/", data=data)
        response = SignUpViewSet.as_view({"post": "sms_validate"})(request, id=user_id)

        self.assertEqual(response.status_code, 401)

    def test_validate_invalid_user_id(self):
        data = {
            "phone_number": "+5527999999999",
            "pin_code": "000000",
        }

        request = factory.post(path="api/v1/signup/invalid_id/activate/", data=data)
        response = SignUpViewSet.as_view({"post": "sms_validate"})(request, id="invalid_id")

        self.assertEqual(response.status_code, 404)

    def test_minor_user_signup_error(self):
        """
        Test that a minor user cannot sign up
        """

        data = self.data.copy()
        data["birth_date"] = timezone.now().strftime("%Y-%m-%d")
        request = factory.post(path="api/v1/signup/", data=data)
        response = SignUpViewSet.as_view({"post": "create"})(request)
        self.assertEqual(response.status_code, 400)

    def test_profile_data(self):
        """
        Test Sign-up user's profile creation.
        """

        data = self.data.copy()
        profile_data = APIProfileSignupSerializerFactory()
        data.update(profile_data)
        request = factory.post(path="api/v1/signup/", data=data)
        response = SignUpViewSet.as_view({"post": "create"})(request)

        user_profile = User.objects.first().profile_data

        self.assertEqual(response.status_code, 201)
        self.assertEqual(user_profile.bio, profile_data["bio"])
        self.assertEqual(user_profile.instagram_handler, profile_data["instagram_handler"])
        self.assertEqual(user_profile.location, profile_data["location"])

    def test_reserved_username_correct_email(self):
        """
        Test that a user can sign up with a reserved username if the email is correct.
        """

        PreSignUpUser.objects.create(email=self.data["email"], username=self.data["username"])
        request = factory.post(path="api/v1/signup/", data=self.data)
        response = SignUpViewSet.as_view({"post": "create"})(request)
        self.assertEqual(response.status_code, 201)

    def test_reserved_username_correct_phone_number(self):
        """
        Test that a user can sign up with a reserved username if the phone number is correct.
        """

        PreSignUpUser.objects.create(phone_number=self.data["phone_number"], username=self.data["username"])
        request = factory.post(path="api/v1/signup/", data=self.data)
        response = SignUpViewSet.as_view({"post": "create"})(request)
        self.assertEqual(response.status_code, 201)

    def test_reserved_username_incorrect_email(self):
        """
        Test that a user cannot sign up with a reserved username if the email is incorrect.
        """

        PreSignUpUser.objects.create(email=self.data["email"][1:], username=self.data["username"])
        request = factory.post(path="api/v1/signup/", data=self.data)
        response = SignUpViewSet.as_view({"post": "create"})(request)
        self.assertEqual(response.status_code, 400)

    def test_reserved_username_incorrect_phone_number(self):
        """
        Test that a user cannot sign up with a reserved username if the phone number is incorrect.
        """

        wrong_phone_number = self.data["phone_number"][:2] + str(abs(int(self.data["phone_number"][3]) - 2)) + self.data["phone_number"][4:]
        PreSignUpUser.objects.create(phone_number=wrong_phone_number, username=self.data["username"])
        request = factory.post(path="api/v1/signup/", data=self.data)
        response = SignUpViewSet.as_view({"post": "create"})(request)
        self.assertEqual(response.status_code, 400)

    def test_reserved_username_incorrect_phone_correct_email(self):
        """
        Test that a user can sign up with a reserved username if the phone number is incorrect but the email is correct.
        """

        wrong_phone_number = self.data["phone_number"][:2] + str(abs(int(self.data["phone_number"][3]) - 2)) + self.data["phone_number"][4:]
        PreSignUpUser.objects.create(phone_number=wrong_phone_number, email=self.data["email"], username=self.data["username"])
        request = factory.post(path="api/v1/signup/", data=self.data)
        response = SignUpViewSet.as_view({"post": "create"})(request)
        self.assertEqual(response.status_code, 201)

    def test_reserved_username_correct_phone_incorrect_email(self):
        """
        Test that a user can sign up with a reserved username if the phone number is correct but the email is incorrect.
        """

        PreSignUpUser.objects.create(phone_number=self.data["phone_number"], email=self.data["email"][1:], username=self.data["username"])
        request = factory.post(path="api/v1/signup/", data=self.data)
        response = SignUpViewSet.as_view({"post": "create"})(request)
        self.assertEqual(response.status_code, 201)
