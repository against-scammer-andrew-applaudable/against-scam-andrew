"""
Follow API View Tests.
"""

from django.contrib.auth import get_user_model
from rest_framework.test import APIRequestFactory, APITestCase, force_authenticate

from apps.users.api.views import FollowAPIView
from apps.users.tests.factories import UserFactory

User = get_user_model()
factory = APIRequestFactory()


class FollowAPITestCase(APITestCase):
    """
    Tests for Follow API View.
    """

    def setUp(self):
        """
        Set up test data.

        [Overrides APITestCase.setUp]
        """

        self.user = UserFactory()
        self.second_user = UserFactory()
        self.user.verify = True
        self.user.is_active = True
        self.second_user.verify = True
        self.second_user.is_active = True
        self.user.save()
        self.second_user.save()

    def test_follow_user(self):
        """
        Test follow user response.
        """

        request = factory.post(path=f"api/v1/user/{self.second_user.id}/follow/")
        force_authenticate(request, user=self.user)
        response = FollowAPIView.as_view()(request, id=str(self.second_user.id))

        self.assertEqual(response.status_code, 201)
        self.assertEqual(self.user.following.count(), 1)
        self.assertEqual(self.second_user.followers.count(), 1)

    def test_unfollow_user(self):
        """
        Test unfollow user.
        """

        follow_request = factory.post(path=f"api/v1/user/{self.second_user.id}/follow/")
        force_authenticate(follow_request, user=self.user)
        FollowAPIView.as_view()(follow_request, id=str(self.second_user.id))

        request = factory.delete(path=f"api/v1/user/{self.second_user.id}/follow/")
        force_authenticate(request, user=self.user)
        response = FollowAPIView.as_view()(request, id=str(self.second_user.id))

        self.assertEqual(response.status_code, 202)
        self.assertEqual(self.user.following.count(), 0)
        self.assertEqual(self.second_user.followers.count(), 0)
