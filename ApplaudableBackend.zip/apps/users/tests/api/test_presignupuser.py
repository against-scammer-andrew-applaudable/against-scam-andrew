from unittest.mock import MagicMock, patch

from django.contrib.auth import get_user_model
from rest_framework.test import APIRequestFactory, APITestCase

from apps.users.api.views import LoginViewSet, SignUpViewSet
from apps.users.models import PreSignUpUser

User = get_user_model()


class PreSignUpUserTestCase(APITestCase):
    def setUp(self):
        self.pre_user = PreSignUpUser.objects.create(phone_number="+5511999999999", name="Test User", email="testuser@applaudable.com")
        self.signup_data = {
            "username": "testuser",
            "name": "Test User",
            "password": "TestPasswordDengun123",
            "birth_date": "1990-01-01",
            "location": "Moon",
            "instagram_handler": "testuser",
            "bio": "Test User Bio",
        }

    @patch("services.twilio.client.TwilioClient.validate")
    @patch("services.twilio.client.TwilioClient.send")
    def test_presignupuser_sms_login(self, mock_send_sms: MagicMock, mock_validate_sms: MagicMock):
        mock_validate_sms.return_value = True

        data = {"phone_number": self.pre_user.phone_number.as_e164}
        pincode_request = APIRequestFactory().post(path="api/v1/login/sms/request/", data=data)
        pincode_response = LoginViewSet.as_view({"post": "pincode_request"})(pincode_request)

        self.assertEqual(pincode_response.status_code, 200)

        login_data = {**data, "pin_code": "000000"}
        login_request = APIRequestFactory().post(path="api/v1/login/sms", data=login_data)
        login_response = LoginViewSet.as_view({"post": "sms"})(login_request)

        self.assertEqual(login_response.status_code, 422)
        self.assertEqual(set(login_response.data["fields"].keys()), {"email", "phone_number"})
        self.assertEqual(login_response.data["missing_fields"], ["username"])
        self.assertIsNotNone(login_response.data["code"])

        signup_data = {**self.signup_data, **login_response.data["fields"], "code": login_response.data["code"]}

        signup_request = APIRequestFactory().post(path="api/v1/signup/", data=signup_data)
        signup_response = SignUpViewSet.as_view({"post": "create"})(signup_request)
        self.assertEqual(signup_response.status_code, 201)
        self.assertEqual(signup_response.data["user"]["username"], signup_data["username"])
        self.assertEqual(signup_response.data["user"]["email"], signup_data["email"])
        self.assertEqual(signup_response.data["user"]["phone_number"], signup_data["phone_number"])
        self.assertEqual(signup_response.data["user"]["location"], signup_data["location"])
        self.assertEqual(signup_response.data["user"]["instagram_handler"], signup_data["instagram_handler"])
        self.assertEqual(signup_response.data["user"]["bio"], signup_data["bio"])
        self.assertTrue(User.objects.first().verify)
        self.assertTrue(signup_response.data["user"]["is_active"])
        self.assertEqual(len(signup_response.data["token"]), 2)

    def test_presignupuser_email_login(self):
        login_data = {"email": self.pre_user.email, "password": "TestPasswordDengun123"}

        login_request = APIRequestFactory().post(path="api/v1/login/email/", data=login_data)
        login_response = LoginViewSet.as_view({"post": "email"})(login_request)

        self.assertEqual(login_response.status_code, 422)
        self.assertEqual(set(login_response.data["fields"].keys()), {"email", "phone_number"})
        self.assertEqual(login_response.data["missing_fields"], ["username"])
        self.assertIsNotNone(login_response.data["code"])

        signup_data = {**self.signup_data, **login_response.data["fields"], "code": login_response.data["code"]}

        signup_request = APIRequestFactory().post(path="api/v1/signup/", data=signup_data)
        signup_response = SignUpViewSet.as_view({"post": "create"})(signup_request)
        self.assertEqual(signup_response.status_code, 201)
        self.assertEqual(signup_response.data["user"]["username"], signup_data["username"])
        self.assertEqual(signup_response.data["user"]["email"], signup_data["email"])
        self.assertEqual(signup_response.data["user"]["phone_number"], signup_data["phone_number"])
        self.assertEqual(signup_response.data["user"]["location"], signup_data["location"])
        self.assertEqual(signup_response.data["user"]["instagram_handler"], signup_data["instagram_handler"])
        self.assertEqual(signup_response.data["user"]["bio"], signup_data["bio"])
        self.assertTrue(User.objects.first().verify)
        self.assertTrue(signup_response.data["user"]["is_active"])
        self.assertEqual(len(signup_response.data["token"]), 2)
