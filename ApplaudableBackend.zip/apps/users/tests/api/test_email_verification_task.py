from unittest.mock import MagicMock, patch

from django.contrib.auth import get_user_model
from rest_framework.test import APIRequestFactory, APITestCase, force_authenticate

from apps.users.api.views import EmailValidationViewSet
from apps.users.models import EmailValidation
from apps.users.tests.factories import UserFactory

User = get_user_model()
factory = APIRequestFactory()


class UserEmailVerificationTestCase(APITestCase):
    """
    Test user's email verification API.
    """

    def setUp(self):
        """
        Set up test data.

        [Overrides APITestCase.setUp]
        """

        self.user = UserFactory()

        self.email_verification = EmailValidation.objects.create(user=self.user)
        self.data = {"code": self.email_verification.code}

    def test_email_validation(self):
        """
        Test user's email validation.
        """

        self.assertFalse(self.user.is_email_validated)

        request = factory.post(path="api/v1/user/email-validation/validate/", data=self.data)
        force_authenticate(request, user=self.user)
        response = EmailValidationViewSet.as_view({"post": "validate"})(request)

        self.assertEqual(response.status_code, 200)
        self.assertTrue(self.user.is_email_validated)
        self.assertIsNone(EmailValidation.objects.filter(user=self.user).first())

    def test_email_validation_wrong_code(self):
        """
        Test user's email validation with wrong code.
        """

        self.assertFalse(self.user.is_email_validated)
        data = self.data.copy()
        data["code"] = "wrong_code"
        request = factory.post(path="api/v1/user/email-validation/validate/", data=data)
        force_authenticate(request, user=self.user)
        response = EmailValidationViewSet.as_view({"post": "validate"})(request)

        self.assertEqual(response.status_code, 400)
        self.assertFalse(self.user.is_email_validated)
        self.assertTrue(EmailValidation.objects.filter(user=self.user).first())

    @patch("apps.users.models.EmailValidation.is_expired")
    def test_email_validation_expired_code(self, mock_is_expired: MagicMock):
        """
        Test user's email validation with expired code.
        """

        mock_is_expired.return_value = True

        self.assertFalse(self.user.is_email_validated)
        request = factory.post(path="api/v1/user/email-validation/validate/", data=self.data)
        force_authenticate(request, user=self.user)
        response = EmailValidationViewSet.as_view({"post": "validate"})(request)

        self.assertEqual(response.status_code, 400)
        self.assertFalse(self.user.is_email_validated)
        self.assertTrue(EmailValidation.objects.filter(user=self.user).first())
