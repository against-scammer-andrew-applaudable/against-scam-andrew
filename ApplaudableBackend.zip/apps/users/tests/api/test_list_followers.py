"""
ListFollowersAPIView Tests.
"""

from django.contrib.auth import get_user_model
from rest_framework.test import APIRequestFactory, APITestCase, force_authenticate

from apps.users.api.views import FollowAPIView, ListFollowersAPIView
from apps.users.tests.factories import UserFactory

User = get_user_model()
factory = APIRequestFactory()


class ListFollowersAPIViewTestCase(APITestCase):
    """
    Tests for User Followers API View.
    """

    def setUp(self):
        """
        Set up test data.

        [Overrides APITestCase.setUp]
        """

        self.user = UserFactory()
        self.second_user = UserFactory()
        self.user.verify = True
        self.user.is_active = True
        self.second_user.verify = True
        self.second_user.is_active = True
        self.user.save()
        self.second_user.save()
        request = factory.post(path=f"api/v1/user/{self.second_user.id}/follow/")
        force_authenticate(request, user=self.user)
        FollowAPIView.as_view()(request, id=str(self.second_user.id))

    def test_list_followers(self):
        """
        Test list followers response.
        """

        request = factory.get(path=f"api/v1/user/{self.second_user.id}/followers/")
        force_authenticate(request, user=self.second_user)
        response = ListFollowersAPIView.as_view()(request, id=self.second_user.id)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["count"], 1)
        self.assertEqual(response.data["results"][0]["id"], str(self.user.id))
        self.assertEqual(response.data["results"][0]["name"], self.user.name)
