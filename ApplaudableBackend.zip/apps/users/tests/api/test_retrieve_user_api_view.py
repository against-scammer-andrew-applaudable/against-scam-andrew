"""
RetrieveUserAPIView Tests.
"""

from django.contrib.auth import get_user_model
from rest_framework.test import APIRequestFactory, APITestCase, force_authenticate

from apps.users.api.views import FollowAPIView, RetrieveUserAPIView
from apps.users.tests.factories import UserFactory

User = get_user_model()
factory = APIRequestFactory()


class RetrieveUserAPIViewTestCase(APITestCase):
    """
    Tests for Retrieve User API View.
    """

    def setUp(self):
        """
        Set up test data.

        [Overrides APITestCase.setUp]
        """

        self.user = UserFactory(verify=True, is_active=True)
        self.second_user = UserFactory(verify=True, is_active=True)
        self.inactive_user = UserFactory(is_active=False)

    def test_retrieve_user_not_following(self):
        """
        Test retrieve user which is not followed.
        """

        request = factory.get(f"api/v1/user/{self.second_user.id}/")
        force_authenticate(request, user=self.user)
        response = RetrieveUserAPIView.as_view()(request, id=str(self.second_user.id))

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["id"], str(self.second_user.id))
        self.assertFalse(response.data["engagement"]["following"])

    def test_retrieve_user_following(self):
        """
        Test retrieve user which is followed.
        """

        request = factory.post(f"api/v1/user/{self.second_user.id}/follow/")
        force_authenticate(request, user=self.user)
        response = FollowAPIView.as_view()(request, id=str(self.second_user.id))

        request = factory.get(f"api/v1/user/{self.second_user.id}/")
        force_authenticate(request, user=self.user)
        response = RetrieveUserAPIView.as_view()(request, id=str(self.second_user.id))

        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.data["engagement"]["following"])

    def test_retrieve_user_inactive(self):
        """
        Test retrieve user which is inactive.
        """

        request = factory.get(f"api/v1/user/{self.inactive_user.id}/")
        force_authenticate(request, user=self.user)
        response = RetrieveUserAPIView.as_view()(request, id=str(self.inactive_user.id))

        self.assertEqual(response.status_code, 404)
