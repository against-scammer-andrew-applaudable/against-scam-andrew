"""
User's test factories.
"""

import random

import factory
from django.contrib.auth import get_user_model
from faker import Faker

from apps.users.tests.base import faker
from apps.users.models import Profile

User = get_user_model()


def random_address():
    """
    Generate a random address.
    """

    address = faker.address()[:40]
    return address


def random_phone_number():
    """
    Generate a random phone number.
    """

    random_number = f"+5527{random.randint(900000000,999999999)}"
    return random_number


def random_valid_birthdate():
    """
    Generate a random valid birthdate.
    """

    fake = Faker(locale="en_US")
    return fake.date_time_between(start_date="-100y", end_date="-18y").strftime("%Y-%m-%d")


class UserFactory(factory.django.DjangoModelFactory):
    """
    Django User instance factory.
    """

    class Meta:
        model = User

    name = factory.LazyAttribute(lambda _: faker.unique.name())
    email = factory.LazyAttribute(lambda _: faker.unique.email())
    username = factory.LazyAttribute(lambda _: faker.unique.user_name())
    password = factory.LazyAttribute(lambda _: faker.password())
    phone_number = factory.LazyAttribute(lambda _: random_phone_number())


class ProfileFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Profile

    location = "Test Av., 40, Faro, Portugal"
    instagram_handler = factory.LazyAttribute(lambda _: faker.user_name())
    bio = factory.LazyAttribute(lambda _: faker.text())
    birth_date = factory.LazyAttribute(lambda _: random_valid_birthdate())
    user = factory.SubFactory(UserFactory)


class APIUserSerializerFactory(factory.DictFactory):
    """
    User serializer factory.
    """

    name = factory.LazyAttribute(lambda _: faker.unique.name())
    email = factory.LazyAttribute(lambda _: faker.unique.email())
    username = factory.LazyAttribute(lambda _: faker.unique.user_name())
    password = factory.LazyAttribute(lambda _: faker.password())
    phone_number = factory.LazyAttribute(lambda _: random_phone_number())
    birth_date = factory.LazyAttribute(lambda _: random_valid_birthdate())


class APIProfileSignupSerializerFactory(factory.DictFactory):
    """
    User's profile sign-up serializer factory.
    """

    location = "Test Av., 40, Faro, Portugal"
    instagram_handler = factory.LazyAttribute(lambda _: faker.user_name())
    bio = factory.LazyAttribute(lambda _: faker.text())
    birth_date = factory.LazyAttribute(lambda _: random_valid_birthdate())
