from django.utils.translation import gettext_lazy as _

PRE_SIGNUP_USER_FIELDS = ["username", "email", "phone_number"]

TERMINATED_USERNAME_REGEX_PATTERN = r"^__terminated__[a-f0-9]{32}__(?P<username>.+)__[0-9]{14}$"

# TODO: Need to add more type this later
class UserCreditReferenceType:
    USER_INVITE = "user_invite"

    @classmethod
    def choices(cls):
        return (
            (cls.USER_INVITE, _("user_invite")),
        )
        
class PreFollowUserReturnType:
    FOLLOW = "follow"
    REVERSE_CONTACT = "reverse_contact"
    PRE_FOLLOW_HASH = "pre_follow_hash"
    OTHERWISE = "otherwise"
    
    
    @classmethod
    def choices(cls):
        return (
            (cls.FOLLOW, _("follow")),
            (cls.REVERSE_CONTACT, _("reverse_contact")),
            (cls.PRE_FOLLOW_HASH, _("pre_follow_hash")),
            (cls.OTHERWISE, _("otherwise")),
        )