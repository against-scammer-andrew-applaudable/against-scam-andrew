import contextlib
from django.contrib.auth import get_user_model
from django_filters import rest_framework as filters

from apps.api.filters import UsernameTrigramSimilarityFilter
from django.db.models import Q


User = get_user_model()


class UserFilter(UsernameTrigramSimilarityFilter):
    """
    User filter
    """

    class Meta:
        model = User
        fields = ("username",)


class UserSearchFilter(filters.FilterSet):
    username = filters.CharFilter(method='q_filter')
    class Meta:
        model = User
        fields = ("username",)
    

    def q_filter(self, queryset, name, value):
        with contextlib.suppress(IndexError, TypeError, ValueError):
            if value == '':
                return queryset
            return queryset.filter(Q(username__icontains=value) | Q(name__icontains=value) | Q(name__trigram_similar=value) | Q(username__trigram_similar=value))
        return queryset