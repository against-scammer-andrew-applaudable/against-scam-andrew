"""
Users API routes.
"""

from django.urls import path
from rest_framework import routers

from apps.users.api.views import (
    AvatarUploadAPIView,
    BlockUserAPIView,
    DeleteUserViewSet,
    EmailValidationViewSet,
    FollowAPIView,
    InviteCountAPIView,
    ListFollowersAPIView,
    ListFollowingAPIView,
    RetrieveUserAPIView,
    SearchUsersAPIView,
    UnblockUserAPIView,
    UserStoriesAPIView,
    UserInviteAPIView,
    ValidInviteAPIView,
    SearchAllUsersAPIView,
    UsernameUpdateApiViewSet,
    UserAddressBookViewSet,
    PreFollowViewSet
)

app_name = "user"

router = routers.SimpleRouter()
router.register("email-validation", EmailValidationViewSet, basename="email-validation")
router.register(r"delete-account", DeleteUserViewSet, basename="delete-account")
router.register(r"update", UsernameUpdateApiViewSet, basename="username-update")

urlpatterns = [
    path("avatar/upload/", AvatarUploadAPIView.as_view(), name="avatar-upload"),
    path("invite/valid/<str:invite_code>/", ValidInviteAPIView.as_view(), name="valid-invite"),
    path("invite/count/", InviteCountAPIView.as_view(), name="invite-count"),
    path("invite/", UserInviteAPIView.as_view(), name="user-invites"),
    path("address-book/", UserAddressBookViewSet.as_view(), name="user-address-book"),
    path("pre-follow/", PreFollowViewSet.as_view(), name="pre-follow"),
    path("search/", SearchAllUsersAPIView.as_view({'get': 'list'}), name="search-all-users"),
    path("<str:id>/block/", BlockUserAPIView.as_view(), name="block-user"),
    path("<str:id>/unblock/", UnblockUserAPIView.as_view(), name="unblock-user"),
    path("<str:id>/follow/", FollowAPIView.as_view(), name="follow-user"),
    path("<str:id>/followers/", ListFollowersAPIView.as_view(), name="list-followers"),
    path("<str:id>/following/", ListFollowingAPIView.as_view(), name="list-following"),
    path("<str:id>/", RetrieveUserAPIView.as_view(), name="retrieve-user"),
    path("<str:id>/stories/", UserStoriesAPIView.as_view(), name="retrieve-stories-user"),
    path("", SearchUsersAPIView.as_view(), name="search-users"),
] + router.urls
