"""
Users API views.
"""

import logging
import datetime

from django.conf import settings
from django.contrib.auth import get_user_model
from django.db.models import Exists, OuterRef, Q
from django.shortcuts import get_object_or_404
from django_filters.rest_framework import DjangoFilterBackend
from drf_yasg.utils import no_body, swagger_auto_schema
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.generics import GenericAPIView, ListAPIView, RetrieveAPIView, ListCreateAPIView
from rest_framework.parsers import FormParser, MultiPartParser
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.viewsets import GenericViewSet, ModelViewSet
from geopy.geocoders import Nominatim

from apps.api.exceptions import InvalidPincode, UnprocessableEntityError, InvalidCode
from apps.api.v1.serializers import SuccessIndicatorSerializer
from apps.collection.models import CollectionType
from apps.core.utils import get_or_create_model_object
from apps.posts.models import Post
from apps.user_auth.utils import get_tokens_for_user
from apps.users.utils import allow_auth_with_test_phone
from apps.users.api.authentication import JWTAuthenticationIgnoreIsActive
from apps.users.api.serializers import (
    AvatarResponseSerializer,
    AvatarUploadSerializer,
    CollectionTypeStorySerializer,
    EmailLoginSerializer,
    EmailValidationSerializer,
    FollowSerializer,
    LoginResponseSerializer,
    PhoneNumberSerializer,
    PinCodeSerializer,
    SignUpSerializer,
    SimpleUserSerializer,
    SMSLoginSerializer,
    UserInfoSerializer,
    UserInviteSerializer,
    UserInviteCreateSerializer,
    FollowUserSerializer,
    NumberInviteCountSerializer,
    UserInfoCheckSerializer,
    LocationMetadataSerializer,
    UsernameEditSerializer,
    UserAddressBookCreateSerializer,
    UserAddressBookResponseSerializer,
    PreFollowSerializer
)
from apps.users.constants import PRE_SIGNUP_USER_FIELDS
from apps.users.filters import UserFilter, UserSearchFilter
from apps.users.models import PreSignUpUser, UserInvite, BlockedUser, BannedUsername
from apps.users.tasks import task_delete_user, task_send_email_validation_code, task_send_sms_validation_code
from apps.users.utils import unprocessed_user_response_data
from services.twilio.client import TwilioClient

User = get_user_model()


def get_user_tokens_and_data(user: User) -> dict:
    """
    Get the user's tokens and data for login and sign-up process.

    :param user: User object

    :return: Serialized token and user data
    """
    user.last_login = datetime.datetime.now()
    user.save()
    return LoginResponseSerializer({"token": get_tokens_for_user(user), "user": user}).data


class SignUpViewSet(GenericViewSet):
    """
    Viewset to process sign-up requests.
    """

    permission_classes = (AllowAny,)
    lookup_field = "id"
    queryset = User.objects.none()
    
    def get_location_metadata(self, data):
        location_metadata = data.get('location_metadata', {})
        location_metadata.setdefault('country', '')
        location_metadata.setdefault('city', '')
        location_metadata.setdefault('state', '')
        lat = location_metadata.get('lat', None)
        long = location_metadata.get('long', None)

        if lat and long:
            geolocator = Nominatim(user_agent="applaudable")
            location = geolocator.reverse(str(lat)+","+str(long))
            address = location.raw['address']
            location_metadata['city'] = address.get('city', '')
            location_metadata['state'] = address.get('state', '')
            location_metadata['country'] = address.get('country', '')
            serializer = LocationMetadataSerializer(location_metadata)
            return serializer.data
        return {}

    @swagger_auto_schema(
        request_body=SignUpSerializer,
        responses={status.HTTP_201_CREATED: LoginResponseSerializer},
    )
    def create(self, request: Request, *args, **kwargs) -> Response:
        """
        Create user and return instance data and tokens.

        :return: Response object

        [Overrides GenericViewSet.create]
        """
        
        signup_data = {
            **request.data, 
            "location_metadata": self.get_location_metadata(data=request.data)
        }
        serializer = SignUpSerializer(data=signup_data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        print("verify", user.verify)

        if not user.verify:
            task_send_sms_validation_code.delay(user.phone_number.as_e164)

        return Response(status=status.HTTP_201_CREATED, data=get_user_tokens_and_data(user))

    @swagger_auto_schema(
        request_body=PinCodeSerializer,
        responses={status.HTTP_200_OK: LoginResponseSerializer},
    )
    @action(
        methods=("post",),
        detail=True,
        name="Activate account via SMS validation",
        url_path="activate",
        url_name="sms-activation",
    )
    def sms_validate(self, request: Request, id: str) -> Response:
        """
        Validate SMS code for given phone number.

        :param id: unverified user's id

        :return: The following response objects
            `Succesful - status 200, token + user's data body`

            Invalid Code - status 401, empty body
        """

        user = get_object_or_404(User, id=id)
        serializer = PinCodeSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        is_allow_sms_for_test = allow_auth_with_test_phone(phone_number=user.phone_number.as_e164, code=serializer.data["pin_code"])
        if is_allow_sms_for_test:
            return Response(status=status.HTTP_200_OK)
        is_code_valid = TwilioClient().validate(phone_number=user.phone_number.as_e164, code=serializer.data["pin_code"])
        if is_code_valid:
            user.verify = True
            user.is_active = True
            user.save()
            return Response(status=status.HTTP_200_OK, data=get_user_tokens_and_data(user))
        raise InvalidPincode({"pincode": "Invalid Pincode"})


    @swagger_auto_schema(
        request_body=SMSLoginSerializer,
        responses={status.HTTP_200_OK: ""},
    )
    @action(
        methods=("post",),
        detail=False,
        name="Validate the SMS pincode",
        url_path="sms/validate",
        url_name="sms-validate",
    )
    def sms_validate_without_id(self, request: Request) -> Response:
        """
        Validate SMS code for given phone number.
        :return: The following response objects
            `Succesful - status 200`

            Invalid Code - status 401, empty body
        """

        serializer = SMSLoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        is_code_valid = False
        is_allow_sms_for_test = allow_auth_with_test_phone(phone_number=serializer.data["phone_number"], code=serializer.data["pin_code"])
        if is_allow_sms_for_test:
            is_code_valid = True
        else:
            is_code_valid = TwilioClient().validate(phone_number=serializer.data["phone_number"], code=serializer.data["pin_code"])
        if is_code_valid:
            return Response(status=status.HTTP_200_OK)
        raise InvalidCode({"pincode": "Invalid Pincode"})
    
    @swagger_auto_schema(
        request_body=UserInfoCheckSerializer,
        responses={status.HTTP_200_OK: SuccessIndicatorSerializer},
    )
    @action(
        methods=("post",),
        detail=False,
        name="Check the existance of the user information like email and username, phone_number",
        url_path="info/validate",
        url_name="info-validate",
    )
    def user_info_existance_check(self, request: Request) -> Response:
        """
        Check the existance of the user information like email and username, phone number.
        :return: The following response objects
            `Succesful - status 200`

            Invalid Code - status 401, empty body
        """

        serializer = UserInfoCheckSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        phone_number = serializer.data["phone_number"]
        email = serializer.data["email"]
        username = serializer.data["username"]
        if phone_number and User.objects.filter(phone_number=phone_number).exists():
            return Response(status=status.HTTP_200_OK, data={"success": True})
        if email and User.objects.filter(email=email).exists():
            return Response(status=status.HTTP_200_OK, data={"success": True})
        if username and User.objects.filter(username=username).exists():
            return Response(status=status.HTTP_200_OK, data={"success": True})
        if username and BannedUsername.objects.filter(username=username).exists():
            return Response(status=status.HTTP_200_OK, data={"success": True})
        return Response(status=status.HTTP_200_OK, data={"success": False})


class LoginViewSet(GenericViewSet):
    """
    ViewSet to handle multiple login types.
    """

    permission_classes = (AllowAny,)
    queryset = User.objects.none()

    @swagger_auto_schema(
        request_body=EmailLoginSerializer,
        responses={status.HTTP_200_OK: LoginResponseSerializer},
    )
    @action(
        methods=("post",),
        detail=False,
        name="Login with email and password",
        url_path="email",
        url_name="email-login",
    )
    def email(self, request: Request, *args, **kwargs) -> Response:
        """
        Login using email and password.
        """

        try:
            serializer = EmailLoginSerializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            user = serializer.validated_data
            if user:
                if not user.verify or not user.is_active:
                    user.verify = True
                    user.is_active = True
                    user.save()
                return Response(status=status.HTTP_200_OK, data=get_user_tokens_and_data(user))
        except UnprocessableEntityError:
            # TODO: We need to handle this in a better way, probably with Firebase Deeplinks to request email validation first
            pre_signup_user = get_or_create_model_object(
                data={"email": request.data["email"]},
                model=PreSignUpUser,
                create=True,
            )
            data = unprocessed_user_response_data(pre_signup_user)

            return Response(
                status=status.HTTP_422_UNPROCESSABLE_ENTITY,
                data=data,
            )

        except Exception as e:
            logging.exception(e)
            raise e

    @swagger_auto_schema(request_body=SMSLoginSerializer, responses={status.HTTP_200_OK: LoginResponseSerializer})
    @action(
        methods=("post",),
        detail=False,
        name="Login with phone number and SMS pincode",
        url_path="sms",
        url_name="sms-pin",
    )
    def sms(self, request: Request, *args, **kwargs) -> Response:
        """
        Login using phone number and SMS pincode.

        If phone number is associated with a pre-registered user and the pincode is valid,
        the API will return the pre-existing user's data and a signup code.
        Using this code during the signup will generate an already verified user.
        """

        serializer = SMSLoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = User.objects.filter(phone_number=serializer.data["phone_number"]).first()
        if not user:
            pre_signup_user = get_or_create_model_object(data={"phone_number": serializer.data["phone_number"]}, model=PreSignUpUser)
            if pre_signup_user:
                data = unprocessed_user_response_data(pre_signup_user)
            else:
                data = {
                    "fields": {},
                    "missing_fields": PRE_SIGNUP_USER_FIELDS,
                    "code": "",
                }
            return Response(
                status=status.HTTP_422_UNPROCESSABLE_ENTITY,
                data=data,
            )
        elif user.is_terminated:
            return Response(status=status.HTTP_403_FORBIDDEN)
        data = {**serializer.data.copy()}
        data["code"] = data.pop("pin_code", None)
        is_code_valid = False
        is_allow_sms_for_test = allow_auth_with_test_phone(phone_number=data['phone_number'], code=data["code"])
        if is_allow_sms_for_test:
            is_code_valid = True
        else:
            is_code_valid = TwilioClient().validate(**data)
        if is_code_valid:
            if not user.verify or not user.is_active:
                user.verify = True
                user.is_active = True
                user.save()
            return Response(status=status.HTTP_200_OK, data=get_user_tokens_and_data(user))
        raise InvalidPincode({"pincode": "Invalid Pincode"})

    @swagger_auto_schema(request_body=PhoneNumberSerializer, responses={status.HTTP_200_OK: ""})
    @action(
        methods=("post",),
        detail=False,
        name="Request SMS pincode for login",
        url_path="sms/request",
        url_name="sms-pin-request",
    )
    def pincode_request(self, request: Request, *args, **kwargs) -> Response:
        """
        Request SMS pincode for login.

        If given phone number doesn't belong to an user, a new pre-registered user'll be created.
        """

        serializer = PhoneNumberSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = User.objects.filter(**serializer.data).first()
        if not user:
            get_or_create_model_object(data={"phone_number": serializer.data["phone_number"]}, model=PreSignUpUser, create=True)
        task_send_sms_validation_code.delay(**serializer.data)
        return Response(status=status.HTTP_200_OK)


class EmailValidationViewSet(GenericViewSet):
    """
    ViewSet to handle user's email validation
    """

    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)

    @swagger_auto_schema(
        request_body=EmailValidationSerializer,
        responses={status.HTTP_200_OK: SuccessIndicatorSerializer()},
    )
    @action(methods=("post",), detail=False, name="Validate user's email")
    def validate(self, request: Request, *args, **kwargs):
        """
        Validate user's email.
        """

        serializer = EmailValidationSerializer(data=request.data, context={"user": request.user})
        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response(status=status.HTTP_200_OK, data={"success": True})

    @swagger_auto_schema(
        request_body=no_body,
        responses={status.HTTP_200_OK: SuccessIndicatorSerializer()},
    )
    @action(
        methods=("post",),
        detail=False,
        name="Request email validation code",
        url_path="request",
        url_name="email-validation-code-request",
    )
    def request_email_validation_code(self, request: Request, *args, **kwargs):
        """
        Request email validation code.
        """

        user = request.user
        if not user.is_email_validated:
            task_send_email_validation_code.delay(str(user.id))
        return Response(status=status.HTTP_200_OK, data={"success": True})


class AvatarUploadAPIView(GenericAPIView):
    """
    View to handle user's avatar upload
    """

    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)
    parser_classes = (FormParser, MultiPartParser)
    serializer_class = AvatarUploadSerializer

    def post(self, request: Request, *args, **kwargs) -> Response:
        """
        Upload user's avatar.
        """

        context = self.get_serializer_context()
        context['profile'] = request.user.profile_data

        serializer = self.get_serializer(data=request.data, context=context)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        avatar_serializer = AvatarResponseSerializer(request.user.profile_data.avatar)
        return Response(status=status.HTTP_200_OK, data={"avatar": avatar_serializer.data})


class FollowAPIView(GenericAPIView):
    """
    View to handle user's follow
    """

    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)

    @swagger_auto_schema(
        request_body=no_body,
        responses={status.HTTP_201_CREATED: ""},
    )
    def post(self, request: Request, id: str = None) -> Response:
        """
        Follow user.
        """

        serializer = FollowSerializer(data={"user": id}, context={"request_user": request.user})
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(status=status.HTTP_201_CREATED)

    @swagger_auto_schema(
        request_body=no_body,
        responses={status.HTTP_202_ACCEPTED: ""},
    )
    def delete(self, request: Request, id: str = None) -> Response:
        """
        Unfollow user.
        """

        serializer = FollowSerializer(data={"user": id}, context={"request_user": request.user})
        serializer.is_valid(raise_exception=True)
        serializer.delete()
        return Response(status=status.HTTP_202_ACCEPTED)


class UsernameUpdateApiViewSet(GenericViewSet):
    """
    View to update username
    """
    http_method_names=['patch']
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)

    @swagger_auto_schema(
        request_body=UsernameEditSerializer,
        responses={
            status.HTTP_200_OK: SuccessIndicatorSerializer,
        },
    )
    @action(detail=False, methods=("patch",))
    def username(self, request: Request):
        serializer = UsernameEditSerializer(data=request.data, context=self.get_serializer_context())
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(status=status.HTTP_200_OK, data={"success": True})

class BaseUserListAPIView(ListAPIView):
    """
    Base class for follow list API views
    """

    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)
    serializer_class = SimpleUserSerializer


class ListFollowersAPIView(BaseUserListAPIView):
    """
    View to handle user's follower list
    """

    serializer_class = FollowUserSerializer

    def get_queryset(self):
        user = get_object_or_404(User, id=self.kwargs["id"])
        current_user = self.request.user
        following_sub_qs = current_user.following.filter(following=OuterRef('pk'))
        follower_qs = User.objects.filter(following__following=user).select_related("profile_data").annotate(is_following=Exists(following_sub_qs))
        return follower_qs


class ListFollowingAPIView(BaseUserListAPIView):
    """
    View to handle user's following list
    """

    serializer_class = FollowUserSerializer

    def get_queryset(self):
        user = get_object_or_404(User, id=self.kwargs["id"])
        current_user = self.request.user
        following_sub_qs = current_user.following.filter(following=OuterRef('pk'))
        following_qs = User.objects.filter(followers__follower=user).select_related("profile_data").annotate(is_following=Exists(following_sub_qs))
        return following_qs


class SearchUsersAPIView(BaseUserListAPIView):
    """
    Search users using username similarity
    """

    filter_backends = (DjangoFilterBackend,)
    filterset_class = UserFilter

    def get_queryset(self):
        if self.request.GET.get("username"):
            return (
                User.objects
                .filter(is_active=True)
                .exclude(id__in=self.request.user.blocked_users.values_list('blocked_user', flat=True))
                .select_related("profile_data")
            )
        return User.objects.none()
    
    
class SearchAllUsersAPIView(ModelViewSet):
    """
    Search users using username similarity
    """
    http_method_names = ['get', 'head', 'options', 'trace']
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)
    serializer_class = SimpleUserSerializer    
    filter_backends = (DjangoFilterBackend,)
    filterset_class = UserSearchFilter

    def get_queryset(self):
        return User.objects.filter(is_active=True).select_related("profile_data")
    
class RetrieveUserAPIView(RetrieveAPIView):
    """
    View to retrieve user's info
    """

    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)
    serializer_class = UserInfoSerializer

    def get_object(self):
        return get_object_or_404(
            User,
            ~Q(id__in=self.request.user.blocked_users.values_list('blocked_user', flat=True)),
            id=self.kwargs["id"],
            is_active=True,
        )


class UserStoriesAPIView(ListAPIView):
    http_method_names = ['get', 'head', 'options', 'trace']
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)
    serializer_class = CollectionTypeStorySerializer

    def get_queryset(self):
        user = get_object_or_404(
            User,
            ~Q(id__in=self.request.user.blocked_users.values_list('blocked_user', flat=True)),
            id=self.kwargs["id"],
            is_active=True,
        )
        collections_has_posts = Post.objects.get_enabled_posts().filter(owner=user, collections__collection_type=OuterRef('pk'))
        return (
            CollectionType.objects.annotate(has_posts=Exists(collections_has_posts))
            .filter(collections__user=user, has_posts=True, is_custom=False)
            .distinct()
            .order_by('order')
        )


class UserInviteAPIView(ListCreateAPIView):
    """
    ViewSet to handle user's invites
    """

    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)
    serializer_class = UserInviteSerializer

    def get_queryset(self):
        user = self.request.user
        return user.invites.all()

    @swagger_auto_schema(
        request_body=UserInviteCreateSerializer,
        responses={status.HTTP_201_CREATED: UserInviteSerializer()},
    )
    def post(self, request, *args, **kwargs):
        from apps.notifications.tasks import notify_object_task

        create_serializer = UserInviteCreateSerializer(data=request.data, context={'request': request})
        create_serializer.is_valid(raise_exception=True)
        self.perform_create(create_serializer)

        # notify invite
        if create_serializer.notify_invite:
            notify_object_task.apply_async(args=(str(create_serializer.instance.id), UserInvite.__name__), countdown=3)

        serializer = self.get_serializer(create_serializer.instance)
        headers = self.get_success_headers(serializer.data)
        response_data = serializer.data
        return Response(response_data, status=status.HTTP_201_CREATED, headers=headers)


class DeleteUserViewSet(ModelViewSet):
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)
    queryset = User.objects
    http_method_names = ('delete',)

    def destroy(self, request, id=None, *args, **kwargs):
        request.user.is_terminated = True
        request.user.is_active = False
        request.user.save()
        task_delete_user.delay(str(request.user.id))
        return Response(status=status.HTTP_204_NO_CONTENT)


class ValidInviteAPIView(GenericAPIView):
    serializer_class = SuccessIndicatorSerializer
    permission_classes = (AllowAny,)

    def get(self, request, invite_code=None):
        is_valid = User.objects.filter(invite_code=invite_code, number_invites__gt=0).exists()
        if is_valid:
            return Response(status=status.HTTP_200_OK, data={"success": True})
        return Response(status=status.HTTP_200_OK, data={"success": False})


class InviteCountAPIView(GenericAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = NumberInviteCountSerializer

    def get(self, request):
        serializer = self.get_serializer(request.user)
        return Response(status=status.HTTP_200_OK, data=serializer.data)


class BlockUserAPIView(GenericAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = SuccessIndicatorSerializer

    def post(self, request, id=None):
        if request.user.id == id:
            return Response(status=status.HTTP_400_BAD_REQUEST, data={"success": False, "message": "You can't block yourself"})
        user = get_object_or_404(User, id=id)
        BlockedUser.objects.get_or_create(user=request.user, blocked_user=user)
        return Response(status=status.HTTP_200_OK, data={"success": True})


class UnblockUserAPIView(GenericAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = SuccessIndicatorSerializer

    def post(self, request, id=None):
        user = get_object_or_404(User, id=id)
        BlockedUser.objects.filter(user=request.user, blocked_user=user).delete()
        return Response(status=status.HTTP_200_OK, data={"success": True})


class UserAddressBookViewSet(GenericAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = UserAddressBookResponseSerializer(many=True)

    @swagger_auto_schema(
        request_body=UserAddressBookCreateSerializer,
        responses={status.HTTP_200_OK: UserAddressBookResponseSerializer(many=True)},
    )
    def post(self, request, id=None):
        serializer = UserAddressBookCreateSerializer(data=request.data, context=self.get_serializer_context())
        serializer.is_valid()
        serializer.save()
        
        result = serializer.find_pre_follow_users()
        return Response(status=status.HTTP_200_OK, data=result)
    
class PreFollowViewSet(GenericAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = SuccessIndicatorSerializer

    @swagger_auto_schema(
        request_body=PreFollowSerializer,
        responses={status.HTTP_201_CREATED: SuccessIndicatorSerializer},
    )
    def post(self, request, id=None):
        serializer = PreFollowSerializer(data=request.data, context=self.get_serializer_context())
        serializer.is_valid()
        serializer.save()
        return Response(status=status.HTTP_201_CREATED, data={"success": True})