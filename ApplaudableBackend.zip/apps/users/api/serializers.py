"""
Users serializers.
"""

from datetime import datetime
from django.utils import timezone

from django.db.models import Exists, F, OuterRef, Q, Subquery, ExpressionWrapper
from django.db.models.functions import Coalesce, Now, Abs
from django.db.models import F, ExpressionWrapper, IntegerField, Case, When, Value
from django.db.models.functions import Now, ExtractDay, TruncDay, ExtractYear
from django.db.models.expressions import Exists, Subquery, OuterRef
from django.db.models import Q

import cloudinary
from dateutil.relativedelta import relativedelta
from django.conf import settings
from django.contrib.auth import get_user_model, password_validation
from django.db import transaction
from django.db.models import Exists, OuterRef, Q
from drf_yasg.utils import swagger_serializer_method
from hashid_field.rest import HashidSerializerCharField
from rest_framework import serializers, status
from apps.api.exceptions import InvalidCredentials, UnprocessableEntityError
from apps.api.v1.serializers import PhoneNumberSerializer
from apps.collection.api.serializers import BaseCollectionSerializer, CustomCollectionSerializer
from apps.collection.models import Collection, CollectionType
from apps.collection.tasks import create_user_collections
from apps.core.serializers import CloudinaryField, MediaField
from apps.media.constants import MediaType
from apps.posts.models import Post, PostUserVisibility, Flag
from apps.posts.constants import PostType, Visibility
from apps.users.models import EmailValidation, Follow, PreSignUpUser, Profile, ProfileAvatar, UserInvite, BannedUsername, UserAddressBook, PreFollow
from apps.users.constants import PreFollowUserReturnType
from apps.users.tasks import task_handle_account_invites
from apps.users.utils import allow_username_if_reserved

User = get_user_model()

PROFILE_FIELDS = ("location","location_metadata", "instagram_handler", "bio", "birth_date", "year_only")
USER_FIELDS = ("name", "username", "email", "password", "phone_number")

class LocationMetadataSerializer(serializers.Serializer):
    lat = serializers.FloatField(required=False)
    long = serializers.FloatField(required=False)
    city = serializers.CharField(required=False, allow_blank=True)
    country = serializers.CharField(required=False, allow_blank=True)
    state = serializers.CharField(required=False, allow_blank=True)
class SignUpSerializer(serializers.ModelSerializer):
    """
    Serializer for creating a new user.
    """

    id = serializers.CharField(read_only=True)
    location = serializers.CharField(required=False, allow_blank=True)
    location_metadata = LocationMetadataSerializer(required=False) 
    instagram_handler = serializers.CharField(required=False, allow_blank=True)
    bio = serializers.CharField(required=False, allow_blank=True)
    code = serializers.CharField(required=False, allow_blank=True)
    invite_code = serializers.CharField(required=True, allow_blank=False)
    birth_date = serializers.DateField(required=True)
    year_only = serializers.BooleanField(required=False)
    verify = serializers.HiddenField(default=False)

    class Meta:
        model = User
        fields = (
            "id",
            "name",
            "username",
            "password",
            "email",
            "phone_number",
            "birth_date",
            "location",
            "location_metadata",
            "instagram_handler",
            "bio",
            "code",
            "invite_code",
            "verify",
            "year_only"
        )
        extra_kwargs = {
            "name": {"required": True},
            "password": {"write_only": True},
            "phone_number": {"required": True, "allow_null": False, "allow_blank": False},
        }

    def validate_birth_date(self, birth_date: datetime) -> datetime:
        """
        Validate that user is not a minor.

        :param birth_date: user's birth date

        :raise: ValidationError if the user is a minor

        :return: user's birth date
        """

        age = relativedelta(datetime.now(), birth_date).years

        if age < 18:
            raise serializers.ValidationError("Must be at least 18 years old to register.")
        else:
            return birth_date

    def validate_password(self, value):
        password_validation.validate_password(value)
        return value

    def validate(self, attrs: dict) -> dict:
        """
        Run custom validations.

        [Overrides ModelSerializer.validate]
        """

        super().validate(attrs)
        phone_number = attrs.get("phone_number")
        if User.objects.filter(phone_number=phone_number).exists():
            raise serializers.ValidationError({"phone_number": "User with this phone number already exists."})
        code = attrs.get("code")
        email = attrs.get("email")
        username = attrs.get("username")

        # Check reserved usernames
        pre_registered_user = PreSignUpUser.objects.filter(username=username).first()
        if pre_registered_user and not allow_username_if_reserved(pre_registered_user, username, phone_number, email):
            raise serializers.ValidationError({"username": "Username is not available."})
        if code:
            try:
                pre_registered_user = PreSignUpUser.objects.filter(Q(phone_number=phone_number) | Q(email=email)).first()
                if pre_registered_user.signup_code and code != pre_registered_user.signup_code:
                    raise serializers.ValidationError({"code": "Invalid code."})
                elif pre_registered_user.signup_code and code == pre_registered_user.signup_code:
                    pre_registered_user.delete()
                else:
                    attrs.pop("code")
            except AttributeError:
                attrs.pop("code")
        return attrs

    def save(self, **kwargs) -> User:
        """
        Save the User instance.

        [Overrides ModelSerializer.save]
        """

        data = self.validated_data
        profile_data = {}

        password = data.pop("password")
        code = data.pop("code", None)
        invite_code = data.pop("invite_code", '')

        for field in PROFILE_FIELDS:
            profile_field_value = data.pop(field, None)
            if profile_field_value:
                profile_data[field] = profile_field_value

        '''
        #TODO: review the flow when the user try to signup by email
        if code:
            # Code will only be present in validated data if the user is
            # pre-registered (by requesting sms pincode or being mentioned by registered users),
            # already validated his phone number using the sms-login/request-pincode endpoints
            # and inputs a valid signup code.
            data["verify"] = True
        else:
            data["is_active"] = False
        '''
        data["verify"] = True

        with transaction.atomic():
            is_user_invite = True
            user_code = User.objects.filter(invite_code=invite_code, number_invites__gt=0).first()
            if user_code:
                is_user_invite = False
            else:
                invite = UserInvite.objects.filter(invite_code=invite_code).first()
                if not invite:
                    raise serializers.ValidationError({"invite_code": "Invalid invite code."})

            user = User.objects.create(**data)
            user.set_password(password)
            user.save()

            create_user_collections.delay(str(user.id))
            Profile.objects.create(user=user, **profile_data)
            if not is_user_invite:
                user_code.number_invites += 1
                user_code.save()
            # TODO: Need to give the credits to the inviters
            task_handle_account_invites.delay(str(user.id), invite_code)

        return user


class TokenSerializer(serializers.Serializer):
    """
    Serializer for JWT tokens.
    """

    refresh = serializers.CharField()
    access = serializers.CharField()


class TokenizedSerializer(serializers.Serializer):
    """
    Serializer to return the token object.
    """

    token = TokenSerializer(required=False)


class LoggedUserResponseSerializer(serializers.ModelSerializer):
    """
    Serializer for logged user information.
    """

    id = serializers.CharField(read_only=True)
    location = serializers.CharField(source="profile_data.location")
    location_metadata = serializers.JSONField(source="profile_data.location_metadata")
    instagram_handler = serializers.CharField(source="profile_data.instagram_handler")
    bio = serializers.CharField(source="profile_data.bio")
    avatar = serializers.CharField(source="profile_data.avatar.media_source", allow_null=True)
    has_profile = serializers.SerializerMethodField()
    invitations_count = serializers.IntegerField(source="number_invites")
    invitation_code = serializers.CharField(source="invite_code")

    class Meta:
        model = User
        fields = (
            "name",
            "username",
            "email",
            "phone_number",
            "location",
            "location_metadata",
            "instagram_handler",
            "bio",
            "id",
            "is_active",
            "is_suspend",
            "avatar",
            "has_profile",
            "invitations_count",
            "invitation_code",
        )

    def get_has_profile(self, user):
        return hasattr(user, "profile_data")


class LoginResponseSerializer(TokenizedSerializer):
    """
    Serializer for token and logged user information.
    """

    user = LoggedUserResponseSerializer()


class PinCodeSerializer(serializers.Serializer):
    """
    Serializer for SMS pin code.
    """

    pin_code = serializers.CharField()


class SMSLoginSerializer(PhoneNumberSerializer, PinCodeSerializer):
    """
    Serializer for SMS login.
    """
    
    
class UserInfoCheckSerializer(serializers.Serializer):
    """
    Serializer for checking existance of the user info.
    """

    phone_number = serializers.CharField(required=False, allow_null=True)
    email = serializers.CharField(required=False, allow_null=True)
    username = serializers.CharField(required=False, allow_null=True)


class EmailLoginSerializer(serializers.Serializer):
    """
    Serializer for email and password login.
    """

    email = serializers.EmailField(write_only=True)
    password = serializers.CharField(write_only=True, style={"input_type": "password"})

    def validate(self, data):
        super().validate(data)
        email = data.pop("email")
        password = data.pop("password")
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            raise UnprocessableEntityError()
        if user.is_terminated:
            raise InvalidCredentials(detail={"account": "Terminated"}, code=status.HTTP_403_FORBIDDEN)
        is_password_valid = user.check_password(password)
        if not is_password_valid:
            raise InvalidCredentials(detail={"credentials": "Invalid credentials"}, code=status.HTTP_401_UNAUTHORIZED)
        return user


class EmailValidationSerializer(serializers.Serializer):
    code = serializers.CharField(write_only=True)

    def validate(self, attrs):
        attrs = super().validate(attrs)
        user = self.context["user"]
        code_validation = EmailValidation.objects.filter(user=user).first()
        if not code_validation:
            raise serializers.ValidationError({"email-validation-code": "Code not found"})
        elif code_validation.is_expired():
            raise serializers.ValidationError({"email-validation-code": "Code is expired"})
        elif not code_validation.is_valid(attrs["code"]):
            raise serializers.ValidationError({"email-validation-code": "Code is invalid"})
        self.context["email_validation"] = code_validation
        return attrs

    def save(self, **kwargs):
        user = self.context["user"]
        user.is_email_validated = True
        user.save()
        self.context["email_validation"].delete()
        return user


class AvatarUploadSerializer(serializers.Serializer):
    avatar = CloudinaryField()

    def save(self, **kwargs):
        avatar = self.validated_data["avatar"]
        cloudinary_resource = cloudinary.uploader.upload_resource(
            avatar, **{"folder": settings.CLOUDINARY_DEFAULT_FOLDER, "tags": ['avatar'], "context": {"user": self.context['request'].user.id}}
        )
        self.context["profile"].save()

        self.context["profile"].avatar.image_source = cloudinary_resource
        self.context["profile"].avatar.type = MediaType.IMAGE
        self.context["profile"].avatar.metadata = getattr(cloudinary_resource, "metadata", {})
        self.context["profile"].avatar.save()

        return self.context["profile"]


class AvatarResponseSerializer(serializers.ModelSerializer):
    avatar = serializers.URLField(source="media_source")
    avatar_detail = MediaField(source="image_source")

    class Meta:
        model = ProfileAvatar
        fields = ('avatar', 'avatar_detail')


class FollowSerializer(serializers.Serializer):
    user = serializers.CharField(write_only=True)

    def validate(self, attrs):
        attrs = super().validate(attrs)

        if self.context["request_user"].id == attrs["user"]:
            raise serializers.ValidationError({"user": "You cannot follow/unfollow yourself"})
        try:
            followee = User.objects.get(id=attrs["user"])
        except User.DoesNotExist:
            raise serializers.ValidationError({"user": "User not found"})
        attrs["user"] = followee
        return attrs

    def save(self, **kwargs):
        from apps.notifications.tasks import notify_object_task

        follow, _ = Follow.objects.get_or_create(follower=self.context["request_user"], following=self.validated_data["user"])

        # notify follow
        notify_object_task.apply_async(args=(follow.id, Follow.__name__), countdown=1)

        return follow

    def delete(self, **kwargs):
        follow = Follow.objects.filter(follower=self.context["request_user"], following=self.validated_data["user"]).first()
        if follow:
            follow.delete()
        return self.context["request_user"]


class UserSerializer(serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)

    class Meta:
        model = User
        fields = (
            "id",
            "name",
            "username",
            "profile_data",
        )


class SimpleUserSerializer(serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)
    avatar = CloudinaryField(read_only=True, source="profile_data.avatar.image_source")

    class Meta:
        model = User
        fields = ("id", "avatar", "name", "username")
        read_only_fields = ['username']


class FollowUserSerializer(SimpleUserSerializer):
    is_following = serializers.BooleanField()

    class Meta:
        model = User
        fields = ("id", "avatar", "name", "username", "is_following")
        read_only_fields = ['username']


class UserCountersSerializer(serializers.Serializer):
    applauds_given = serializers.IntegerField()
    applauds_received = serializers.IntegerField()
    followers = serializers.IntegerField()
    following = serializers.IntegerField()
    posts = serializers.IntegerField()
    influences = serializers.IntegerField()
    credits = serializers.IntegerField()


class UserEngagementSerializer(serializers.Serializer):
    following = serializers.BooleanField()
    
class UsernameEditSerializer(serializers.ModelSerializer):
    user = serializers.HiddenField(default=serializers.CurrentUserDefault())
    username = serializers.CharField(required=True)
    
    class Meta:
        model = User
        fields = ("user", "username",)
    
    def validate(self, attrs, options=[]):
        attrs = super().validate(attrs)
        username = attrs.get('username')
        user = attrs.get('user')
        if user.username == username:
            return attrs
        if username and User.objects.filter(username=username).exists():
            raise serializers.ValidationError({"username": "the username already used"})
        if username and BannedUsername.objects.filter(username=username).exists():
            raise serializers.ValidationError({"username": "the username restricted"})
        return attrs
    
    def save(self, *args, **kwargs):
        username = self.validated_data.get('username')
        user = self.validated_data.get('user')
        return User.objects.filter(id=user.id).update(username=username)


class UserProfileSerializer(SimpleUserSerializer):
    counters = UserCountersSerializer(read_only=True)
    location = serializers.CharField(source="profile_data.location", required=False)
    location_metadata = serializers.JSONField(source="profile_data.location_metadata", required=False)
    instagram_handler = serializers.CharField(source="profile_data.instagram_handler", required=False)
    bio = serializers.CharField(source="profile_data.bio", required=False)
    birth_date = serializers.DateField(source="profile_data.birth_date", required=False)
    year_only = serializers.BooleanField(source="profile_data.year_only", required=False)
    collections = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = User
        fields = ("name", "username", "location", "location_metadata", "instagram_handler", "bio", "avatar", "birth_date", "year_only", "counters", "collections")
        read_only_fields = ['username']

    @swagger_serializer_method(serializer_or_field=BaseCollectionSerializer(many=True))
    def get_collections(self, obj):
        return BaseCollectionSerializer(obj.collections.all(), many=True).data

    def update(self, instance, validated_data):
        try:
            profile_validate_data = validated_data.pop('profile_data')
        except KeyError:
            profile_validate_data = {}
        for field, value in profile_validate_data.items():
            setattr(instance.profile_data, field, value)
            instance.profile_data.save()

        return super().update(instance, validated_data)


class UserInfoSerializer(UserProfileSerializer):
    engagement = serializers.SerializerMethodField()
    collections = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ("id", "name", "username", "avatar", "birth_date", "year_only", "counters", "bio", "engagement", "collections")
        read_only_fields = ['username']

    @swagger_serializer_method(serializer_or_field=UserEngagementSerializer())
    def get_engagement(self, obj):
        return UserEngagementSerializer({"following": self.context["request"].user.following.filter(following_id=obj.id).exists()}).data

    @swagger_serializer_method(serializer_or_field=CustomCollectionSerializer(many=True))
    def get_collections(self, obj):
        return CustomCollectionSerializer(obj.collections.filter(collection_type__is_custom=True), many=True).data


class CollectionListField(serializers.ListField):
    def to_representation(self, data):
        posts = Post.objects.filter(collections=OuterRef('pk'))
        sub_collections = Collection.objects.annotate(has_posts=Exists(posts)).filter(collection_group=OuterRef('pk'), has_posts=True)
        data = data.annotate(has_posts=Exists(posts), has_subcollections=Exists(sub_collections)).filter(
            (Q(has_posts=False) & Q(has_subcollections=True)) | (Q(collection_group__isnull=True) & Q(has_posts=True))
        )
        return super().to_representation(data.order_by('order'))


class PostStoryListField(serializers.ListField):
    def to_representation(self, data):
        if data.instance.visual == "map":
            return super().to_representation(data.filter(nupp__location__isnull=False).order_by('-when'))
        else:
            return super().to_representation(data.all().order_by('-when'))


class BubbleUserStorySerializer(serializers.Serializer):
    id = HashidSerializerCharField()
    name = serializers.CharField()
    avatar = serializers.URLField(source="profile_data.avatar.media_source", allow_null=True)
    collections = serializers.ListField(child=HashidSerializerCharField())


class CollectionStorySerializer(BaseCollectionSerializer):
    from apps.posts.api.serializers import PostSerializer

    posts = PostStoryListField(child=PostSerializer(), max_length=10)
    collections = serializers.SerializerMethodField()
    bubbles = serializers.SerializerMethodField()
    weight = serializers.SerializerMethodField()

    class Meta:
        model = Collection
        fields = ('id', 'name', 'order', 'visual', 'type', 'posts', 'weight', 'bubbles', 'collections')

    def get_weight(self, obj):
        return obj.posts.count()

    @swagger_serializer_method(serializer_or_field=BubbleUserStorySerializer)
    def get_bubbles(self, obj):
        bubbles = list()
        if obj.collections_item.exists() and obj.type == "group" and obj.visual == "bubble":
            users = User.objects.filter(id__in=obj.collections_item.values_list('posts__user').all()).all()
            for user in users:
                collections_id_user = obj.collections_item.filter(posts__user=user).values_list("id", flat=True)
                user_dict = {"id": user.id, "name": user.name, "collections": collections_id_user}
                try:
                    user_dict['avatar'] = user.profile_data.avatar.media_source if user.profile_data.avatar else None
                except User.profile_data.RelatedObjectDoesNotExist:
                    # Create blank profile to avoid future Exceptions
                    Profile.objects.create(user=user)
                    user_dict['avatar'] = None
                except Profile.avatar.RelatedObjectDoesNotExist:
                    user_dict['avatar'] = None
                bubbles.append(user_dict)
            return serializers.ListField(child=BubbleUserStorySerializer()).to_representation(bubbles)
        else:
            return []

    @swagger_serializer_method(serializer_or_field=BaseCollectionSerializer)
    def get_collections(self, obj):
        return serializers.ListField(child=BaseCollectionSerializer(context=self.context)).to_representation(obj.collections_item.all())


class CollectionTypeStorySerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    collections = CollectionListField(child=CollectionStorySerializer())

    class Meta:
        model = CollectionType
        fields = ('id', 'name', 'order', 'visual', 'collections')


class UserInviteSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    invited_by = SimpleUserSerializer(read_only=True)
    user = SimpleUserSerializer(read_only=True)
    number_invites = serializers.IntegerField(read_only=True, source='invited_by.number_invites')

    class Meta:
        model = UserInvite
        fields = ('id', 'name', 'invited_by', 'user', 'created_at', 'invite_code', 'number_invites')


class UserInviteCreateSerializer(serializers.ModelSerializer):
    notify = serializers.BooleanField(required=False)

    class Meta:
        model = UserInvite
        fields = ('name', 'email', 'phone_number', 'notify')

    def validate(self, attrs: dict) -> dict:
        """
        Run custom validations.

        [Overrides ModelSerializer.validate]
        """

        attrs = super().validate(attrs)

        self._notify = attrs.pop("notify", False)

        # set invited by user
        request = self.context.get('request', None)
        attrs['invited_by'] = request.user

        # only allow phone or email.
        phone_number = attrs.get("phone_number")
        email = attrs.get("email")
        if not phone_number and not email:
            raise serializers.ValidationError("phone_number or email is required.")

        # validate existing users
        if phone_number and User.objects.filter(phone_number=phone_number).exists():
            raise serializers.ValidationError({"phone_number": "User with this phone number already exists."})

        if email and User.objects.filter(email=email).exists():
            raise serializers.ValidationError({"email": "User with this email already exists."})

        return attrs

    def create(self, validated_data):
        """
        Create user invite.
        """

        with transaction.atomic():
            invited_by = validated_data['invited_by']
            # Remove limitation of invite
            # if invited_by.number_invites == 0:
            #     raise serializers.ValidationError({"invites": "You don't have invites available."})
            user_invite = UserInvite.objects.create(**validated_data)
            invited_by.number_invites += 1
            invited_by.save()
        return user_invite

    @property
    def notify_invite(self) -> bool:
        return self._notify


class NumberInviteCountSerializer(serializers.Serializer):
    number_invites = serializers.IntegerField(read_only=True)
    invitation_code = serializers.CharField(read_only=True, source='invite_code')
    
class UserAddressBookSerializer(serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)
    phone_number = serializers.CharField(required=False)
    email = serializers.CharField(required=False)
    class Meta:
        model = UserAddressBook
        fields = (
            "id",
            "phone_number",
            "email",
        )
        

class UserAddressBookResponseSerializer(serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)
    user = SimpleUserSerializer()
    type = serializers.CharField()
    phone_number = serializers.CharField(required=False)
    email = serializers.CharField(required=False)
    class Meta:
        model = UserAddressBook
        fields = (
            "id",
            "user",
            "type",
            "phone_number",
            "email",
        )
        read_only_fields = ['id', "type", "phone_number", "email"]

class UserAddressBookCreateSerializer(serializers.Serializer):
    """
    Serializer for creating a new user address book.
    """

    addresses = serializers.ListField(child=UserAddressBookSerializer(), write_only=True, required=False, allow_empty=True, help_text="List of phone numbers")
    class Meta:
        model = UserAddressBook
        fields = (
            "addresses",
        )
        
    def validate(self, attrs):
        return super().validate(attrs)
    
    # Store all address book
    def save(self, **kwargs):
        user = self.context["request"].user
        addresses = self.validated_data.get("addresses", None)
        address_collections = []
        if addresses:
            for address in addresses:
                phone_number = address.get("phone_number", None)
                email = address.get("email", None)
                matched_user  = User.objects.filter(phone_number=phone_number).first()
                can_append = True
                if phone_number and UserAddressBook.objects.filter(user=user, phone_number=phone_number).exists():
                    can_append = False
                if email and UserAddressBook.objects.filter(user=user, email=email).exists():
                    can_append = False
                if can_append:
                    address_collections.append(UserAddressBook(user=user, phone_number=phone_number, email=email, matched_user=matched_user))
            UserAddressBook.objects.bulk_create(address_collections)
        return None
    
    def find_pre_follow_users(self):
        """
        Find the applaudable users who has contacts belongs my phone number
        """
        user = self.context["request"].user
        user_phone_number = user.phone_number
        
        # Should return user
        users_belongs_in_my_phone = UserAddressBook.objects.filter(phone_number=user_phone_number).exclude(user=user)

        user_ids_belongs_in_my_phone = []
        if users_belongs_in_my_phone:
            for user_with_phone in users_belongs_in_my_phone:
                if user_with_phone.user:
                    user_ids_belongs_in_my_phone.append(user_with_phone.user.id)
        # Should return matched user
        users_belongs_in_my_contacts = UserAddressBook.objects.filter(user=user, matched_user__isnull=False).exclude(matched_user_id__in=user_ids_belongs_in_my_phone)
        # Should return phone number or email
        my_addresses_without_user = UserAddressBook.objects.filter(user=user, matched_user__isnull=True)
        # Should return owner
        top_post_owners = []
        total_users_count = len(users_belongs_in_my_phone) + len(users_belongs_in_my_contacts)
        max_count = 50
        if total_users_count < max_count:
            top_post_owners = self.get_top_post_owners(count=max_count-total_users_count)
            
        result = []
        if users_belongs_in_my_phone:
            for address in users_belongs_in_my_phone:
                data = {
                    "user": SimpleUserSerializer(address.user).data if address.user else None,
                    "type": PreFollowUserReturnType.FOLLOW,
                    "phone_number": address.phone_number,
                    "email": address.email,
                }
                result.append(UserAddressBookResponseSerializer(data).data)
                
        if users_belongs_in_my_contacts:
            for address in users_belongs_in_my_contacts:
                data = {
                    "user": SimpleUserSerializer(address.matched_user).data if address.matched_user else None,
                    "type": PreFollowUserReturnType.REVERSE_CONTACT,
                    "phone_number": address.phone_number,
                    "email": address.email,
                }
                result.append(UserAddressBookResponseSerializer(data).data)
        if my_addresses_without_user:
            for address in my_addresses_without_user:
                data = {
                    "user": None,
                    "type": PreFollowUserReturnType.PRE_FOLLOW_HASH,
                    "phone_number": address.phone_number,
                    "email": address.email,
                }
                result.append(UserAddressBookResponseSerializer(data).data)
                
        if top_post_owners:
            for post in top_post_owners:
                owner = post.owner
                data = {
                    "user": SimpleUserSerializer(post.owner).data if post.owner else None,
                    "type": PreFollowUserReturnType.OTHERWISE,
                    "phone_number": owner.phone_number,
                    "email": owner.email,
                }
                result.append(UserAddressBookResponseSerializer(data).data)

        return result
            

        
        
    def get_top_post_owners(self, count):
        user = self.context["request"].user
        user_location = Profile.objects.filter(user_id=user.id).values('location_metadata').first()['location_metadata']
        if user_location:
            user_country = user_location['country']
            user_state = user_location['state']
            user_city = user_location['city']
        else:
            user_country, user_state, user_city = None, None, None
        visible_user_condition = Exists(
            PostUserVisibility.objects.filter(
                user_id=user.id,
                post_id=OuterRef('pk')
            )
        )

        follow_condition = Exists(
            Follow.objects.filter(
                follower_id = user.id,
                following_id = OuterRef('pk')
            )
        )

        country_condition = Exists(
            Profile.objects.filter(
                user_id=OuterRef('owner_id'),
                location_metadata__country=user_country,
            ).filter(
                ~Q(location_metadata__state=user_state),
                ~Q(location_metadata__city=user_city)
            )
        )

        state_condition = Exists(
            Profile.objects.filter(
                user_id = OuterRef('owner_id'),
                location_metadata__state = user_state
            ).filter(
                ~Q(location_metadata__city = user_city)
            )
        )

        city_condition = Exists(
            Profile.objects.filter(
                user_id = OuterRef('owner_id'),
                location_metadata__city = user_city
            )
        )

        poster_age =Coalesce(Subquery(
            Profile.objects.filter(user_id=OuterRef('owner_id'))
            .annotate(
                age=ExpressionWrapper(
                    ExtractYear(Now()) - ExtractYear('birth_date'),
                    output_field = IntegerField()
                )
            ).values('age')[:1],
            output_field = IntegerField()
        ), Value(0))

        viewer_age = Coalesce(Subquery(
            Profile.objects.filter(user_id=user.id)
            .annotate(
                age=ExpressionWrapper(
                    ExtractYear(Now()) - ExtractYear('birth_date'),
                    output_field = IntegerField()
                )
            ).values('age')[:1],
            output_field=IntegerField()
        ), Value(0))
        return Post.objects.get_enabled_posts().exclude(
                    Q(type__in=PostType.circle_question_types()) |
                    # Visibility
                    (~Q(owner__id=user.id) & (Q(visibility=Visibility.ONLYME) | (Q(visibility=Visibility.CUSTOM) & ~Q(visible_user_condition)))) |
                    # Disappearing
                    Q(ranking__lte=2) |
                    Q(disappeared_at__isnull=False) |
                    Q(id__in=(Flag.objects.filter(user=user).values_list("post", flat=True))) |
                    Q(owner__id__in=(user.blocked_users.values_list("blocked_user", flat=True)))
                ).prefetch_related("media", "nupp", "owner", "mentions", "related_post").annotate(
                    days_since_posted=Coalesce(ExpressionWrapper(
                        ExtractDay(Now() - TruncDay('created_at')),
                        output_field=IntegerField()
                    ), Value(0)),
                    engagement_rate = Coalesce(F('applauds') / F('view_count') * 100, Value(0)),
                    # F('engagement_rate') + 
                    relevancy_score=ExpressionWrapper(
                        100 - F('days_since_posted') + Case(
                            When(visible_user_condition, then=Value(25)),
                            default=Value(0),
                            output_field=IntegerField()
                        ) + Case(
                            When(follow_condition, then=Value(20)),
                            default=Value(0),
                            output_field=IntegerField()
                        ) + Case(
                            When(country_condition, then=Value(2)),
                            default=Value(0),
                            output_field=IntegerField()
                        ) + Case(
                            When(state_condition, then=Value(5)),
                            default=Value(0),
                            output_field=IntegerField()
                        ) + Case(
                            When(city_condition, then=Value(10)),
                            default=Value(0),
                            output_field=IntegerField()
                        ),
                        output_field=IntegerField()
                    ) - Abs(poster_age - viewer_age) * 2,
                    has_highlights=Exists(Subquery(Post.objects.filter(related_post__id=OuterRef("pk"), type=PostType.HIGHLIGHT))),
                ).order_by("-relevancy_score", "-created_at")[:count]



class PreFollowSerializer(serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)
    invites = serializers.ListField(child=serializers.CharField(), write_only=True, required=True, allow_empty=True, help_text="List of invite_ids")
    class Meta:
        model = PreFollow
        fields = (
            "id",
            "invites",
        )
        read_only_fields = ['id']
    
    def validate(self, attrs):
        return super().validate(attrs)
    
    def save(self, **kwargs):
        user = self.context["request"].user
        invites = self.validated_data["invites"]
        pre_follow = []
        for invite_id in invites:
            user_invite = UserInvite.objects.filter(id=invite_id).first()
            if user_invite and not PreFollow.objects.filter(follower=user, user_invite_id=invite_id).exists():
                pre_follow.append(PreFollow(follower=user, user_invite=user_invite, created_at=timezone.now()))
        if pre_follow:
            PreFollow.objects.bulk_create(pre_follow)
        return []