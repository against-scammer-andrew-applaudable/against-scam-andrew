"""
Users models.
"""
import logging
import secured_fields
from datetime import datetime
from django.contrib.auth.models import AbstractUser as AbstractDjangoUser
from django.contrib.auth.models import Group as DjangoGroup
from django.contrib.auth.validators import UnicodeUsernameValidator
from django.db import models
from dateutil.relativedelta import relativedelta

from django.utils.translation import gettext_lazy as _
from phonenumber_field.modelfields import PhoneNumberField

from apps.core.models import (
    AbstractCreatedDateMixin,
    AbstractCreatedUpdatedDateMixin,
    AbstractUniqueBigHashIDMixin,
    AbstractUniqueHashIDMixin,
    AbstractUpdatedDateMixin,
    AbstractValidation,
)
from apps.core.utils import generate_unique_code
from apps.media.constants import MediaType
from apps.media.models import AbstractMedia
from apps.users.constants import UserCreditReferenceType
from django.db.models import Sum

from .notify import user_follow_notify, user_invite_notify, user_notify_did_not_post_story_push
from .managers import ActiveUserManager, FollowUserManager


class Group(DjangoGroup):
    """
    Overrides DjangoGroup model.
    """

    class Meta:
        proxy = True


class User(AbstractUniqueBigHashIDMixin, AbstractUpdatedDateMixin, AbstractDjangoUser):
    """
    Applaudable User model.
    """

    username_validator = UnicodeUsernameValidator()

    username = models.CharField(
        _("username"),
        max_length=150,
        unique=True,
        help_text=_("Letters, digits and @/./+/-/_ only."),
        validators=[username_validator],
        error_messages={
            "unique": _("A user with that username already exists."),
        },
    )
    name = models.CharField(_("name"), max_length=150, blank=True)
    email = models.EmailField(_("email address"), blank=False, unique=True)
    phone_number = PhoneNumberField(blank=True)
    notes = models.TextField(_("notes"), blank=True, null=True)
    verify = models.BooleanField(_("Verified User"), default=False)
    is_email_validated = models.BooleanField(_("Verified email address"), default=False)
    is_suspend = models.BooleanField(_("Suspended User"), default=False)
    is_disabled = models.BooleanField(_("Disabled User"), default=False)
    is_terminated = models.BooleanField(_("Terminated User"), default=False)
    start_date_suspension = models.DateTimeField(_("start date suspension"), blank=True, null=True)
    end_date_suspension = models.DateTimeField(_("end date suspension"), blank=True, null=True)
    timezone = models.CharField(max_length=50, blank=True, default='Europe/Lisbon')
    invite_code = models.CharField(_("invite code"), max_length=6, unique=True, null=True)
    number_invites = models.PositiveIntegerField(default=2)
    # TODO: remove this field after ending Beta phase
    last_story_qty_trigger = models.PositiveIntegerField(default=0)  # prevent users erasing stories and posting again to get more invites

    # custom managers
    active_objects = ActiveUserManager()
    follow_objects = FollowUserManager()

    class Meta:
        db_table = "users_user"
        verbose_name = _("user")
        verbose_name_plural = _("users")
        default_manager_name = 'objects'
        indexes = [*AbstractUniqueHashIDMixin.Meta.indexes]

    def __str__(self):
        return self.username

    def __repr__(self):
        return f"User('{self.id}', '{self.username}', '{self.email}')"

    @property
    def counters(self):
        """
        Returns the user counters.
        """
        from apps.influence.models import PostImpression
        from apps.posts.models import Applaud
        
        user_credit = self.credit_receivers.aggregate(Sum('credit_point'))['credit_point__sum']
        user_credit = user_credit if user_credit else 0
        return {
            "applauds_given": Applaud.objects.filter(user_id=self.id).count(),
            "applauds_received": Applaud.objects.filter(post__owner_id=self.id).count(),
            "posts": self.owned_posts.filter(is_disabled=False).count(),
            "followers": self.followers.count(),
            "following": self.following.count(),
            "influences": PostImpression.objects.filter(post__owner=self.id, is_valid=True).values("user").distinct('user').count(),
            "credits": user_credit
        }

    @classmethod
    def mention_field_name(cls) -> str:
        return "user"

    def get_mention_label(self):
        return self.username

    def get_icon(self):
        try:
            profile = self.profile_data
            avatar = profile.avatar
        except Profile.DoesNotExist:
            Profile.objects.create(user=self)
            return ''
        except ProfileAvatar.DoesNotExist:
            ProfileAvatar.objects.create(profile=self.avatar)
            return ''
        except Exception as e:
            logging.exception(e)
            return ''
        return avatar.cloudinary_resource.url

    def notify_did_not_post_story(self):
        user_notify_did_not_post_story_push(self)

    def delete(self, using=None, keep_parents=False):
        from apps.notifications.tasks import delete_user_notification_as_related_cascade
        from apps.notifications.utils import serialize_model_object

        serialized_model_object = serialize_model_object(self)
        delete_user_notification_as_related_cascade.delay(serialized_model_object, 'actors')
        super().delete(using=using, keep_parents=keep_parents)

    def save(self, *args, **kwargs):
        if not self.invite_code:
            self.invite_code = self.generate_invite_code()
        super().save(*args, **kwargs)

    def generate_invite_code(self):
        while True:
            code = generate_unique_code(length=6)
            if not self.__class__.objects.filter(invite_code=code).exists():
                return code

class BannedUsername(AbstractCreatedDateMixin):
    """
    Banned Username model.
    """
    
    username = models.CharField(_("banned username"), max_length=150, unique=True, help_text=_("The username that is banned from being used."))
    
    class Meta:
        verbose_name = _("Banned Username")
        verbose_name_plural = _("Banned Usernames")
        db_table = 'banned_usernames'

    def __str__(self):
        return self.username

class Profile(AbstractCreatedUpdatedDateMixin):
    """
    User's profile model.
    """

    user = models.OneToOneField(User, related_name="profile_data", on_delete=models.CASCADE)
    location = models.CharField(max_length=45, blank=True)
    location_metadata = models.JSONField(blank=True, null=True, default=dict)
    applaudable = models.PositiveIntegerField(default=0)
    instagram_handler = models.CharField(max_length=150, blank=True, null=True)
    birth_date = models.DateField(_("birth date"), blank=True, null=True)
    year_only = models.BooleanField(blank=False, null=False, default=False)
    bio = models.TextField(blank=True, null=True)

    def __repr__(self):
        return f"Profile('{self.user}'"

    def __str__(self):
        return self.user.username
    
    @property
    def age(self):
        if self.birth_date:            
            return relativedelta(datetime.now(), self.birth_date).years
        return 0

    def save(self, *args, **kwargs):
        if hasattr(self, 'avatar'):
            super().save(*args, **kwargs)
            return
        super().save(*args, **kwargs)
        ProfileAvatar.objects.create(profile=self)


class ProfileAvatar(AbstractMedia):
    """
    Profile Avatar model
    """

    profile = models.OneToOneField(Profile, related_name="avatar", on_delete=models.CASCADE, blank=True, null=True)

    def save(self, *args, **kwargs):
        self.type = MediaType.IMAGE
        super().save(*args, **kwargs)


class Follow(AbstractCreatedDateMixin):
    """
    User's follow representation model.
    """

    follower = models.ForeignKey(User, related_name="following", on_delete=models.CASCADE)
    following = models.ForeignKey(User, related_name="followers", on_delete=models.CASCADE)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["follower", "following"], name="unique_follow")]

    def notify(self):
        user_follow_notify(self)


class EmailValidation(AbstractValidation):
    """
    Email validation model.
    """

    user = models.OneToOneField(User, related_name="email_validation", on_delete=models.CASCADE)


class PreSignUpUser(AbstractUniqueHashIDMixin, AbstractCreatedUpdatedDateMixin):
    """
    This model represents unregistered users.
    During SignUp or Login process, we will check if an instance with
    the same email or phone number already exists.
    If it does, we will populate the SignUp info using PreSignUpUser data.
    In case there was Username reservation, we will check this table to verify email/phone number info.
    """

    email = models.EmailField(_("email address"), blank=True)
    username = models.CharField(blank=True, max_length=150)
    name = models.CharField(_("name"), max_length=150, blank=True)
    phone_number = PhoneNumberField(blank=True)
    signup_code = models.CharField(max_length=6, blank=True)

    class Meta:
        verbose_name = _("Pre Sign-Up User")
        verbose_name_plural = _("Pre Sign-Up Users")

    def __str__(self):
        return f"{self.id} - {self.email} - {self.phone_number} - {self.name}"


def get_default_invite_code():
    return generate_unique_code(length=8)


class UserInvite(AbstractUniqueHashIDMixin, AbstractCreatedUpdatedDateMixin):
    name = models.CharField(_("name"), max_length=150)
    email = models.EmailField(_("email address"), blank=True, null=True)
    phone_number = PhoneNumberField(blank=True, null=True)
    invited_by = models.ForeignKey(User, related_name="invites", on_delete=models.CASCADE)
    notified_at = models.DateTimeField(_("notified at"), null=True, blank=True)
    accepted_at = models.DateTimeField(_("accepted at"), null=True, blank=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    invite_code = models.CharField(_("invite code"), default=get_default_invite_code, max_length=12, unique=True)

    class Meta:
        verbose_name = _("User Invite")
        verbose_name_plural = _("User Invites")

    def __str__(self):
        return f"{self.id} - {self.name}"

    @classmethod
    def mention_field_name(cls) -> str:
        return "user_invite"

    def get_mention_label(self):
        return self.name if not self.user else self.user.username

    def allowed_delivery_methods(self):
        from apps.notifications.constants import DeliveryMethod

        delivery_methods = set()
        if self.email:
            delivery_methods.add(DeliveryMethod.EMAIL)
        if self.phone_number:
            delivery_methods.add(DeliveryMethod.SMS)
        return delivery_methods

    def invite_url(self):
        from apps.users.utils import acquire_invite_user_dynamic_link

        return acquire_invite_user_dynamic_link(self)

    def notify(self):
        user_invite_notify(self)


class UserCreationInvite(AbstractCreatedUpdatedDateMixin):
    user = models.OneToOneField(User, related_name="invite", on_delete=models.CASCADE)
    invite = models.ForeignKey(UserInvite, on_delete=models.CASCADE)


class NonStaffUser(User):
    """
    NonStaffUser proxy model.
    """

    class Meta:
        verbose_name = _("App User")
        verbose_name_plural = _("App Users")
        proxy = True


class SubAdmin(User):
    """
    SubAdmin proxy model.
    """

    class Meta:
        verbose_name = _("Sub Admin")
        verbose_name_plural = _("Sub Admins")
        proxy = True


class BlockedUser(AbstractCreatedDateMixin):
    """
    Blocked User model.
    """

    user = models.ForeignKey(User, related_name="blocked_users", on_delete=models.CASCADE)
    blocked_user = models.ForeignKey(User, related_name="blocked_by_users", on_delete=models.CASCADE)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["user", "blocked_user"], name="unique_blocked_user")]

class UserCredit(AbstractUniqueHashIDMixin, AbstractCreatedDateMixin):
    """
    This model represents user credits.    
    When user accept the invitation and create an account in applaudable, 
    The user will give some credit to the inviter and parent of inviter
    """
    receiver = models.ForeignKey(User, related_name="credit_receivers", on_delete=models.CASCADE, null=True, blank=True)
    sender = models.ForeignKey(User, related_name="credit_senders", on_delete=models.CASCADE, null=True, blank=True)
    reference_id = secured_fields.EncryptedCharField(max_length=255, searchable=True)
    reference_type = models.CharField(max_length=25, choices=UserCreditReferenceType.choices(), blank=False, null=False, default=UserCreditReferenceType.USER_INVITE)
    credit_point = models.PositiveIntegerField(default=0)
    class Meta:
        verbose_name = _("User Credits")
        verbose_name_plural = _("User Credits")

    def __str__(self):
        return f"{self.id}"

# Create address book and fetch matched user and store all address
# Find the applaudable users who has contacts belongs my phone number
# Find the applaudable users who is in my contacts
# Otherwise, return phone number list
# Otherwise, find the applaudable users based on the post relevance
class UserAddressBook(AbstractUniqueHashIDMixin, AbstractCreatedDateMixin):
    """
    This model represents address book of the user.
    During the signup, the user can be able to upload their address book.
    We can store the user address information using secured field
    It will be used for pre-follow flow
    """

    user = models.ForeignKey(User, related_name="address_book", on_delete=models.CASCADE)
    
    """
    Email is optional field for now
    """
    email = secured_fields.EncryptedCharField(max_length=50, searchable=True, blank=True, null=True)
    phone_number = secured_fields.EncryptedCharField(max_length=50, searchable=True, blank=True, null=True)
    
    """
    Matched user with the phone number
    """
    matched_user = models.ForeignKey(User, related_name="address_matched_user", on_delete=models.CASCADE, null=True, blank=True)

    class Meta:
        verbose_name = _("Users address book")
        verbose_name_plural = _("Users address book")

    def __str__(self):
        return f"{self.id}"
    

class PreFollow(AbstractCreatedDateMixin):
    """
    User's PreFollow representation model.
    In registration flow, the user can invite someones.
    When the invites create new account, it should follow automatically
    """

    follower = models.ForeignKey(User, related_name="pre_following", on_delete=models.CASCADE)
    user_invite = models.ForeignKey(UserInvite, related_name="pre_follow_invite", on_delete=models.CASCADE)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["follower", "user_invite"], name="unique_pre_follow")]
