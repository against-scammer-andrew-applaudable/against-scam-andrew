from django import forms
from django.contrib.auth.forms import SetPasswordForm, UserChangeForm, UserCreationForm
from django.contrib.auth.tokens import default_token_generator
from django.contrib.sites.shortcuts import get_current_site
from django.core.exceptions import ValidationError
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from django.utils.translation import gettext_lazy as _

from apps.core.widgets import DateInputWidget
from apps.users.models import User
from apps.users.utils import send_admin_password_email


class BaseUserAdminForm(forms.ModelForm):
    def validate_unique(self):
        exclude = self._get_validation_exclusions()
        if not self.cleaned_data.get("email"):
            exclude.append("email")
        try:
            self.instance.validate_unique(exclude=exclude)
        except ValidationError as e:
            self._update_errors(e)

    class Meta:
        model = User
        fields = "__all__"


class UserCreationAdminForm(BaseUserAdminForm, UserCreationForm):
    class Meta:
        model = User
        fields = "__all__"
        exclude = ("notes",)


class UserChangeAdminForm(BaseUserAdminForm, UserChangeForm):
    class Meta:
        model = User
        fields = "__all__"
        exclude = ("notes",)


class SuspendUserForm(forms.Form):
    start_date_suspension = forms.DateField(widget=DateInputWidget())
    end_date_suspension = forms.DateField(widget=DateInputWidget())

    def clean(self):
        cleaned_data = super().clean()
        initial_date = cleaned_data.get("start_date_suspension")
        final_date = cleaned_data.get("end_date_suspension")

        if final_date <= initial_date:
            raise forms.ValidationError("Final date must be later than initial date")
        return cleaned_data


class SubAdminAddForm(BaseUserAdminForm):
    class Meta:
        model = User
        fields = ("name", "email")

    def save(self, commit=True):
        if "email" in self.changed_data:
            self.instance.is_email_validated = False
        self.instance.is_staff = True
        if not self.instance.is_email_validated:
            self.instance.is_active = False
        else:
            self.instance.is_active = True
        self.instance.is_superuser = False
        self.instance.username = self.cleaned_data["email"]
        if commit:
            self.instance.save()
        return self.instance

    def save_m2m(self):
        return self.save()


class SubAdminChangeForm(BaseUserAdminForm):
    class Meta:
        model = User
        fields = ("name", "email", "is_active")

    def save(self, commit=True):
        if "email" in self.changed_data:
            self.instance.is_email_validated = False
        self.instance.is_staff = True
        if not self.instance.is_email_validated:
            self.instance.is_active = False
        else:
            self.instance.is_active = True
        self.instance.is_superuser = False
        self.instance.username = self.cleaned_data["email"]
        if commit:
            self.instance.save()
        return self.instance

    def save_m2m(self):
        return self.save()


class AdminResetForm(forms.Form):
    email = forms.EmailField(
        label=_("Email"),
        max_length=254,
        widget=forms.EmailInput(attrs={"autocomplete": "email"}),
    )

    def get_users(self, email, user_change):
        """
        Return active staff users matching the given email.

        :param email: Email address
        :param user_change: If True, filter for users that are not active in the platform yet

        [Override PasswordResetForm.get_users]
        """

        active_staff = User.objects.filter(
            email__iexact=email,
            is_active=not user_change,
            is_staff=True,
        )

        return active_staff

    def send_mail(
        self,
        subject_template_name,
        email_template_name,
        context,
        from_email,
        to_email,
        html_email_template_name=None,
    ):
        """
        [Override PasswordResetForm.send_mail]
        """

        send_admin_password_email(context["email"], context["uid"], context["token"])

    def save(
        self,
        domain_override=None,
        subject_template_name="registration/password_reset_subject.txt",
        email_template_name="registration/password_reset_email.html",
        use_https=False,
        token_generator=default_token_generator,
        from_email=None,
        request=None,
        html_email_template_name=None,
        extra_email_context=None,
        user_change=False,
    ):
        """
        Generate a one-use only link for resetting password and send it to the
        user.

        CUSTOM PARAMETERS:

        :param user_change: If True, filter for users that are not active in the platform yet

        [Override PasswordResetForm.save]
        """

        email = self.cleaned_data["email"]
        if not domain_override:
            current_site = get_current_site(request)
            site_name = current_site.name
            domain = current_site.domain
        else:
            site_name = domain = domain_override

        for user in self.get_users(email, user_change):
            user_email = user.email
            context = {
                "email": user_email,
                "domain": domain,
                "site_name": site_name,
                "uid": urlsafe_base64_encode(force_bytes(user.pk)),
                "user": user,
                "token": token_generator.make_token(user),
                "protocol": "https" if use_https else "http",
                **(extra_email_context or {}),
            }
            self.send_mail(
                subject_template_name,
                email_template_name,
                context,
                from_email,
                user_email,
                html_email_template_name=html_email_template_name,
            )


class SetAdminPasswordForm(SetPasswordForm):
    def save(self, commit=True):
        password = self.cleaned_data["new_password1"]
        self.user.set_password(password)
        self.user.is_active = True
        self.user.is_email_validated = True
        if commit:
            self.user.save()
        return self.user
