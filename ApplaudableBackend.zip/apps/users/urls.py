app_name = "users"

urlpatterns = []
