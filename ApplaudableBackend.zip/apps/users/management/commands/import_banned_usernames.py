import gspread
from django.core.management.base import BaseCommand
from google.oauth2.service_account import Credentials
from apps.users.models import BannedUsername
from django.conf import settings

class Command(BaseCommand):
    help = 'Import banned usernames from Google Sheets into the PostgreSQL database'

    def add_arguments(self, parser):
        parser.add_argument('-s', '--sheet-name', type=str, help='Name of the Google Sheet to import')

    def handle(self, *args, **kwargs):
        print("Starting script...")
        scope = [
            'https://www.googleapis.com/auth/spreadsheets',
            'https://www.googleapis.com/auth/drive'
        ]

        sheet_name = kwargs['sheet_name']
        if not sheet_name:
            self.stdout.write(self.style.ERROR('Sheet name is required. Use --sheet-name to specify it.'))
            return

        credentials_path = getattr(settings, 'GOOGLE_APPLICATION_CREDENTIALS', None)
        if credentials_path:
            print(f"Using credentials path: {credentials_path}")
            try:
                credentials = Credentials.from_service_account_file(
                    credentials_path,
                    scopes=scope,
                )
                client = gspread.authorize(credentials)
                try:
                    sheet = client.open(sheet_name)
                    print(sheet.title)

                    for index, worksheet in enumerate(sheet.worksheets()):
                        headers = worksheet.row_values(1)
                        if index == 0:
                            column_name = "Account"
                        else:
                            column_name = "User Name"
                        try:
                            col_index = headers.index(column_name) + 1
                        except ValueError:
                            print(f"'{column_name}' column not found in {worksheet.title}")
                            continue
                        
                        values = worksheet.col_values(col_index)[1:]
                        
                        for value in values:
                            if index != 0:
                                value = value.replace('@', '')
                            print(value)
                            BannedUsername.objects.update_or_create(username=value)
                        
                        success_message = f'Successfully imported "{column_name}" from {worksheet.title}.'
                        self.stdout.write(self.style.SUCCESS(success_message))
                except Exception as e:
                    print(f"Error accessing Google Sheet: {e}")
            except Exception as e:
                print(f"Error accessing Google Sheets: {e}")
        else:
            print("GOOGLE_APPLICATION_CREDENTIALS not set in settings.")
        

