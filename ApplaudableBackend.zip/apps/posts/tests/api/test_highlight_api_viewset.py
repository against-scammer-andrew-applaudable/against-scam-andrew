# from rest_framework.test import APIRequestFactory, APITestCase, force_authenticate
# import pytest
# from apps.collection.tests.factories import CollectionModelFactory
# from apps.nupp.tests.factories import NuppModelFactory
# from apps.posts.api.views import HighlightAPIView
# from apps.posts.models import Post
# from apps.posts.tests.factories import CategoryModelFactory, PostAPIFactory, HighlightModelFactory, PostModelFactory
# from apps.users.tests.factories import UserFactory

# factory = APIRequestFactory()


# class HighlightViewSetTestCase(APITestCase):
#     def setUp(self):
#         self.user = UserFactory()
#         self.main_post = PostModelFactory()
#         self.child = HighlightModelFactory(related_post=self.main_post)

#     def test_get_highlights(self):
#         get_request = factory.get(path=f"api/v1/posts/{self.main_post.id}/highlights/")
#         force_authenticate(request=get_request, user=self.user)
#         response = HighlightAPIView.as_view()(get_request, id=self.main_post.id)
#         self.assertEqual(response.status_code, 200)
#         self.assertEqual(response.data["count"], 2)
