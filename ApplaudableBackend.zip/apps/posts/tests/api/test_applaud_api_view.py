from rest_framework.test import APIRequestFactory, APITestCase, force_authenticate

from apps.collection.tests.factories import CollectionModelFactory
from apps.influence.models import PostImpression
from apps.nupp.tests.factories import NuppModelFactory
from apps.posts.api.views import ApplaudAPIView, PostViewSet
from apps.posts.models import Applaud, Post
from apps.posts.tests.factories import CategoryModelFactory, PostAPIFactory
from apps.users.tests.factories import UserFactory

factory = APIRequestFactory()


class ApplaudAPIViewTestCase(APITestCase):
    def setUp(self):
        self.user = UserFactory()
        nupp = NuppModelFactory(is_validated=True, is_public=True)
        post = PostAPIFactory()
        post["segment"] = nupp.segment
        post["nupp"] = str(nupp.id)
        post['category'] = str(CategoryModelFactory().id)
        post["collections"] = [str(CollectionModelFactory(user=self.user).id)]
        post["owner"] = str(self.user.id)
        post_request = factory.post(path="api/v1/posts/", data=post)
        force_authenticate(request=post_request, user=self.user)
        PostViewSet.as_view({"post": "create"})(post_request)
        self.post = Post.objects.first()
        self.data = {"type": "applaud_type"}

    def test_applaud_post(self):
        request = factory.patch(path=f"api/v1/posts/{self.post.id}/applaud/", data=self.data)
        force_authenticate(request=request, user=self.user)
        response = ApplaudAPIView.as_view()(request, id=self.post.id)
        self.post.refresh_from_db()

        self.assertEqual(response.status_code, 200)
        self.assertEqual(Applaud.objects.count(), 1)
        self.assertEqual(self.post.applauds, 1)

    def test_applaud_post_twice(self):
        request = factory.patch(path=f"api/v1/posts/{self.post.id}/applaud/", data=self.data)
        force_authenticate(request=request, user=self.user)
        response = ApplaudAPIView.as_view()(request, id=self.post.id)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(Applaud.objects.count(), 1)
        self.assertEqual(Applaud.objects.first().post.applauds, 1)

    def test_applaud_post_invalid_post(self):
        request = factory.patch(path="api/v1/posts/invalid/applaud/", data=self.data)
        force_authenticate(request=request, user=self.user)
        response = ApplaudAPIView.as_view()(request, id="invalid")
        self.assertEqual(response.status_code, 400)
        self.assertEqual(Applaud.objects.count(), 0)

    def test_delete_applaud(self):
        patch_request = factory.patch(path=f"api/v1/posts/{self.post.id}/applaud/", data=self.data)
        force_authenticate(request=patch_request, user=self.user)
        ApplaudAPIView.as_view()(patch_request, id=self.post.id)

        request = factory.delete(path=f"api/v1/posts/{self.post.id}/applaud/")
        force_authenticate(request=request, user=self.user)
        response = ApplaudAPIView.as_view()(request, id=self.post.id)
        self.post.refresh_from_db()

        self.assertEqual(response.status_code, 202)
        self.assertEqual(Applaud.objects.count(), 0)
        self.assertEqual(self.post.applauds, 0)

    def test_applaud_create_post_impression(self):
        request = factory.patch(path=f"api/v1/posts/{self.post.id}/applaud/", data=self.data)
        force_authenticate(request=request, user=self.user)
        ApplaudAPIView.as_view()(request, id=self.post.id)

        self.assertEqual(PostImpression.objects.count(), 1)
        self.assertTrue(PostImpression.objects.first().is_valid)

    def test_duplicate_applaud_post_impression(self):
        request = factory.patch(path=f"api/v1/posts/{self.post.id}/applaud/", data=self.data)
        force_authenticate(request=request, user=self.user)
        ApplaudAPIView.as_view()(request, id=self.post.id)

        second_request = factory.patch(path=f"api/v1/posts/{self.post.id}/applaud/", data=self.data)
        force_authenticate(request=request, user=self.user)
        ApplaudAPIView.as_view()(second_request, id=self.post.id)

        self.assertEqual(PostImpression.objects.count(), 1)
