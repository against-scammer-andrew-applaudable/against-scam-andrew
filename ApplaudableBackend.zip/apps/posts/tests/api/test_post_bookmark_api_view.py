from rest_framework.test import APIRequestFactory, APITestCase, force_authenticate

from apps.collection.tests.factories import CollectionModelFactory
from apps.influence.models import PostImpression
from apps.nupp.tests.factories import NuppModelFactory
from apps.posts.api.views import PostBookmarkAPIView, PostViewSet
from apps.posts.models import Bookmark, Post
from apps.posts.tests.factories import CategoryModelFactory, PostAPIFactory
from apps.users.tests.factories import UserFactory

factory = APIRequestFactory()


class PostBookmarkAPIViewTestCase(APITestCase):
    def setUp(self):
        self.user = UserFactory()
        nupp = NuppModelFactory(is_validated=True, is_public=True)
        post = PostAPIFactory()
        post["segment"] = nupp.segment
        post["nupp"] = str(nupp.id)
        post['category'] = str(CategoryModelFactory().id)
        post["collections"] = [str(CollectionModelFactory(user=self.user).id)]
        post["owner"] = str(self.user.id)
        post_request = factory.post(path="api/v1/posts/", data=post)
        force_authenticate(request=post_request, user=self.user)
        PostViewSet.as_view({"post": "create"})(post_request)
        self.post = Post.objects.first()

    def test_bookmark_post(self):
        request = factory.patch(path=f"api/v1/posts/{self.post.id}/bookmark/")
        force_authenticate(request=request, user=self.user)
        response = PostBookmarkAPIView.as_view()(request, id=self.post.id)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(Bookmark.objects.count(), 1)
        self.assertTrue(response.data["engagement"]["bookmarked"])

    def test_bookmark_post_twice(self):
        request = factory.patch(path=f"api/v1/posts/{self.post.id}/bookmark/")
        force_authenticate(request=request, user=self.user)
        response = PostBookmarkAPIView.as_view()(request, id=self.post.id)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(Bookmark.objects.count(), 1)

    def test_bookmark_post_invalid_post(self):
        request = factory.patch(path="api/v1/posts/invalid/bookmark/")
        force_authenticate(request=request, user=self.user)
        response = PostBookmarkAPIView.as_view()(request, id="invalid")
        self.assertEqual(response.status_code, 404)
        self.assertEqual(Bookmark.objects.count(), 0)

    def test_delete_bookmark(self):
        patch_request = factory.patch(path=f"api/v1/posts/{self.post.id}/bookmark/")
        force_authenticate(request=patch_request, user=self.user)
        PostBookmarkAPIView.as_view()(patch_request, id=self.post.id)

        request = factory.delete(path=f"api/v1/posts/{self.post.id}/bookmark/")
        force_authenticate(request=request, user=self.user)
        response = PostBookmarkAPIView.as_view()(request, id=self.post.id)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(Bookmark.objects.count(), 0)
        self.assertFalse(response.data["engagement"]["bookmarked"])

    def test_bookmark_create_post_impression(self):
        request = factory.patch(path=f"api/v1/posts/{self.post.id}/bookmark/")
        force_authenticate(request=request, user=self.user)
        PostBookmarkAPIView.as_view()(request, id=self.post.id)

        self.assertEqual(PostImpression.objects.count(), 1)

    def test_duplicate_bookmark_post_impression(self):
        request = factory.patch(path=f"api/v1/posts/{self.post.id}/bookmark/")
        force_authenticate(request=request, user=self.user)
        PostBookmarkAPIView.as_view()(request, id=self.post.id)

        second_request = factory.patch(path=f"api/v1/posts/{self.post.id}/bookmark/")
        force_authenticate(request=second_request, user=self.user)
        PostBookmarkAPIView.as_view()(request, id=self.post.id)

        self.assertEqual(PostImpression.objects.count(), 1)
