from rest_framework.test import APIRequestFactory, APITestCase, force_authenticate

from apps.collection.tests.factories import CollectionModelFactory
from apps.nupp.tests.factories import NuppModelFactory
from apps.posts.api.views import PostBookmarkAPIView, PostViewSet
from apps.posts.constants import PostType
from apps.posts.models import Flag, Post
from apps.posts.tests.factories import CategoryModelFactory, PostAPIFactory
from apps.users.api.views import FollowAPIView
from apps.users.tests.factories import UserFactory

factory = APIRequestFactory()


class PostViewSetTestCase(APITestCase):
    def setUp(self):
        self.data = PostAPIFactory()
        self.user = UserFactory()
        self.nupp = NuppModelFactory(is_validated=True, is_public=True)
        self.data["elements"] = [{"type": "rich_text", "elements": [{"type": "text", "text": "test"}]}]
        self.data["segment"] = self.nupp.segment
        self.data["nupp"] = str(self.nupp.id)
        self.data["collections"] = [str(CollectionModelFactory(user=self.user).id)]
        self.data['category'] = str(CategoryModelFactory().id)

    def test_create_post(self):
        request = factory.post(path="api/v1/posts/", data=self.data)
        force_authenticate(request=request, user=self.user)
        response = PostViewSet.as_view({"post": "create"})(request)
        self.assertEqual(response.status_code, 201)

        created_post = Post.objects.first()

        self.assertEqual(created_post.id, response.data["id"])
        self.assertEqual(str(created_post.owner.id), response.data["owner"]["id"])

    def test_get_post(self):
        post_request = factory.post(path="api/v1/posts/", data=self.data)
        force_authenticate(request=post_request, user=self.user)
        PostViewSet.as_view({"post": "create"})(post_request)

        get_request = factory.get(path="api/v1/posts/")
        force_authenticate(request=get_request, user=self.user)
        response = PostViewSet.as_view({"get": "list"})(get_request)

        created_post = Post.objects.first()

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["count"], 1)
        self.assertEqual(response.data["results"][0]["id"], str(created_post.id))
        self.assertEqual(response.data["results"][0]["owner"]["id"], str(created_post.owner.id))

    def test_delete_post(self):
        post_request = factory.post(path="api/v1/posts/", data=self.data)
        force_authenticate(request=post_request, user=self.user)
        PostViewSet.as_view({"post": "create"})(post_request)

        created_post = Post.objects.first()

        delete_request = factory.delete(path=f"api/v1/posts/{created_post.id}/")
        force_authenticate(request=delete_request, user=self.user)
        response = PostViewSet.as_view({"delete": "destroy"})(delete_request, id=created_post.id)

        self.assertEqual(response.status_code, 202)
        self.assertEqual(Post.objects.count(), 0)

    def test_delete_invalid_user(self):
        invalid_user = UserFactory()
        post_request = factory.post(path="api/v1/posts/", data=self.data)
        force_authenticate(request=post_request, user=self.user)
        PostViewSet.as_view({"post": "create"})(post_request)

        created_post = Post.objects.first()

        delete_request = factory.delete(path=f"api/v1/posts/{created_post.id}/")
        force_authenticate(request=delete_request, user=invalid_user)
        response = PostViewSet.as_view({"delete": "destroy"})(delete_request, id=created_post.id)

        self.assertEqual(response.status_code, 404)
        self.assertEqual(Post.objects.count(), 1)

    def test_patch_post(self):
        post_request = factory.post(path="api/v1/posts/", data=self.data)
        force_authenticate(request=post_request, user=self.user)
        PostViewSet.as_view({"post": "create"})(post_request)

        created_post = Post.objects.first()

        new_collection = CollectionModelFactory(user=self.user)

        data = {"collections": [str(new_collection.id)]}

        patch_request = factory.patch(path=f"api/v1/posts/{created_post.id}/", data=data)
        force_authenticate(request=patch_request, user=self.user)
        response = PostViewSet.as_view({"patch": "partial_update"})(patch_request, id=created_post.id)
        self.assertEqual(response.status_code, 202)
        self.assertEqual(response.data["collections"][0]["id"], str(new_collection.id))

    def test_post_filter_type_following(self):
        second_user = UserFactory()
        post_request = factory.post(path="api/v1/posts/", data=self.data)
        force_authenticate(request=post_request, user=self.user)
        PostViewSet.as_view({"post": "create"})(post_request)

        get_request = factory.get(path="api/v1/posts/", data={"type": "following"})
        force_authenticate(request=get_request, user=second_user)
        response = PostViewSet.as_view({"get": "list"})(get_request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["count"], 0)

        follow_request = factory.post(path=f"api/v1/user/{self.user.id}/follow/")
        force_authenticate(request=follow_request, user=second_user)
        FollowAPIView.as_view()(follow_request, id=str(self.user.id))

        get_request = factory.get(path="api/v1/posts/", data={"type": "following"})
        force_authenticate(request=get_request, user=second_user)
        response = PostViewSet.as_view({"get": "list"})(get_request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["count"], 1)

    def test_post_filter_type_bookmark(self):
        post_request = factory.post(path="api/v1/posts/", data=self.data)
        force_authenticate(request=post_request, user=self.user)
        PostViewSet.as_view({"post": "create"})(post_request)

        get_request = factory.get(path="api/v1/posts/", data={"type": "bookmark"})
        force_authenticate(request=get_request, user=self.user)
        response = PostViewSet.as_view({"get": "list"})(get_request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["count"], 0)

        bookmark_request = factory.patch(path=f"api/v1/posts/{Post.objects.first().id}/bookmark/")
        force_authenticate(request=bookmark_request, user=self.user)
        PostBookmarkAPIView.as_view()(bookmark_request, id=str(Post.objects.first().id))

        get_request = factory.get(path="api/v1/posts/", data={"type": "bookmark"})
        force_authenticate(request=get_request, user=self.user)
        response = PostViewSet.as_view({"get": "list"})(get_request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["count"], 1)

    def test_post_filter_owner(self):
        second_user = UserFactory()

        first_post_request = factory.post(path="api/v1/posts/", data=self.data)
        force_authenticate(request=first_post_request, user=self.user)
        PostViewSet.as_view({"post": "create"})(first_post_request)

        second_post_request = factory.post(path="api/v1/posts/", data=self.data)
        force_authenticate(request=second_post_request, user=second_user)
        PostViewSet.as_view({"post": "create"})(second_post_request)

        get_request = factory.get(path="api/v1/posts/", data={"owner": str(self.user.id)})
        force_authenticate(request=get_request, user=self.user)
        response = PostViewSet.as_view({"get": "list"})(get_request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["count"], 1)

        get_request = factory.get(path="api/v1/posts/", data={"owner": str(UserFactory().id)})
        force_authenticate(request=get_request, user=self.user)
        response = PostViewSet.as_view({"get": "list"})(get_request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["count"], 0)

    def test_post_filter_category(self):
        second_category = CategoryModelFactory()

        first_post_request = factory.post(path="api/v1/posts/", data=self.data)
        force_authenticate(request=first_post_request, user=self.user)
        PostViewSet.as_view({"post": "create"})(first_post_request)

        data = self.data.copy()
        first_category = data.pop("category")
        data["category"] = str(second_category.id)

        second_post_request = factory.post(path="api/v1/posts/", data=data)
        force_authenticate(request=second_post_request, user=self.user)
        PostViewSet.as_view({"post": "create"})(second_post_request)

        self.nupp.category = second_category
        self.nupp.save()

        data.pop("category")

        third_post_request = factory.post(path="api/v1/posts/", data=data)
        force_authenticate(request=third_post_request, user=self.user)
        PostViewSet.as_view({"post": "create"})(third_post_request)

        get_request = factory.get(path="api/v1/posts/", data={"category": str(first_category)})
        force_authenticate(request=get_request, user=self.user)
        response = PostViewSet.as_view({"get": "list"})(get_request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["count"], 1)

        get_request = factory.get(path="api/v1/posts/", data={"category": str(second_category.id)})
        force_authenticate(request=get_request, user=self.user)
        response = PostViewSet.as_view({"get": "list"})(get_request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["count"], 3)  # 3 from nupp, but only 2 from post category

        get_request = factory.get(path="api/v1/posts/", data={"category": str(CategoryModelFactory().id)})
        force_authenticate(request=get_request, user=self.user)
        response = PostViewSet.as_view({"get": "list"})(get_request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["count"], 0)

    def test_hidden_disabled_post(self):
        post_request = factory.post(path="api/v1/posts/", data=self.data)
        force_authenticate(request=post_request, user=self.user)
        PostViewSet.as_view({"post": "create"})(post_request)

        post = Post.objects.first()
        post.is_disabled = True
        post.save()

        get_request = factory.get(path="api/v1/posts/")
        force_authenticate(request=get_request, user=self.user)
        response = PostViewSet.as_view({"get": "list"})(get_request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["count"], 0)

    def test_post_has_highlights(self):
        first_post_request = factory.post(path="api/v1/posts/", data=self.data)
        force_authenticate(request=first_post_request, user=self.user)
        first_post_response = PostViewSet.as_view({"post": "create"})(first_post_request)

        first_post = Post.objects.get(id=first_post_response.data["id"])

        first_get_request = factory.get(path=f"api/v1/posts/{first_post.id}/")
        force_authenticate(request=first_get_request, user=self.user)
        first_response = PostViewSet.as_view({"get": "retrieve"})(first_get_request, id=first_post.id)
        self.assertFalse(first_response.data["has_highlights"])

        second_post_request = factory.post(path="api/v1/posts/", data=self.data)
        force_authenticate(request=second_post_request, user=self.user)
        second_post_response = PostViewSet.as_view({"post": "create"})(second_post_request)

        second_post = Post.objects.get(id=second_post_response.data["id"])

        data = self.data.copy()
        data["related_post_id"] = first_post_response.data["id"]
        data["type"] = PostType.HIGHLIGHT
        third_post_request = factory.post(path="api/v1/posts/", data=data)
        force_authenticate(request=third_post_request, user=self.user)
        third_post_response = PostViewSet.as_view({"post": "create"})(third_post_request)

        third_post = Post.objects.get(id=third_post_response.data["id"])

        second_get_request = factory.get(path=f"api/v1/posts/{first_post.id}/")
        force_authenticate(request=second_get_request, user=self.user)
        response = PostViewSet.as_view({"get": "retrieve"})(second_get_request, id=first_post.id)
        self.assertTrue(response.data["has_highlights"])

        third_get_request = factory.get(path=f"api/v1/posts/{second_post.id}/")
        force_authenticate(request=third_get_request, user=self.user)
        response = PostViewSet.as_view({"get": "retrieve"})(third_get_request, id=second_post.id)
        self.assertFalse(response.data["has_highlights"])

        fourth_get_request = factory.get(path=f"api/v1/posts/{third_post.id}/")
        force_authenticate(request=fourth_get_request, user=self.user)
        response = PostViewSet.as_view({"get": "retrieve"})(fourth_get_request, id=third_post.id)
        self.assertFalse(response.data["has_highlights"])

    def test_flag_post(self):
        self.assertEqual(Flag.objects.count(), 0)

        user = UserFactory()

        post_request = factory.post(path="api/v1/posts/", data=self.data)
        force_authenticate(request=post_request, user=user)
        post_response = PostViewSet.as_view({"post": "create"})(post_request)

        post = Post.objects.get(id=post_response.data["id"])

        flag_request = factory.post(path=f"api/v1/posts/{post.id}/flag/")
        force_authenticate(request=flag_request, user=self.user)
        response = PostViewSet.as_view({"post": "flag"})(flag_request, id=post.id)

        self.assertEqual(response.status_code, 202)
        flags = Flag.objects.all()
        self.assertEqual(flags.count(), 1)
        self.assertEqual(flags.first().post, post)
        self.assertEqual(flags.first().user, self.user)

    def test_hidden_flagged_post(self):
        user = UserFactory()

        post_request = factory.post(path="api/v1/posts/", data=self.data)
        force_authenticate(request=post_request, user=user)
        post_response = PostViewSet.as_view({"post": "create"})(post_request)

        post = Post.objects.get(id=post_response.data["id"])

        flag_request = factory.post(path=f"api/v1/posts/{post.id}/flag/")
        force_authenticate(request=flag_request, user=self.user)
        PostViewSet.as_view({"post": "flag"})(flag_request, id=post.id)

        get_request = factory.get(path="api/v1/posts/")
        force_authenticate(request=get_request, user=self.user)
        response = PostViewSet.as_view({"get": "list"})(get_request)

        self.assertEqual(response.data["count"], 0)

        second_get_request = factory.get(path="api/v1/posts/")
        force_authenticate(request=second_get_request, user=user)
        response = PostViewSet.as_view({"get": "list"})(second_get_request)

        self.assertEqual(response.data["count"], 1)

    def test_flag_post_twice(self):
        user = UserFactory()

        post_request = factory.post(path="api/v1/posts/", data=self.data)
        force_authenticate(request=post_request, user=user)
        post_response = PostViewSet.as_view({"post": "create"})(post_request)

        post = Post.objects.get(id=post_response.data["id"])

        flag_request = factory.post(path=f"api/v1/posts/{post.id}/flag/")
        force_authenticate(request=flag_request, user=self.user)
        PostViewSet.as_view({"post": "flag"})(flag_request, id=post.id)

        second_flag_request = factory.post(path=f"api/v1/posts/{post.id}/flag/")
        force_authenticate(request=second_flag_request, user=self.user)
        response = PostViewSet.as_view({"post": "flag"})(second_flag_request, id=post.id)

        self.assertEqual(response.status_code, 202)
        self.assertEqual(Flag.objects.count(), 1)
