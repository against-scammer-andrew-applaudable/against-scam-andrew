"""
Posts' test factories.
"""

import random

import factory

from apps.posts.constants import PostType, Segment
from apps.posts.models import Category, Post
from apps.users.tests.factories import UserFactory
from apps.posts.tests.base import faker


class CategoryModelFactory(factory.django.DjangoModelFactory):
    """
    Category instance factory.
    """

    label = factory.LazyAttribute(lambda _: "".join(faker.random_letters(5)))
    segment = factory.LazyAttribute(lambda _: random.choice(Segment.choices())[0])
    api_tags = factory.LazyAttribute(lambda _: [faker.word() for _ in range(3)])
    source_tags = factory.LazyAttribute(lambda _: [faker.word() for _ in range(3)])

    class Meta:
        model = Category


class PostAPIFactory(factory.DictFactory):
    """
    Post serializer factory.
    """

    title = factory.LazyAttribute(lambda _: faker.text())
    text = factory.LazyAttribute(lambda _: faker.text())
    ranking = factory.LazyAttribute(lambda _: faker.random_number(2))
    type = factory.LazyAttribute(lambda _: PostType.POST)
    elements = list()


class PostModelFactory(factory.django.DjangoModelFactory):
    """
    Post instance factory.
    """

    owner = factory.SubFactory('apps.users.tests.factories.UserFactory')
    text = factory.LazyAttribute(lambda _: faker.text())
    ranking = factory.LazyAttribute(lambda _: faker.random_number(2))
    type = factory.LazyAttribute(lambda _: PostType.POST)
    category = factory.SubFactory(CategoryModelFactory)

    class Meta:
        model = Post


class HighlightModelFactory(PostModelFactory):
    type = PostType.HIGHLIGHT
    related_post = factory.SubFactory(PostModelFactory)

    class Meta:
        model = Post
