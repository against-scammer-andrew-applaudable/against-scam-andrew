import logging
from django.conf import settings
from django.contrib.auth import get_user_model
from django.db.models import Exists, F, OuterRef, Q, Subquery, ExpressionWrapper, fields
from django.db.models.functions import Coalesce, Now, Abs
from django.db.models import F, ExpressionWrapper, IntegerField, CharField, Case, When, Value
from django.db.models.functions import Now, ExtractDay, TruncDay, ExtractYear, TruncYear
from django.db.models.expressions import Exists, Subquery, OuterRef
from django.db.models import Q
from django.db import transaction, connection
from django.http import Http404
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from django_filters.rest_framework import DjangoFilterBackend
from drf_yasg.utils import no_body, swagger_auto_schema
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.generics import GenericAPIView, ListAPIView, CreateAPIView
from rest_framework.parsers import FormParser, MultiPartParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet
from apps.api.v1.serializers import SuccessIndicatorSerializer
from datetime import datetime, timedelta
from django.utils import timezone
from apps.core.models import ToJSONB
from apps.nupp.models import NuppMedia
from apps.circle.models import Circle, CirclePost, CircleMember
from apps.posts.api.serializers import (
    ApplaudSerializer,
    CreatePostSerializer,
    # HighlightSerializer,
    MediaInfoSerializer,
    MediaUploadSimpleSerializer,
    MediaUploadPostSerializer,
    MediaUpdateSerializer,
    MediaDeleteSerializer,
    PatchPostSerializer,
    PostCategoriesBySegmentSerializer,
    PostCategorySerializer,
    PostSerializer,
    PostTagSerializer,
    UserPostEngagementSerializer,
    PostElementCreateSerializer,
    PostUserVisibilityCreateSerializer,
    PostLevelSerializer,
    PostLevelUpdateSerializer,
    PostEditionSerializer,
    PostCircleCreateSerializer
)
from apps.posts.constants import PostType, Segment
from apps.posts.filters import CategoryFilter, PostsFilter, TagFilter
from apps.posts.models import Applaud, Bookmark, Category, Flag, Highlight, Media, Post, Tag, PostUserVisibility, PostMention
from apps.posts.tasks import check_user_life_story_qty_task
from apps.users.api.authentication import JWTAuthenticationIgnoreIsActive
from apps.users.api.serializers import SimpleUserSerializer
from apps.experience.api.serializers import ElementLocationSerializer
from apps.experience.constant import ExperienceDataType
from apps.users.models import Profile, Follow
from apps.notifications.tasks import notify_object_task, notify_post_disappearing_task
from apps.posts.constants import Visibility
User = get_user_model()

class PostFeedListViewSet(ListAPIView):
    serializer_class = PostSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)

    def get_queryset(self):
        user = self.request.user
        user_location = Profile.objects.filter(user_id=user.id).values('location_metadata').first()['location_metadata']
        if user_location:
            user_country = user_location['country']
            user_state = user_location['state']
            user_city = user_location['city']
        else:
            user_country, user_state, user_city = None, None, None
        visible_user_condition = Exists(
            PostUserVisibility.objects.filter(
                user_id=user.id,
                post_id=OuterRef('pk')
            )
        )
        
        circle_visible_user_condition = Exists(
            Circle.objects.filter(
                posts__post_id=OuterRef('pk')
            ).filter(
                members__accepted_at__isnull=False
            ).filter(
                members__user_id=user.id
            )
        )

        follow_condition = Exists(
            Follow.objects.filter(
                follower_id = user.id,
                following_id = OuterRef('pk')
            )
        )

        country_condition = Exists(
            Profile.objects.filter(
                user_id=OuterRef('owner_id'),
                location_metadata__country=user_country,
            ).filter(
                ~Q(location_metadata__state=user_state),
                ~Q(location_metadata__city=user_city)
            )
        )

        state_condition = Exists(
            Profile.objects.filter(
                user_id = OuterRef('owner_id'),
                location_metadata__state = user_state
            ).filter(
                ~Q(location_metadata__city = user_city)
            )
        )

        city_condition = Exists(
            Profile.objects.filter(
                user_id = OuterRef('owner_id'),
                location_metadata__city = user_city
            )
        )

        poster_age =Coalesce(Subquery(
            Profile.objects.filter(user_id=OuterRef('owner_id'))
            .annotate(
                age=ExpressionWrapper(
                    ExtractYear(Now()) - ExtractYear('birth_date'),
                    output_field = IntegerField()
                )
            ).values('age')[:1],
            output_field = IntegerField()
        ), Value(0))

        viewer_age = Coalesce(Subquery(
            Profile.objects.filter(user_id=user.id)
            .annotate(
                age=ExpressionWrapper(
                    ExtractYear(Now()) - ExtractYear('birth_date'),
                    output_field = IntegerField()
                )
            ).values('age')[:1],
            output_field=IntegerField()
        ), Value(0))
        
        exclude_query = Q(~Q(type__in=PostType.include_post_types()) |
            # Visibility
            (~Q(owner__id=self.request.user.id) & (Q(visibility=Visibility.ONLYME) | (Q(visibility=Visibility.CUSTOM) & ~Q(visible_user_condition)))) |
            (Q(type__in=PostType.circle_question_types()) & ~Q(circle_visible_user_condition)) |
            # Disappearing
            Q(created_at__lte=(datetime.now() - timedelta(days=1))) |
            Q(id__in=(Flag.objects.filter(user=self.request.user).values_list("post", flat=True))) |
            Q(owner__id__in=(self.request.user.blocked_users.values_list("blocked_user", flat=True))))


        post_list = (
            Post.objects.get_enabled_posts()
            .exclude(exclude_query)
            .prefetch_related("media", "nupp", "owner", "mentions", "related_post")
            .annotate(
                days_since_posted=Coalesce(ExpressionWrapper(
                    ExtractDay(Now() - TruncDay('created_at')),
                    output_field=IntegerField()
                ), Value(0)),
                engagement_rate = Coalesce(F('applauds') / F('view_count') * 100, Value(0)),
                # F('engagement_rate') + 
                relevancy_score=ExpressionWrapper(
                    100 - F('days_since_posted') + Case(
                        When(visible_user_condition, then=Value(25)),
                        default=Value(0),
                        output_field=IntegerField()
                    ) + Case(
                        When(follow_condition, then=Value(20)),
                        default=Value(0),
                        output_field=IntegerField()
                    ) + Case(
                        When(country_condition, then=Value(2)),
                        default=Value(0),
                        output_field=IntegerField()
                    ) + Case(
                        When(state_condition, then=Value(5)),
                        default=Value(0),
                        output_field=IntegerField()
                    ) + Case(
                        When(city_condition, then=Value(10)),
                        default=Value(0),
                        output_field=IntegerField()
                    ),
                    output_field=IntegerField()
                ) - Abs(poster_age - viewer_age) * 2,
                has_highlights=Exists(Subquery(Post.objects.filter(related_post__id=OuterRef("pk"), type=PostType.HIGHLIGHT))),
            )
            .order_by("-relevancy_score")
            .order_by("-created_at")
        )
        return post_list
    
    
class PostDisappearFeedListViewSet(ListAPIView):
    serializer_class = PostSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)

    def get_queryset(self):
        visible_user_condition = Exists(
            PostUserVisibility.objects.filter(
                user_id=self.request.user.id,
                post_id=OuterRef('pk')
            )
        )
        
        filter_query = Q(type=PostType.GLIMPSE, created_at__gte=(datetime.now() - timedelta(days=1)))
        exclude_query = Q(Q(type__in=PostType.exclude_post_types()) |
            # Visibility
            (~Q(owner__id=self.request.user.id) & (Q(visibility=Visibility.ONLYME) | (Q(visibility=Visibility.CUSTOM) & ~Q(visible_user_condition)))) |
            Q(id__in=(Flag.objects.filter(user=self.request.user).values_list("post", flat=True))) |
            Q(owner__id__in=(self.request.user.blocked_users.values_list("blocked_user", flat=True))))
        
        post_list = (
            Post.objects.get_enabled_posts()
            .filter(filter_query)
            .exclude(exclude_query)
            .prefetch_related("media", "nupp", "owner", "mentions", "related_post")
            .order_by("-created_at")
        )
        return post_list
    
class PostCircleQuestionFeedListViewSet(ListAPIView):
    serializer_class = PostSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)

    def get_queryset(self):
        post_list = (
            Post.objects.get_enabled_posts()
            .filter(related_post_id=self.kwargs["id"], type=PostType.CIRCLE_QUESTION_REPLY)
            .exclude(
                Q(id__in=(Flag.objects.filter(user=self.request.user).values_list("post", flat=True))) |
                Q(owner__id__in=(self.request.user.blocked_users.values_list("blocked_user", flat=True)))
            )
            .prefetch_related("media", "owner", "mentions", "related_post")
            .order_by("-created_at")
        )
        return post_list
    

class PostGlimpseQuestionFeedListViewSet(ListAPIView):
    serializer_class = PostSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)

    def get_queryset(self):
        post_list = (
            Post.objects.get_enabled_posts()
            .filter(related_post_id=self.kwargs["id"], type=PostType.GLIMPSE_QUESTION_REPLY)
            .exclude(
                Q(id__in=(Flag.objects.filter(user=self.request.user).values_list("post", flat=True))) |
                Q(owner__id__in=(self.request.user.blocked_users.values_list("blocked_user", flat=True)))
            )
            .prefetch_related("media", "owner", "mentions", "related_post")
            .order_by("-created_at")
        )
        return post_list
    
class PostUserProfileFeedListViewSet(ListAPIView):
    serializer_class = PostSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)

    def get_queryset(self):
        self_user_id = self.request.user.id
        user_id = self.request.GET.get('user_id', self.request.user.id)
        # Visiter should be able to see posts which have visibility
        visible_user_condition = Exists(
            PostUserVisibility.objects.filter(
                user_id=self_user_id,
                post_id=OuterRef('pk')
            )
        )
        filter_query = Q(Q(owner__id=user_id) & 
                (Q(visible_user_condition) | Q(visibility=Visibility.PUBLIC)))
        exclude_query = Q(
            Q(type__in=PostType.exclude_profile_post_types()) |
            Q(id__in=(Flag.objects.filter(user=self.request.user).values_list("post", flat=True))) |
            Q(owner__id__in=(self.request.user.blocked_users.values_list("blocked_user", flat=True)))
        )
        if user_id != self_user_id:
            exclude_query = Q(
                Q(type__in=PostType.exclude_profile_post_types()) |
                (Q(type=PostType.GLIMPSE, created_at__lte=(datetime.now() - timedelta(days=1)))) |
                Q(id__in=(Flag.objects.filter(user=self.request.user).values_list("post", flat=True))) |
                Q(owner__id__in=(self.request.user.blocked_users.values_list("blocked_user", flat=True)))
            )
        post_list = (
            Post.objects.get_enabled_posts()
            .filter(filter_query)
            .exclude(exclude_query)
            .prefetch_related("media", "nupp", "owner", "visible_users", "mentions", "related_post")
            .order_by("-created_at")
        )
        return post_list
    
class PostUserPrivateFeedListViewSet(ListAPIView):
    serializer_class = PostSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)

    def get_queryset(self):
        user_id = self.request.user.id
        filter_query = Q(Q(type=PostType.GLIMPSE) & Q(owner__id=user_id) & Q(visibility=Visibility.ONLYME))
        post_list = (
            Post.objects.get_enabled_posts()
            .filter(filter_query)
            .exclude(Q(type__in=PostType.exclude_post_types()))
            .prefetch_related("media", "nupp", "owner", "visible_users", "mentions", "related_post")
            .order_by("-created_at")
        )
        return post_list
    
class GlimpseFeedListForUserViewSet(ListAPIView):
    serializer_class = PostSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)

    def get_queryset(self):
        user_id = self.kwargs['user_id']
        filter_query = Q(Q(type=PostType.GLIMPSE) & Q(owner__id=user_id) & Q(created_at__gte=(datetime.now() - timedelta(days=1))))
        post_list = (
            Post.objects.get_enabled_posts()
            .filter(filter_query)
            .exclude(Q(type__in=PostType.exclude_post_types()))
            .prefetch_related("media", "nupp", "owner", "visible_users", "mentions", "related_post")
            .order_by("-created_at")
        )
        return post_list
    
class GlimpseListForUserViewSet(ListAPIView):
    serializer_class = PostSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)

    def get_queryset(self):
        user_id = self.request.user.id
        filter_query = Q(Q(type=PostType.GLIMPSE) & Q(owner__id=user_id))
        post_list = (
            Post.objects.get_enabled_posts()
            .filter(filter_query)
            .exclude(Q(type__in=PostType.exclude_post_types()))
            .prefetch_related("media", "nupp", "owner", "visible_users", "mentions", "related_post")
            .order_by("-created_at")
        )
        return post_list
    
class PostUserTagFeedListViewSet(ListAPIView):
    serializer_class = PostSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)

    def get_queryset(self):
        user_id = self.request.GET.get('user_id', self.request.user.id)
        mention_user_condition = Exists(
            PostMention.objects.filter(
                user_id=user_id,
                post_id=OuterRef('pk')
            )
        )
        # Their profile
        # Need to consider for the tag feed for glimpse
        if user_id == self.request.user.id :
            post_list = (
                Post.objects.get_enabled_posts()
                .filter(Q(type=PostType.GLIMPSE) & Q(mention_user_condition))
                .exclude(
                    Q(type__in=PostType.circle_question_types()) |
                    Q(id__in=(Flag.objects.filter(user=self.request.user).values_list("post", flat=True))) |
                    Q(owner__id__in=(self.request.user.blocked_users.values_list("blocked_user", flat=True)))
                )
                .prefetch_related("media", "nupp", "owner", "visible_users", "mentions", "related_post")
                .order_by("-created_at")
            )
        else:            
            visible_user_condition = Exists(
                PostUserVisibility.objects.filter(
                    user_id=user_id,
                    post_id=OuterRef('pk')
                )
            )            
            post_list = (
                Post.objects.get_enabled_posts()
                .filter(Q(type=PostType.GLIMPSE) & Q(mention_user_condition) & 
                        (Q(visibility=Visibility.PUBLIC) | Q(visible_user_condition)))
                .exclude(
                    Q(type__in=PostType.circle_question_types()) |
                    Q(created_at__lte=(datetime.now() - timedelta(days=1))) |
                    Q(id__in=(Flag.objects.filter(user=self.request.user).values_list("post", flat=True))) |
                    Q(owner__id__in=(self.request.user.blocked_users.values_list("blocked_user", flat=True)))
                )
                .prefetch_related("media", "nupp", "owner", "visible_users", "mentions", "related_post")
                .order_by("-created_at")
            )
        return post_list

class PostViewSet(ModelViewSet):
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)
    serializer_class = PostSerializer
    lookup_field = "id"
    http_method_names = ("get", "post", "delete", "patch")
    filter_backends = (DjangoFilterBackend,)
    filterset_class = PostsFilter

    def get_queryset(self):
        nupp_media_source = NuppMedia.objects.filter(type="image", nupp=OuterRef('nupp_id'))[:1]
        post_media_source = Media.objects.filter(type="image", post__nupp=OuterRef('nupp_id'), post__is_disabled=False)[:1]

        post_list = (
            Post.objects.get_enabled_posts()
            .exclude(
                Q(id__in=(Flag.objects.filter(user=self.request.user).values_list("post", flat=True))) |
                Q(owner__id__in=(self.request.user.blocked_users.values_list("blocked_user", flat=True)))
            )
            .prefetch_related("media", "nupp", "owner", "mentions", "related_post")
            .annotate(
                has_highlights=Exists(Subquery(Post.objects.filter(related_post__id=OuterRef("pk"), type=PostType.HIGHLIGHT))),
                image_source=Coalesce(ToJSONB(nupp_media_source), ToJSONB(post_media_source)),
            )
            .order_by("-created_at")
        )
        return post_list


    def get_object(self):
        nupp_media_source = NuppMedia.objects.filter(type="image", nupp=OuterRef('nupp_id'))[:1]
        post_media_source = Media.objects.filter(type="image", post__nupp=OuterRef('nupp_id'), post__is_disabled=False)[:1]
        extra_kwargs = {}
        if self.request.method in ["PATCH", "DELETE"]:
            extra_kwargs = {"owner": self.request.user}
        try:
            return (
                Post.objects.get_enabled_posts()
                .prefetch_related("media", "nupp", "owner", "mentions", "related_post")
                .annotate(
                    has_highlights=Exists(Subquery(Post.objects.filter(related_post__id=self.kwargs["id"], type=PostType.HIGHLIGHT))),
                    image_source=Coalesce(ToJSONB(nupp_media_source), ToJSONB(post_media_source)),
                )
                .get(id=self.kwargs["id"], **extra_kwargs)
            )
        except Post.DoesNotExist:
            raise Http404

    def get_serializer_context(self):
        context = super().get_serializer_context()
        context['mentioner'] = self.request.user
        return context
    
    # Need to keep this function https://github.com/axnsan12/drf-yasg/issues/503
    def get_parsers(self):
        if getattr(self, 'swagger_fake_view', False):
            return []
        return super().get_parsers()
    
    def update_circle(self, data, post):
        circles = data.get('circles', None)
        if circles and post:
            for circle_id in circles:
                default_data = {'post_id': post, 'circle_id': circle_id}
                circle_post_serializer = PostCircleCreateSerializer(data=default_data)
                circle_post_serializer.is_valid(raise_exception=True)
                circle_post_serializer.save()
    
    def update_media(self, data, post):
        medias = data.get('medias', None)
        if medias and post:
            default_data = {'post': post, 'medias': medias}
            media_update_serializer = MediaUpdateSerializer(data=default_data)
            media_update_serializer.is_valid(raise_exception=True)
            media_update_serializer.save()
            
    def update_post_elements(self, data, post):
        post_elements = data.get('post_elements', None)
        if post_elements and post:
            for post_element in post_elements:
                post_element_serializer = PostElementCreateSerializer(data=post_element)
                post_element_serializer.is_valid(raise_exception=True)
                post_element_serializer.save(post=post)
                
    def update_post_user_visibility(self, data, post):
        visible_users = data.get('visible_users', None)
        if visible_users and post:
            for user in visible_users:
                user_data = {'user_id': user}
                serializer = PostUserVisibilityCreateSerializer(data=user_data)
                serializer.is_valid(raise_exception=True)
                visibility = serializer.save(post=post)
                notify_object_task.apply_async(args=(str(visibility.id), PostUserVisibility.__name__), countdown=10)
                
    def create_business_profile_for_location(self, data, post):
        element_locations = data.get('element_locations', None)
        if element_locations and post:
            for element_location in element_locations:
                serializer = ElementLocationSerializer(data=element_location)
                serializer.is_valid(raise_exception=True)
                experience_element = serializer.save(user=self.request.user)
                post_element={
                    'experience_id': element_location.get('experience_id', None),
                    'element_id': str(experience_element.id),
                    'content': element_location.get('content', None),
                    'metadata' : {},
                    'data_type': ExperienceDataType.LOCATION
                }
                post_element_serializer = PostElementCreateSerializer(data=post_element)
                post_element_serializer.is_valid(raise_exception=True)
                post_element_serializer.save(post=post)
            
    @swagger_auto_schema(
        request_body=CreatePostSerializer,
        responses={status.HTTP_201_CREATED: PostSerializer()},
    )
    def create(self, request: Request):

        serializer = CreatePostSerializer(data=request.data, context=self.get_serializer_context())
        serializer.is_valid(raise_exception=True)
        serializer.save()
        post = serializer.data.get('id')
        
        try:    
            # Update media ids
            self.update_circle(data=request.data, post=post)
        except Exception as e:
            print('Update media exception', e)
            pass
            # 
        try:            
            # Create business profile for location
            self.create_business_profile_for_location(data=request.data, post=post)
        except Exception as e:
            print('Create business profile exception', e)
            pass   
        try:    
            # Update media ids
            self.update_media(data=request.data, post=post)
        except Exception as e:
            print('Update media exception', e)
            pass
            # 
            
        try:    
            # Link post elements
            self.update_post_elements(data=request.data, post=post)
        except Exception as e:
            print('Link post elements exception', e)
            pass

            
        try:    
            # Link post user visibility
            self.update_post_user_visibility(data=request.data, post=post)
        except Exception as e:
            print('Link post user visibility exception', e)
            pass

                
            check_user_life_story_qty_task.delay(str(request.user.id))

            # notify post
            notify_object_task.apply_async(args=(str(serializer.instance.id), Post.__name__), countdown=10)

        try:    
            # notify disappearing post
            if serializer.instance.can_disappeared():
                disappearing_time_delta = timezone.now() + timedelta(hours=int(settings.DISAPPEAR_NOTIFICATION_TTL))
                notify_post_disappearing_task.apply_async(args=(str(serializer.instance.id),), eta=disappearing_time_delta)
        except Exception as e:
            print('notify disappearing post exception', e)
            pass
        
        response_serializer = PostSerializer(serializer.instance, context=self.get_serializer_context())
        return Response(status=status.HTTP_201_CREATED, data=response_serializer.data)

    def partial_update(self, request: Request, id: str = None, *args, **kwargs):
        post = self.get_object()
        serializer = PatchPostSerializer(post, data=request.data, partial=True, context=self.get_serializer_context())
        serializer.is_valid(raise_exception=True)
        serializer.save()
        response_serializer = PostSerializer(serializer.instance, context=self.get_serializer_context())
        return Response(status=status.HTTP_202_ACCEPTED, data=response_serializer.data)

    def destroy(self, request: Request, id: str = None):
        post = get_object_or_404(Post, id=id, owner=request.user)
        with transaction.atomic():
            if post.related_post:
                post.related_posts.update(related_post=post.related_post)
            else:
                post.related_posts.update(type=PostType.POST)
            post.delete()
        return Response(status=status.HTTP_202_ACCEPTED)
    
    @swagger_auto_schema(
        request_body=PostEditionSerializer,
        responses={
            status.HTTP_200_OK: PostSerializer(),
        },
    )
    @action(detail=True, methods=("patch",))
    def edit(self, request: Request, id: str = None):
        context = self.get_serializer_context()
        context["post"] = id
        serializer = PostEditionSerializer(data=request.data, context=context)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        post = Post.objects.filter(id=id).first()
        response_serializer = PostSerializer(post, context=self.get_serializer_context())
        return Response(status=status.HTTP_200_OK, data=response_serializer.data)

    @swagger_auto_schema(
        request_body=MediaUploadPostSerializer,
        responses={
            status.HTTP_201_CREATED: MediaInfoSerializer(),
        },
    )
    # Old api
    @action(detail=True, methods=("post",), parser_classes=(FormParser, MultiPartParser))
    def media(self, request: Request, id: str = None):
        context = self.get_serializer_context()
        context["post"] = id
        serializer = MediaUploadPostSerializer(data=request.data, context=context)
        serializer.is_valid(raise_exception=True)
        instance = serializer.save()
        response_serializer = MediaInfoSerializer(instance)
        return Response(status=status.HTTP_201_CREATED, data=response_serializer.data)

    @swagger_auto_schema(request_body=no_body, responses={status.HTTP_202_ACCEPTED: ""})
    @action(detail=True, methods=("post",))
    def flag(self, request: Request, id: str = None):
        post = self.get_object()
        if request.user != post.owner:
            flag, created = Flag.objects.get_or_create(post=post, user=request.user)
            if created:
                flag.notify()
        return Response(status=status.HTTP_202_ACCEPTED)
    
class MediaAPIView(GenericAPIView):
    permission_classes = (IsAuthenticated,)
    http_method_names = ("post", "delete", "patch")
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    serializer_class = MediaInfoSerializer
    queryset = Media.objects.all()
    lookup_field = "id"
    
    def get_serializer_context(self):
        return super().get_serializer_context()
    
    @swagger_auto_schema(
        request_body=MediaUploadSimpleSerializer,
        responses={
            status.HTTP_201_CREATED: MediaInfoSerializer(),
        },
    )
    @action(detail=True, methods=("post",), parser_classes=(FormParser, MultiPartParser))
    def post(self, request: Request):
        context = self.get_serializer_context()
        serializer = MediaUploadSimpleSerializer(data=request.data, context=context)
        serializer.is_valid(raise_exception=True)
        instance = serializer.save()
        response_serializer = MediaInfoSerializer(instance)
        return Response(status=status.HTTP_201_CREATED, data=response_serializer.data)
    
    @swagger_auto_schema(
        request_body=MediaDeleteSerializer,
        responses={
            status.HTTP_200_OK: SuccessIndicatorSerializer(),
        },
    )
    @action(detail=True, methods=("delete",))
    def delete(self, request: Request):
        context = self.get_serializer_context()
        serializer = MediaDeleteSerializer(data=request.data, context=context)
        serializer.is_valid(raise_exception=True)
        serializer.delete()
        return Response(status=status.HTTP_200_OK, data={"success": True})
    
    
class ApplaudAPIView(GenericAPIView):
    permission_classes = (IsAuthenticated,)
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    serializer_class = ApplaudSerializer
    queryset = Applaud.objects.all()
    lookup_field = "id"

    @method_decorator(cache_page(15 * 1 * 1))   # fast cache just to relieve any unnecessary load
    @swagger_auto_schema(responses={status.HTTP_200_OK: SimpleUserSerializer(many=True)})
    def get(self, request: Request, id: str = None):
        post = get_object_or_404(Post, id=id)
        applaud_users = (
            User.objects.filter(applauds__post=post)
            .annotate(applaud_date=F('applauds__created_at'))
            .prefetch_related("profile_data__avatar")
            .only('id', 'username', 'name', 'profile_data__avatar')
            .order_by("-applaud_date")
        )
        page = self.paginate_queryset(applaud_users)
        if page is not None:
            serializer = SimpleUserSerializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = SimpleUserSerializer(applaud_users, many=True)
        return Response(status=status.HTTP_200_OK, data=serializer.data)

    def patch(self, request: Request, id: str = None):
        context = self.get_serializer_context()
        context["post"] = id
        serializer = self.get_serializer(
            data=request.data,
            context=context,
        )
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(status=status.HTTP_200_OK, data=serializer.data)

    def delete(self, request: Request, id: str = None):
        context = self.get_serializer_context()
        context["post"] = id
        serializer = self.get_serializer(
            data=request.data,
            context=context,
        )
        serializer.is_valid(raise_exception=True)
        serializer.delete()
        return Response(status=status.HTTP_202_ACCEPTED, data=serializer.data)


class PostCategoryListAPIView(ListAPIView):
    permission_classes = (IsAuthenticated,)
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    filter_backends = (DjangoFilterBackend,)
    filterset_class = CategoryFilter
    queryset = Category.objects.all()

    def get_serializer_class(self):
        q_params = self.request.query_params
        q_params_copy = q_params.copy()
        q_params_copy.pop('offset', None)
        q_params_copy.pop('limit', None)
        if len(q_params_copy):
            return PostCategorySerializer
        return PostCategoriesBySegmentSerializer

    @method_decorator(cache_page(60 * 60 * 1, key_prefix='api_page'))
    def get(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        q_params = self.request.query_params
        q_params_copy = q_params.copy()
        q_params_copy.pop('offset', None)
        q_params_copy.pop('limit', None)
        result = queryset
        if not len(q_params_copy):
            segments = {segment[0]: {"categories": set(), "display_segment": ''} for segment in Segment.choices()}
            for category in queryset:
                try:
                    segments[category.segment]['categories'].add(category)
                    if not segments[category.segment]['display_segment']:
                        segments[category.segment]['display_segment'] = category.get_segment_display()
                except KeyError as e:
                    logging.error(e)
                    continue
            result = [
                {"segment": segment, "display_segment": items['display_segment'], "categories": items['categories']} for segment, items in segments.items()
            ]
        page = self.paginate_queryset(result)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        serializer = self.get_serializer(result, many=True)
        return Response(serializer.data)
        

class PostTagListAPIView(ListAPIView):
    permission_classes = (IsAuthenticated,)
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    serializer_class = PostTagSerializer
    filter_backends = (DjangoFilterBackend,)
    filterset_class = TagFilter

    def get_queryset(self):
        return Tag.objects.all()


class PostBookmarkAPIView(GenericAPIView):
    permission_classes = (IsAuthenticated,)
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    lookup_field = "id"

    @swagger_auto_schema(
        request_body=no_body,
        responses={
            status.HTTP_200_OK: UserPostEngagementSerializer(),
        },
    )
    def patch(self, request: Request, id: str = None):
        from apps.influence.tasks import task_create_bookmark_influence

        post = get_object_or_404(Post, id=id)
        bookmark, created = post.bookmarked.get_or_create(user=request.user)
        if created:
            task_create_bookmark_influence.apply_async((str(bookmark.id),), countdown=60)
        serializer = UserPostEngagementSerializer(post, context=self.get_serializer_context())
        return Response(status=status.HTTP_200_OK, data=serializer.data)

    @swagger_auto_schema(
        responses={
            status.HTTP_200_OK: UserPostEngagementSerializer(),
        }
    )
    def delete(self, request: Request, id: str = None):
        post = get_object_or_404(Post, id=id)
        try:
            post.bookmarked.get(user=request.user).delete()
        except Bookmark.DoesNotExist:
            pass
        serializer = UserPostEngagementSerializer(post, context=self.get_serializer_context())
        return Response(status=status.HTTP_200_OK, data=serializer.data)


# class HighlightAPIView(ListAPIView):
#     serializer_class = HighlightSerializer
#     permission_classes = (IsAuthenticated,)
#     authentication_classes = (JWTAuthenticationIgnoreIsActive,)

#     def get_queryset(self):
#         subquery = Highlight.objects.filter(id=self.kwargs["id"]).values('start_of_ancestry')[:1]
#         descendant = Highlight.objects.filter(related_post=OuterRef('pk'))
#         return (
#             Highlight.objects.filter(start_of_ancestry=Subquery(subquery))
#             .annotate(
#                 media=Subquery(Media.objects.filter(post=OuterRef('pk')).distinct("post").values('image_source')), has_descendant=Exists(descendant)
#             )
#             .order_by('-has_descendant')
#         )

class PostElementListAPIView(ListAPIView):
    serializer_class = PostSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)

    def get_queryset(self):
        return (
            Post.objects.filter(post_elements__element_id=self.kwargs["id"])
            .order_by("-created_at")
        )


class PostLevelAPIView(GenericAPIView):
    permission_classes = (IsAuthenticated,)
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)

    @swagger_auto_schema(request_body=PostLevelSerializer, responses={status.HTTP_200_OK: SuccessIndicatorSerializer()})
    def patch(self, request: Request, id: str = None):
        context = self.get_serializer_context()
        context["post"] = id
        serializer = PostLevelUpdateSerializer(data=request.data, context=context)
        serializer.is_valid(raise_exception=True)
        serializer.save() 

        force_disappear = request.data.get('force_disappear', False)
        post = Post.objects.filter(id=id).first()
        if post and force_disappear and post.can_disappeared():
            # notify disappearing post
            disappearing_time_delta = timezone.now() + timedelta(hours=int(settings.DISAPPEAR_NOTIFICATION_TTL))
            notify_post_disappearing_task.apply_async(args=(str(id),), eta=disappearing_time_delta)
        
        return Response(status=status.HTTP_200_OK, data={"success": True})
