"""
Posts API serializers
"""

import cloudinary
from django.conf import settings
from django.contrib.auth import get_user_model
from django.db import IntegrityError, transaction
from django.db.models import Count, F
from drf_yasg.utils import swagger_serializer_method
from hashid_field.rest import HashidSerializerCharField
from rest_framework import serializers

from django.utils import timezone

from apps.collection.api.serializers import BaseCollectionSerializer
from apps.core.richtext.serializers import ElementsSerializerMixin
from apps.media.serializers import MediaSerializer
from apps.media.constants import MediaType
from apps.mention.api.serializers import MentionSerializer
from apps.nupp.api.serializers import NuppSerializer
from apps.nupp.models import Nupp
from apps.nupp.tasks import task_find_nupp_metadata
from apps.posts.constants import PostType, Segment
from apps.posts.models import Applaud, Category, Highlight, Media, Post, Tag, PostElement, PostUserVisibility, PostMention
from apps.users.api.serializers import SimpleUserSerializer
from apps.experience.models import Experience, ExperienceElement
from apps.experience.api.serializers import ExperienceSimpleSerializer, ExperienceElementSimpleSerializer, ElementLocationSerializer
from apps.experience.constant import ExperienceDataType
from apps.notifications.tasks import notify_object_task
from apps.circle.models import CirclePost, Circle

User = get_user_model()


class PostFromContext:
    requires_context = True

    def __call__(self, serializer_field):
        try:
            return Post.objects.get(id=serializer_field.context["post"])
        except Post.DoesNotExist:
            raise serializers.ValidationError("Post not found.")

    def __repr__(self):
        return f"{self.__class__.__name__}()"


class MediaInfoSerializer(MediaSerializer, serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)

    class Meta:
        model = Media
        fields = ("url", "type", "id", "text", "media_detail", "height", "width", "order", "duration")

class MediaUploadBaseSerializer(serializers.ModelSerializer):
    source = serializers.FileField(required=False)
    def validate(self, attrs):
        if attrs['type'] != "text" and "source" not in attrs:
            raise serializers.ValidationError({"source": "For this type the source is required"})

        return super().validate(attrs)

    def save(self, **kwargs):
        try:
            file = self.validated_data.pop("source")
            media_type = self.validated_data["type"]
            return self.upload_media(file, media_type)
        except KeyError:
            image = cloudinary.CloudinaryImage(settings.CLOUDINARY_DEFAULT_BACKGROUND)
            return self.create_media_instance("image", image)

    def upload_media(self, file, media_type):
        resource_type = "image" if media_type == "image" else "video"
        uploaded_media = cloudinary.uploader.upload_resource(
            file, resource_type=resource_type, **{"folder": settings.CLOUDINARY_DEFAULT_FOLDER,  "tags": ['post'], "context": {"user": self.context['request'].user.id}} # when the media type is image, no need to define resource_type but if the type is video, resource_type should be video.
        )
        return self.create_media_instance(media_type, uploaded_media)

    def create_media_instance(self, media_type, uploaded_media):
        self.validated_data[f"{media_type}_source"] = uploaded_media
        self.validated_data["metadata"] = getattr(uploaded_media, "metadata", {})
        return Media.objects.create(**self.validated_data)
    
class MediaUploadPostSerializer(MediaUploadBaseSerializer, serializers.ModelSerializer):
    post = serializers.HiddenField(default=PostFromContext())    
    class Meta:
        model = Media
        fields = ("source", "type", "text", "post")
        extra_kwargs = {"type": {"choices": MediaType.valid_upload_options()}}

class MediaUploadSimpleSerializer(MediaUploadBaseSerializer, serializers.ModelSerializer):
    class Meta:
        model = Media
        fields = ("source", "type", "text")
        extra_kwargs = {"type": {"choices": MediaType.valid_upload_options()}}
        
        
class MediaIdSerializer(serializers.ModelSerializer):
    id = serializers.CharField(required=True)
    order = serializers.IntegerField(required=True)
    class Meta:
        model = Media
        fields = ("id", "order")
    
    
class MediaUpdateSerializer(serializers.ModelSerializer):
    post = serializers.CharField(required=True)
    medias = serializers.ListField(
        child=MediaIdSerializer(required=True),
        required=True,
        allow_empty=False
    ) 
    class Meta:
        model = Media
        fields = ("medias", "post")
        
    def validate(self, attrs):
        post = attrs.get('post', None)
        if post is None:
            raise serializers.ValidationError({"post": "This field is required."})
        if not Post.objects.filter(id=post).exists():
            raise serializers.ValidationError({"post": "Post doesn't exist."})
        medias = attrs.get('medias', None)
        if medias is None:
            raise serializers.ValidationError({"medias": "This field is required."})
        media_ids = [media.get('id') for media in medias]
        if not Media.objects.filter(id__in=media_ids).exists():
            raise serializers.ValidationError({"media_ids": "Media doesn't exist."})

        return attrs
    
    def save(self, **kwargs):
        medias = self.validated_data.pop("medias", None)
        post = self.validated_data.pop("post", None)
        for media in medias: 
            Media.objects.filter(id=media.get('id')).update(post_id=post, order= media.get('order'))
        return None
    
class MediaDeleteSerializer(serializers.ModelSerializer):
    media_ids = serializers.ListField(
        child=serializers.CharField(required=True),
        required=True,
        allow_empty=False
    )
    class Meta:
        model = Media
        fields = ("media_ids", "metadata")
        
    def validate(self, attrs):
        media_ids = attrs.get('media_ids', None)
        if media_ids is None:
            raise serializers.ValidationError({"media_ids": "This field is required."})
        if not Media.objects.filter(id__in=media_ids).exists():
            raise serializers.ValidationError({"media_ids": "Media doesn't exist."})
        
        return attrs
    
    def delete(self, **kwargs):
        if media_ids := self.validated_data.pop("media_ids", None):
            medias = Media.objects.filter(id__in=media_ids)
            for media in medias:
                metadata = media.metadata
                public_id = metadata['public_id']
                if public_id:
                    cloudinary.uploader.destroy(public_id=public_id) 
            Media.objects.filter(id__in=media_ids).delete()
        return None

class PostTagSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)

    class Meta:
        model = Tag
        fields = ("id", "label")


class PostCategorySerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    tags = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = Category
        fields = (
            "id",
            "label",
            "tags",
            "segment",
            "icon_slug",
        )

    @swagger_serializer_method(serializer_or_field=PostTagSerializer(many=True))
    def get_tags(self, obj):
        return PostTagSerializer(
            Tag.objects.annotate(post_count=Count("post")).filter(category=obj).order_by("-post_count", "id").values("id", "label")[:10],
            many=True,
        ).data


class PostCategoriesBySegmentSerializer(serializers.Serializer):
    segment = serializers.CharField()
    display_segment = serializers.CharField()
    categories = PostCategorySerializer(many=True)


class EngagementSerializer(serializers.Serializer):
    applauds = serializers.BooleanField()
    bookmarked = serializers.BooleanField()


class CounterSerializer(serializers.Serializer):
    applauds = serializers.IntegerField()
    shares = serializers.IntegerField()
    influences = serializers.IntegerField()


class PostEngagementMixin(metaclass=serializers.SerializerMetaclass):
    engagement = serializers.SerializerMethodField(read_only=True)

    @swagger_serializer_method(serializer_or_field=EngagementSerializer)
    def get_engagement(self, obj) -> dict:
        data = {
            "applauds": obj.post_applauds.filter(user=self.context['request'].user).exists(),
            "bookmarked": obj.bookmarked.filter(user=self.context['request'].user).exists(),
        }
        return EngagementSerializer(data).data
    
class PostLikesMixin(metaclass=serializers.SerializerMetaclass):
    applaud_users = serializers.SerializerMethodField(read_only=True)

    @swagger_serializer_method(serializer_or_field=SimpleUserSerializer)
    def get_applaud_users(self, obj) -> dict:
        data = obj.post_applauds.all()[:6]
        applaud_users = []
        for user in data:
            applaud_users.append(SimpleUserSerializer(user.user).data)
        return applaud_users


class PostCounterMixin(metaclass=serializers.SerializerMetaclass):
    counters = serializers.SerializerMethodField(read_only=True)

    @swagger_serializer_method(serializer_or_field=CounterSerializer)
    def get_counters(self, obj) -> dict:
        data = {
            "applauds": obj.applauds,
            "shares": obj.shares,
            "influences": obj.influences,
        }
        return CounterSerializer(data).data

class PostElementSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    experience = ExperienceSimpleSerializer(read_only=True)
    element = ExperienceElementSimpleSerializer(read_only=True)
    class Meta:
        model = PostElement
        fields = ("id", "experience", "element", "content", "metadata" , "data_type")
        
        
class PostUserVisibilitySerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    user = SimpleUserSerializer(read_only=True)
    class Meta:
        model = PostUserVisibility
        fields = ("id", "user")


class PostSimpleSerializer(serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)
    owner = SimpleUserSerializer()
    media = MediaInfoSerializer(many=True)
    
    class Meta:
        model = Post
        fields = (
            "id",
            "owner",
            "created_at",
            "media",
            "title",
            "text",
        )

class PostCircleSimpleSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    name = serializers.CharField()
    description = serializers.CharField()
    media = serializers.CharField(source="media.media_source")
    class Meta:
        model = Circle
        fields=('id', 'name', 'description', 'media')

class PostRepliesSerializer(serializers.Serializer):
    count = serializers.IntegerField()
    replies = SimpleUserSerializer(many=True)
    
    
    # Need to the get the question of parent post
    # If It is the answer of a circle question, should get the circle question
    # If It is the answer of a glimpse question, should get the glimpse question
class PostParentQuestionSerializer(serializers.Serializer):
    title = serializers.CharField()
    text = serializers.CharField()
    type = serializers.CharField()
    
class PostSerializer(PostEngagementMixin, PostCounterMixin, PostLikesMixin, serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)
    owner = SimpleUserSerializer()
    media = MediaInfoSerializer(many=True)
    related_post_id = serializers.CharField(source="related_post.id", read_only=True, allow_null=True)
    collections = BaseCollectionSerializer(many=True)
    user = SimpleUserSerializer()
    nupp = serializers.SerializerMethodField()
    category = PostCategorySerializer(required=False)
    tags = PostTagSerializer(many=True)
    mentions = MentionSerializer(many=True)
    post_elements = PostElementSerializer(many=True)
    visible_users = PostUserVisibilitySerializer(many=True)
    relevancy_score = serializers.IntegerField(read_only=True)
    has_highlights = serializers.SerializerMethodField(read_only=True)
    visibility = serializers.CharField()
    circles = serializers.SerializerMethodField()
    replies = serializers.SerializerMethodField()
    question = serializers.SerializerMethodField()
    owner_glimpses = serializers.SerializerMethodField()

    @swagger_serializer_method(serializer_or_field=NuppSerializer)
    def get_nupp(self, obj):
        nupp = obj.nupp
        if not nupp:
            return
        try:
            nupp.image_source = obj.image_source
            return NuppSerializer(nupp).data
        except AttributeError as e:
            pass

    @swagger_serializer_method(serializer_or_field=serializers.BooleanField)
    def get_has_highlights(self, obj):
        if not hasattr(obj, 'has_highlights'):
            obj.has_highlights = Post.objects.filter(related_post__id=obj.id, type=PostType.HIGHLIGHT).exists()
        return obj.has_highlights or obj.type == PostType.HIGHLIGHT
    
    
    @swagger_serializer_method(serializer_or_field=PostCircleSimpleSerializer(many=True))
    def get_circles(self, obj):
        post_ids = [obj.id, obj.related_post_id]
        circles = Circle.objects.filter(posts__post_id__in=post_ids)
        data = []
        for circle in circles:
            serializer = PostCircleSimpleSerializer(circle)
            data.append(serializer.data)
        return data

    @swagger_serializer_method(serializer_or_field=PostRepliesSerializer)
    def get_replies(self, obj):
        if obj.type == PostType.CIRCLE_QUESTION or obj.type == PostType.GLIMPSE_QUESTION:
            count = Post.objects.filter(related_post_id=obj.id).count()
            posts = Post.objects.filter(related_post_id=obj.id).distinct('owner')[:5]
            data = []
            for post in posts:
                owner = post.owner
                serializer = SimpleUserSerializer(owner)
                data.append(serializer.data)
            return {
                "count": count,
                "replies": data
            }
        elif obj.type == PostType.GLIMPSE_QUESTION_REPLY or obj.type == PostType.CIRCLE_QUESTION_REPLY:
            count = Post.objects.filter(related_post_id=obj.related_post_id).count()
            posts = Post.objects.filter(related_post_id=obj.related_post_id).distinct('owner')[:5]
            data = []
            for post in posts:
                owner = post.owner
                serializer = SimpleUserSerializer(owner)
                data.append(serializer.data)
            return {
                "count": count,
                "replies": data
            }
        else:
            return None
    
    @swagger_serializer_method(serializer_or_field=serializers.IntegerField())
    def get_owner_glimpses(self, obj):
        if obj.type == PostType.GLIMPSE or obj.type == PostType.GLIMPSE_QUESTION:
            count = Post.objects.filter(owner_id=obj.owner_id, type=PostType.GLIMPSE).count()
            return count
        else:
            return 0
        
    @swagger_serializer_method(serializer_or_field=PostParentQuestionSerializer)
    def get_question(self, obj):
        if obj.related_post:
            if obj.type == PostType.GLIMPSE_QUESTION_REPLY or obj.type == PostType.CIRCLE_QUESTION_REPLY:
                parent_post = obj.related_post
                return {
                    "title": parent_post.title,
                    "text": parent_post.text,
                    "type": parent_post.type
                }               
        else:
            return None
            

    class Meta:
        model = Post
        fields = (
            "id",
            "owner",
            "created_at",
            "when",
            "ranking",
            "counters",
            "applaud_users",
            "media",
            "title",
            "text",
            "elements",
            "collections",
            "type",
            "related_post_id",
            "segment",
            "nupp",
            "user",
            "engagement",
            "category",
            "tags",
            "mentions",
            "has_highlights",
            "location",
            "when_date_format",
            "post_elements",
            "circles",
            "disappeared_at",
            # TODO: Need to remove this param later
            "visible_users", 
            "relevancy_score",  
            "visibility",
            "replies",
            "long_content",
            "owner_glimpses",
            "resource_type",
            "question"
        )


class CreateSerializer(serializers.Serializer):
    type = serializers.CharField()
    name = serializers.CharField()
    source_ref = serializers.CharField(required=False)
    source = serializers.CharField(required=False)

    def validate(self, attrs):
        attrs = super().validate(attrs)
        valid_creation_types = [
            'nupp',
        ]  # in the future we might have others like (invite)
        if attrs.get("type") not in valid_creation_types:
            raise serializers.ValidationError({"type": "Invalid creation type."})

        if attrs.get("source") and not attrs.get("source_ref"):
            raise serializers.ValidationError({"source_ref": "This field is required."})

        if attrs.get("source_ref") and not attrs.get("source"):
            raise serializers.ValidationError({"source": "This field is required."})

        return attrs

    def save(self, post_data):
        if self.validated_data['type'] == 'nupp':
            # get or create nupp by source_ref
            if self.validated_data.get('source') and self.validated_data.get('source_ref'):
                obj, created = Nupp.objects.get_or_create(
                    source=self.validated_data['source'],
                    source_ref=self.validated_data['source_ref'],
                    segment=post_data['segment'],
                    defaults={
                        "name": self.validated_data['name'],
                        "source": self.validated_data['source'],
                        "source_ref": self.validated_data['source_ref'],
                        "creator": post_data['owner'],
                        "segment": post_data['segment'],
                        "category": post_data.get('category'),
                    },
                )
            # fallback and get or create by name
            else:
                obj, created = Nupp.objects.get_or_create(
                    name=self.validated_data['name'],
                    creator=post_data['owner'],
                    segment=post_data['segment'],
                    defaults={
                        "name": self.validated_data['name'],
                        "creator": post_data['owner'],
                        "segment": post_data['segment'],
                        "category": post_data.get('category'),
                    },
                )

            # add tags to nupp on creation
            if created and post_data.get('tags'):
                obj.tags.set(post_data['tags'])

            # trigger metadata handler
            if created:
                # give some delay to allow the user to tag the post
                task_find_nupp_metadata.apply_async(args=(str(obj.id),), countdown=60)
            return obj
        return None
    
    
 
    
class PostElementCreateSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    experience_id = serializers.CharField(allow_null=False, required=True)
    element_id = serializers.CharField(allow_null=True, required=False)
    content = serializers.CharField()
    metadata = serializers.JSONField(required=False)
    data_type = serializers.CharField()
    
    class Meta:
        model = PostElement
        fields = ("id", "experience_id", "element_id", "data_type", "content", "metadata")

    def validate(self, attrs):
        experience_id = attrs.get('experience_id', None)
        if experience_id is None:
            raise serializers.ValidationError({"experience_id": "This field is required."})
        if not Experience.objects.filter(id=experience_id).exists():
            raise serializers.ValidationError({"experience_id": "Experience doesn't exist."})
        element_id = attrs.get('element_id', None)
        if element_id and not ExperienceElement.objects.filter(id=element_id).exists():
            raise serializers.ValidationError({"element_id": "Element doesn't exist."})
        
        return attrs
        

    def save(self, post):
        validated_data = self.validated_data
        if post: 
           validated_data['post_id'] = post
        else:
           raise serializers.ValidationError({"post": "Post doesn't exist."})
        return super().create(validated_data)
    
    
class PostUserVisibilityCreateSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    user_id = serializers.CharField(allow_null=False, required=True)
    
    class Meta:
        model = PostUserVisibility
        fields = ("id", "user_id")

    def validate(self, attrs):
        user_id = attrs.get('user_id', None)
        if user_id is None:
            raise serializers.ValidationError({"user_id": "This field is required."})
        if not User.objects.filter(id=user_id).exists():
            raise serializers.ValidationError({"user_id": "User doesn't exist."})
        
        return attrs
        

    def save(self, post):
        validated_data = self.validated_data
        if post: 
           validated_data['post_id'] = post
        else:
           raise serializers.ValidationError({"post": "Post doesn't exist."})
        return super().create(validated_data)



class BasePostCreationSerializer(ElementsSerializerMixin):
    id = serializers.CharField(read_only=True)
    create = CreateSerializer(required=False)
    owner = serializers.HiddenField(default=serializers.CurrentUserDefault())
    related_post_id = serializers.PrimaryKeyRelatedField(queryset=Post.objects.get_enabled_posts(), allow_null=True, required=False)
    user = serializers.PrimaryKeyRelatedField(
        queryset=User.objects.filter(is_active=True),
        required=False,
        allow_null=True,
    )
    segment = serializers.CharField(required=False)

    class Meta:
        model = Post
        fields = (
            "id",
            "owner",
            "created_at",
            "when",
            "text",
            "elements",
            "collections",
            "title",
            "type",
            "resource_type",
            "ranking",
            "related_post_id",
            "category",
            "tags",
            "nupp",
            "user",
            "segment",
            "create",
            "location",
            "when_date_format",
            "visibility",
            "anonymous",
            "long_content"
        )
        extra_kwargs = {
            "created_at": {"read_only": True},
            "segment": {"required": False},
        }

    def validate(self, attrs, segment_options=[]):
        elements = attrs.get("elements", None)
        if elements is not None:
            attrs["elements"] = self.validate_elements(attrs.get("elements", []))
        attrs = super().validate(attrs)

        if attrs.get("segment"):
            if Segment.older_values().get(attrs["segment"]):
                attrs["segment"] = Segment.older_values()[attrs["segment"]]
            elif attrs["segment"] not in [choice[0] for choice in Segment.choices()]:
                raise serializers.ValidationError({"segment": "Invalid segment."})
        segment = attrs.get("segment")

        # skip type validation if instance exists
        if not (self.instance and self.instance.type):
            if not attrs.get("type"):
                raise serializers.ValidationError({"type": "This field is required."})

            if attrs.get("type") in PostType.relation_types() and not attrs.get("related_post_id"):
                raise serializers.ValidationError({"related_post_id": "This field is required."})

        # New flow allow user to create a post without nupp or user.
        # if this ever changes, uncomment the following lines.
        # if not any(segment_options) and not attrs.get("create") and not attrs.get("type") == "story":
        #     raise serializers.ValidationError({"create": "This field is required."})

        # validate if NUPP has same as post segment.
        if attrs.get("nupp") and attrs.get("nupp").segment != segment:
            raise serializers.ValidationError({"nupp": "Invalid Nupp segment."})

        # only allow user or nupp for someone segment.
        if segment == Segment.SOMEONE and all(segment_options):
            raise serializers.ValidationError({"user": "Cannot be used while nupp is present.", "nupp": "Cannot be used while user is present."})

        # only allow user on someone segment.
        if segment != Segment.SOMEONE and attrs.get("user"):
            raise serializers.ValidationError({"user": "Cannot use user with this segment."})

        if attrs.get("user") == attrs["owner"]:
            raise serializers.ValidationError({"user": "User cannot be the same as owner"})

        # ignore create if user or nupp is present.
        if any(segment_options):
            attrs.pop('create', None)

        return attrs

    def save(self, **kwargs):
        related_post = self.validated_data.pop("related_post_id", None)
        if related_post:
            self.validated_data["related_post"] = related_post

        create = self.validated_data.pop("create", None)
        if create:
            create_serializer = CreateSerializer(data=create)
            create_serializer.is_valid(raise_exception=True)
            created_obj = create_serializer.save(post_data=self.validated_data)
            if isinstance(created_obj, Nupp):
                self.validated_data['nupp'] = created_obj
        return super().save(**kwargs)


class CreatePostSerializer(BasePostCreationSerializer):
    def validate(self, attrs):
        segment_options = [attrs.get("nupp"), attrs.get("user")]
        return super().validate(attrs, segment_options=segment_options)


class PatchPostSerializer(BasePostCreationSerializer):
    def validate(self, attrs):
        segment_options = [self.instance.nupp, self.instance.user, attrs.get("nupp"), attrs.get("user")]
        attrs["owner"] = self.instance.owner
        return super().validate(attrs, segment_options=segment_options)


class ApplaudSerializer(PostEngagementMixin, PostCounterMixin, serializers.ModelSerializer):
    id = serializers.CharField(source="post.id", read_only=True)
    post = serializers.HiddenField(default=PostFromContext())
    user = serializers.HiddenField(default=serializers.CurrentUserDefault())

    class Meta:
        model = Applaud
        fields = ("id", "post", "user", "counters", "engagement")

    def validate(self, attrs):
        super().validate(attrs)
        try:
            self.instance = Applaud.objects.get(post=attrs["post"], user=attrs["user"])
        except Applaud.DoesNotExist:
            pass
        return attrs

    @swagger_serializer_method(serializer_or_field=CounterSerializer)
    def get_counters(self, obj) -> dict:
        return super().get_counters(self.validated_data["post"])

    @swagger_serializer_method(serializer_or_field=CounterSerializer)
    def get_engagement(self, obj) -> dict:
        return super().get_engagement(self.validated_data["post"])

    def save(self, **kwargs):
        from apps.influence.tasks import task_create_applaud_influence
        from apps.notifications.tasks import notify_object_task

        if self.instance:
            self.instance.type = self.validated_data.get("type")
            self.instance.save()
            return self.instance

        post = self.validated_data["post"]
        # Using update_or_create to avoid Integrity errors
        applaud = None
        with transaction.atomic():
            applaud, created = Applaud.objects.update_or_create(
                post=post,
                user=self.validated_data["user"],
                defaults={"type": self.validated_data.get("type")},
            )

            if created:
                task_create_applaud_influence.apply_async((str(applaud.id),), countdown=60)
            post.applauds = F('applauds') + 1
            post.save(update_fields=['applauds'])
            post.refresh_from_db()

            # notify applaud
            notify_object_task.apply_async(args=(applaud.id, Applaud.__name__), countdown=1)

        return applaud

    def delete(self, **kwargs):
        if self.instance:
            post = self.validated_data["post"]
            with transaction.atomic():
                self.instance.delete()
                try:
                    post.applauds = F('applauds') - 1
                    post.save()
                    post.refresh_from_db()
                except IntegrityError:
                    # In case applaud count is already 0, do not rollback the transaction
                    pass


class UserPostEngagementSerializer(PostCounterMixin, PostEngagementMixin, serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)

    class Meta:
        model = Post
        fields = ("id", "counters", "engagement")


# class HighlightSerializer(serializers.ModelSerializer):
#     id = HashidSerializerCharField(read_only=True)
#     ancestry = serializers.ListField(child=HashidSerializerCharField(), read_only=True, allow_null=True, allow_empty=True)
#     media = serializers.SerializerMethodField()
#     start_of_ancestry = HashidSerializerCharField()
#     has_descendant = serializers.BooleanField()
#     related_post = HashidSerializerCharField()

#     def get_media(self, obj):
#         try:
#             return obj.media.url
#         except AttributeError:
#             return None

#     class Meta:
#         model = Highlight
#         fields = ("id", "media", "number_of_ancestors", "related_post", "ancestry", "start_of_ancestry", "has_descendant")


class PostLevelSerializer(serializers.Serializer):
    level = serializers.IntegerField()
    force_disappear = serializers.BooleanField()
    
    
class PostLevelUpdateSerializer(serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)
    level = serializers.IntegerField()
    force_disappear = serializers.BooleanField(default=False)
    post = serializers.HiddenField(default=PostFromContext())

    class Meta:
        model = Post
        fields = ("id", "level", "post", "force_disappear")
        
    def validate(self, attrs):
        post = attrs["post"]
        if post.id is None:
            raise serializers.ValidationError({"post": "This field is required."})
        if not Post.objects.filter(id=post.id).exists():
            raise serializers.ValidationError({"post": "Post doesn't exist."})
        return attrs
    
    def save(self, **kwargs):
        post = self.validated_data["post"]
        force_disappear = self.validated_data.get('force_disappear', False)
        if force_disappear:
            return Post.objects.filter(id=post.id).update(
                ranking=self.validated_data["level"],
                disappeared_at=timezone.now()
            )
        return Post.objects.filter(id=post.id).update(
                ranking=self.validated_data["level"],
                disappeared_at=None
        )
        
        
class PostVisibleUserEditSerializer(serializers.Serializer):
    remove=serializers.ListField(
        child=serializers.CharField(required=True),
        required=False,
        allow_empty=True
    )
    add=serializers.ListField(
        child=serializers.CharField(required=True),
        required=False,
        allow_empty=True
    )
    
class PostMediaEditSerializer(serializers.Serializer):
    remove=serializers.ListField(
        child=serializers.CharField(required=True),
        required=False,
        allow_empty=True
    ) 
    add=serializers.ListField(
        child=MediaIdSerializer(required=True),
        required=False,
        allow_empty=True
    ) 
    
class PostCircleEditSerializer(serializers.Serializer):
    remove=serializers.ListField(
        child=serializers.CharField(required=True),
        required=False,
        allow_empty=True
    ) 
    add=serializers.ListField(
        child=serializers.CharField(required=True),
        required=False,
        allow_empty=True
    ) 
    
class PostElementEditSerializer(serializers.Serializer):
    remove=serializers.ListField(
        child=serializers.CharField(required=True),
        required=False,
        allow_empty=True
    ) 
    add=serializers.ListField(
        child=PostElementCreateSerializer(required=True),
        required=False,
        allow_empty=True
    ) 
    
class PostMentionSerializer(serializers.Serializer):
    type=serializers.CharField(required=True)
    id=serializers.CharField(required=True)
    
class PostMentionEditSerializer(serializers.Serializer):
    remove=serializers.ListField(
        child=serializers.CharField(required=True),
        required=False,
        allow_empty=True
    ) 
    add=serializers.ListField(
        child=PostMentionSerializer(required=True),
        required=False,
        allow_empty=True
    ) 
    
    
class PostCircleCreateSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    circle_id = serializers.CharField(required=True)
    post_id = serializers.CharField(required=True)
    class Meta:
        model = CirclePost
        fields = ('id', 'circle_id', 'post_id')
        
    def validate(self, attrs):
        return super().validate(attrs)
        
    def save(self, **kwargs):
        data = self.validated_data
        circle_id = data['circle_id']
        post_id = data['post_id']
        if CirclePost.objects.filter(circle_id=circle_id, post_id=post_id).exists():
            return None
        else:
            return super().save(**data)
    
        
        
        
class PostEditionSerializer(serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)
    post = serializers.HiddenField(default=PostFromContext())
    owner = serializers.HiddenField(default=serializers.CurrentUserDefault())
    related_post_id = serializers.PrimaryKeyRelatedField(queryset=Post.objects.get_enabled_posts(), allow_null=True, required=False)
    visible_users = PostVisibleUserEditSerializer(required=False)
    medias=PostMediaEditSerializer(required=False)
    post_elements=PostElementEditSerializer(required=False)
    mentions=PostMentionEditSerializer(required=False)
    circles=PostCircleEditSerializer(required=False)
    element_locations=serializers.ListField(
        child=ElementLocationSerializer(required=True),
        required=False,
        allow_empty=True
    ) 
    class Meta:
        model = Post
        fields = (
            "id",
            "post",
            "owner",
            "text",
            "title",
            "related_post_id",
            "visibility",
            "visible_users",
            "medias",
            "post_elements",
            "mentions",
            "circles",
            "element_locations",
            "long_content"
        )
        
    def validate(self, attrs):
        post = attrs["post"]
        if post.id is None:
            raise serializers.ValidationError({"post": "This field is required."})
        return attrs
    
    def save(self, **kwargs):
        from apps.mention.tasks import notify_mentions_task
        post = self.validated_data["post"]
        text = self.validated_data.get("text", None)
        title = self.validated_data.get("title", None)
        visibility = self.validated_data.get("visibility", None)
        related_post_id=self.validated_data.get("related_post_id", None)
        with transaction.atomic():
            try:
                if text:
                    post.text = text
                if title:
                    post.title = title
                if related_post_id and Post.objects.filter(id=related_post_id).exists():
                    post.related_post=related_post_id
                if visibility:
                    post.visibility = visibility
                post.save()
                post.refresh_from_db()
            except IntegrityError:
                # In case applaud count is already 0, do not rollback the transaction
                pass
        visible_users=self.validated_data.get("visible_users", None)
        if visible_users:
            remove_ids = visible_users.get("remove", None)
            add_users = visible_users.get("add", None)
            if remove_ids:
                for remove_id in remove_ids:
                    if PostUserVisibility.objects.filter(id=remove_id, post_id=post.id).exists():
                        PostUserVisibility.objects.filter(id=remove_id).delete()
            if add_users:
                for user_id in add_users:
                    if not PostUserVisibility.objects.filter(post_id=post.id, user_id=user_id).exists():
                        user_data = {'user_id': user_id}
                        serializer = PostUserVisibilityCreateSerializer(data=user_data)
                        serializer.is_valid(raise_exception=True)
                        visibility = serializer.save(post=post.id)
                        # Send notification to users
                        notify_object_task.apply_async(args=(str(visibility.id), PostUserVisibility.__name__), countdown=10)

                        
        mentions=self.validated_data.get("mentions", None)
        if mentions:
            remove_mentions=mentions.get("remove", None)
            add_mentions=mentions.get("add", None)
            if remove_mentions:
                for remove_id in remove_mentions:
                    # need to update the element text later
                    if PostMention.objects.filter(id=remove_id, post_id=post.id).exists():
                        PostMention.objects.filter(id=remove_id).delete()
            if add_mentions:
                for mention in add_mentions:
                    type = mention["type"]
                    mention_id = mention["id"]
                    owner = self.validated_data["owner"]
                    # need to update the element text later
                    if type == "user" and mention_id is not None and not PostMention.objects.filter(post_id=post.id, user_id=mention_id).exists():
                        post_mention = PostMention.objects.create(post_id=post.id, user_id=mention_id, mentioner_id=owner.id)
                        # Send notification
                        notify_mentions_task.apply_async(args=([post_mention.id], PostMention.__name__), countdown=1)
                    if type == "invite" and mention_id is not None and not PostMention.objects.filter(post_id=post.id, user_invite_id=mention_id).exists():
                        PostMention.objects.create(post_id=post.id, user_invite_id=mention_id, mentioner_id=owner.id)
                        
        post_elements = self.validated_data.get("post_elements", None)
        if post_elements:
            remove_elements=post_elements.get("remove", None)
            add_elements=post_elements.get("add", None)
            if remove_elements:
                for remove_id in remove_elements:
                    if PostElement.objects.filter(id=remove_id, post_id=post.id).exists():
                        PostElement.objects.filter(id=remove_id).delete()
            if add_elements:
                for element in add_elements:
                    post_element_serializer = PostElementCreateSerializer(data=element)
                    post_element_serializer.is_valid(raise_exception=True)
                    post_element_serializer.save(post=post.id)
                    
        medias = self.validated_data.get("medias", None)
        if medias:
            remove_medias=medias.get("remove", None)
            add_medias=medias.get("add", None)
            if remove_medias:
                for remove_id in remove_medias:
                    if Media.objects.filter(id=remove_id, post_id=post.id).exists():
                        Media.objects.filter(id=remove_id).delete()
            if add_medias:
                media_data = {'post': str(post.id), 'medias': add_medias}
                media_update_serializer = MediaUpdateSerializer(data=media_data)
                media_update_serializer.is_valid(raise_exception=True)
                media_update_serializer.save()
                
        element_locations = self.validated_data.get("element_locations", None)
        if element_locations:
                owner = self.validated_data["owner"]
                for element_location in element_locations:
                    serializer = ElementLocationSerializer(data=element_location)
                    serializer.is_valid(raise_exception=True)
                    experience_element = serializer.save(user=owner)
                    post_element={
                        'experience_id': element_location.get('experience_id', None),
                        'element_id': str(experience_element.id),
                        'content': element_location.get('content', None),
                        'metadata' : {},
                        'data_type': ExperienceDataType.LOCATION
                    }
                    post_element_serializer = PostElementCreateSerializer(data=post_element)
                    post_element_serializer.is_valid(raise_exception=True)
                    post_element_serializer.save(post=post.id)
        circles = self.validated_data.get("circles", None)
        if circles:
            remove_circles=circles.get("remove", None)
            add_circles=circles.get("add", None)
            if remove_circles:
                for circle_id in remove_circles:
                    if CirclePost.objects.filter(circle_id=circle_id, post_id=post.id).exists():
                        CirclePost.objects.filter(circle_id=circle_id, post_id=post.id).delete()
            if add_circles:
                for circle_id in add_circles:
                    data = { "circle_id": circle_id, "post_id": str(post.id)}
                    serializer = PostCircleCreateSerializer(data=data)
                    serializer.is_valid(raise_exception=True)
                    serializer.save()
        return None;
                    