from django.urls import path
from rest_framework.routers import DefaultRouter

from apps.posts.api.views import (
    ApplaudAPIView, 
    PostBookmarkAPIView, 
    PostCategoryListAPIView, 
    PostTagListAPIView, 
    PostViewSet, 
    # HighlightAPIView, 
    MediaAPIView, 
    PostElementListAPIView, 
    PostFeedListViewSet, 
    PostLevelAPIView, 
    PostDisappearFeedListViewSet, 
    PostUserProfileFeedListViewSet, 
    PostUserPrivateFeedListViewSet,
    PostUserTagFeedListViewSet,
    PostCircleQuestionFeedListViewSet,
    GlimpseFeedListForUserViewSet,
    PostGlimpseQuestionFeedListViewSet,
    GlimpseListForUserViewSet
    )

app_name = "posts"

router = DefaultRouter()
router.register(r"", PostViewSet, basename="posts")

urlpatterns = [
    path("feeds/", PostFeedListViewSet.as_view(), name="post_feed_list"),
    path("disappear-feeds/", PostDisappearFeedListViewSet.as_view(), name="post_disappear_feed_list"),
    path("profile/", PostUserProfileFeedListViewSet.as_view(), name="post_user_profile_feed_list"),
    path("private/", PostUserPrivateFeedListViewSet.as_view(), name="post_user_private_feed_list"),
    path("profile-tag/", PostUserTagFeedListViewSet.as_view(), name="post_user_tag_feed_list"),
    path("categories/", PostCategoryListAPIView.as_view(), name="categories_list"),    
    path("tags/", PostTagListAPIView.as_view(), name="tags_list"),
    path("media/", MediaAPIView.as_view(), name="media"),
    path("glimpse-user/<str:user_id>/", GlimpseFeedListForUserViewSet.as_view(), name="glimpse-feed-for-user"),
    path("glimpses/", GlimpseListForUserViewSet.as_view(), name="glimpses-for-user"),
    path("<str:id>/applaud/", ApplaudAPIView.as_view(), name="applaud"),
    path("<str:id>/bookmark/", PostBookmarkAPIView.as_view(), name="bookmark"),
    # path("<str:id>/highlights/", HighlightAPIView.as_view(), name="highlight_list"),
    path("<str:id>/circle-questions/", PostCircleQuestionFeedListViewSet.as_view(), name="circle_questions_list"),
    path("<str:id>/glimpse-questions/", PostGlimpseQuestionFeedListViewSet.as_view(), name="glimpse_questions_list"),
    path("<str:id>/element/", PostElementListAPIView.as_view(), name="post_by_element_list"),
    path("<str:id>/level/", PostLevelAPIView.as_view(), name="post_level_update"),

] + router.urls
