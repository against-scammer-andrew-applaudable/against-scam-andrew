from django.utils.translation import ngettext

from apps.posts.constants import PostType
from apps.posts.models import Post


def change_post_availability(queryset, action: str):
    action_dict = {
        "disable": True,
        "enable": False,
    }
    try:
        if isinstance(queryset, Post):
            updated = 1
            queryset.is_disabled = action_dict[action]
            queryset.save()
        else:
            updated = queryset.update(is_disabled=action_dict[action])
    except KeyError:
        raise ValueError("Invalid action")
    return ngettext(
        f'{updated} post was successfully {action}d.',
        f'{updated} posts were successfully {action}d.',
        updated,
    )


def check_user_life_story_qty(user):
    from apps.users.notify import user_notify_new_invites_push
    life_story_count = user.owned_posts.filter(type=PostType.STORY).count()
    if life_story_count % 7 == 0 and life_story_count > user.last_story_qty_trigger:
        user.number_invites += 1
        user.last_story_qty_trigger = life_story_count
        user.save()
        user_notify_new_invites_push(user)
