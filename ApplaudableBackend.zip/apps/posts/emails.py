"""
Post's app emails.
"""

from django import forms

from apps.email import EmailDefinition, register


@register("User Invite Post Mention")
class UserInvitePostMentionEmail(EmailDefinition):
    html_template = "email/user_invite.html"
    text_template = "email/user_invite.txt"

    subject = forms.CharField(initial="{{ site.name }} - Invite")
    title = forms.CharField(initial="You have been invited")
    sub_title = forms.CharField(initial='Create your account using the <a href="{{ target.invite_url }}">invite link</a>')
    message = forms.CharField(initial="The {{ site.name }} team", widget=forms.Textarea)

    @classmethod
    def sample_context(cls, bank):
        return {
            "target": {"invite_url": "https://www.applaudable.com/"},
        }


@register("Post Flagged Succesfully")
class PostFlaggedSuccesfullyEmail(EmailDefinition):
    html_template = "email/post_flagged.html"
    text_template = "email/post_flagged.txt"

    subject = forms.CharField(initial="{{ site.name }} - Post Flagged Succesfully")
    title = forms.CharField(initial="Post Flagged Succesfully")
    message = forms.CharField(initial="The {{ site.name }} team", widget=forms.Textarea)

    @classmethod
    def sample_context(cls, bank):
        return {}
