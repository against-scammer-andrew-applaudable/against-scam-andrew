from django.db.models import Manager


class PostManager(Manager):
    def get_enabled_posts(self):
        queryset = super().get_queryset()
        return queryset.filter(is_disabled=False)
