"""
Post's app notifications.
"""

from django import forms

from apps.notifications import AppNotificationDefinition, PushNotificationDefinition, SmsNotificationDefinition, register


@register("User Post Mention")
class UserPostMentionPushNotification(PushNotificationDefinition):
    TYPE = 'user_post_mention'

    title = forms.CharField(initial="You were mentioned in {{ site.name }}")
    text = forms.CharField(initial="{{ actor.name }} mentioned you in a post")


@register("User Post Mention")
class UserPostMentionAppNotification(AppNotificationDefinition):
    TYPE = 'user_post_mention'

    title = forms.CharField(initial="You were mentioned in {{ site.name }}")
    text = forms.CharField(initial="{{ actor.name }} mentioned you in a post")
    
    
    
@register("User Post Visibility")
class UserPostVisiblePushNotification(PushNotificationDefinition):
    TYPE = 'user_post_visibility'
    # TODO: Might need to update this later
    title = forms.CharField(initial="You were invited in {{ site.name }}")
    text = forms.CharField(initial="{{ actor.name }} invited you in a post")


@register("User Post Visibility")
class UserPostVisibleAppNotification(AppNotificationDefinition):
    TYPE = 'user_post_visibility'
    # TODO: Might need to update this later
    title = forms.CharField(initial="You were invited in {{ site.name }}")
    text = forms.CharField(initial="{{ actor.name }} invited you in a post")


@register("User Invite Post Mention")
class UserInvitePostMentionSmsNotification(SmsNotificationDefinition):
    TYPE = 'user_invite_post_mention'

    title = forms.CharField(initial="You have been invited to join {{ site.name }}")
    text = forms.CharField(initial="Create your account using the following link {{ target.invite_url }}")


@register("Post Applaud")
class PostApplaudPushNotification(PushNotificationDefinition):
    TYPE = 'post_applaud'

    title = forms.CharField(initial="Your post was applauded")
    text = forms.CharField(initial="{{ actor.name }} applauded your post")


@register("Post Applaud")
class PostApplaudAppNotification(AppNotificationDefinition):
    TYPE = 'post_applaud'

    title = forms.CharField(initial="Your post was applauded")
    text = forms.CharField(initial="{{ actor.name }} applauded your post")


@register("Post Someone User")
class PostSomeonePushNotification(PushNotificationDefinition):
    TYPE = 'post_someone_user'

    title = forms.CharField(initial="You were referenced in {{ site.name }}")
    text = forms.CharField(initial="{{ actor.name }} posted about you")


@register("Post Someone User")
class PostSomeoneAppNotification(AppNotificationDefinition):
    TYPE = 'post_someone_user'

    title = forms.CharField(initial="You were referenced in {{ site.name }}")
    text = forms.CharField(initial="{{ actor.name }} posted about you")
    
    
@register("Post Disappearing")
class PostDisappearPushNotification(PushNotificationDefinition):
    TYPE = 'post_disappearing'

    title = forms.CharField(initial="Your recent post will disappear in 1 hour")
    text = forms.CharField(initial="")


@register("Post Disappearing")
class PostDisappearAppNotification(AppNotificationDefinition):
    TYPE = 'post_disappearing'

    title = forms.CharField(initial="Your recent post will disappear in 1 hour")
    text = forms.CharField(initial="")
