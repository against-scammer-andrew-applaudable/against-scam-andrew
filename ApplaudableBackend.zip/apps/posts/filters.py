from django.contrib.auth import get_user_model
from django.db.models import Q, Exists, OuterRef
from django_filters import rest_framework as filters

from apps.api.filters import DynamicLookupFilter
from apps.collection.models import Collection
from apps.posts.models import Category, Tag, Post
from apps.posts.constants import PostType, Segment
from apps.nupp.models import Nupp

User = get_user_model()


class PostsFilter(DynamicLookupFilter):
    """
    User filter
    """

    user_field_name = "owner"
    active_filters = ("bookmark", "following", "suggestion", "post", "story")

    category = filters.ModelMultipleChoiceFilter(
        method="filter_by_category", help_text="Filter by category (NUPP category or post category", queryset=Category.objects.all()
    )
    type = filters.CharFilter(method="filter_by_selected_lookup", help_text="Filter by selected lookup (bookmark, following, suggestion)")
    owner = filters.ModelChoiceFilter(queryset=User.objects.filter(is_active=True), help_text="Filter by owner ID")
    collections = filters.ModelChoiceFilter(queryset=Collection.objects.all(), help_text="Filter by collection ID")
    nupp = filters.ModelChoiceFilter(queryset=Nupp.objects.all(), help_text="Filter by NUUP ID")

    @property
    def lookups(self):
        return {
            "following": {
                f"{self.user_field_name}__id__in": self.request.user.following.values_list("following_id", flat=True),
            },
            "bookmark": {
                "id__in": self.request.user.bookmarks.values_list("post_id", flat=True),
            },
            "suggestion": {},
            "post": {"type__in": PostType.regular_types()},
            "story": {"type": PostType.STORY},
        }

    def filter_by_category(self, queryset, value, *args, **kwargs):
        try:
            category_list = args[0]
            if category_list:
                queryset = queryset.filter(Q(nupp__category__in=category_list) | Q(category__in=category_list))
        except (IndexError, TypeError, ValueError):
            pass
        return queryset


class TagFilter(filters.FilterSet):
    category = filters.CharFilter(field_name='category__id')
    segment = filters.CharFilter(field_name="category__segment", distinct=True, method="segment_with_older_values")

    class Meta:
        model = Tag
        fields = ("category", "segment")

    def segment_with_older_values(self, queryset, name, value):
        if Segment.older_values().get(value):
            value = Segment.older_values()[value]
        return queryset.filter(category__segment=value)


class CategoryFilter(DynamicLookupFilter):
    active_filters = ("following", "suggestion")
    user_field_name = "owner"

    type = filters.CharFilter(method="filter_by_selected_lookup", help_text="Filter by selected lookup (following)")
    segment = filters.CharFilter(distinct=True, method="segment_with_older_values")

    class Meta:
        model = Category
        fields = ("type", "segment")

    @property
    def lookups(self):
        return {
            "following": {
                f"category_posts__{self.user_field_name}__in": self.request.user.following.values_list("following_id", flat=True),
            },
            "suggestion": {"post_exists": True, "nupp_exists": True},
        }

    def filter_by_selected_lookup(self, queryset, value, *args, **kwargs):
        posts = Post.objects.get_enabled_posts().filter(category_id=OuterRef('pk'))
        nupps = Nupp.objects.filter(category_id=OuterRef('pk'))
        queryset = queryset.annotate(post_exists=Exists(posts), nupp_exists=Exists(nupps))
        return super().filter_by_selected_lookup(queryset, value, *args, **kwargs)

    def segment_with_older_values(self, queryset, name, value):
        if Segment.older_values().get(value):
            value = Segment.older_values()[value]
        return queryset.filter(segment=value)
