import logging

from celery import shared_task
from django.db import IntegrityError, transaction
from django.db.models import F

from apps.core.services import RedisContextManager


@shared_task
def update_applaud_count_task():
    from apps.posts.models import Post

    with RedisContextManager() as redis:
        post_list = redis.hgetall("applauds")
        redis.delete("applauds")
    with transaction.atomic():
        for post_id, applaud_count in post_list.items():
            try:
                Post.objects.filter(id=post_id).update(applauds=F("applauds") + int(applaud_count))
            except IntegrityError as e:
                # May happen if desync happen and a negative applaud count is stored in redis
                # while post applaude count is already 0
                logging.exception(e)
                continue


@shared_task
def increment_applaud_count_task(post_id: int):
    with RedisContextManager() as redis:
        redis.hincrby("applauds", post_id, 1)


@shared_task
def decrement_applaud_count_task(post_id: int):
    with RedisContextManager() as redis:
        redis.hincrby("applauds", post_id, -1)


@shared_task
def check_user_life_story_qty_task(user_id: str):
    from apps.posts.utils import check_user_life_story_qty
    from apps.users.models import User

    user = User.objects.get(id=user_id)
    check_user_life_story_qty(user)
