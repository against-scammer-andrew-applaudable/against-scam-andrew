from django.utils.translation import gettext_lazy as _


class PostType:
    PERSON = "person"
    POST = "post"
    HIGHLIGHT = "highlight"
    REPOST = "repost"
    STORY = "story"
    CIRCLE_QUESTION = "circle_question"
    CIRCLE_QUESTION_REPLY = "circle_question_reply"
    GLIMPSE = 'glimpse'
    GLIMPSE_QUESTION = 'glimpse_question'
    GLIMPSE_QUESTION_REPLY = "glimpse_question_reply"

    @classmethod
    def choices(cls):
        return (
            (cls.PERSON, _("Person")),
            (cls.POST, _("Post")),
            (cls.HIGHLIGHT, _("Highlight")),
            (cls.REPOST, _("Repost")),
            (cls.STORY, _("Story")),
            (cls.CIRCLE_QUESTION, _("CircleQuestion")),
            (cls.CIRCLE_QUESTION_REPLY, _("CircleQuestionReply")),
            (cls.GLIMPSE, _("Glimpse")),
            (cls.GLIMPSE_QUESTION, _("GlimpseQuestion")),
            (cls.GLIMPSE_QUESTION_REPLY, _("GlimpseQuestionReply")),
        )

    @classmethod
    def relation_types(cls):
        return (cls.HIGHLIGHT, cls.REPOST)

    @classmethod
    def regular_types(cls):
        return (cls.POST, cls.PERSON, cls.HIGHLIGHT, cls.GLIMPSE)
    
    @classmethod
    def glimpse_types(cls):
        return (cls.GLIMPSE_QUESTION, cls.GLIMPSE, cls.GLIMPSE_QUESTION_REPLY)
    
    @classmethod
    def include_post_types(cls):
        return (cls.GLIMPSE_QUESTION, cls.GLIMPSE, cls.GLIMPSE_QUESTION_REPLY, cls.CIRCLE_QUESTION, cls.CIRCLE_QUESTION_REPLY)
    
    @classmethod
    def circle_question_types(cls):
        return (cls.CIRCLE_QUESTION, cls.CIRCLE_QUESTION_REPLY)
    
    @classmethod
    def exclude_post_types(cls):
        return (cls.CIRCLE_QUESTION, cls.CIRCLE_QUESTION_REPLY)
    
    @classmethod
    def exclude_profile_post_types(cls):
        return (cls.CIRCLE_QUESTION, cls.CIRCLE_QUESTION_REPLY, cls.GLIMPSE_QUESTION, cls.GLIMPSE_QUESTION_REPLY)
    
    
    @classmethod
    def glimpse_question_types(cls):
        return (cls.GLIMPSE_QUESTION, cls.GLIMPSE_QUESTION_REPLY)
    

# This will be used for glimpse
# To recognize the either glimpse is map or otherwise
class ResourceType:
    MAP = "map"
    TEXT = "text"
    IMAGE = "image"
    VIDEO = "video"
    OTHER = "other"

    @classmethod
    def choices(cls):
        return (
            (cls.MAP, _("Map")),
            (cls.TEXT, _("Text")),
            (cls.IMAGE, _("Image")),
            (cls.VIDEO, _("Video")),
            (cls.OTHER, _("Other")),
        )


class Segment:
    ACTIVITIES = "activities"
    SOMEONE = "people"
    SOMETHING = "things"
    SOMEWHERE = "places"

    @classmethod
    def choices(cls):
        return (
            (cls.ACTIVITIES, _("Activity")),
            (cls.SOMEONE, _("Person")),
            (cls.SOMETHING, _("Thing")),
            (cls.SOMEWHERE, _("Place")),
        )
    
    @classmethod
    def older_values(cls):
        return {
            'someone': cls.SOMEONE,
            'something': cls.SOMETHING,
            'somewhere': cls.SOMEWHERE,
        }


class ApplaudType:
    @classmethod
    def choices(cls):
        raise NotImplementedError


class HighlightSQL:
    sql = """
        DROP VIEW IF EXISTS highlight;
        CREATE OR REPLACE VIEW highlight AS
            WITH RECURSIVE highlight AS (
                SELECT posts_post.*, 0 AS number_of_ancestors, ARRAY [id] AS ancestry, id AS start_of_ancestry
                FROM posts_post
                WHERE related_post_id IS NULL AND type='post'
                UNION
                    SELECT p.*, h.number_of_ancestors + 1 AS ancestry_size, ARRAY_APPEND(h.ancestry, p.id) AS ascentry,
                    COALESCE(h.start_of_ancestry, p.related_post_id) AS start_of_ancestry
                    FROM posts_post AS p
                    INNER JOIN highlight AS h ON (h.id=p.related_post_id)
                    WHERE p.type='highlight'
        )
        SELECT * FROM highlight;
    """

    reverse_sql = "DROP VIEW IF EXISTS highlight;"


class Visibility:
    ONLYME = "onlyme"
    CUSTOM = "custom"
    PUBLIC = "public"

    @classmethod
    def choices(cls):
        return (
            (cls.ONLYME, _("onlyme")),
            (cls.CUSTOM, _("custom")),
            (cls.PUBLIC, _("public")),
        )