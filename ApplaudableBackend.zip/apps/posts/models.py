import logging
from re import compile as re_compile

from django.contrib.auth import get_user_model
from django.contrib.postgres.fields import ArrayField
from django.db import models
from hashid_field import BigHashidField
from datetime import timedelta
from django.utils import timezone

from apps.collection.models import Collection
from apps.core.models import (
    AbstractCreatedDateMixin,
    AbstractCreatedUpdatedDateMixin,
    AbstractMetadata,
    AbstractUniqueBigHashIDMixin,
    AbstractUniqueHashIDMixin,
)
from apps.core.richtext.models import AbstractRichTextModel
from apps.core.utils import clear_api_page_cache
from apps.media.models import AbstractMedia
from apps.mention.models import AbstractMention
from apps.posts.constants import PostType, Segment, Visibility, ResourceType
from apps.posts.managers import PostManager
from apps.posts.notify import (
    flagged_post_succesfully_notify,
    post_applaud_notify,
    post_mention_notify,
    post_notify,
    post_user_visibility_notify,
    post_disappear_notify
)
from  apps.experience.models import ExperienceElement, Experience
from  apps.experience.constant import ExperienceDataType

User = get_user_model()


class Tag(AbstractUniqueHashIDMixin):
    label = models.CharField(max_length=255)
    api_tags = ArrayField(models.CharField(max_length=200), blank=True)
    source_tags = ArrayField(models.CharField(max_length=200), blank=True)

    class Meta:
        verbose_name = "Tag"
        verbose_name_plural = "Tags"
        indexes = [
            *AbstractUniqueHashIDMixin.Meta.indexes,
        ]

    def __str__(self) -> str:
        return self.label


class Category(AbstractUniqueHashIDMixin):
    label = models.CharField(max_length=255)
    segment = models.CharField(max_length=25, choices=Segment.choices(), blank=True, null=True)
    icon_slug = models.CharField(max_length=48, blank=True)
    api_tags = ArrayField(models.CharField(max_length=200), blank=True)
    source_tags = ArrayField(models.CharField(max_length=200), blank=True)
    tags = models.ManyToManyField(Tag, blank=True)

    class Meta:
        verbose_name = "Category"
        verbose_name_plural = "Categories"
        indexes = [
            *AbstractUniqueHashIDMixin.Meta.indexes,
        ]

    def __str__(self) -> str:
        return self.label

    def save(self, *args, **kwargs):
        clear_api_page_cache()
        super().save(*args, **kwargs)


class PostBase(
    AbstractUniqueBigHashIDMixin,
    AbstractCreatedUpdatedDateMixin,
    AbstractRichTextModel,
    AbstractMetadata,
):
    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name="owned_%(class)ss")
    when = models.DateTimeField(null=True, blank=True)
    ranking = models.PositiveSmallIntegerField(default=0)
    applauds = models.PositiveIntegerField(default=0)
    shares = models.PositiveIntegerField(default=0)
    influences = models.PositiveIntegerField(default=0)
    type = models.CharField(max_length=45, blank=True, choices=PostType.choices())
    resource_type = models.CharField(max_length=45, blank=True, null=True, choices=ResourceType.choices())
    related_post = models.ForeignKey("self", on_delete=models.SET_NULL, related_name="related_%(class)ss", null=True, blank=True)
    segment = models.CharField(max_length=45, choices=Segment.choices())
    nupp = models.ForeignKey('nupp.Nupp', on_delete=models.SET_NULL, null=True, related_name="nupp_%(class)ss")
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="mentioned_%(class)ss", blank=True, null=True)
    category = models.ForeignKey(Category, blank=True, null=True, related_name="category_%(class)ss", on_delete=models.SET_NULL)
    is_disabled = models.BooleanField(default=False)
    title = models.CharField(max_length=60, null=True, blank=True)
    long_content=models.TextField(null=True, blank=True)
    location = models.CharField(max_length=255, blank=True)
    when_date_format = models.CharField(max_length=3, blank=True, default="DMY")
    visibility = models.CharField(max_length=45, blank=True, choices=Visibility.choices(), default=Visibility.PUBLIC)
    anonymous = models.BooleanField(default=False)
    view_count = models.PositiveIntegerField(default=1)
    disappeared_at=models.DateTimeField(null=True, blank=True)


    objects = PostManager()

    class Meta:
        abstract = True

    def __str__(self):
        return str(self.id)

    @staticmethod
    def calculate_text_reading_time(content: str) -> int:
        """
        Remove spaces, newlines, tabs, etc, and count words

        Return time in milliseconds
        """

        words_per_millisecond = 0.00333  # 200 words per minute
        word_length = 5
        elements_regex = re_compile(r':\w+:|<[@#]\w+>')  # Pattern to find rich_text elements in text (e.g :emoji:, <@user>, <#hashtag>)
        chars_to_remove = re_compile(r'[\s\n\t\r]')
        content = elements_regex.sub('AWORD', content)  # Replace emojis, mentions, hashtags with 5 letters to count as a word
        content = chars_to_remove.sub('', content)  # Remove spaces, newlines, tabs, etc
        words = len(content) / word_length
        return round(words / words_per_millisecond)

    def calculate_total_reading_time(self) -> int:
        """
        Returns time in milliseconds
        """

        non_text_media = self.media.exclude(type='text').count()
        text_media = ''.join(text for text in self.media.filter(type='text').values_list('text', flat=True))

        content = self.text + text_media
        reading_time = self.calculate_text_reading_time(content) + (non_text_media * 1000)
        return reading_time
    
    def can_disappeared(self) -> bool:
        time_delta = timezone.now() - timedelta(days=1)
        if self.ranking <= 2 or (self.disappeared_at and self.disappeared_at >= time_delta):
            return True
        return False 

    def delete(self, using=None, keep_parents=False):
        from apps.notifications.tasks import delete_user_notification_as_related_cascade
        from apps.notifications.utils import serialize_model_object

        serialized_model_object = serialize_model_object(self)
        delete_user_notification_as_related_cascade.delay(serialized_model_object)
        super().delete(using=using, keep_parents=keep_parents)


class Post(PostBase):
    tags = models.ManyToManyField(Tag, blank=True)
    collections = models.ManyToManyField(Collection, blank=True, related_name="posts")

    class Meta:
        verbose_name = "Post"
        verbose_name_plural = "Posts"
        indexes = [*AbstractUniqueBigHashIDMixin.Meta.indexes, *AbstractMetadata.Meta.indexes, models.Index(fields=['type'])]

    def notify(self):
        post_notify(self)
        
    def disappear_notify(self):
        post_disappear_notify(self)

    def get_icon(self):
        try:
            return self.media.first().cloudinary_resource.url
        except Exception as e:
            logging.exception(e)
            return ''

# Unused for now
class Highlight(PostBase):
    number_of_ancestors = models.IntegerField()
    ancestry = ArrayField(BigHashidField())
    start_of_ancestry = BigHashidField()

    class Meta:
        managed = False
        db_table = 'highlight'


class PostMention(AbstractMention):
    post = models.ForeignKey(Post, related_name="mentions", on_delete=models.CASCADE)

    def __str__(self):
        return str(self.post_id)

    @classmethod
    def mention_field_name(cls) -> str:
        return "post"

    def notify(self):
        post_mention_notify(self)
        
        
class PostUserVisibility(AbstractCreatedDateMixin):
    post = models.ForeignKey(Post, related_name="visible_users", on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="post_visibility")
    class Meta:
        constraints = [models.UniqueConstraint(fields=["post", "user"], name="unique_visible_users")]
        db_table = "post_user_visibility"

    def __str__(self):
        return str(self.post_id)

    def notify(self):
        post_user_visibility_notify(self)


class Media(AbstractMedia):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name="media", null=True)
    order = models.PositiveIntegerField(default=0)
    class Meta:
        verbose_name = "Media"
        verbose_name_plural = "Media"
        ordering = ['order']
        indexes = [
            *AbstractMedia.Meta.indexes,
        ]


class Bookmark(AbstractCreatedDateMixin):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name="bookmarked")
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="bookmarks")

    class Meta:
        constraints = [models.UniqueConstraint(fields=["post", "user"], name="unique_bookmark")]


class Applaud(AbstractCreatedDateMixin):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name="post_%(class)ss")
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="applauds")
    type = models.CharField(max_length=45, blank=True, null=True, default="applaud")

    class Meta:
        constraints = [models.UniqueConstraint(fields=["post", "user"], name="unique_applaud")]

    def __str__(self):
        return f"{self.post} - {self.user}"

    def notify(self):
        post_applaud_notify(self)


class Flag(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name="post_%(class)ss")
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="flags")

    def __str__(self):
        return f"{self.post} - {self.user}"

    def notify(self):
        flagged_post_succesfully_notify(self.user, self.post)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["post", "user"], name="unique_flag")]


class PostElement(models.Model):    
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name="post_elements")
    experience = models.ForeignKey(Experience, on_delete=models.CASCADE, null=True)
    element = models.ForeignKey(ExperienceElement, on_delete=models.CASCADE, null=True)
    data_type = models.CharField(max_length=60, blank=False, choices=ExperienceDataType.choices(), default=ExperienceDataType.FREEFORM)
    content = models.TextField()
    metadata = models.JSONField(blank=True, null=True, default=dict)
    class Meta:
        db_table = "post_elements"
