import random

from django.contrib import admin
from django.contrib.auth import get_user_model
from django.db.models import BooleanField, Case, Count, OuterRef, Subquery, When
from django.http.request import HttpRequest
from django.shortcuts import redirect
from django.urls import reverse
from apps.core.import_export import resources
from apps.core.import_export.admin import ImportExportAdminMixin
from import_export.fields import Field
from import_export.widgets import DateTimeWidget, ForeignKeyWidget, ManyToManyWidget

from apps.core.admin import FIELDSET_METADATA
from apps.media.admin import MediaAdmin, MediaInline
from apps.mention.admin import MentionAdmin
from apps.nupp.models import Nupp
from apps.posts.constants import PostType, Segment
from apps.posts.models import Applaud, Category, Flag, Media, Post, PostMention, Tag
from apps.posts.tasks import decrement_applaud_count_task
from apps.posts.utils import change_post_availability

User = get_user_model()


@admin.register(Tag)
class TagAdmin(admin.ModelAdmin):
    search_fields = ('label',)
    list_display = (
        'id',
        'label',
    )


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    search_fields = ('label',)
    filter_horizontal = ('tags',)
    list_display = (
        'id',
        'label',
        'segment',
    )


class PostMediaInline(MediaInline):
    model = Media

    def has_module_permission(self, request: HttpRequest) -> bool:
        return True


@admin.register(Media)
class PostMediaAdmin(MediaAdmin):
    raw_id_fields = ["post"]


class PostResource(resources.ModelResource):
    owner = Field(column_name='owner', attribute='owner', widget=ForeignKeyWidget(User))
    category = Field(column_name='category', attribute='category', widget=ForeignKeyWidget(Category))
    nupp = Field(column_name='nupp', attribute='nupp', widget=ForeignKeyWidget(Nupp))
    tags = Field(column_name='tags', attribute='tags', widget=ManyToManyWidget(Tag, separator='|'))
    when = Field(attribute='when', column_name='when', widget=DateTimeWidget('%Y-%m-%dT%H:%M:%S'))

    def before_import_row(self, row, **kwargs):
        post_type = row['type']

        allowed_post_types = [PostType.POST, PostType.STORY]
        if post_type not in allowed_post_types:
            row['type'] = random.choice(allowed_post_types)

    class Meta:
        model = Post
        fields = (
            "id",
            "text",
            "owner",
            "type",
            "segment",
            "category",
            "tags",
            "nupp",
            "when",
            "location",
            "title",
        )
        export_order = (
            "id",
            "text",
            "owner",
            "type",
            "segment",
            "category",
            "tags",
            "nupp",
            "when",
            "location",
            "title",
        )

        report_skipped = False
        skip_unchanged = True
        # clean_model_instances = True


class FlaggedPostsListFilter(admin.SimpleListFilter):
    title = 'Is Flagged'
    parameter_name = 'is_flagged'

    def lookups(self, request, model_admin):
        return (
            ('1', 'True'),
            ('0', 'False'),
        )

    def queryset(self, request, queryset):
        if self.value() == '1':
            return queryset.filter(is_flagged=True)
        elif self.value() == '0':
            return queryset.filter(is_flagged=False)


@admin.register(Post)
class PostAdmin(ImportExportAdminMixin, admin.ModelAdmin):
    list_filter = (
        'segment',
        'category',
        'tags',
        'is_disabled',
        FlaggedPostsListFilter,
    )
    search_fields = (
        'id',
        'owner__username',
        'text',
    )
    list_display = ('id', 'type', 'owner', 'segment', 'category', 'flag_count', 'is_flagged', 'created_at')
    fieldsets = (
        (
            None,
            {
                "fields": (
                    'title',
                    'text',
                    'owner',
                    (
                        'applauds',
                        'shares',
                        'influences',
                    ),
                    'location',
                    'type',
                    'segment',
                    'category',
                    'tags',
                    'collections',
                ),
            },
        ),
        # ("Dates", {"fields": ('when', 'created_at', 'updated_at')}),
        ("Relation", {"fields": ('user', 'nupp', 'related_post')}),
        (
            "Management",
            {
                "fields": (
                    'flag_count',
                    'is_disabled',
                )
            },
        ),
        FIELDSET_METADATA,
    )
    readonly_fields = ('flag_count', 'is_flagged')
    inlines = [
        PostMediaInline,
    ]

    resource_class = PostResource

    actions = ['disable_posts', 'enable_posts']

    change_form_template = 'admin/post_change_form.html'

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        qs = qs.annotate(
            flag_count=Count('post_flags'),
            is_flagged=Case(When(flag_count__gt=0, then=True), default=False, output_field=BooleanField()),
        )
        return qs

    def has_add_permission(self, request):
        return False

    # def has_change_permission(self, request, obj=None):
    #    return False

    def changeform_view(self, request, object_id=None, form_url="", extra_context=None):
        extra_context = extra_context or {}
        try:
            extra_context["is_disabled"] = Post.objects.get(id=object_id).is_disabled
        except Post.DoesNotExist:
            return redirect(reverse("admin:posts_post_changelist"))

        action_dict = {
            "_disable_posts": "disable",
            "_enable_posts": "enable",
        }

        try:
            action = action_dict.get(set(action_dict.keys()).intersection(set(request.POST.keys())).pop())
        except KeyError:
            action = None

        if request.method == "POST" and action:
            obj = Post.objects.get(id=object_id)
            message = change_post_availability(obj, action)
            self.message_user(request, message)
            return redirect(reverse("admin:posts_post_change", args=(object_id,)))
        return super().changeform_view(request, object_id, form_url, extra_context)

    @admin.action(description='Disable selected posts')
    def disable_posts(self, request, queryset):
        message = change_post_availability(queryset, "disable")
        self.message_user(request, message)

    @admin.action(description='Enable selected posts')
    def enable_posts(self, request, queryset):
        message = change_post_availability(queryset, "enable")
        self.message_user(request, message)

    @admin.display(description='Flag Count', ordering='flag_count')
    def flag_count(self, obj):
        return obj.flag_count

    @admin.display(description='Is Flagged', boolean=True, ordering='is_flagged')
    def is_flagged(self, obj):
        return obj.is_flagged


@admin.register(PostMention)
class PostMentionAdmin(MentionAdmin):
    search_fields = ('post__id',) + MentionAdmin.search_fields


@admin.register(Applaud)
class ApplaudAdmin(admin.ModelAdmin):
    list_display = ("post", "user")
    search_fields = ("post", "user")

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def delete_model(self, request, obj):
        decrement_applaud_count_task.delay(post_id=str(obj.post.id))
        return super().delete_model(request, obj)


@admin.register(Flag)
class FlagAdmin(admin.ModelAdmin):
    list_display = ("post", "user")
    search_fields = ("post", "user")

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
