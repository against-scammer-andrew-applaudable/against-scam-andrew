from apps.mention.constants import MentionType
from apps.posts import notifications
from apps.posts import emails
from apps.posts.constants import Segment
from datetime import timedelta
from django.utils import timezone

POST_APPLAUD = 'post_applaud'
POST_SOMEONE_USER = 'post_someone_user'
FLAGGED_POST_SUCCESFULLY = 'flagged_post_succesfully'
POST_VISIBLE_USER = 'post_visible_user'
POST_DISAPPEARING = 'post_disappearing'

POST_DELIVERY_NOTIFICATION_MAP = {
    MentionType.USER: [notifications.UserPostMentionPushNotification, notifications.UserPostMentionAppNotification],
    MentionType.NUPP: [],
    MentionType.INVITE: [notifications.UserInvitePostMentionSmsNotification, emails.UserInvitePostMentionEmail],
    POST_APPLAUD: [notifications.PostApplaudPushNotification, notifications.PostApplaudAppNotification],
    POST_SOMEONE_USER: [notifications.PostSomeonePushNotification, notifications.PostSomeoneAppNotification],
    POST_VISIBLE_USER: [notifications.UserPostVisiblePushNotification, notifications.UserPostVisibleAppNotification],
    FLAGGED_POST_SUCCESFULLY: [emails.PostFlaggedSuccesfullyEmail],
    POST_DISAPPEARING: [notifications.PostDisappearAppNotification, notifications.PostDisappearPushNotification]
}


def flagged_post_succesfully_notify(user, post):
    from apps.notifications.utils import create_and_send_notification

    delivery_definitions = POST_DELIVERY_NOTIFICATION_MAP.get(FLAGGED_POST_SUCCESFULLY, [])

    for delivery_definition in delivery_definitions:
        create_and_send_notification(
            delivery_definition,
            actors=[],
            scope=post,
            target=user,
            metadata={
                "post_type": post.type,
                "text": post.text,
                "title": post.title,
                "long_content": post.long_content
            },
        )


def post_mention_notify(post_mention):
    from apps.notifications.utils import create_and_send_notification

    target_type = post_mention.object_type
    target = post_mention.mentioned_object

    delivery_definitions = POST_DELIVERY_NOTIFICATION_MAP.get(target_type, [])

    for delivery_definition in delivery_definitions:
        delivery_method = delivery_definition.delivery_method()

        # special rule for invites
        if target_type == MentionType.INVITE and delivery_method not in target.allowed_delivery_methods():
            continue
        post = post_mention.post
        # handle notification
        create_and_send_notification(
            delivery_definition,
            actors=[
                post_mention.mentioner,
            ],
            scope=post,
            target=target,
            metadata={
                "post_type": post.type,
                "text": post.text,
                "title": post.title,
                "long_content": post.long_content
            },
        )
        
        
def post_user_visibility_notify(post_user_visibility):
    from apps.notifications.utils import create_and_send_notification

    target = post_user_visibility.user
    post = post_user_visibility.post
    actor = post_user_visibility.post.owner

    delivery_definitions = POST_DELIVERY_NOTIFICATION_MAP.get(POST_VISIBLE_USER, [])

    for delivery_definition in delivery_definitions:
        # handle notification
        create_and_send_notification(
            delivery_definition,
            actors=[
                actor,
            ],
            scope=post,
            target=target,
            metadata={
                "post_type": post.type,
                "text": post.text,
                "title": post.title,
                "long_content": post.long_content
            },
        )


def post_applaud_notify(post_applaud):
    from apps.notifications.utils import create_and_send_notification

    delivery_definitions = POST_DELIVERY_NOTIFICATION_MAP.get(POST_APPLAUD, [])

    for delivery_definition in delivery_definitions:
        post = post_applaud.post
        # handle notification
        create_and_send_notification(
            delivery_definition,
            actors=[
                post_applaud.user,
            ],
            scope=post,
            target=post.owner,
            metadata={
                "post_type": post.type,
                "text": post.text,
                "title": post.title,
                "long_content": post.long_content
            },
        )


def post_notify(post):
    from apps.notifications.utils import create_and_send_notification

    if post.segment == Segment.SOMEONE and post.user:
        delivery_definitions = POST_DELIVERY_NOTIFICATION_MAP.get(POST_SOMEONE_USER, [])
    else:
        delivery_definitions = []

    for delivery_definition in delivery_definitions:
        # handle notification
        create_and_send_notification(
            delivery_definition,
            actors=[
                post.owner,
            ],
            scope=post,
            target=post.user,
            metadata={
                "post_type": post.type,
                "text": post.text,
                "title": post.title,
                "long_content": post.long_content
            },
        )

def post_disappear_notify(post):
    from apps.notifications.utils import create_and_send_notification
    time_delta = timezone.now() - timedelta(hours=22)

    if post.ranking <= 2 and post.created_at >= time_delta:
        delivery_definitions = POST_DELIVERY_NOTIFICATION_MAP.get(POST_DISAPPEARING, [])
    elif post.disappeared_at and post.disappeared_at >= time_delta:
        delivery_definitions = POST_DELIVERY_NOTIFICATION_MAP.get(POST_DISAPPEARING, [])

    for delivery_definition in delivery_definitions:
        # handle notification
        create_and_send_notification(
            delivery_definition,
            actors=[],
            scope=post,
            target=post.owner,
            metadata={
                "post_type": post.type,
                "text": post.text,
                "title": post.title,
                "long_content": post.long_content
            },
        )