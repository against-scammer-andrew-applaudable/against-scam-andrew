from celery import shared_task

from apps.influence.constant import InflunceAction
from apps.influence.models import PostImpression
from apps.influence.utils import validate_post_impression

AVERAGE_TIME_VIEW = 30


@shared_task
def task_validate_post_impression(impression_id):
    try:
        impression = PostImpression.objects.get(id=impression_id)
        validate_post_impression(impression)
    except PostImpression.DoesNotExist:
        pass


@shared_task
def task_create_applaud_influence(applaud_id):
    from apps.posts.models import Applaud

    try:
        applaud = Applaud.objects.get(id=applaud_id)
    except Applaud.DoesNotExist:
        return

    impression, created = PostImpression.objects.get_or_create(user=applaud.user, post=applaud.post, action=InflunceAction.APPLAUD)
    if created:
        validate_post_impression(impression)


@shared_task
def task_create_bookmark_influence(bookmark_id):
    from apps.posts.models import Bookmark

    try:
        bookmark = Bookmark.objects.get(id=bookmark_id)
    except Bookmark.DoesNotExist:
        return

    impression, created = PostImpression.objects.get_or_create(user=bookmark.user, post=bookmark.post, action=InflunceAction.BOOKMARK)
    if not created:
        validate_post_impression(impression)
