from django.db import transaction
from django.db.models import F

from apps.influence.constant import InflunceAction
from apps.influence.models import PostImpression


def validate_post_impression(impression):
    with transaction.atomic():
        user = impression.user
        post = impression.post

        view_time = impression.view_time

        if impression.action == InflunceAction.VIEW and (not view_time or view_time < post.calculate_total_reading_time()):
            impression.delete()
            return

        if not PostImpression.objects.filter(user=user, post=post, is_valid=True).exclude(id=impression.id).exists():
            impression.is_valid = True
            impression.save()
            post.influences = F('influences') + 1
            post.save()
