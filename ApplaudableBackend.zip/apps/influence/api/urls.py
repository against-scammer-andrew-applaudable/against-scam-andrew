from django.urls import path
from .views import PostViewsViewSet

app_name = "influences"


urlpatterns = [
    path("posts/", PostViewsViewSet.as_view(), name="influence_post_create")
]