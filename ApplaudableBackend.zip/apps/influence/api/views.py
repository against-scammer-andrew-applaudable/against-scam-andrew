from rest_framework.generics import CreateAPIView

from apps.influence.api.serializer import PostImpressionModelSerializer
from apps.influence.constant import InflunceAction
from apps.influence.models import PostImpression


class PostViewsViewSet(CreateAPIView):
    http_method_names = ['post', 'head', 'options', 'trace']
    queryset = PostImpression.objects.all()
    serializer_class = PostImpressionModelSerializer

    def get_serializer(self, *args, **kwargs):
        kwargs['many'] = True
        return super().get_serializer(*args, **kwargs)

    def get_serializer_context(self):
        context = super().get_serializer_context()
        context['action'] = InflunceAction.VIEW
        return context

    def create(self, request, *args, **kwargs):
        response = super().create(request, *args, **kwargs)
        response.data = None
        return response
