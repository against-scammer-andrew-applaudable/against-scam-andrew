from rest_framework import serializers
from hashid_field.rest import HashidSerializerCharField

from apps.influence.constant import InflunceAction
from apps.influence.models import PostImpression
from apps.influence.tasks import task_validate_post_impression
from apps.posts.models import Post


class PostImpressionListSerializer(serializers.ListSerializer):
    pass


class PostImpressionModelSerializer(serializers.ModelSerializer):
    post = serializers.PrimaryKeyRelatedField(pk_field=HashidSerializerCharField(source_field='posts.Post.id'), queryset=Post.objects.all())
    user = serializers.HiddenField(default=serializers.CurrentUserDefault())
    action = serializers.HiddenField(default=InflunceAction.VIEW)

    class Meta:
        model = PostImpression
        fields = ['post', 'view_time', 'metadata', 'user', 'action']
        list_serializer_class = PostImpressionListSerializer

    def create(self, validated_data):
        impression = super().create(validated_data)
        task_validate_post_impression.delay(str(impression.id))
        return impression
