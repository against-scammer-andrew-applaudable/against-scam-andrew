import factory

from apps.influence.models import PostImpression


class PostImpressionFactory(factory.django.DjangoModelFactory):
    user = factory.SubFactory('apps.users.tests.factories.UserFactory')
    post = factory.SubFactory('apps.posts.tests.factories.PostModelFactory')

    class Meta:
        model = PostImpression
