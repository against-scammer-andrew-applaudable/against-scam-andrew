from django.contrib.auth import get_user_model
from django.test import TestCase

from apps.influence.constant import InflunceAction
from apps.influence.models import PostImpression
from apps.influence.tests.factories import PostImpressionFactory
from apps.influence.utils import validate_post_impression

User = get_user_model()


class ValidatePostImpressionTestCase(TestCase):
    def setUp(self):
        self.impression = PostImpressionFactory(action=InflunceAction.VIEW)

    def test_validate_post_impression(self):
        self.impression.view_time = self.impression.post.calculate_total_reading_time()
        self.impression.save()

        validate_post_impression(self.impression)
        self.assertTrue(self.impression.is_valid)
        self.impression.post.refresh_from_db()
        self.assertEqual(self.impression.post.influences, 1)

    def test_duplicate_post_impression(self):
        self.impression.view_time = self.impression.post.calculate_total_reading_time()
        self.impression.save()

        validate_post_impression(self.impression)
        second_impression = PostImpressionFactory(user=self.impression.user, post=self.impression.post, action=InflunceAction.VIEW)
        validate_post_impression(second_impression)
        self.assertFalse(second_impression.is_valid)
        self.impression.post.refresh_from_db()
        self.assertEqual(self.impression.post.influences, 1)

    def test_view_time_not_enough(self):
        self.impression.view_time = self.impression.post.calculate_total_reading_time() - 1
        self.impression.save()

        self.assertEqual(PostImpression.objects.count(), 1)
        validate_post_impression(self.impression)
        self.assertEqual(PostImpression.objects.count(), 0)
        self.assertFalse(self.impression.is_valid)
        self.impression.post.refresh_from_db()
        self.assertEqual(self.impression.post.influences, 0)
