from django.utils.translation import gettext_lazy as _


class InflunceAction:
    APPLAUD = "applaud"
    BOOKMARK = "bookmark"
    VIEW = "view"
    NUPP = "nupp"

    @classmethod
    def choices(cls):
        return (
            (cls.APPLAUD, _("Applaud")),
            (cls.BOOKMARK, _("Bookmark")),
            (cls.VIEW, _("View")),
            (cls.NUPP, _("Nupp")),
        )
