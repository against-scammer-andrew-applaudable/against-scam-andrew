from django.contrib.auth import get_user_model
from django.db import models

from apps.core.models import AbstractUniqueHashIDMixin, AbstractCreatedDateMixin
from .constant import InflunceAction
from apps.posts.models import Post

User = get_user_model()


class ImpressionBase(AbstractUniqueHashIDMixin, AbstractCreatedDateMixin):
    action = models.CharField(choices=InflunceAction.choices(), max_length=50, null=False)
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    is_valid = models.BooleanField(default=False)
    metadata = models.JSONField(null=True)

    class Meta:
        abstract = True


class PostImpression(ImpressionBase):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name="impressions")
    view_time = models.PositiveIntegerField(null=True)

    class Meta:
        index_together = ['post', 'user']
