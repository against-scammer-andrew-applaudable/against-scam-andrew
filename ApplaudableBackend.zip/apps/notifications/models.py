import json

from django.contrib.auth import get_user_model
from django.contrib.postgres.fields import ArrayField
from django.db import models
from django.utils import timezone
from django.utils.module_loading import import_string
from django.utils.translation import gettext_lazy as _

from apps.core.models import AbstractCreatedDateMixin, AbstractUniqueBigHashIDMixin
from apps.users.models import UserInvite

from .constants import DeliveryMethod

User = get_user_model()


class NotificationEvent(AbstractCreatedDateMixin):
    delivery_method = models.CharField(max_length=48, choices=DeliveryMethod.choices())
    definition_name = models.CharField(max_length=252, default="", blank=True)
    actors = ArrayField(models.CharField(max_length=252), blank=True)
    target = models.CharField(max_length=252, db_index=True)
    scope = models.CharField(max_length=252, db_index=True)
    sent_at = models.DateTimeField(_("Sent date"), null=True, blank=True)
    metadata = models.JSONField(blank=True, null=True, default=dict)

    @property
    def definition_class(self):
        return import_string(self.definition_name)

    def _load_serialized_model(self, serialized_model):
        if serialized_model:
            model_module, model_id = json.loads(serialized_model)
            return import_string(model_module).objects.get(id=model_id)
        return None

    def get_actors(self):
        return [self._load_serialized_model(serialized_model) for serialized_model in self.actors]

    def get_target(self):
        return self._load_serialized_model(self.target)

    def get_scope(self):
        return self._load_serialized_model(self.scope)

    def send(self):
        from apps.notifications.utils import send

        DefinitionClass = self.definition_class

        target = self.get_target()
        actors = self.get_actors()
        context = {
            'actor': actors[0] if actors else None,
            'actors': actors,
            'scope': self.get_scope(),
            'target': target,
            'created_at': self.created_at,
            'metadata': self.metadata,
        }

        if send(DefinitionClass, context, target):
            # mark as sent
            self.sent_at = timezone.now()
            self.save(
                update_fields=[
                    'sent_at',
                ]
            )

            # update invites notified field
            if isinstance(target, UserInvite):
                target.notified_at = self.sent_at
                target.save(
                    update_fields=[
                        'notified_at',
                    ]
                )


class UserNotification(AbstractUniqueBigHashIDMixin, AbstractCreatedDateMixin):
    definition_name = models.CharField(max_length=252)
    type = models.CharField(max_length=252, db_index=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="notifications")
    scope = models.CharField(max_length=252, blank=True)
    actors = ArrayField(models.CharField(max_length=252), blank=True)
    metadata = models.JSONField(blank=True, null=True, default=dict)
    viewed = models.BooleanField(default=False)

    class Meta:
        verbose_name = "User Notification"
        verbose_name_plural = "User Notifications"
        indexes = [
            *AbstractUniqueBigHashIDMixin.Meta.indexes,
        ]

    @property
    def definition_class(self):
        return import_string(self.definition_name)
