from django.apps import AppConfig
from django.utils.module_loading import autodiscover_modules


def autodiscover():
    from apps.notifications import definitions

    autodiscover_modules("notifications", register_to=definitions)


class NotificationsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.notifications"
    verbose_name = "Notifications"

    def ready(self):
        super().ready()
        autodiscover()
