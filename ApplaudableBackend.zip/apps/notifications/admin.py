from django.contrib import admin, messages
from django.utils.translation import ngettext

from .models import NotificationEvent, UserNotification
from .tasks import send_notification_task


@admin.action(description='Send selected Notifications(s)')
def action_send_notifications(modeladmin, request, queryset):
    processing = 0
    for obj in queryset:
        send_notification_task.delay(str(obj.id))
        processing += 1

    modeladmin.message_user(
        request,
        ngettext(
            '%d notification is being sent.',
            '%d notification(s) are being sent.',
            processing,
        )
        % processing,
        messages.SUCCESS,
    )


@admin.register(NotificationEvent)
class NotificationEventAdmin(admin.ModelAdmin):
    list_display = ('__str__', 'delivery_method', 'actors', 'scope', 'target', 'created_at', 'sent_at')
    list_filter = ('delivery_method',)
    actions = [
        action_send_notifications,
    ]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


@admin.register(UserNotification)
class UserNotificationAdmin(admin.ModelAdmin):
    list_display = (
        '__str__',
        'type',
        'actors',
        'scope',
        'user',
        'viewed',
        'created_at',
    )
    list_filter = (
        'type',
        'viewed',
    )

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
