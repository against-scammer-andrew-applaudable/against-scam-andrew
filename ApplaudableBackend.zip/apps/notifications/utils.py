"""
Email utils.
"""

import json
import logging

from typing import Type

from django.conf import settings
from django.db import models

from apps.core.email import send_email
from apps.core.push import send_push
from apps.core.sms import send_sms
from apps.notifications.constants import DeliveryMethod


def model_to_notification_dict(model) -> dict:
    try:
        icon = model.get_icon()
    except AttributeError:
        icon = ''

    return {
        'id': str(model.id),
        'type': model._meta.model_name,
        'icon': icon,
        'name': model.name if hasattr(model, 'name') else str(model),
    }


def serialize_model_object(model):
    if not isinstance(model, models.Model):
        raise Exception(f"Expecting Model object, got {type(model)}")
    return json.dumps([f"{model.__class__.__module__}.{model.__class__.__name__}", str(model.id)])


def delete_user_notification(target_user_id, scope_model, notification_type):
    from apps.notifications.models import UserNotification
    
    try:
        serialized_model_object = serialize_model_object(scope_model)
        UserNotification.objects.filter(type=notification_type, user_id=target_user_id, scope=serialized_model_object).delete()
    except Exception as e:
        logging.exception(e)
        pass

def create_and_send_notification(definition_class, actors=[], target=None, scope=None, metadata={}, allow_duplicated=False):
    from apps.notifications.models import NotificationEvent
    from apps.notifications.tasks import send_notification_task

    delivery_method = definition_class.delivery_method()
    definition_name = definition_class.comp_name()

    # Skip notification if target is in actors
    # avoid sending notification to self
    if target and target in actors:
        return

    actors = [serialize_model_object(a) for a in actors]
    target = serialize_model_object(target) if target else ''
    scope = serialize_model_object(scope) if scope else ''

    # check if notification exists, avoid sending the same notification twice
    if not allow_duplicated and (
        not definition_class.Meta.repeatable
        and NotificationEvent.objects.filter(
            delivery_method=delivery_method, definition_name=definition_name, actors__contains=actors, target=target, scope=scope
        ).exists()
    ):
        return

    notification_obj = NotificationEvent.objects.create(
        delivery_method=delivery_method, definition_name=definition_name, actors=actors, target=target, scope=scope, metadata=metadata
    )

    delay_seconds = 2  # TODO: this can be per definition, defaults to 2 seconds
    send_notification_task.apply_async(args=(notification_obj.id,), countdown=delay_seconds)


def create_in_app_notification(definition, recipients=[]) -> bool:
    from apps.notifications.models import UserNotification

    definition_name = definition.comp_name()
    context = definition.get_context()

    actors = [serialize_model_object(actor) for actor in context.get('actors', [])]
    scope = serialize_model_object(context.get('scope')) if context.get('scope') else ''

    for user in recipients:
        UserNotification.objects.create(
            definition_name=definition_name, type=definition.TYPE, user=user, scope=scope, actors=actors, metadata=context.get('metadata', {})
        )

    return True


def send(definition_class: Type, context: dict, target) -> bool:
    """
    Send notification with given options.

    :param definition_class: NotificationDefinition based function
    :param context: dictionary with email context
    :param target: the target object e.g: User

    :return: None
    """
    definition = definition_class(context=context)

    # do not send emails during testing
    if settings.TESTING:
        return False

    if definition.delivery_method() == DeliveryMethod.APP:
        recipients = [
            target,
        ]
        if definition.allow_send(recipients):
            return create_in_app_notification(definition=definition, recipients=recipients)
    elif definition.delivery_method() == DeliveryMethod.PUSH:
        recipients = [
            target.id,
        ]
        if definition.allow_send(recipients):
            return send_push(message=definition.get_message(), recipients=recipients)

    elif definition.delivery_method() == DeliveryMethod.SMS:
        recipients = [
            target.phone_number,
        ]
        if definition.allow_send(recipients):
            return send_sms(message=definition.get_message(), recipients=recipients)

    elif definition.delivery_method() == DeliveryMethod.EMAIL:
        options = {}
        recipients = [
            target.email,
        ]
        if definition.allow_send(recipients):
            return send_email(
                **options,
                subject=definition.get_subject(),
                text_content=definition.get_text_content(),
                html_content=definition.get_html_content(),
                recipients=recipients,
            )
