from django.utils.translation import gettext_lazy as _

from apps.email.options import DELIVERY_METHOD_EMAIL


class DeliveryMethod:
    EMAIL = DELIVERY_METHOD_EMAIL
    APP = "app"
    PUSH = "push"
    SMS = "sms"

    @classmethod
    def choices(cls):
        return (
            (cls.EMAIL, _("Email")),
            (cls.APP, _("In App Notification")),
            (cls.PUSH, _("Push Notification")),
            (cls.SMS, _("Sms")),
        )
