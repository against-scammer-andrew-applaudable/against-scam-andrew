"""
Notification options.
"""
import json

from django import forms
from django.template import Context, Template
from firebase_admin.messaging import Message, Notification

from apps.core.utils import domain_with_proto

from .constants import DeliveryMethod
from .api.serializers import NotificationDataSerializer
from .utils import model_to_notification_dict


class AlreadyRegistered(Exception):
    """
    Exception for duplicate notification definition registration attempts.
    """

    pass


class NotificationDefinition(forms.Form):
    TYPE = None

    title = forms.CharField(initial="")
    text = forms.CharField(initial="")

    class Meta:
        repeatable = False

    def __init__(self, *args, **kwargs):
        self.context = kwargs.pop("context") if "context" in kwargs else {}
        self.lang = kwargs.pop("lang") if "lang" in kwargs else None
        super().__init__(*args, **kwargs)

    def get_base_context(self):
        from django.contrib.sites.models import Site

        context = {
            "proto_and_domain": domain_with_proto(),
            "site": Site.objects.get_current(),
        }
        context.update(self.context.copy())
        return context

    def get_context(self):
        context = self.get_base_context()

        for field_name, field in self.declared_fields.items():
            if field_name not in context:
                context[field_name] = field.initial

        for key, value in context.items():
            # check if we need to render template variables or tags
            if isinstance(value, str) and ("{{" in value or "{%" in value):
                template = Template(value)
                context[key] = template.render(Context(context))

        return context

    def get_message_data(self):
        context = self.get_context()
        serializer = NotificationDataSerializer(
            data={
                'type': self.TYPE,
                'created_at': context.get('created_at'),
                'actors': [model_to_notification_dict(actor) for actor in context.get('actors', [])],
                'target': model_to_notification_dict(context.get('target')),
                'scope': model_to_notification_dict(context.get('scope')) if context.get('scope') else None,
                'metadata': context.get('metadata'),
            }
        )
        serializer.is_valid(raise_exception=True)
        return serializer.data

    def get_message_title(self):
        form_field = self.fields.get("title", None)
        title = form_field.initial
        if title:
            return Template(title).render(Context(self.get_context()))
        return None

    def get_message_body(self):
        form_field = self.fields.get("text", None)
        body = form_field.initial
        if body:
            return Template(body).render(Context(self.get_context()))
        return None

    def get_message_image(self):
        if hasattr(self, 'image') and isinstance(self.image, str):
            # TODO validate if image is a valid image url
            return self.image
        return None

    @classmethod
    def comp_name(cls) -> str:
        return f"{cls.__module__}.{cls.__name__}"

    @classmethod
    def delivery_method(cls) -> str:
        raise NotImplementedError()

    def allow_send(self, recipients):
        if not recipients:
            return False
        return True

    def get_message(self):
        raise NotImplementedError()


class AppNotificationDefinition(NotificationDefinition):
    TYPE = 'app_notification'

    class Meta:
        repeatable = False

    @classmethod
    def delivery_method(cls) -> str:
        return DeliveryMethod.APP

    def allow_send(self, recipients):
        if not recipients:
            return False
        return True


class PushNotificationDefinition(NotificationDefinition):
    TYPE = 'push_notification'

    class Meta:
        repeatable = False

    @classmethod
    def delivery_method(cls) -> str:
        return DeliveryMethod.PUSH

    def get_message_notification(self):
        return Notification(
            title=self.get_message_title(),
            body=self.get_message_body(),
            image=self.get_message_image(),
        )

    def get_message(self):
        return Message(data={'json': json.dumps(self.get_message_data())}, notification=self.get_message_notification())


class SmsNotificationDefinition(NotificationDefinition):
    TYPE = 'sms_notification'

    class Meta:
        repeatable = False

    @classmethod
    def delivery_method(cls) -> str:
        return DeliveryMethod.SMS

    def get_message(self):
        texts = []
        title = self.get_message_title()
        if title:
            texts.append(title)
        body = self.get_message_body()
        if body:
            texts.append(body)
        return ", ".join(texts)


class NotificationDefinitions:
    def __init__(self, name="app_notify_definitions"):
        self._registry = {}
        self.name = name

    def all(self):
        return self._registry

    def get(self, comp_name):
        return self._registry[comp_name]

    def register(self, name, notify_def, **options):
        if not issubclass(notify_def, NotificationDefinition):
            raise ValueError(f"notify_def class {notify_def} must subclass NotificationDefinition")

        comp_name = notify_def.comp_name()
        if comp_name in self._registry:
            msg = f"The NotificationDefinition {comp_name} is already registered "
            raise AlreadyRegistered(msg)

        self._registry[comp_name] = {**options, "definition": notify_def, "name": name}


definitions = NotificationDefinitions()
