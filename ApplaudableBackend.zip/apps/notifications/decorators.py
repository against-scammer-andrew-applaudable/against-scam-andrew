def register(name):
    from apps.notifications import definitions

    def _notify_definition_wrapper(notify_def):
        definitions.register(name, notify_def)
        return notify_def

    return _notify_definition_wrapper
