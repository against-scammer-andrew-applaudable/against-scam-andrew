from rest_framework import serializers


class NotificationActorSerializer(serializers.Serializer):
    id = serializers.CharField()
    type = serializers.CharField()
    icon = serializers.CharField(allow_blank=True)
    name = serializers.CharField()


class NotificationTargetSerializer(serializers.Serializer):
    id = serializers.CharField()
    type = serializers.CharField()
    icon = serializers.CharField(allow_blank=True)
    name = serializers.CharField()


class NotificationScopeSerializer(serializers.Serializer):
    id = serializers.CharField()
    type = serializers.CharField()
    icon = serializers.CharField(allow_blank=True)
    name = serializers.CharField()


class NotificationDataSerializer(serializers.Serializer):
    type = serializers.CharField()
    created_at = serializers.DateTimeField()
    actors = NotificationActorSerializer(many=True)
    target = NotificationTargetSerializer()
    scope = NotificationScopeSerializer(required=False, allow_null=True)
    metadata = serializers.JSONField()


class NotificationSerializer(NotificationDataSerializer):
    title = serializers.CharField()
    text = serializers.CharField()
    viewed = serializers.BooleanField()
    id = serializers.CharField()
