from django.urls import path

from apps.notifications.api.views import NotificationListAPIView, NotificationViewedAPIView, NotificationDeleteAPIView

app_name = "notifications"

urlpatterns = [
    path("", NotificationListAPIView.as_view(), name="notification-list"),
    path("<str:id>/", NotificationDeleteAPIView.as_view(), name="notification-delete"),
    path("<str:id>/viewed/", NotificationViewedAPIView.as_view(), name="notification-mark-as-viewed"),
]
