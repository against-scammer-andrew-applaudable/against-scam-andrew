import json

from django.utils.module_loading import import_string
from drf_yasg.utils import no_body, swagger_auto_schema
from rest_framework import status
from rest_framework.generics import GenericAPIView, ListAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.request import Request
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend

from apps.notifications.api.serializers import NotificationSerializer
from apps.notifications.models import UserNotification
from apps.users.api.authentication import JWTAuthenticationIgnoreIsActive
from apps.api.v1.serializers import SuccessIndicatorSerializer


class NotificationBaseView(GenericAPIView):
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)
    serializer_class = NotificationSerializer

    def get_queryset(self):
        types = self.request.GET.getlist('type', None)
        if types:
            return UserNotification.objects.select_related('user').filter(user=self.request.user, type__in=types).order_by("-created_at")
        else:
            return UserNotification.objects.select_related('user').filter(user=self.request.user).order_by("-created_at")

    def get_serializer(self, data, **kwargs):
        is_many = kwargs.get('many', False)
        new_data = []
        if isinstance(data, UserNotification) and not is_many:
            data = [
                data,
            ]

        # prefetch related data.
        model_by_type = {}
        for notification in data:
            notification._json_actors = [json.loads(a) for a in notification.actors] if notification.actors else []
            for item in notification._json_actors:
                if item[0] not in model_by_type:
                    model_by_type[item[0]] = set()
                model_by_type[item[0]].add(item[1])

            notification.json_scope = json.loads(notification.scope) if notification.scope else None
            if notification.json_scope:
                if notification.json_scope[0] not in model_by_type:
                    model_by_type[notification.json_scope[0]] = set()
                model_by_type[notification.json_scope[0]].add(notification.json_scope[1])

        for model_module, id_list in model_by_type.items():
            model_by_type[model_module] = {o.id: o for o in import_string(model_module).objects.filter(id__in=id_list)}

        # represent new data
        for notification in data:
            actors = [model_by_type[actor[0]].get(actor[1]) for actor in notification._json_actors]
            scope = model_by_type[notification.json_scope[0]].get(notification.json_scope[1]) if notification.json_scope else None

            context = {
                'actor': actors[0] if actors else None,
                'actors': actors,
                'scope': scope,
                'target': notification.user,
                'created_at': notification.created_at,
                'metadata': notification.metadata,
            }

            # init notification definition
            definition = notification.definition_class(context=context)

            new_data.append(
                {
                    **definition.get_message_data(),
                    'id': str(notification.id),
                    'type': notification.type,
                    'title': definition.get_message_title(),
                    'text': definition.get_message_body(),
                    'viewed': notification.viewed,
                }
            )

        if new_data and not is_many:
            new_data = new_data[0]

        serializer_class = self.get_serializer_class()
        kwargs.setdefault('context', self.get_serializer_context())
        return serializer_class(new_data, **kwargs)


class NotificationListAPIView(NotificationBaseView, ListAPIView):
    serializer_class = NotificationSerializer


class NotificationViewedAPIView(NotificationBaseView):
    serializer_class = NotificationSerializer
    lookup_field = "id"

    @swagger_auto_schema(
        request_body=no_body,
        responses={
            status.HTTP_200_OK: NotificationSerializer(),
        },
    )
    def patch(self, request: Request, id: str = None):
        notification = self.get_object()
        notification.viewed = True
        notification.save(
            update_fields=[
                'viewed',
            ]
        )

        data = self.get_serializer(notification).data
        return Response(status=status.HTTP_200_OK, data=data)

class NotificationDeleteAPIView(NotificationBaseView):
    serializer_class = NotificationSerializer
    lookup_field = "id"    
    
    @swagger_auto_schema(
        request_body=no_body,
        responses={
            status.HTTP_202_ACCEPTED: SuccessIndicatorSerializer(),
        },
    )
    def delete(self, request: Request, id: str = None):
        UserNotification.objects.filter(id=id).delete()
        return Response(status=status.HTTP_202_ACCEPTED, data={'success': True})