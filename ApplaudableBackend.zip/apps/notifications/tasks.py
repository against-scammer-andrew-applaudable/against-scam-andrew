from celery import shared_task
from django.conf import settings
from django.utils import timezone


@shared_task
def notify_object_task(object_id, model_name):
    from apps.posts.models import Post, Applaud, PostMention, PostUserVisibility
    from apps.users.models import Follow, UserInvite

    notifiable_models = [Post, Applaud, PostMention, Follow, UserInvite, PostUserVisibility]

    obj = None
    for model_class in notifiable_models:
        # retrieve object
        if model_name == model_class.__name__:
            obj = model_class.objects.get(id=object_id)

    obj.notify()
    
@shared_task
def notify_post_disappearing_task(object_id):
    from apps.posts.models import Post
    post = Post.objects.get(id=object_id)
    post.disappear_notify()


@shared_task
def send_notification_task(notification_id):
    from apps.notifications.models import NotificationEvent

    notification = NotificationEvent.objects.get(id=notification_id)
    notification.send()


@shared_task
def send_notification_story_not_made():
    from django.conf import settings
    from django.contrib.auth import get_user_model
    from django.db.models.expressions import RawSQL
    from django.utils import timezone

    from apps.core.services import RedisContextManager
    from apps.posts.constants import PostType
    from apps.posts.models import Post

    User = get_user_model()
    now = timezone.now()
    formatted_now = now.strftime("%Y-%m-%dT%H:%M:%S%z")

    current_day_sql = RawSQL(
        sql="""
            EXTRACT('day' FROM "posts_post"."created_at" AT TIME ZONE 
                (SELECT U0."timezone" FROM "users_user" U0 WHERE U0."id" = ("posts_post"."owner_id"))
            )
        """,
        params=(),
    )

    current_month_sql = RawSQL(
        sql="""
            EXTRACT('month' FROM "posts_post"."created_at" AT TIME ZONE 
                (SELECT U0."timezone" FROM "users_user" U0 WHERE U0."id" = ("posts_post"."owner_id"))
            )
        """,
        params=(),
    )

    current_year_sql = RawSQL(
        sql="""
            EXTRACT('year' FROM "posts_post"."created_at" AT TIME ZONE 
                (SELECT U0."timezone" FROM "users_user" U0 WHERE U0."id" = ("posts_post"."owner_id"))
            )
        """,
        params=(),
    )

    current_hour_sql = RawSQL(
        sql="""
            EXTRACT('hour' FROM %s AT TIME ZONE 
                (SELECT U0."timezone" FROM "users_user" U0 WHERE U0."id" = "users_user"."id")
            )
        """,
        params=(formatted_now,),
    )

    annotated_posts = Post.objects.annotate(
        creation_day=current_day_sql,
        creation_month=current_month_sql,
        creation_year=current_year_sql
    )
    users_with_stories = list(annotated_posts.filter(
        creation_day=now.day,
        creation_month=now.month,
        creation_year=now.year,
        type=PostType.STORY,
    ).values_list('owner', flat=True))

    annotated_users = User.objects.annotate(current_hour=current_hour_sql)
    users_without_stories = annotated_users.exclude(id__in=users_with_stories).filter(current_hour__gte=settings.STORY_PUSH_NOTIFICATION_HOUR)
    user_ids = list(users_without_stories.values_list('id', flat=True))

    with RedisContextManager() as r:
        ids = [f'story_not_made:{user}' for user in user_ids]
        users_notified = r.mget(ids)
        # mget returns None if key does not exist and a str "1" if it does
        notified_user_ids = [user_id for user_id, notified in zip(user_ids, users_notified) if notified]
        users_without_stories = users_without_stories.exclude(id__in=notified_user_ids)
        for user in users_without_stories:
            user.notify_did_not_post_story()
            r.setex(f'story_not_made:{user.id}', 86400, 1)  # 86400 seconds = 24 hours


@shared_task
def delete_old_notifications():
    from apps.notifications.models import UserNotification

    target_date = timezone.now() - timezone.timedelta(days=settings.NOTIFICATION_TTL)
    UserNotification.objects.filter(created_at__lt=target_date).delete()


@shared_task
def delete_user_notification_as_related_cascade(serialized_model_object, related='scope'):
    from apps.notifications.models import UserNotification

    if related == 'actors':
        serialized_model_object = [serialized_model_object]

    query = {related: serialized_model_object}
    UserNotification.objects.filter(**query).delete()
