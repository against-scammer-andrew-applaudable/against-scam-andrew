from django.contrib import admin


class MentionAdmin(admin.ModelAdmin):
    list_display = ('__str__', 'mentioner', 'mentioned_object', 'created_at')
    search_fields = (
        'mentioner__id',
        'mentioner__name',
        'mentioner__username',
        'user__id',
        'user__name',
        'user__username',
        'nupp__id',
        'nupp__name',
        'user_invite__id',
        'user_invite__name',
    )

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.select_related('mentioner', 'user', 'nupp', 'user_invite')

    def mentioned_object(self, obj):
        return obj.mentioned_object

    mentioned_object.short_description = "Object"

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
