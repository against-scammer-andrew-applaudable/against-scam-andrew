from django.apps import AppConfig


class MentionsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.mention"
    verbose_name = "Mentions"
