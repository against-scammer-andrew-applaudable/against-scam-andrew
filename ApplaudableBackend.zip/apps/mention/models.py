from django.contrib.auth import get_user_model
from django.db import models

from apps.core.models import AbstractCreatedDateMixin

from .constants import MentionType

User = get_user_model()


class AbstractMention(AbstractCreatedDateMixin):
    mentioner = models.ForeignKey(User, related_name="mentioners", on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    nupp = models.ForeignKey("nupp.Nupp", on_delete=models.CASCADE, null=True)
    user_invite = models.ForeignKey("users.UserInvite", on_delete=models.CASCADE, null=True)

    class Meta:
        abstract = True

    def __str__(self) -> str:
        return 'Mention'

    @property
    def object_type(self):
        if self.user_id:
            return MentionType.USER
        elif self.nupp_id:
            return MentionType.NUPP
        elif self.user_invite_id:
            return MentionType.INVITE
        return None

    @property
    def mentioned_object(self):
        if self.user_id:
            return self.user
        elif self.nupp_id:
            return self.nupp
        elif self.user_invite_id:
            return self.user_invite
        return None

    @classmethod
    def mention_field_name(cls) -> str:
        """
        We use this to identify mention models, and to figure out what is the field name
        to bind mentions to
        """
        raise NotImplementedError()
