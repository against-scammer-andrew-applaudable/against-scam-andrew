from django.utils.translation import gettext_lazy as _

from apps.core.richtext.serializers import INVITE_ELEMENT, NUPP_ELEMENT, USER_ELEMENT


class MentionType:
    USER = USER_ELEMENT
    NUPP = NUPP_ELEMENT
    INVITE = INVITE_ELEMENT

    @classmethod
    def choices(cls):
        return (
            (cls.USER, _("User")),
            (cls.NUPP, _("Nupp")),
            (cls.INVITE, _("Invite")),
        )
