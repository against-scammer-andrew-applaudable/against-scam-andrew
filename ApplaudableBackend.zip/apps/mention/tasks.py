from celery import shared_task


@shared_task
def notify_mentions_task(mention_ids, mention_model_name):
    from apps.notifications.tasks import notify_object_task
    from apps.posts.models import PostMention

    # retrieve mention objects
    if mention_model_name == PostMention.__name__:
        mention_qs = PostMention.objects.filter(id__in=mention_ids)
    else:
        mention_qs = []

    for obj in mention_qs:
        notify_object_task.delay(obj.id, obj.__class__.__name__)
