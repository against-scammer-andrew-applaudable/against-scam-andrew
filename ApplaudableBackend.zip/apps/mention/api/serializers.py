from drf_yasg.utils import swagger_serializer_method
from hashid_field.rest import HashidSerializerCharField
from rest_framework import serializers

from apps.mention.constants import MentionType

from apps.media.serializers import MediaSerializer
from apps.users.api.serializers import SimpleUserSerializer


class MentionSerializer(serializers.Serializer):
    id = HashidSerializerCharField(read_only=True)
    mention_id = serializers.SerializerMethodField()
    type = serializers.SerializerMethodField()
    label = serializers.SerializerMethodField()
    user = serializers.SerializerMethodField()
    avatar = serializers.SerializerMethodField()
    is_public = serializers.SerializerMethodField()
    mentioned_by = serializers.SerializerMethodField()

    def get_mention_id(self, obj):
        return str(obj.mentioned_object.id)

    def get_type(self, obj):
        return obj.object_type

    def get_label(self, obj):
        return str(obj.mentioned_object.get_mention_label())
    
    def get_avatar(self, obj):
        if obj.object_type != MentionType.USER:
            return None
        try:
            return str(obj.mentioned_object.get_icon())
        except AttributeError:
            return None        

    def get_mentioned_by(self, obj):
        return [
            str(obj.mentioner_id),
        ]

    def get_is_public(self, obj):
        if obj.object_type == MentionType.NUPP:
            return obj.mentioned_object.is_public
        elif obj.object_type == MentionType.USER:
            return True
        return False

    def get_user(self, obj):
        if obj.object_type != MentionType.INVITE:
            return None
        user = getattr(obj.mentioned_object, 'user', None)
        return SimpleUserSerializer(user).data if user else None


class MentionSearchEngagementSerializer(serializers.Serializer):
    following = serializers.BooleanField()


class MentionSearchSerializer(serializers.Serializer):
    description = serializers.CharField()
    nupp_id = HashidSerializerCharField()
    media = MediaSerializer()
    source_ref = serializers.CharField()
    source = serializers.CharField()
    category_id = HashidSerializerCharField()
    structured_formatting = serializers.JSONField()
    engagement = serializers.SerializerMethodField()
    metadata = serializers.JSONField()

    @swagger_serializer_method(serializer_or_field=MentionSearchEngagementSerializer())
    def get_engagement(self, obj):
        return MentionSearchEngagementSerializer({"following": obj.get('following', False)}).data
