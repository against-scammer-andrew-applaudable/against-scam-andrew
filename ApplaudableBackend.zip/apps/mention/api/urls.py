from django.urls import path
from rest_framework.routers import DefaultRouter

from .views import SearchForMentionAPIView

router = DefaultRouter()

app_name = "mention"

urlpatterns = [
    path("search/", SearchForMentionAPIView.as_view(), name="mention-search"),
] + router.urls
