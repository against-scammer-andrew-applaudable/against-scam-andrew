import coreapi
from django.contrib.auth import get_user_model
from django.contrib.postgres.search import TrigramWordSimilarity
from django.db.models import BooleanField, Case, Exists, F, FloatField, OuterRef, Q, Sum, Value, When
from django.db.models.functions import JSONObject
from django.utils import timezone
from rest_framework.filters import BaseFilterBackend
from rest_framework.generics import GenericAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from apps.nupp.constants import SourceType
from apps.nupp.models import Nupp
from apps.nupp.utils import (
    build_nupp_descriptive_texts,
    build_query_pattern,
    get_prediction_media,
    handle_hashid,
    structured_formatting_from_string,
)
from apps.posts.constants import Segment
from apps.users.models import Follow, UserInvite

from .serializers import MentionSearchSerializer

User = get_user_model()


class SearchForMentionFilterBackend(BaseFilterBackend):
    def get_schema_fields(self, view):
        return [
            coreapi.Field(name='q', location='query', required=True, type='string'),
        ]


class SearchForMentionAPIView(GenericAPIView):
    """
    Search predictions for mentions.
    """

    filter_backends = (SearchForMentionFilterBackend,)
    permission_classes = (IsAuthenticated,)
    serializer_class = MentionSearchSerializer
    BASE_VALUES = ('id', 'main_text', 'secondary_text', 'type', 'cat_id', 'is_following', 'data', 'similarity', 'rank')

    def get_queryset(self):
        return Nupp.objects.filter(Q(is_public=True))

    def default_user_prediction_qs(self, requesting_user):
        """
        Default user fetches the requesting user following, and latest mentions.
        """
        user_posting_time_delta = timezone.now() - timezone.timedelta(days=7)
        prediction_qs = (
            User.active_objects.filter(
                Q(followers__follower=requesting_user)
                | Q(mentioned_posts__owner=requesting_user, owned_posts__created_at__gte=user_posting_time_delta)
            )
            .exclude(pk=requesting_user.pk)
            .annotate(
                main_text=F('username'),
                secondary_text=F('name'),
                type=Value("user"),
                cat_id=Value(0),
                is_following=Exists(Follow.objects.filter(follower=requesting_user, following=OuterRef('id'))),
                data=JSONObject(username=F('username'), name=F('name')),
                similarity=Value(0.2, output_field=FloatField()),
                rank=Sum(Case(When(is_following=True, then=F('similarity') * 2), default=F('similarity') * 1.43, output_field=FloatField())),
            )
            .values(*self.BASE_VALUES)
        )
        return prediction_qs

    def user_prediction_qs(self, query: str, requesting_user):
        prediction_qs = (
            User.active_objects.filter(Q(name__icontains=query) | Q(name__trigram_similar=query) | Q(username__trigram_similar=query))
            .exclude(pk=requesting_user.pk)
            .annotate(
                main_text=F('username'),
                secondary_text=F('name'),
                type=Value("user"),
                cat_id=Value(0),
                is_following=Exists(Follow.objects.filter(follower=requesting_user, following=OuterRef('id'))),
                data=JSONObject(username=F('username'), name=F('name')),
                similarity=TrigramWordSimilarity(query, 'username'),
                rank=Sum(Case(When(is_following=True, then=F('similarity') * 2), default=F('similarity') * 1.43, output_field=FloatField())),
            )
            .values(*self.BASE_VALUES)
        )
        return prediction_qs

    def default_nupp_prediction_qs(self, requesting_user):
        """
        Default nupp fetches the latest nupp's posted by the user.
        """
        nupp_posting_time_delta = timezone.now() - timezone.timedelta(days=15)
        prediction_qs = (
            self.get_queryset()
            .filter(nupp_posts__owner=requesting_user, nupp_posts__created_at__gte=nupp_posting_time_delta)
            .annotate(
                main_text=F('name'),
                secondary_text=F('detail_text'),
                type=Value("nupp"),
                cat_id=F('category_id'),
                is_following=Case(default=False, output_field=BooleanField()),
                data=F('metadata'),
                similarity=Value(0.01, output_field=FloatField()),
                rank=Sum(
                    Case(
                        When(segment=Segment.SOMEONE, then=F('similarity') * 1.33),
                        When(segment=Segment.SOMETHING, then=F('similarity')),
                        When(segment=Segment.ACTIVITIES, then=F('similarity')),
                        When(segment=Segment.SOMEWHERE, then=F('similarity') * 1.15),
                        default=0,
                        output_field=FloatField(),
                    )
                ),
            )
            .values(*self.BASE_VALUES)
        )
        return prediction_qs

    def nupp_prediction_qs(self, query: str, requesting_user):
        prediction_qs = (
            self.get_queryset()
            .filter(Q(search_text__icontains=query) | Q(search_text__trigram_similar=query))
            .annotate(
                main_text=F('name'),
                secondary_text=F('detail_text'),
                type=Value("nupp"),
                cat_id=F('category_id'),
                is_following=Case(default=False, output_field=BooleanField()),
                data=F('metadata'),
                similarity=TrigramWordSimilarity(query, 'search_text'),
                rank=Sum(
                    Case(
                        When(segment=Segment.SOMEONE, then=F('similarity') * 1.33),
                        When(segment=Segment.SOMETHING, then=F('similarity')),
                        When(segment=Segment.ACTIVITIES, then=F('similarity')),
                        When(segment=Segment.SOMEWHERE, then=F('similarity') * 1.15),
                        default=0,
                        output_field=FloatField(),
                    )
                ),
            )
            .values(*self.BASE_VALUES)
        )
        return prediction_qs

    def default_invite_prediction_qs(self, requesting_user):
        """
        Default invite fetches the invites created during the past 7days
        """
        invite_time_delta = timezone.now() - timezone.timedelta(days=7)
        prediction_qs = (
            UserInvite.objects.filter(created_at__gte=invite_time_delta)
            .filter(user__isnull=True, invited_by=requesting_user)
            .annotate(
                main_text=F('name'),
                secondary_text=F('name'),
                type=Value("invite"),
                cat_id=Value(0),
                is_following=Case(default=False, output_field=BooleanField()),
                data=JSONObject(name=F('name')),
                similarity=Value(0.01, output_field=FloatField()),
                rank=Sum(Case(default=F('similarity') * 1.25, output_field=FloatField())),
            )
            .values(*self.BASE_VALUES)
        )
        return prediction_qs

    def invite_prediction_qs(self, query: str, requesting_user):
        prediction_qs = (
            UserInvite.objects.filter(Q(name__icontains=query) | Q(name__trigram_similar=query))
            .filter(user__isnull=True, invited_by=requesting_user)
            .annotate(
                main_text=F('name'),
                secondary_text=F('name'),
                type=Value("invite"),
                cat_id=Value(0),
                is_following=Case(default=False, output_field=BooleanField()),
                data=JSONObject(name=F('name')),
                similarity=TrigramWordSimilarity(query, 'name'),
                rank=Sum(Case(default=F('similarity') * 1.25, output_field=FloatField())),
            )
            .values(*self.BASE_VALUES)
        )
        return prediction_qs

    def get(self, request, *args, **kwargs):
        response_data = []
        limit_results = 30
        query = request.GET.get('q')
        query_pattern = build_query_pattern(query)

        if query:
            predictions = (
                self.user_prediction_qs(query, request.user)
                .union(self.invite_prediction_qs(query, request.user))
                .union(self.nupp_prediction_qs(query, request.user))
                .order_by('-rank')[:limit_results]
            )

        else:
            predictions = (
                self.default_user_prediction_qs(request.user)
                .union(self.default_invite_prediction_qs(request.user))
                .union(self.default_nupp_prediction_qs(request.user))
                .order_by('-rank')[:limit_results]
            )

        # prefetch media items
        media_by_nupp_id, media_by_user_id = get_prediction_media(predictions)
        for prediction in predictions:
            description, main_text, secondary_text = build_nupp_descriptive_texts(prediction)

            data = {
                'description': description,
                'source_ref': None,
                'source': None,
                'structured_formatting': structured_formatting_from_string(main_text, secondary_text, query_pattern),
                'nupp_id': None,
                'media': None,
                'category_id': handle_hashid(prediction['cat_id']) if prediction['cat_id'] else None,
                'following': prediction['is_following'],
                'metadata': prediction['data'],
            }
            if prediction['type'] == 'user':
                data.update({'media': media_by_user_id.get(prediction['id']), 'source': SourceType.USER, 'source_ref': prediction['id']})
            elif prediction['type'] == 'nupp':
                data.update({'media': media_by_nupp_id.get(prediction['id']), 'nupp_id': prediction['id']})
            elif prediction['type'] == 'invite':
                data.update({'source': SourceType.INVITE, 'source_ref': prediction['id']})
            response_data.append(data)

        # response
        page = self.paginate_queryset(response_data)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(response_data, many=True)
        return Response(serializer.data)
