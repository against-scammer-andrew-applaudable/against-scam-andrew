from django.contrib import admin

from import_export.fields import Field
from import_export.admin import ImportExportModelAdmin, ImportExportMixin
from apps.core.import_export.admin import ImportExportAdminMixin
from apps.core.import_export.resources import ModelResource
from apps.core.import_export.widgets import BigHashidWidget, HashidWidget
from import_export.widgets import ForeignKeyWidget
from apps.life_story.models import Question, OpenAIPromptQuestion
from apps.collection.models import CollectionTemplate
from apps.core.import_export.resources import ModelResource


class QuestionResource(ModelResource):
    collection_template = Field(column_name="collection_template", attribute="collection_template", widget=ForeignKeyWidget(CollectionTemplate))

    class Meta:
        model = Question
        export_order = ('id', 'question', 'title', 'answer_example', 'prompt_main', 'prompt_1', 'prompt_2', 'prompt_3', 'collection_template')
        fields = ('id', 'question', 'title', 'answer_example', 'prompt_main', 'prompt_1', 'prompt_2', 'prompt_3', 'collection_template')
        clean_model_instances = True


@admin.register(Question)
class QuestionAdmin(ImportExportAdminMixin, admin.ModelAdmin):
    resource_class = QuestionResource

class OpenAIPromptQuestionResource(ModelResource):
    class Meta:
        model = OpenAIPromptQuestion
        fields = (
            "id",
            "type",
            "prompt_text",
            "is_active",
        )

        report_skipped = False
        skip_unchanged = True
        # clean_model_instances = True

# Register your models here.
class OpenAIPromptQuestionAdmin(admin.ModelAdmin):
    list_display = ('id', 'type', 'prompt_text', 'is_active',)
    search_fields = (
        'id',
        'type',
        'prompt_text',
    )
    fieldsets = (
        (
            None,
            {
                "fields": (
                    'type',
                    'prompt_text',
                    'is_active',
                ),
            },
        ),
    )
    resource_class = OpenAIPromptQuestionResource

admin.site.register(OpenAIPromptQuestion, OpenAIPromptQuestionAdmin)
