from django.utils.translation import gettext_lazy as _


class OpenAIQuestionType:
    CASUAL = "casual"
    OBJECTIVE = "objective"
    WITTY = "witty"
    INTELLIGENT = "intelligent"
    HIGHLIGHT_PEOPLE = "highlight_people"
    HIGHLIGHT_PLACE = "highlight_place"
    HIGHLIGHT_ACTIVITY = "highlight_activity"
    HIGHLIGHT_TITLE = "highlight_title"

    @classmethod
    def choices(cls):
        return (
            (cls.CASUAL, _("Casual")),
            (cls.OBJECTIVE, _("Objective")),
            (cls.WITTY, _("Witty")),
            (cls.INTELLIGENT, _("Intelligent")),
            (cls.HIGHLIGHT_PEOPLE, _("Highlight People")),
            (cls.HIGHLIGHT_PLACE, _("Highlight Place")),
            (cls.HIGHLIGHT_ACTIVITY, _("Highlight Activity")),
            (cls.HIGHLIGHT_TITLE, _("Highlight Title")),
        )