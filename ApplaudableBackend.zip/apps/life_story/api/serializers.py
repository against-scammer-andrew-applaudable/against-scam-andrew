from rest_framework import serializers
from drf_yasg.utils import swagger_serializer_method

from apps.collection.api.serializers import BaseCollectionTypeSerializer
from apps.collection.models import Collection, CollectionType
from apps.collection.utils import create_collection_into_user

from apps.life_story.models import Question


class StoryCollectionTypeSerializer(BaseCollectionTypeSerializer):
    class Meta:
        model = CollectionType
        fields = ("id", "name")


class StoryCollectionSerializer(serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)
    collection_type = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = Collection
        fields = ("id", "name", "collection_type")

    @swagger_serializer_method(serializer_or_field=StoryCollectionTypeSerializer)
    def get_collection_type(self, instance):
        return StoryCollectionTypeSerializer(instance.collection_type).data


class StoryQuestionSerializer(serializers.ModelSerializer):
    tones = serializers.SerializerMethodField(read_only=True)
    collection = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = Question
        fields = ("id", "question", "title", "collection", "answer_example", "tones")

    @swagger_serializer_method(serializer_or_field=serializers.ListField(child=serializers.CharField()))
    def get_tones(self, instance):
        return list(map(lambda x: x[0], instance.tones))

    @swagger_serializer_method(serializer_or_field=StoryCollectionSerializer(many=False))
    def get_collection(self, instance):
        user = self.context["request"].user
        collection = Collection.objects.filter(
            user=user,
            collection_template=instance.collection_template,
        ).first()
        if not collection:
            collection = create_collection_into_user(user, instance.collection_template)
        serializer = StoryCollectionSerializer(collection)
        return serializer.data


class StoryCompletionResponseSerializer(serializers.Serializer):
    text = serializers.CharField()


class StoryCompletionSerializer(serializers.Serializer):
    answer = serializers.CharField()
    question = serializers.CharField()
    title = serializers.CharField()
    tones = serializers.ListField(child=serializers.CharField())
    # collection IDs are hashIDs
    collection = serializers.CharField()

    def validate_collection(self, value):
        user = self.context["request"].user
        return Collection.objects.filter(user=user, id=value).first()

    def validate_question(self, value):
        question = Question.objects.filter(question=value).first()
        if question is None:
            raise serializers.ValidationError("Question not found")
        return question

    def validate(self, attrs):
        # parse tones
        question = attrs.get("question")
        question_tones = getattr(question, "tones", [])
        question_tones_mapping = {key: value for key, value in question_tones}
        tones = attrs.get("tones", [])
        result = []
        for tone in tones:
            result.append(question_tones_mapping.get(tone))

        attrs["prompts"] = result
        return attrs

class TextImproveSerializer(serializers.Serializer):
    prompt = serializers.CharField()
    content = serializers.CharField()