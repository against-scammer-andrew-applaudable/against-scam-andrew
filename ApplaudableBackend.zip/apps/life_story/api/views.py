from drf_yasg.utils import swagger_auto_schema
from django_filters.rest_framework import DjangoFilterBackend

from rest_framework import status
from rest_framework.generics import GenericAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from apps.users.api.authentication import JWTAuthenticationIgnoreIsActive

from apps.life_story.utils import openai_improve_text, openai_improve_text_with_prompt
from apps.life_story.models import Question
from apps.life_story.filters import QuestionFilter
from apps.life_story.models import OpenAIPromptQuestion

from .serializers import (
    StoryQuestionSerializer,
    StoryCompletionSerializer,
    StoryCompletionResponseSerializer,
    TextImproveSerializer
)


class StoryQuestionsView(GenericAPIView):
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)
    serializer_class = StoryQuestionSerializer
    filter_backends = (DjangoFilterBackend,)
    filterset_class = QuestionFilter

    def get_queryset(self):
        return Question.objects.filter(is_fixed=False, is_active=True).order_by("?")

    def paginate_queryset(self, queryset):
        queryset = super().paginate_queryset(queryset)[:5]
        if self.request.user.owned_posts.filter(type="story").exists():
            questions = Question.objects.filter(is_fixed=True).order_by("?")[:5]
            if questions.count() > 0:
                queryset = queryset[: 5 - questions.count()] + list(questions)
        return queryset

    def get(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)
        serializer = self.get_serializer(page, many=True)
        return self.paginator.get_paginated_response(serializer.data)


class StoryCompletionView(GenericAPIView):
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)
    http_method_names = ("post",)
    serializer_class = StoryCompletionSerializer

    @swagger_auto_schema(
        responses={
            status.HTTP_200_OK: StoryCompletionResponseSerializer(),
        }
    )
    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        result_text = openai_improve_text(serializer.validated_data)
        response_data = {"text": result_text}
        response_serializer = StoryCompletionResponseSerializer(response_data)
        return Response(status=status.HTTP_200_OK, data=response_serializer.data)


class TextImproveWithOpenAIView(GenericAPIView):
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)
    http_method_names = ("post",)
    serializer_class = TextImproveSerializer

    @swagger_auto_schema(
        responses={
            status.HTTP_200_OK: StoryCompletionResponseSerializer(),
        }
    )
    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        prompt_type = request.data['prompt']
        content = request.data['content']
        openai_prompt = OpenAIPromptQuestion.objects.filter(type=prompt_type)
        if openai_prompt.first():
            prompt = openai_prompt.first().prompt_text
            result_text = openai_improve_text_with_prompt(prompt=prompt, content=content)
        response_data = {"text": result_text}
        response_serializer = StoryCompletionResponseSerializer(response_data)
        return Response(status=status.HTTP_200_OK, data=response_serializer.data)