from django.urls import path
from rest_framework.routers import DefaultRouter

from .views import StoryQuestionsView, StoryCompletionView, TextImproveWithOpenAIView

app_name = "life_story"

router = DefaultRouter()

urlpatterns = [
    path("questions/", StoryQuestionsView.as_view(), name="story-questions"),
    path("completion/", StoryCompletionView.as_view(), name="story-completion"),
    path("improve-text/", TextImproveWithOpenAIView.as_view(), name="text-improve"),
] + router.urls
