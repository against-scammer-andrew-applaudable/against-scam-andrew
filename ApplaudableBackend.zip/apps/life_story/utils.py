from openai import OpenAI, OpenAIError
import tiktoken
import re

from django.conf import settings
from django.template import engines


client = OpenAI(
    api_key=settings.OPENAPI_API_KEY,
)


def openai_improve_text(payload, context={}):
    # TODO: parse selected prompts
    context.update(payload)
    if payload['collection']:
        context['collection_name'] = payload['collection'].name
    question_instance = payload.get("question")

    django_engine = engines["django"]
    template = django_engine.from_string(getattr(question_instance, "prompt_main", "Sample Template \n{{ prompts }}"))

    prompt = template.render(context)

    if context.get('prompts'):
        prompt = prompt + "".join(context.get('prompts'))
    try:
        response = client.chat.completions.create(
            messages=[
                {"role": "user", "content": prompt}
            ],
            model="gpt-3.5-turbo",
        )
        choices = response.choices
        if not choices:
            return None
        return choices[0].text.strip()
    except OpenAIError as e:
        print("openAIError", e)
        return None


def openai_improve_text_with_prompt(prompt, content):
    try:
        enc = tiktoken.get_encoding("p50k_base")
        num_tokens = len(enc.encode(prompt))
        response = client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": content},
                ],
            )
        choices = response.choices
        print(choices)
        if not choices:
            return None
        return choices[0].message.content.strip()
    except OpenAIError as e:
        print("openAIError", e)
        return None
        


def get_template_vars(text_template):
    """
    Get the variables of a text (via regex) that uses {[ mustache }} templating
    """
    return re.split(r'\{{ *|\ *}}.*?{{ *|\ *}}.*', text_template, flags=re.DOTALL)[1:-1]
