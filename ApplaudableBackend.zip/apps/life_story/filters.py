from django.db.models import Exists, OuterRef
from django_filters import rest_framework as filters
from .models import Question
from apps.collection.models import Collection


class QuestionFilter(filters.FilterSet):
    collection = filters.CharFilter(method="collection_filter")

    class Meta:
        model = Question
        fields = ("collection",)

    def collection_filter(self, queryset, name, value):
        collection_user = Collection.objects.filter(user=self.request.user, id=value, collection_template=OuterRef("collection_template"))
        return queryset.annotate(exists=Exists(collection_user)).filter(exists=True)
