from apps.life_story.tests.factories import QuestionFactory

from django.test import TestCase


class TestQuestionModel(TestCase):
    """
    Question Model Tests.
    """

    def setUp(self):
        self.question_text = 'Is this a test question?'
        self.question = QuestionFactory(question=self.question_text)

    def test_str(self):
        self.assertEqual(self.question.__str__(), self.question_text)
