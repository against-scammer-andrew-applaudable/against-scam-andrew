from rest_framework.test import APIRequestFactory, APITestCase, force_authenticate

from apps.collection.models import Collection, CollectionTemplate, CollectionType
from apps.collection.tests.factories import CollectionTypeTemplateModelFactory

from apps.users.tests.factories import UserFactory

from apps.life_story.api.views import StoryQuestionsView
from apps.life_story.tests.factories import QuestionFactory

factory = APIRequestFactory()


class StoryQuestionsViewTestCase(APITestCase):
    def setUp(self):
        self.user = UserFactory()
        self.user2 = UserFactory()

        collection_type_template = CollectionTypeTemplateModelFactory()
        collection_template = CollectionTemplate.objects.create(
            name="test", collection_type=collection_type_template
        )
        collection_type = CollectionType.objects.create(
            user=self.user,
            name=collection_type_template.name,
            is_custom=collection_type_template.is_custom,
        )
        self.collection = Collection.objects.create(
            name=collection_template.name,
            collection_template=collection_template,
            collection_type=collection_type,
            user=self.user,
        )
        self.question = QuestionFactory(prompt_1="HAPPY:make it joyfull")
        self.question.collection_templates.add(collection_template)
        self.question.save()

    def test_list(self):
        request = factory.get("/api/v1/story/questions/")
        force_authenticate(request, user=self.user)
        response = StoryQuestionsView.as_view()(request)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["count"], 1)
        self.assertEqual(len(response.data["results"][0]["collections"]), 1)

    def test_list_no_templates(self):
        request = factory.get("/api/v1/story/questions/")
        force_authenticate(request, user=self.user2)
        response = StoryQuestionsView.as_view()(request)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["count"], 1)
        self.assertEqual(len(response.data["results"][0]["collections"]), 0)
