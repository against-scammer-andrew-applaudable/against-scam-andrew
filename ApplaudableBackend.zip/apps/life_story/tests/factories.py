import factory

from .base import faker

from apps.life_story.models import Question


class QuestionFactory(factory.django.DjangoModelFactory):
    question = f'{faker.sentence()[:-1]}?'
    answer_example = faker.sentence()
    prompt_main = f'{question} {answer_example}'

    class Meta:
        model = Question


class StoryCompletionAPIFactory(factory.DictFactory):
    """
    Story Completion serializer factory.
    """

    text = factory.LazyAttribute(lambda _: faker.text())
    question = factory.LazyAttribute(lambda _: faker.text())
    tones = list()
    collections = list()