from apps.collection.models import CollectionTemplate
from apps.core.models import AbstractCreatedUpdatedDateMixin

from django.db import models
from django.core.exceptions import ValidationError
import re
from apps.life_story.constants import OpenAIQuestionType

def validate_prompt_main(value) -> None:
    prompt_vars = ['question', 'answer', 'collection_name', 'title']
    regex = r"\{\{(.*?)\}\}"
    matches = re.findall(regex, value)
    for match in matches:
        if match not in prompt_vars:
            raise ValidationError(f"{match} Invalid variable name")
    return None


def validate_prompt(value) -> None:
    regex = r"^\s*(.*?[^:\s])\s*:\s*(.+)$"
    if not re.match(regex, value):
        raise ValidationError("Invalid format")
    return None


class Question(AbstractCreatedUpdatedDateMixin):
    question = models.TextField()
    answer_example = models.TextField()
    title = models.TextField()
    prompt_main = models.TextField(validators=[validate_prompt_main])
    prompt_1 = models.CharField(max_length=350, blank=True, null=True, validators=[validate_prompt])
    prompt_2 = models.CharField(max_length=350, blank=True, null=True, validators=[validate_prompt])
    prompt_3 = models.CharField(max_length=350, blank=True, null=True, validators=[validate_prompt])
    collection_template = models.ForeignKey(CollectionTemplate, related_name='questions', blank=False, null=True, on_delete=models.SET_NULL)
    is_fixed = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.question[:100]

    @property
    def tones(self):
        fields = ["prompt_1", "prompt_2", "prompt_3"]
        result = []
        for field in fields:
            value = getattr(self, field, None)
            if value is not None and ":" in value:
                result.append(value.split(":"))
        return result

class OpenAIPromptQuestion(AbstractCreatedUpdatedDateMixin):
    type = models.CharField(max_length=60, blank=False, choices=OpenAIQuestionType.choices(), default=OpenAIQuestionType.CASUAL)
    prompt_text = models.TextField()
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.type