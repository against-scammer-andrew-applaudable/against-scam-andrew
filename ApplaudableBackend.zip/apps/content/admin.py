"""
Content admin config.
"""

from django.contrib import admin

from apps.content.models import TextContent


@admin.register(TextContent)
class TextContentAdmin(admin.ModelAdmin):
    """
    TextContent admin settings.
    """

    list_display = ("type", "created_at", "updated_at")
    fieldsets = (("", {"fields": ("type", "content")}),)
