"""
Content API URLs.
"""

from rest_framework import routers

from apps.content.api.views import TextContentAPIViewSet

app_name = "content"

router = routers.SimpleRouter()
router.register(r"", TextContentAPIViewSet, basename="content")

urlpatterns = [] + router.urls
