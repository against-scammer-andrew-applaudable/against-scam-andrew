"""
Content API views.
"""

from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from rest_framework import mixins, viewsets

from apps.content.api.serializers import TextContentSerializer
from apps.content.models import TextContent


@method_decorator(cache_page(360, key_prefix="api_content"), name="dispatch")
class TextContentAPIViewSet(viewsets.GenericViewSet, mixins.RetrieveModelMixin):
    """
    Get Text Contents eg: (Terms and Conditions, Privacy)
    Valid types:
    - privacy
    - terms-and-conditions
    - faqs
    - about-us
    """

    permission_classes = []
    authentication_classes = []
    queryset = TextContent.objects.all()
    serializer_class = TextContentSerializer
    http_method_names = [
        "get",
    ]
    lookup_field = "type"
