"""
Content serializers.
"""

from rest_framework import serializers

from apps.content.models import TextContent


class TextContentSerializer(serializers.ModelSerializer):
    """
    Serializer for TextContent model.
    """

    class Meta:
        model = TextContent
        fields = ("content", "updated_at")
