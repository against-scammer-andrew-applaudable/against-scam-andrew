"""
Content constants.
"""

from typing import Type, TypeVar

from django.utils.translation import gettext_lazy as _

T = TypeVar("T", bound="TextContentType")


class TextContentType:
    """
    Choice selectors for text content types.
    """

    PRIVACY = "privacy"
    TERMS_AND_CONDITIONS = "terms-and-conditions"
    FAQS = "faqs"
    ABOUT_US = "about-us"

    @classmethod
    def choices(cls: Type[T]) -> tuple:
        """
        TextContent type choices.

        :return: tuple of tuples containing choice values and translatable values
        """

        return (
            (cls.PRIVACY, _("Privacy")),
            (cls.TERMS_AND_CONDITIONS, _("Terms & Conditions")),
            (cls.FAQS, _("FAQs")),
            (cls.ABOUT_US, _("About us")),
        )
