"""
Content models.
"""

from django.core.cache import cache
from django.db import models
from django.utils.translation import gettext_lazy as _

from apps.content.constants import TextContentType
from apps.core.models import AbstractCreatedUpdatedDateMixin


class TextContent(AbstractCreatedUpdatedDateMixin):
    """
    TextContent model.
    """

    type = models.SlugField(choices=TextContentType.choices(), max_length=30, unique=True)
    content = models.TextField(null=True, blank=True)

    class Meta:
        verbose_name = _("Content")
        verbose_name_plural = _("Contents")
        indexes = [
            models.Index(
                fields=[
                    "type",
                ]
            ),
        ]

    def __repr__(self):
        return f"TextContent('{self.type}', '{self.content}')"

    def save(self, *args, **kwargs):
        """
        Delete content cache when saving

        [Overrides AbstractCreatedUpdatedDateMixin.save]
        """

        for cache_key in cache.keys("*api_content*"):
            cache.delete(cache_key)
        return super().save(*args, **kwargs)
