from rest_framework import serializers

class LocationSerializer(serializers.Serializer):
    place_id = serializers.CharField(max_length=100)
    
class NearbySearchSerializer(serializers.Serializer):
    location = serializers.CharField()

class LocationInfoSerializer(serializers.Serializer):
    name = serializers.CharField()
    formatted_title = serializers.CharField()
    geometry = serializers.JSONField()
    url = serializers.CharField()
    photos = serializers.ListField(child=serializers.JSONField())
    place_id = serializers.CharField()