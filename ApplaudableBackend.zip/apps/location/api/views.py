from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import viewsets
from drf_yasg.utils import swagger_auto_schema
from apps.nupp.metadata.somewhere import (
    handle_google_place_result
)
from apps.location.api.serializers import LocationSerializer, LocationInfoSerializer, NearbySearchSerializer
from apps.users.api.authentication import JWTAuthenticationIgnoreIsActive
from services.google.place import GooglePlaceClient


class LocationAPIView(viewsets.GenericViewSet):
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)
    serializer_class = LocationSerializer
    
    @swagger_auto_schema(
        query_serializer=LocationSerializer,
        responses={200: LocationInfoSerializer},
    )

    def list(self, *args, **kwargs):
        serializer = self.get_serializer(data=self.request.GET)
        serializer.is_valid(raise_exception=True)
        place_id = serializer.data["place_id"]
        if serializer.data["place_id"] is None:
            return Response({"error": "Query parameter is missing."}, status=400)
        details = GooglePlaceClient().details(place_id)
        if details and details.get('status') == 'OK':
            private_metadata = handle_google_place_result(details['result'])
            data = {
                'name': private_metadata.get('name', None),
                'formatted_title': private_metadata.get('formatted_address', None),
                'geometry': private_metadata.get('geometry', {}),
                'url': private_metadata.get('url', None),
                "photos": private_metadata.get('photos', None),
                "place_id": place_id
            }
            return Response(data=data)
    
class NearbySearchAPIView(viewsets.GenericViewSet):
    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)
    serializer_class = NearbySearchSerializer
    
    @swagger_auto_schema(
        query_serializer=NearbySearchSerializer,
        responses={200: LocationInfoSerializer},
    )
        

    def list(self, *args, **kwargs):
        serializer = self.get_serializer(data=self.request.GET)
        serializer.is_valid(raise_exception=True)
        location = serializer.data.get('location', None)
        if location is None:
            return Response({"error": "Location parameter is missing."}, status=400)
        details = GooglePlaceClient().nearbySearch(location)
        if details and details.get('status') == 'OK':
            results = []
            for item in details['results']:
                private_metadata = handle_google_place_result(item)
                data = {
                    'name': private_metadata.get('name', None),
                    'formatted_title': private_metadata.get('vicinity', None),
                    'geometry': private_metadata.get('geometry', {}),
                    'url': private_metadata.get('url', None),
                    "photos": private_metadata.get('photos', None),
                    "place_id": private_metadata.get('place_id', None)
                }
                results.append(data)
            return Response(data=results)