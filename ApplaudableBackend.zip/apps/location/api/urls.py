from django.urls import path
from rest_framework.routers import DefaultRouter

from apps.location.api.views import LocationAPIView, NearbySearchAPIView

app_name = "location"

router = DefaultRouter()

urlpatterns = [
    path("detail/", LocationAPIView.as_view({'get': 'list'}), name="location-detail-by-place-id"),
    path("nearbysearch/", NearbySearchAPIView.as_view({'get': 'list'}), name="near-by-search"),
] + router.urls
