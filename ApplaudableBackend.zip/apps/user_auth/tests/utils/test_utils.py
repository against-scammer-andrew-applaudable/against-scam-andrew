from django.contrib.auth import get_user_model
from django.test import TestCase

from apps.user_auth.utils import get_tokens_for_user, get_user_id_from_jwt_token

User = get_user_model()


class GetTokensForUserTestCase(TestCase):
    """ """

    def test_get_tokens_for_active_user(self):
        """
        Test that the tokens for a user are returned.
        """

        user = User.objects.create(username="test_user_verified")
        user.verify = True
        user.save()
        tokens = get_tokens_for_user(user)
        self.assertEqual(len(tokens), 2)

    def test_get_tokens_for_inactive_user(self):
        """
        Test that the tokens for a inactive user are not returned.
        """

        user = User.objects.create(username="test_user_inactive")
        user.is_active = False
        user.save()
        tokens = get_tokens_for_user(user)
        self.assertIsNone(tokens)

    def test_get_tokens_for_unverified_user(self):
        """
        Test that the tokens for a unverified user are not returned.
        """

        user = User.objects.create(username="test_user_unverified")
        user.verify = False
        user.save()
        tokens = get_tokens_for_user(user)
        self.assertIsNone(tokens)

    def test_get_tokens_for_suspended_user(self):
        """
        Test that the tokens for a suspended user are returned.
        """

        user = User.objects.create(username="test_user_suspended")
        user.is_suspend = True
        user.verify = True
        user.save()
        tokens = get_tokens_for_user(user)
        self.assertEqual(len(tokens), 2)


class GetUserIdFromJWTTestCase(TestCase):
    """ """

    def setUp(self):
        self.user = User.objects.create(username="test_user")

    def test_get_user_id_from_jwt_token(self):
        """
        Test that the user id is returned.
        """

        self.user.verify = True
        self.user.save()
        token = get_tokens_for_user(self.user)
        user_id = get_user_id_from_jwt_token(token["access"])
        self.assertEqual(user_id, self.user.id)

    def test_get_user_id_from_invalid_jwt_token(self):
        """
        Test that the user id is not returned.
        """

        user_id = get_user_id_from_jwt_token("invalid_token")
        self.assertIsNone(user_id)
