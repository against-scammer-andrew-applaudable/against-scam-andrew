"""
Tests for password recovery flow.
"""

from unittest.mock import MagicMock, patch

from django.contrib.auth import get_user_model
from rest_framework.test import APIRequestFactory, APITestCase

from apps.user_auth.api.views import PasswordResetViewSet
from apps.user_auth.models import PasswordReset
from apps.users.tests.factories import UserFactory

User = get_user_model()
factory = APIRequestFactory()


class PasswordRecoveryTestCase(APITestCase):
    """
    Test Password Recovery API.
    """

    def setUp(self):
        """
        Set up test data.

        [Overrides APITestCase.setUp]
        """

        self.user = UserFactory()

    @patch("services.firebase.dynamic_links.DynamicLinks.create_short_link")
    def test_password_recovery_request(self, patch_get_firebase_dynamic_link: MagicMock):
        """
        Test password recovery request.
        """

        patch_get_firebase_dynamic_link.return_value = (
            "https://applaudable.com/api/v1/password-reset/"
        )

        data = {"email": self.user.email}
        request = factory.post("/api/v1/auth/password/reset/email/", data=data)
        response = PasswordResetViewSet.as_view({"post": "password_recovery_email_request"})(
            request
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(PasswordReset.objects.count(), 1)
        self.assertEqual(PasswordReset.objects.first().user, self.user)
        patch_get_firebase_dynamic_link.assert_called_once()

    def test_password_recovery_request_invalid_user(self):
        """
        Test password recovery request.
        """

        data = {"email": self.user.email[1:]}
        request = factory.post("/api/v1/auth/password/reset/email/", data=data)
        response = PasswordResetViewSet.as_view({"post": "password_recovery_email_request"})(
            request
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(PasswordReset.objects.count(), 0)

    def test_password_change(self):
        """
        Test password change.
        """

        passwd_reset_instance = PasswordReset.objects.create(user=self.user)
        data = {
            "email": self.user.email,
            "code": passwd_reset_instance.code,
            "password": "new_password",
            "confirm_password": "new_password",
        }

        request = factory.patch("/api/v1/auth/password/reset/", data=data)
        response = PasswordResetViewSet.as_view({"patch": "change_password_email"})(request)
        self.assertEqual(response.status_code, 200)
        self.user.refresh_from_db()
        self.assertTrue(self.user.check_password("new_password"))
        self.assertEqual(PasswordReset.objects.count(), 0)

    def test_password_change_invalid_code(self):
        """
        Test password change with invalid code.
        """

        PasswordReset.objects.create(user=self.user)

        data = {
            "email": self.user.email,
            "code": "invalid_code",
            "password": "new_password",
            "confirm_password": "new_password",
        }

        request = factory.patch("/api/v1/auth/password/reset/", data=data)
        response = PasswordResetViewSet.as_view({"patch": "change_password_email"})(request)
        self.assertEqual(response.status_code, 400)
        self.assertEqual(PasswordReset.objects.count(), 1)

    def test_password_change_invalid_user(self):
        """
        Test password change with invalid user.
        """

        passwd_reset_instance = PasswordReset.objects.create(user=self.user)

        data = {
            "email": self.user.email[1:],
            "code": passwd_reset_instance.code,
            "password": "new_password",
            "confirm_password": "new_password",
        }

        request = factory.patch("/api/v1/auth/password/reset/", data=data)
        response = PasswordResetViewSet.as_view({"patch": "change_password_email"})(request)
        self.assertEqual(response.status_code, 400)
        self.assertEqual(PasswordReset.objects.count(), 1)

    @patch("apps.user_auth.models.PasswordReset.is_expired")
    def test_password_change_expired_code(self, mock_is_expired: MagicMock):
        """
        Test password change with expired code.
        """

        mock_is_expired.return_value = True
        passwd_reset_instance = PasswordReset.objects.create(user=self.user)

        data = {
            "email": self.user.email,
            "code": passwd_reset_instance.code,
            "password": "new_password",
            "confirm_password": "new_password",
        }

        request = factory.patch("/api/v1/auth/password/reset/", data=data)
        response = PasswordResetViewSet.as_view({"patch": "change_password_email"})(request)
        self.assertEqual(response.status_code, 400)
        self.assertEqual(PasswordReset.objects.count(), 1)
