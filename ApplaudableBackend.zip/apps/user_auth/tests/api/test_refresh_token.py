"""
Tests for Refresh Token API View.
"""

from django.contrib.auth import get_user_model
from rest_framework.test import APIRequestFactory, APITestCase

from apps.user_auth.api.views import RefreshTokenAPIView
from apps.users.api.views import LoginViewSet
from apps.users.tests.factories import UserFactory

User = get_user_model()
factory = APIRequestFactory()


class RefreshTokenAPITestCase(APITestCase):
    """
    Tests for Refresh Token API View.
    """

    def setUp(self):
        """
        Set inital test data.

        [Overrides APITestCase.setUp]
        """

        self.user = UserFactory()
        password = "Dengun2022"
        self.user.verify = True
        self.user.set_password(password)
        self.user.save()
        self.data = {"email": self.user.email, "password": password}

    def test_get_new_refresh_token(self):
        """
        Test obtain new refresh token.
        """

        login_request = factory.post(path="api/v1/login/email/", data=self.data)
        login_response = LoginViewSet.as_view({"post": "email"})(login_request)

        access_token = login_response.data["token"]["access"]
        refresh_token = login_response.data["token"]["refresh"]

        token_request = factory.post(
            path="api/v1/auth/token/refresh/",
            data={"refresh": refresh_token},
            HTTP_AUTHORIZATION=f"Bearer {access_token}",
        )
        token_response = RefreshTokenAPIView.as_view()(token_request)

        self.assertEqual(token_response.status_code, 200)
        self.assertEqual(len(token_response.data), 2)
        self.assertNotEqual(token_response.data["refresh"], refresh_token)

    def test_invalid_token(self):
        """
        Test invalid access token request.
        """

        login_request = factory.post(path="api/v1/login/email/", data=self.data)
        login_response = LoginViewSet.as_view({"post": "email"})(login_request)

        access_token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNz\
            IiwiZXhwIjoxNjYxOTU3ODg4LCJpYXQiOjE2NjE5NTc4ODUsImp0aSI6IjE2MzAxYzE4YWEwMTQwZ\
                GI5NmQ4ZTBkODMzZTFhN2YzIiwidXNlcl9pZCI6OTk5fQ.TeGbtQNsx-oaWLJaTf5j1XNHcJ9\
                    S0Xu5fvbloE4Xu1k"
        refresh_token = login_response.data["token"]["refresh"]

        token_request = factory.post(
            path="api/v1/auth/token/refresh/",
            data={"refresh": refresh_token},
            HTTP_AUTHORIZATION=f"Bearer {access_token}",
        )
        token_response = RefreshTokenAPIView.as_view()(token_request)
        self.assertEqual(token_response.status_code, 401)
