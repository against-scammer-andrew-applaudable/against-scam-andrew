from django import forms

from apps.email import EmailDefinition, register


@register("Recovery Password")
class PasswordRecoveryEmail(EmailDefinition):
    html_template = "email/user_password_recovery.html"
    text_template = "email/user_password_recovery.txt"

    subject = forms.CharField(initial="{{ site.name }} - Recovery Password")
    title = forms.CharField(initial="Recovery Password")
    sub_title = forms.CharField(initial='Click this <a href="{{ dynamic_link }}">link</a> to reset your password')
    message = forms.CharField(initial="The {{ site.name }} team", widget=forms.Textarea)

    @classmethod
    def sample_context(cls, bank):
        return {
            "dynamic_link": "https://www.applaudable.com/api/v1/auth/change-password/email/?\
                code=f64f4ae9-26ce-47eb-8d71-ef725f234bd5&email=admin@applaudable.com",
        }


@register("Contact Email")
class ContactEmail(EmailDefinition):
    html_template = "contact/contact_request_email.html"
    text_template = "contact/contact_request_email.txt"

    subject = forms.CharField(initial="Contact Request")
    name = forms.CharField(initial="{{name}}")
    email = forms.CharField(initial='{{email}}')
    message = forms.CharField(
        initial="{{msg}}",
        widget=forms.Textarea,
    )


@register("Press Email")
class PressEmail(EmailDefinition):
    html_template = "contact/contact_request_email.html"
    text_template = "contact/contact_request_email.txt"

    subject = forms.CharField(initial="Press Request")
    name = forms.CharField(initial="{{name}}")
    email = forms.CharField(initial='{{email}}')
    message = forms.CharField(
        initial="{{msg}}",
        widget=forms.Textarea,
    )


@register("Careers Email")
class CareersEmail(EmailDefinition):
    html_template = "careers/careers_request_email.html"
    text_template = "careers/careers_request_email.txt"

    subject = forms.CharField(initial="Careers Request")
    name = forms.CharField(initial="{{name}}")
    email = forms.CharField(initial='{{email}}')
    phone_number = forms.CharField(initial='{{phone_number}}')
    message = forms.CharField(
        initial="{{msg}}",
        widget=forms.Textarea,
    )
