from celery import shared_task
from django.core.files import File
from django.contrib.auth import get_user_model

from apps.user_auth.models import PasswordReset
from apps.user_auth.utils import (
    send_password_recovery_code,
    acquire_password_reset_dynamic_link,
    send_contact_email,
    send_press_email,
    send_careers_email,
)

User = get_user_model()


@shared_task
def task_send_password_reset(user_id: str):
    """
    Send password reset code to user.

    :param method: password reset method (email or sms)
    :param user_id: user id
    """

    user = User.objects.filter(id=user_id).first()
    if not user:
        return

    password_reset, _ = PasswordReset.objects.update_or_create(user=user)
    dynamic_link = acquire_password_reset_dynamic_link(password_reset.code, user.email)
    send_password_recovery_code(user.email, dynamic_link)


@shared_task
def task_send_test_email(user_email: str):
    """
    Send test email to user.

    :param method: password reset method (email or sms)
    :param user_id: user id
    """
    dynamic_link = "https://applauable.com"
    send_password_recovery_code(user_email, dynamic_link)


@shared_task
def task_send_contact_email(user_name: str, user_email: str, user_message: str):
    """
    Asynchronous task to send a general contact email to the specified recipients.

    :param user_name: The name of the user sending the email
    :param user_email: The email address of the user sending the email
    :param user_message: The content/message of the email
    """
    recipients = ["info@applaudable.com"]
    send_contact_email(user_name, user_email, user_message, recipients)


@shared_task
def task_send_press_email(user_name: str, user_email: str, user_message: str):
    """
    Asynchronous task to send a press-related email to the specified recipients.

    :param user_name: The name of the user sending the email
    :param user_email: The email address of the user sending the email
    :param user_message: The content/message of the email
    """
    recipients = ["press@applaudable.com"]
    send_press_email(user_name, user_email, user_message, recipients)


@shared_task
def task_send_careers_email(user_name: str, user_email: str, user_phone_number: str, user_message: str, user_resume: File):
    """
    Asynchronous task to send a career-related email, including a resume attachment, to the specified recipients.

    :param user_name: The name of the user sending the email
    :param user_email: The email address of the user sending the email
    :param user_phone_number: The phone number of the user (included for potential follow-ups)
    :param user_message: The content/message of the email
    :param user_resume: The resume file to be attached to the email
    """
    recipients = ["careers@applaudable.com"]
    # Assuming send_careers_email function handles the conversion of File to the attachment
    send_careers_email(user_name, user_email, user_phone_number, user_message, recipients, attachments=user_resume)
