import logging
from django.contrib.auth import get_user_model
from rest_framework import serializers, status
from rest_framework.response import Response
from django.core.files.base import ContentFile
from phonenumber_field.serializerfields import PhoneNumberField

from apps.api.v1.serializers import EmailSerializer
from apps.user_auth.models import PasswordReset
from apps.user_auth.tasks import task_send_password_reset
from apps.user_auth.tasks import task_send_test_email, task_send_contact_email, task_send_press_email, task_send_careers_email

logger = logging.getLogger(__name__)
User = get_user_model()


class TestEmailRequestSerializer(EmailSerializer):
    def save(self, **kwargs):
        email = self.validated_data["email"]
        task_send_test_email.delay(str(email))
        return email


class EmailPasswordRecoveryRequestSerializer(EmailSerializer):
    def save(self, **kwargs):
        email = self.validated_data["email"]
        user = User.objects.filter(email=email).first()
        if user:
            task_send_password_reset.delay(str(user.id))
        return email


class ResetPasswordSerializer(serializers.ModelSerializer):
    confirm_password = serializers.CharField(write_only=True, style={"input_type": "password"})

    class Meta:
        model = User
        fields = ("password", "confirm_password")
        extra_kwargs = {
            "password": {"write_only": True, "style": {"input_type": "password"}},
        }

    def validate(self, attrs):
        attrs = super().validate(attrs)
        if attrs["password"] != attrs["confirm_password"]:
            raise serializers.ValidationError({"confirm_password": "Passwords do not match"})
        return attrs

    def save(self, **kwargs):
        user = self.context["user"]
        user.set_password(self.validated_data["password"])
        user.save()
        return user


class EmailChangePasswordSerializer(EmailSerializer):
    password = serializers.CharField(write_only=True, style={"input_type": "password"})
    confirm_password = serializers.CharField(write_only=True, style={"input_type": "password"})
    code = serializers.CharField(write_only=True)

    def validate(self, attrs):
        super().validate(attrs)
        user = User.objects.filter(email=attrs["email"]).first()
        if not user:
            raise serializers.ValidationError({"email": "Email is invalid"})
        self.context["user"] = user
        if attrs["password"] != attrs["confirm_password"]:
            raise serializers.ValidationError({"confirm_password": "Passwords do not match"})
        passwd_reset_instance = PasswordReset.objects.filter(user=user, code=attrs["code"]).first()
        if not passwd_reset_instance or passwd_reset_instance.is_expired():
            raise serializers.ValidationError({"code": "Code is invalid or expired"})
        self.context["passwd_reset_instance"] = passwd_reset_instance
        return attrs

    def save(self, **kwargs):
        self.context["user"].set_password(self.validated_data["password"])
        self.context["user"].save()
        self.context["passwd_reset_instance"].delete()
        return self.context["user"]


class UserChangePasswordSerializer(serializers.ModelSerializer):
    old_password = serializers.CharField(write_only=True, required=True, style={'input_type': 'password', 'placeholder': 'Password'})
    confirm_password = serializers.CharField(write_only=True, required=True, style={'input_type': 'password', 'placeholder': 'Password'})

    class Meta:
        model = User
        fields = ("password", "old_password", "confirm_password")

    def validate(self, attrs):
        super().validate(attrs)
        user = self.context['request'].user
        if not user.check_password(attrs["old_password"]):
            raise serializers.ValidationError({"old_password": "The password is not correct"})
        if not user:
            raise serializers.ValidationError({"email": "Email is invalid"})
        if attrs["password"] != attrs["confirm_password"]:
            raise serializers.ValidationError({"confirm_password": "Passwords do not match"})
        return attrs

    def save(self, **kwargs):
        self.context['request'].user.set_password(self.validated_data["password"])
        self.context['request'].user.save()
        return self.context['request'].user


class ContactEmailRequestSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=100)
    email = serializers.CharField()
    message = serializers.CharField(max_length=100)

    def save(self, **kwargs):
        name = self.validated_data["name"]
        email = self.validated_data["email"]
        message = self.validated_data["message"]
        send_result = task_send_contact_email.delay(str(name), str(email), str(message))
        return send_result


class PressEmailRequestSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=100)
    email = serializers.CharField()
    message = serializers.CharField(max_length=1000)

    def save(self, **kwargs):
        name = self.validated_data["name"]
        email = self.validated_data["email"]
        message = self.validated_data["message"]
        send_result = task_send_press_email.delay(str(name), str(email), str(message))
        return send_result


class CareersEmailRequestSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=100)
    email = serializers.EmailField()
    phone_number = PhoneNumberField()
    message = serializers.CharField(max_length=1000)
    resume = serializers.FileField()

    def save(self, **kwargs):
        name = self.validated_data["name"]
        email = self.validated_data["email"]
        phone_number = self.validated_data["phone_number"]
        message = self.validated_data["message"]
        resume = self.validated_data['resume']

        # Handling the resume file upload
        email_attachments = [(resume.name, resume.read(), resume.content_type)]

        send_result = task_send_careers_email.delay(str(name), str(email), str(phone_number), str(message), email_attachments)
        return send_result
