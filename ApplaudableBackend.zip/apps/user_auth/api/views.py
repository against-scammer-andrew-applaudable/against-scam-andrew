import logging
from django.contrib.auth import get_user_model
from drf_yasg.utils import swagger_auto_schema
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.generics import CreateAPIView
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.viewsets import GenericViewSet
from rest_framework.generics import RetrieveUpdateAPIView
from rest_framework_simplejwt.serializers import TokenRefreshSerializer
from rest_framework_simplejwt.views import TokenObtainPairView

from apps.api.v1.serializers import SuccessIndicatorSerializer
from apps.user_auth.api.serializers import (
    EmailChangePasswordSerializer,
    EmailPasswordRecoveryRequestSerializer,
    ResetPasswordSerializer,
    UserChangePasswordSerializer,
    TestEmailRequestSerializer,
    ContactEmailRequestSerializer,
    PressEmailRequestSerializer,
    CareersEmailRequestSerializer,
)
from apps.user_auth.utils import get_tokens_for_user, get_user_id_from_jwt_token
from apps.users.api.authentication import JWTAuthenticationIgnoreIsActive

logger = logging.getLogger(__name__)
User = get_user_model()


class TestEmailViewSet(GenericViewSet):
    """
    ViewSet to handle sending test email flow.
    """

    permission_classes = (AllowAny,)

    @swagger_auto_schema(
        request_body=TestEmailRequestSerializer,
        responses={status.HTTP_200_OK: TestEmailRequestSerializer()},
    )
    @action(
        methods=("post",),
        detail=False,
        name="Request test email by email",
        url_path="password/test/email",
        url_name="password-test-email-request",
    )
    def test_email_request(self, request: Request, *args, **kwargs):
        """
        Test sending email.
        """

        serializer = TestEmailRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(status=status.HTTP_200_OK, data=serializer.data)


class RefreshTokenAPIView(TokenObtainPairView):
    """
    Generates a new refresh token
    """

    authentication_classes = (JWTAuthenticationIgnoreIsActive,)
    permission_classes = (IsAuthenticated,)

    serializer_class = TokenRefreshSerializer

    @swagger_auto_schema(responses={status.HTTP_200_OK: TokenRefreshSerializer()})
    def post(self, request: Request, *args, **kwargs) -> Response:
        """
        Authenticate using a valid Access Token and pass
        the old Refresh Token in the body of the request.
        Returns a new valid token pair.
        """

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user_id = get_user_id_from_jwt_token(serializer.validated_data["refresh"])
        user = User.objects.get(id=user_id)
        new_refresh = get_tokens_for_user(user)

        return Response(
            {"access": new_refresh["access"], "refresh": new_refresh["refresh"]},
            status=status.HTTP_200_OK,
        )


class PasswordResetViewSet(GenericViewSet):
    """
    ViewSet to handle user's password reset flow.
    """

    permission_classes = (AllowAny,)

    @swagger_auto_schema(
        request_body=EmailPasswordRecoveryRequestSerializer,
        responses={status.HTTP_200_OK: EmailPasswordRecoveryRequestSerializer()},
    )
    @action(
        methods=("post",),
        detail=False,
        name="Request email password recovery by email",
        url_path="password/reset/email",
        url_name="password-recovery-email-request",
    )
    def password_recovery_email_request(self, request: Request, *args, **kwargs):
        """
        Request password recovery by email.
        """

        serializer = EmailPasswordRecoveryRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(status=status.HTTP_200_OK, data=serializer.data)

    @swagger_auto_schema(
        request_body=ResetPasswordSerializer,
        responses={status.HTTP_200_OK: SuccessIndicatorSerializer()},
    )
    @action(
        methods=("patch",),
        detail=False,
        name="Change password by email flow",
        url_path="change-password/email",
        url_name="change-password-email",
    )
    def change_password_email(self, request: Request, *args, **kwargs):
        """
        Reset user's password using email flow.
        """

        serializer = EmailChangePasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response(status=status.HTTP_200_OK, data={"success": True})


class UserChangePasswordView(RetrieveUpdateAPIView):
    permission_classes = (IsAuthenticated,)
    http_method_names = ['patch', 'head', 'options', 'trace']
    queryset = User.objects.filter(is_active=True)
    serializer_class = UserChangePasswordSerializer

    def get_object(self):
        return self.request.user

    @swagger_auto_schema(
        request_body=UserChangePasswordSerializer,
        responses={status.HTTP_202_ACCEPTED: ""},
    )
    def patch(self, request, *args, **kwargs):
        super().update(request, *args, **kwargs)
        return Response(status=status.HTTP_202_ACCEPTED)


from rest_framework.views import status
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from rest_framework.generics import CreateAPIView


# Base class for all email sending viewsets
class BaseEmailViewSet(CreateAPIView):
    permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        send_result = serializer.save()
        if send_result:
            return Response({"message": "Email sent successfully."}, status=status.HTTP_200_OK)
        else:
            logger.error("Failed to send email")
            return Response({"message": "Failed to send email."}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class ContactEmailViewSet(BaseEmailViewSet):
    serializer_class = ContactEmailRequestSerializer

    @swagger_auto_schema(request_body=ContactEmailRequestSerializer)
    def create(self, request, *args, **kwargs):
        return super().create(request, *args, **kwargs)


class PressEmailViewSet(BaseEmailViewSet):
    serializer_class = PressEmailRequestSerializer

    @swagger_auto_schema(request_body=PressEmailRequestSerializer)
    def create(self, request, *args, **kwargs):
        return super().create(request, *args, **kwargs)


class CareersEmailViewSet(BaseEmailViewSet):
    serializer_class = CareersEmailRequestSerializer

    @swagger_auto_schema(request_body=CareersEmailRequestSerializer)
    def create(self, request, *args, **kwargs):
        return super().create(request, *args, **kwargs)
