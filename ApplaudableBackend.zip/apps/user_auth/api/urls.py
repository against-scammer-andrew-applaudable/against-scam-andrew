from django.urls import path
from rest_framework import routers
from rest_framework_simplejwt.views import TokenVerifyView

from apps.user_auth.api.views import (
    TestEmailViewSet,
    PasswordResetViewSet,
    RefreshTokenAPIView,
    UserChangePasswordView,
    ContactEmailViewSet,
    PressEmailViewSet,
    CareersEmailViewSet,
)

app_name = "auth"

router = routers.SimpleRouter()
router.register(r"", PasswordResetViewSet, "password-reset")
router.register(r"", TestEmailViewSet, "email-test")

urlpatterns = [
    path("token/refresh/", RefreshTokenAPIView.as_view(), name="token-refresh"),
    path("token/verify/", TokenVerifyView.as_view(), name="token-verify"),
    path("change-password/", UserChangePasswordView.as_view(), name="user-reset-password"),
    path("contact/", ContactEmailViewSet.as_view(), name="contact-email"),
    path("press/", PressEmailViewSet.as_view(), name="press-email"),
    path("careers/", CareersEmailViewSet.as_view(), name="careers-email"),
] + router.urls
