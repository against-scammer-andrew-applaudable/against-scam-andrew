from django.conf import settings
from django.contrib import admin

from apps.user_auth.models import PasswordReset


class PasswordResetAdmin(admin.ModelAdmin):
    """
    Password reset admin.
    """

    list_display = ("user", "updated_at", "is_expired")
    search_fields = ("user__username", "user__email")
    list_filter = ("created_at",)
    readonly_fields = ("code",)
    list_select_related = ("user",)

    fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": (
                    "code",
                    "user",
                    "extra_data",
                ),
            },
        ),
    )


if settings.DEBUG:
    admin.site.register(PasswordReset, PasswordResetAdmin)
