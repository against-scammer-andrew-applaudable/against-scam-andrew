import logging
from typing import Optional

from django.core.files import File
from django.conf import settings
from django.contrib.auth import get_user_model
from jwt import decode as jwt_decode
from rest_framework_simplejwt.exceptions import InvalidToken, TokenError
from rest_framework_simplejwt.tokens import RefreshToken, UntypedToken

from apps.core.utils import domain_with_proto
from apps.email.utils import send
from apps.user_auth.emails import PasswordRecoveryEmail, ContactEmail, PressEmail, CareersEmail
from services.firebase.utils import generate_dynamic_link

User = get_user_model()


def get_tokens_for_user(user: User) -> dict:
    """
    Return pair of tokens if user is verified.

    :param user: User instance

    :return: pair of tokens if user is verified, None otherwise
    """

    if not (user.verify and user.is_active and not user.is_disabled):
        return None

    refresh = RefreshToken.for_user(user)

    return {
        "refresh": str(refresh),
        "access": str(refresh.access_token),
    }


def get_user_id_from_jwt_token(token: str) -> Optional[int]:
    """
    Verify a JWT token and return the user id.

    :param token: JWT token

    :return: user id if token is valid, None otherwise
    """

    try:
        # This will automatically validate the token and raise an error if token is invalid
        UntypedToken(token)
    except (InvalidToken, TokenError) as e:
        logging.error(e, exc_info=True)
        return None
    else:
        #  Then token is valid, decode it
        decoded_data = jwt_decode(token, settings.SECRET_KEY, algorithms=["HS256"])
        # Will return a dictionary like -
        # {
        #     "token_type": "access",
        #     "exp": 1568770772,
        #     "jti": "5c15e80d65b04c20ad34d77b6703251b",
        #     "user_id": 6
        # }

        # Get the user using ID
        return decoded_data["user_id"]


def send_password_recovery_code(user_email: str, dynamic_link: str):
    """
    Send password recovery code to user.

    :param user_email: user email address
    :param dynamic_link: Firebase dynamic link
    """

    context = {"dynamic_link": dynamic_link}

    send(
        PasswordRecoveryEmail,
        context,
        [
            user_email,
        ],
    )


def acquire_password_reset_dynamic_link(code, email):
    password_reset_link = domain_with_proto("/reset-password")
    link_url = f"{password_reset_link}?code={code}&email={email}"
    return generate_dynamic_link(link_url)


def send_contact_email(user_name: str, user_email: str, user_message: str, recipients: str):
    """
    Send a general contact email on behalf of a user to specified recipients. This function
    prepares the email content using provided user details and sends it through a predefined
    ContactEmail configuration.

    :param user_name: The sender's name.
    :param user_email: The sender's email address.
    :param user_message: The body of the message to be sent.
    :param recipients: A list of email addresses to which the email will be sent.
    """

    context = {"name": user_name, "email": user_email, "msg": user_message}
    send(ContactEmail, context, recipients)


def send_press_email(user_name: str, user_email: str, user_message: str, recipients: str):
    """
    Send a press-related email from a user to specified recipients. This function is tailored
    for communications related to press inquiries or press statements and uses the PressEmail
    configuration to format and send the email.

    :param user_name: The sender's name.
    :param user_email: The sender's email address.
    :param user_message: The content of the press-related message.
    :param recipients: A list of email addresses to which the email will be sent.
    """

    context = {"name": user_name, "email": user_email, "msg": user_message}
    send(PressEmail, context, recipients)


def send_careers_email(user_name: str, user_email: str, user_phone_number: str, user_message: str, recipients: str, attachments: File = None):
    """
    Send a career-related email, including a resume attachment, from a user to specified recipients.
    This function is specifically designed for job application or recruitment inquiries and can handle
    an optional file attachment (typically a resume).

    :param user_name: The sender's name.
    :param user_email: The sender's email address.
    :param user_phone_number: The sender's phone number for potential follow-ups.
    :param user_message: The message detailing the user's career inquiry or application.
    :param recipients: A list of email addresses to which the email will be sent.
    :param attachments: A resume file to be attached to the email, optional.
    """

    context = {"name": user_name, "email": user_email, "phone_number": user_phone_number, "msg": user_message}
    send(CareersEmail, context, recipients, attachments)
