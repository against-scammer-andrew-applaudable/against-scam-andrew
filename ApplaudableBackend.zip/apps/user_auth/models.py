from django.contrib.auth import get_user_model
from django.db import models

from apps.core.models import AbstractValidation

User = get_user_model()


class PasswordReset(AbstractValidation):
    """
    Password reset model.
    """

    user = models.OneToOneField(User, related_name="password_reset", on_delete=models.CASCADE)
    extra_data = models.JSONField(default=dict)
