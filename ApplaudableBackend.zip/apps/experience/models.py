# Create your models here.
from email.policy import default
from random import choices
from django.contrib.auth import get_user_model
from django.db import models
from django.contrib.postgres.indexes import GinIndex
from .constant import ExperienceDataType
from apps.media.models import AbstractMedia

from apps.core.models import AbstractCreatedUpdatedDateMixin, AbstractMetadata, AbstractUniqueHashIDMixin


User = get_user_model()


class Experience(AbstractUniqueHashIDMixin):
    name = models.TextField(null=False)
    order = models.IntegerField(blank=False, default=0)
    data_type = models.CharField(max_length=60, blank=False, choices=ExperienceDataType.choices(), default=ExperienceDataType.OTHER)
    icon_slug = models.TextField(null=True)
    usage = models.IntegerField(blank=False, default=0)
    published = models.BooleanField(default=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)

    class Meta:
        db_table = "experience"
        ordering = ['order']

    def __str__(self):
        return f"{self.id} - {self.name}"


class ExperienceElement(AbstractUniqueHashIDMixin, AbstractCreatedUpdatedDateMixin, AbstractMetadata):
    experience = models.ForeignKey(Experience, on_delete=models.CASCADE, null=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    name = models.TextField(null=True)
    category = models.TextField(null=True)
    sub_category = models.TextField(null=True)
    published = models.BooleanField(default=False)
    is_validated = models.BooleanField(default=False)
    # It will be a placeId for the location data type
    reference=models.CharField(default="", max_length=255)

    class Meta:
        db_table = "experience_element"
        indexes = [
            *AbstractMetadata.Meta.indexes,
            GinIndex(
                name="element_reference_gin",
                # `opclasses` and `fields` should be the same length
                fields=["reference"],
                opclasses=["gin_trgm_ops"],
            ),
        ]

    def __str__(self):
        return f"{self.id} - {self.name}"
    
    
class ElementMedia(AbstractMedia):
    element = models.ForeignKey(ExperienceElement, on_delete=models.CASCADE, related_name="media")

    class Meta:
        db_table = "elements_media"
        verbose_name = "Media"
        verbose_name_plural = "Media"
        indexes = [
            *AbstractMedia.Meta.indexes,
        ]
