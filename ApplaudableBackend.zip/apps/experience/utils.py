from io import BytesIO

import cloudinary
from django.conf import settings
from PIL import Image

from apps.media.constants import MediaType
from apps.media.utils import cloudinary_resource_to_dict
from apps.experience.models import ElementMedia


def create_post_element_media(element, img, min_size=280):
    # verify image size
    if img.size[0] < min_size or img.size[1] < min_size:
        return None

    basewidth = getattr(settings, 'METADATA_IMAGE_BASE_WIDTH', 1200)

    # resize images larger than
    if img.size[0] > basewidth:
        wpercent = basewidth / float(img.size[0])
        hsize = int((float(img.size[1]) * float(wpercent)))
        img = img.resize((basewidth, hsize), Image.ANTIALIAS)

    # save Image
    tmp_file = BytesIO()

    # remove image alpha channels
    if img.mode != 'RGB':
        new_image = Image.new("RGB", img.size, (255, 255, 255, 255))
        try:
            new_image.paste(img, mask=img)
        except ValueError:
            new_image.paste(img)
    else:
        new_image = img

    new_image.convert("RGB")

    # save new tmp file
    new_image.save(
        tmp_file,
        "JPEG",
        quality=getattr(settings, 'METADATA_IMAGE_QUALITY', 90),
        optimize=True,
        progressive=True,
    )

    # upload to cloudinary
    image_source = cloudinary.uploader.upload_resource(tmp_file.getvalue(), **{"folder": settings.CLOUDINARY_DEFAULT_FOLDER, "tags": ['element']})
    print("create element media", element, image_source)
    # save media object
    return ElementMedia.objects.create(element=element, image_source=image_source, type=MediaType.IMAGE)

def get_prediction_media_element(predictions):
    element_ids = set()
    for prediction in predictions:
        element_ids.add(prediction['id'])

    element_media_qs = (
        ElementMedia.objects.filter(element_id__in=element_ids, type=MediaType.IMAGE, image_source__isnull=False)
        .values_list('element_id', 'image_source', 'metadata')
        .order_by('element_id')
    )

    media_by_element_id = {m[0]: cloudinary_resource_to_dict(m[1], metadata=m[2]) for m in element_media_qs}
    return media_by_element_id
