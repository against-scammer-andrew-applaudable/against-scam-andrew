"""
Experience API serializers
"""

from django.conf import settings
from django.contrib.auth import get_user_model
from apps.experience.models import Experience, ExperienceElement, ElementMedia
from rest_framework import serializers
from apps.users.api.serializers import SimpleUserSerializer
from hashid_field.rest import HashidSerializerCharField
from apps.media.serializers import MediaSerializer
from apps.experience.task import (task_find_element_metadata)
from drf_yasg.utils import swagger_serializer_method

User = get_user_model()


class ExperienceSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    class Meta:
        model = Experience
        fields = ("id", "name", "order", "data_type", "icon_slug", "usage", "published")

class ExperienceSimpleSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    class Meta:
        model = Experience
        fields = ("id", "name")
        
class ElementMediaSerializer(MediaSerializer, serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)
    class Meta:
        model = ElementMedia
        fields = ("url", "type", "id", "text", "media_detail", "height", "width")
        
class ExperienceElementSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    media = serializers.SerializerMethodField()
    
    @swagger_serializer_method(serializer_or_field=ElementMediaSerializer)
    def get_media(self, obj):
        media = ElementMedia.objects.filter(element=obj.id)
        if not media:
            return
        try:
            return ElementMediaSerializer(media.first()).data
        except AttributeError as e:
            pass

    class Meta:
        model = ExperienceElement
        fields = ("id", "name", "category", "sub_category", "published", "metadata", "media")


class ExperienceElementSimpleSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    avatar = serializers.SerializerMethodField()
    name = serializers.SerializerMethodField()
    address = serializers.SerializerMethodField()
    
    def get_name(self, obj):
        try:
            if obj.metadata and obj.metadata['name']:
                return obj.metadata['name']
            return obj.name
        except Exception as e:
            return None   
        
    def get_address(self, obj):
        try:
            if obj.metadata and obj.metadata['formatted_title']:
                return obj.metadata['formatted_title']
            return obj.name
        except Exception as e:
            return None   
    
    def get_avatar(self, obj):
        try:
            return ElementMedia.objects.filter(element_id=obj.id).first().cloudinary_resource.url
        except AttributeError:
            return None   


    class Meta:
        model = ExperienceElement
        fields = ("id", "name", "address", "avatar")     
        

        
class ExperienceElementPostSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    name = serializers.CharField()
    category = serializers.CharField()
    sub_category = serializers.CharField()
    published = serializers.BooleanField()
    experience_id = HashidSerializerCharField(allow_null=False, required=True)
    user_id = HashidSerializerCharField(allow_null=True, required=False)
    
    class Meta:
        model = ExperienceElement
        fields = (
            "id", "name", "category", "sub_category", "published", "experience_id", "user_id", "metadata"
        )
        extra_kwargs = {
            "created_at": {"read_only": True},
            "metadata": {"required": False},
            "user_id": {"required": False},
            "category": {"required": False},
            "sub_category": {"required": False},
        }

    def validate(self, attrs, options=[]):
        attrs = super().validate(attrs)
        return attrs

    def save(self, **kwargs):
        user = self.validated_data.pop("user", None)
        if user:
            self.validated_data["user"] = user
        return super().save(**kwargs)
    
    
class ExperienceAutocompleteSerializer(serializers.Serializer):
    query = serializers.CharField(max_length=100)
    location = serializers.CharField(required=False)

class ExperienceAutocompleteResponseSerializer(serializers.Serializer):
    description = serializers.CharField()
    place_id = serializers.CharField()
    element_id = HashidSerializerCharField()
    media = MediaSerializer()
    structured_formatting = serializers.JSONField()
    metadata = serializers.JSONField()
    
class ElementLocationSerializer(serializers.Serializer):
    experience_id = serializers.CharField()
    place_id = serializers.CharField()
    content = serializers.CharField()

    def validate(self, attrs):
        attrs = super().validate(attrs)
        if not attrs.get("place_id"):
            raise serializers.ValidationError({"place_id": "This field is required."})

        if not attrs.get("experience_id"):
            raise serializers.ValidationError({"experience_id": "This field is required."})

        if not attrs.get("content"):
            raise serializers.ValidationError({"content": "This field is required."})

        return attrs

    def save(self, user):
        obj, created = ExperienceElement.objects.get_or_create(
                            experience_id=self.validated_data['experience_id'],
                            reference=self.validated_data['place_id'],
                            user_id=user.id,
                            name=self.validated_data['content'],
                        )
            # trigger metadata handler
        if created:
            # give some delay to allow the user to tag the post
            task_find_element_metadata(str(obj.id))
            # Need to check this task why it doesn't work
            # task_find_element_metadata.apply_async(args=(str(obj.id),), countdown=60)
        return obj