import logging
from django.contrib.auth import get_user_model
from rest_framework.permissions import IsAuthenticated
from rest_framework.viewsets import ModelViewSet, GenericViewSet
from rest_framework.generics import ListAPIView
from services.google.place import GooglePlaceClient

from django_filters.rest_framework import DjangoFilterBackend
from drf_yasg.utils import swagger_auto_schema
from rest_framework import status
from rest_framework.request import Request
from rest_framework.response import Response


from apps.experience.api.serializers import ExperienceSerializer, ExperienceElementSerializer, ExperienceElementPostSerializer, ExperienceAutocompleteSerializer, ExperienceAutocompleteResponseSerializer
from apps.experience.models import Experience, ExperienceElement
from apps.experience.filters import ExperienceElementFilter
from apps.experience.utils import (
    get_prediction_media_element
)

User = get_user_model()


class ExperienceViewSet(ModelViewSet):
    http_method_names = ['get']
    permission_classes = (IsAuthenticated,)
    queryset = Experience.objects.filter(published=True)
    serializer_class = ExperienceSerializer
    
    
class ExperienceElementListViewSet(ListAPIView):
    http_method_names = ['get']
    # Ignore pagination
    pagination_class = None
    permission_classes = (IsAuthenticated,)
    serializer_class = ExperienceElementSerializer
    filter_backends = (DjangoFilterBackend,)
    filterset_class = ExperienceElementFilter

    def get_queryset(self):
        id = self.kwargs["id"]
        if id: 
            queryset = ExperienceElement.objects.filter(experience_id=id, published=True)
        else:
            queryset = ExperienceElement.objects.filter(published=True)
        return queryset
    
class ExperienceElementCreateViewSet(ModelViewSet):
    http_method_names = ['post']
    permission_classes = (IsAuthenticated,)
    queryset = ExperienceElement.objects.all()
    serializer_class = ExperienceElementSerializer
    
    @swagger_auto_schema(
        request_body=ExperienceElementPostSerializer,
        responses={status.HTTP_201_CREATED: ExperienceElementSerializer()},
    )
    def create(self, request: Request):
        serializer = ExperienceElementPostSerializer(data=request.data, context=self.get_serializer_context())
        serializer.is_valid(raise_exception=True)
        serializer.save()

        response_serializer = ExperienceElementSerializer(serializer.instance, context=self.get_serializer_context())
        return Response(status=status.HTTP_201_CREATED, data=response_serializer.data)
    
    
class ExperienceElementDetailViewSet(ModelViewSet):
    http_method_names = ['get']
    permission_classes = (IsAuthenticated,)
    queryset = ExperienceElement.objects.filter(published=True)
    serializer_class = ExperienceElementSerializer
    lookup_field = "id"

    def get_queryset(self):
        id = self.kwargs["id"]
        if id: 
            queryset = ExperienceElement.objects.filter(id=id, published=True)
        else:
            queryset = ExperienceElement.objects.filter(published=True)
        return queryset
        

class ExperienceElementAutoCompleteViewSet(GenericViewSet):
    permission_classes = (IsAuthenticated,)
    serializer_class = ExperienceAutocompleteSerializer
    queryset=ExperienceElement.objects.all()

    @swagger_auto_schema(
        query_serializer=ExperienceAutocompleteSerializer,
        responses={200: ExperienceAutocompleteResponseSerializer()},
    )
    
    def list(self, *args, **kwargs):
        serializer = self.get_serializer(data=self.request.GET)
        serializer.is_valid(raise_exception=True)
        query = serializer.data["query"]
        location = serializer.data.get('location', "")
        if query is None:
            return Response({"error": "Query parameter is missing."}, status=400)
        result = GooglePlaceClient().autocomplete(query, location)
        place_ids = [x['place_id'] for x in result['predictions']]
        element_qs = self.queryset.filter(reference__in=place_ids)
        element_by_place_id = {n.reference: n for n in element_qs}

        # prefetch media items
        media_by_element_id = get_prediction_media_element([{'id': n.id} for n in element_qs])

        response_data = []
        for prediction in result['predictions']:
            data = {
                'description': prediction['description'],
                'place_id': prediction['place_id'],
                'structured_formatting': prediction['structured_formatting'],
                'element_id': None,
                'media': None,
                'metadata' : {}
            }
            element = element_by_place_id.get(prediction['place_id'])
            if element:
                data.update(
                    {
                        'description': element.name,
                        'element_id': str(element.id),
                        'media': media_by_element_id.get(element.id).get('media_source'),
                        'structured_formatting': prediction['structured_formatting'],
                        'metadata': element.metadata
                    }
                )

            response_data.append(data)
        return Response(data=response_data)