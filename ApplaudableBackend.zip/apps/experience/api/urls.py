from django.urls import path
from rest_framework.routers import DefaultRouter

from apps.experience.api.views import ExperienceViewSet, ExperienceElementListViewSet, ExperienceElementCreateViewSet, ExperienceElementAutoCompleteViewSet, ExperienceElementDetailViewSet

app_name = "experience"

router = DefaultRouter()
router.register(r"", ExperienceViewSet, "experience")

urlpatterns = [
    path("<str:id>/elements/", ExperienceElementListViewSet.as_view(), name="element-list"),
    path("element/", ExperienceElementCreateViewSet.as_view({'post': 'create'}), name="element-create"),
    path("element/<str:id>/", ExperienceElementDetailViewSet.as_view({'get': 'retrieve'}), name="element-detail"),
    path("autocomplete/", ExperienceElementAutoCompleteViewSet.as_view({'get': 'list'}), name="element-autocomplete")

] +router.urls
