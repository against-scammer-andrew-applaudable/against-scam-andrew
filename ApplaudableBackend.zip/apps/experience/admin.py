from django.contrib import admin
from apps.experience.models import Experience, ExperienceElement
# Register your models here.    
class ExperienceAdmin(admin.ModelAdmin):
    list_filter=['name', 'data_type']
    list_display = ('name', 'order', 'data_type', 'icon_slug', 'usage', 'published')
    
class ExperienceElementAdmin(admin.ModelAdmin):
    list_filter=['experience', 'user', 'name', 'reference']
    list_display = ('experience', 'user', 'name', 'category', 'sub_category', 'published', 'is_validated', 'reference', 'metadata', "private_metadata")

admin.site.register(Experience, ExperienceAdmin)
admin.site.register(ExperienceElement, ExperienceElementAdmin)
