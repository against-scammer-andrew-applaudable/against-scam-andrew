
from celery import shared_task

from services.google.place import GooglePlaceClient
from apps.experience.constant import ExperienceDataType
from apps.experience.models import ExperienceElement

from apps.nupp.utils import (
    download_image_url, download_photo_reference
)
from .utils import (
    create_post_element_media
)
from apps.nupp.metadata.somewhere import (
    handle_google_place_result
)

# @shared_task
def task_process_post_element_metadata(element_id: str):
    """
    Grab element metadata, and process images and descriptions
    """
    print("start process media")
    element = ExperienceElement.objects.get(id=element_id)

    # TODO read private metadata and fetch media, and text description for this post_element.

    image = element.get_value_from_private_metadata('image', None)
    search = element.get_value_from_private_metadata('search', {})

    fallback_photo_reference = None
    if element.experience.data_type == ExperienceDataType.LOCATION:
        photos = element.get_value_from_private_metadata('photos', [])
        if photos:
            fallback_photo_reference = photos[0]

    if not image:
        image = search.get('image', None)

    if not image:
        image = element.get_value_from_private_metadata('cse_image', None)

    # image download
    element_media = None
    has_media = bool(element.media.all())
    if image and not has_media:
        img = download_image_url(image)
        if img:
            element_media = create_post_element_media(element, img)


    if not element_media and fallback_photo_reference and not has_media:
        img = download_photo_reference(fallback_photo_reference)
        if img:
            element_media = create_post_element_media(element, img)

    element.save()
    
    
    
# @shared_task
def task_find_element_metadata(element_id: str):

    """
    Find nupp metadata using specific API's.
    """
    element = ExperienceElement.objects.get(id=element_id)

    if element.experience.data_type == ExperienceDataType.LOCATION:
        if element.reference:
            result = GooglePlaceClient().details(element.reference)
            private_metadata = handle_google_place_result(result['result'])
            element.store_value_in_private_metadata(private_metadata)
            metadata = {
                'name': private_metadata.get('name', None),
                'formatted_title': private_metadata.get('formatted_address', None),
                'geometry': private_metadata.get('geometry', {}),
                'url': private_metadata.get('url', None),
                'place_id': private_metadata.get('place_id', None),
            }
            element.store_value_in_metadata(metadata)
            element.published = True
        else:
            result = GooglePlaceClient().text_search(element.category)
            private_metadata = handle_google_place_result(result['results'][0]) if result['results'] else {}
            metadata = {
                'name': private_metadata.get('name', None),
                'formatted_title': private_metadata.get('formatted_address', None),
                'geometry': private_metadata.get('geometry', {}),
                'url': private_metadata.get('url', None),
                'place_id': private_metadata.get('place_id', None),
            }
            element.store_value_in_metadata(metadata)
            element.store_value_in_private_metadata(private_metadata)

    # save element changes
    element.save()

    # handle element texts
    task_process_post_element_metadata(element_id)