from django.utils.translation import gettext_lazy as _


class ExperienceDataType:
    USER = "user"
    LOCATION = "location"
    DATE = "date"
    FOOD = "food"
    OTHER = "other"
    PERSON = "person"
    FREEFORM = "freeform"

    @classmethod
    def choices(cls):
        return (
            (cls.USER, _("user")),
            (cls.LOCATION, _("location")),
            (cls.DATE, _("date")),
            (cls.FOOD, _("food")),
            (cls.OTHER, _("other")),
            (cls.PERSON, _("person")),
            (cls.FREEFORM, _("freeform")),
        )



