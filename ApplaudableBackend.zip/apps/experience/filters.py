from .models import ExperienceElement
from django_filters import rest_framework as filters


class ExperienceElementFilter(filters.FilterSet):
    name = filters.CharFilter(method='q_filter')
    class Meta:
        model = ExperienceElement
        fields = ("name", "user", "published")
    

    def q_filter(self, queryset, name, value):
        if value == '':
            return queryset
        query = ExperienceElement.objects.filter(name__contains=value)

        return query
