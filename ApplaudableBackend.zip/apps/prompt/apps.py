from django.apps import AppConfig


class PromptConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.prompt'
    verbose_name = "Prompt"
