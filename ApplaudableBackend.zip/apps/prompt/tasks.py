
from celery import shared_task
from django.contrib.auth import get_user_model

User = get_user_model()

@shared_task
def task_send_prompt_notification(prompt_id: str, admin_user_id: str):
    from apps.prompt.models import Prompt
    from apps.posts.models import Post
    from apps.posts.constants import PostType, ResourceType, Visibility
    from apps.prompt.constants import PromptActionType
    
    """
    Send prompt notification using specific API's.
    """

    prompt = Prompt.objects.get(id=prompt_id)    

    users = prompt.users.all()
    print('admin user', admin_user_id)
    # Need to create a post
    if prompt.action_type == PromptActionType.GLIMPSE_QUESTION:
        glimpse_question_data = {
            "owner_id": admin_user_id,
            'type': PostType.GLIMPSE_QUESTION,
            'resource_type': ResourceType.TEXT,
            'title': prompt.title,
            'text': prompt.content,
            "visibility": Visibility.PUBLIC
        }
        post = Post.objects.create(**glimpse_question_data)
        prompt.metadata = {
            "glimpse_id": str(post.id)
        }
        prompt.save()
    # Send the notification to special users
    if users and len(users):
        prompt.published = True
        prompt.save()
        prompt.notify(users=users)
    else:
        user_list = []
        all_users = User.active_objects.all()    
        for user in all_users:
            if filter_users_for_prompt(prompt=prompt, user=user):
                user_list.append(user)
        if user_list and len(user_list):
            prompt.published = True
            prompt.save()
            prompt.notify(users=user_list)
    
def filter_users_for_prompt(prompt, user):
    from apps.users.models import Profile
    profile = Profile.objects.filter(user_id=user.id,).first()
    if profile:
        age_condition = True
        if prompt.age_from and prompt.age_to:
            age_condition = prompt.age_from <= profile.age <= prompt.age_to
        elif prompt.age_from:
            age_condition = profile.age >= prompt.age_from
        elif prompt.age_to:
            age_condition = profile.age <=prompt.age_to
        country_condition = True
        if prompt.country:
            country_condition = False
            user_country = profile.location_metadata.get('country', None)
            if user_country:
                country_condition = user_country.lower() == prompt.country.name.lower()
        return country_condition & age_condition
    else:
        return False
    

