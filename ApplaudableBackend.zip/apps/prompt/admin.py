from django.contrib import admin, messages
from django.utils.translation import ngettext
from apps.prompt.models import Prompt, PromptInteraction
from import_export.fields import Field
from django.contrib.auth import get_user_model
from import_export.widgets import ManyToManyWidget
from apps.core.import_export.resources import ModelResource
from .tasks import task_send_prompt_notification

User = get_user_model()

@admin.action(description='Send notification for selected prompt(s)')
def action_send_prompt_notification(modeladmin, request, queryset):
    processing = 0
    admin_user_id = str(request.user.id)
    print("request", admin_user_id)
    
    for obj in queryset:
        task_send_prompt_notification.delay(str(obj.id), admin_user_id)
        processing += 1

    modeladmin.message_user(
        request,
        ngettext(
            'sending notification for %d prompt.',
            'looking for prompt for %d prompt(s).',
            processing,
        )
        % processing,
        messages.SUCCESS,
    )

class PromptResource(ModelResource):
    users = Field(column_name='users', attribute='users', widget=ManyToManyWidget(User, field='label'))

    class Meta:
        model = Prompt
        skip_unchanged = True
        report_skipped = False
        fields = ('id', 'title', 'content', 'action_type', 'published', 'users', 'age_from', 'age_to', 'metadata')

# Register your models here.
class PromptAdmin(admin.ModelAdmin):
    list_filter=['action_type', 'published']
    list_display = ('id', 'title', 'content', 'action_type', 'published', 'created_at', 'updated_at', 'age_from', 'age_to', 'country', 'metadata')
    search_fields = (
        'id',
        'title',
        'content',
    )
    filter_horizontal = ('users',)

    fieldsets = (
        (
            None,
            {
                "fields": (
                    'title',
                    'content',
                    'action_type',
                    'age_from',
                    'age_to',
                    'country',
                    'users',
                ),
            },
        ),
    )
    actions = [
        action_send_prompt_notification,
    ]
    resource_class = PromptResource
    

admin.site.register(Prompt, PromptAdmin)

class PromptInteractionAdmin(admin.ModelAdmin):
    list_filter=['user', 'prompt']
    list_display = ('id', 'user', 'prompt', 'created_at', 'updated_at')
    
    def has_add_permission(self, request, obj=None):
        return False
            
admin.site.register(PromptInteraction, PromptInteractionAdmin)
