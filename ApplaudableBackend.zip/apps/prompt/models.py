from django.contrib.auth import get_user_model
from django.db import models
from .constants import PromptActionType
from django.utils.translation import gettext_lazy as _
from apps.core.models import AbstractCreatedUpdatedDateMixin, AbstractUniqueHashIDMixin
from django_countries.fields import CountryField
from .notify import prompt_notify


User = get_user_model()


class Prompt(AbstractUniqueHashIDMixin, AbstractCreatedUpdatedDateMixin):
    title = models.CharField(max_length=255, blank=False, null=True, default="Question of the day?")
    content = models.TextField(null=False)
    action_type = models.CharField(max_length=60, blank=False, choices=PromptActionType.choices(), default=PromptActionType.DEFAULT)
    country = CountryField(null=True, blank=True)
    published = models.BooleanField(default=False)
    users = models.ManyToManyField(User, related_name="prompts", blank=True)
    age_from = models.PositiveIntegerField(null=True, blank=True)
    age_to = models.PositiveIntegerField(null=True, blank=True)
    metadata = models.JSONField(null=True, blank=True)
    
    class Meta:
        db_table = "prompt"

    def __str__(self):
        return f"{self.id} - {self.title}"
    
    def notify(self, users):
        prompt_notify(self, users=users)
    
    
class PromptInteraction(AbstractUniqueHashIDMixin, AbstractCreatedUpdatedDateMixin):
    prompt = models.ForeignKey(Prompt, on_delete=models.CASCADE, null=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    class Meta:
        db_table = "prompt_interaction"

    def __str__(self):
        return f"{self.id}"