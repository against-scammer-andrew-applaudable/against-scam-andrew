from .notifications import PromptAppNotification, PromptPushNotification

def prompt_notify(prompt, users):
    from apps.notifications.utils import create_and_send_notification
    glimpse_id = None
    if prompt.metadata and prompt.metadata["glimpse_id"]:
        glimpse_id = prompt.metadata["glimpse_id"]
    for user in users:
        delivery_definitions = [PromptAppNotification, PromptPushNotification]
        for delivery_definition in delivery_definitions:
            # handle notification
            create_and_send_notification(
                delivery_definition,
                actors=[],
                scope=prompt,
                target=user,
                metadata={
                    "type": prompt.action_type,
                    "prompt": str(prompt.id),
                    "glimpse_id": glimpse_id
                },
                allow_duplicated=True
            )