from django.utils.translation import gettext_lazy as _

# Next time need to update the name “people post” and “experience post”
class PromptActionType:
    DEFAULT = 'default'
    GLIMPSE = "glimpse"
    GLIMPSE_QUESTION = 'glimpse_question'

    @classmethod
    def choices(cls):
        return (
            (cls.DEFAULT, _("Default Prompt")),
            (cls.GLIMPSE, _("Glimpse creation")),
            (cls.GLIMPSE_QUESTION, _("Glimpse question")),
        )
