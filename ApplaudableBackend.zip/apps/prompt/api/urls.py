from django.urls import path
from rest_framework.routers import DefaultRouter

from apps.prompt.api.views import PromptInteractionCreateViewSet

app_name = "prompt"

router = DefaultRouter()
router.register(r"", PromptInteractionCreateViewSet, "prompt")

urlpatterns = [
] +router.urls
