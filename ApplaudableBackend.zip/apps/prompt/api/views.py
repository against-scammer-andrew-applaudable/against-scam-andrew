from django.contrib.auth import get_user_model
from rest_framework.permissions import IsAuthenticated
from rest_framework.viewsets import ModelViewSet
from drf_yasg.utils import swagger_auto_schema
from rest_framework import status
from rest_framework.request import Request
from rest_framework.response import Response
from apps.prompt.models import Prompt, PromptInteraction
from apps.prompt.api.serializers import PromptInteractionSerializer, PromptInteractionCreateSerializer


User = get_user_model()
    
class PromptInteractionCreateViewSet(ModelViewSet):
    http_method_names = ['post']
    permission_classes = (IsAuthenticated,)
    queryset = PromptInteraction.objects.all()
    serializer_class = PromptInteractionSerializer
    
    @swagger_auto_schema(
        request_body=PromptInteractionCreateSerializer,
        responses={status.HTTP_201_CREATED: PromptInteractionSerializer()},
    )
    def create(self, request: Request):
        serializer = PromptInteractionCreateSerializer(data=request.data, context=self.get_serializer_context())
        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response(status=status.HTTP_201_CREATED, data=serializer.data)
    
    