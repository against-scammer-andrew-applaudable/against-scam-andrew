"""
Experience API serializers
"""

from django.contrib.auth import get_user_model
from apps.prompt.models import Prompt, PromptInteraction
from rest_framework import serializers
from hashid_field.rest import HashidSerializerCharField

User = get_user_model()


class PromptSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    class Meta:
        model = Prompt
        fields = ("id", "content", "action_type", "published")

class PromptInteractionSerializer(serializers.ModelSerializer):
    id = HashidSerializerCharField(read_only=True)
    class Meta:
        model = PromptInteraction
        fields = ("id", "user", "prompt", "created_at", "updated_at")
        
class PromptInteractionCreateSerializer(serializers.ModelSerializer):
    id = serializers.CharField(read_only=True)
    user = serializers.HiddenField(default=serializers.CurrentUserDefault())
    prompt_id = serializers.CharField(allow_null=False, required=True)
    class Meta:
        model = PromptInteraction
        fields = ("id", "user", "prompt_id")

    def validate(self, attrs, options=[]):
        attrs = super().validate(attrs)
        prompt_id = attrs.get('prompt_id', None)
        if prompt_id and not Prompt.objects.filter(id=prompt_id).exists():
            raise serializers.ValidationError({"prompt": "Prompt doesn't exist."})

        return attrs

    def save(self, **kwargs):
        prompt_id = self.validated_data["prompt_id"]
        user = self.validated_data["user"]
        prompt_interaction, created = PromptInteraction.objects.update_or_create(
                prompt_id=prompt_id,
                user=user,
            )
        
        return prompt_interaction