"""
Post's app notifications.
"""

from django import forms

from apps.notifications import AppNotificationDefinition, PushNotificationDefinition, register
    
    
@register("Prompt")
class PromptPushNotification(PushNotificationDefinition):
    TYPE = 'prompt'

    title = forms.CharField(initial="{{ scope.title }}")
    text = forms.CharField(initial="{{ scope.content }}")


@register("Prompt")
class PromptAppNotification(AppNotificationDefinition):
    TYPE = 'prompt'

    title = forms.CharField(initial="{{ scope.title }}")
    text = forms.CharField(initial="{{ scope.content }}")
