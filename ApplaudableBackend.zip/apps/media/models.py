from cloudinary.models import CloudinaryField
from django.contrib.gis.db import models

from apps.core.models import AbstractCreatedUpdatedDateMixin, AbstractUniqueBigHashIDMixin

from .constants import MediaType
from .tasks import bulk_cloudinary_media_invalidation


class AbstractMedia(AbstractUniqueBigHashIDMixin, AbstractCreatedUpdatedDateMixin):
    image_source = CloudinaryField(resource_type="image", blank=True, null=True)
    video_source = CloudinaryField(resource_type="video", blank=True, null=True)
    type = models.CharField(max_length=45, choices=MediaType.choices())
    text = models.TextField(blank=True)
    metadata = models.JSONField(blank=True, null=True)


    class Meta:
        abstract = True
        verbose_name = "Media"
        verbose_name_plural = "Media"
        indexes = [
            *AbstractUniqueBigHashIDMixin.Meta.indexes,
        ]

    def __str__(self):
        return f"{self.id} - {self.type}"

    @property
    def media_source(self):
        if self.type == MediaType.IMAGE:
            return self.image_source.url
        elif self.type == MediaType.VIDEO:
            return self.video_source.url
        try:
            return self.cloudinary_resource.build_url(
                transformation=[
                    {
                        'overlay': {'font_family': "Source%20Sans%20Pro", 'font_size': 28, 'font_weight': "700", 'text': self.text},
                        'width': 245,
                        'crop': "fit",
                        'color': "white",
                    }
                ]
            )
        except:
            return None

    @property
    def cloudinary_public_info(self):
        if self.image_source is None:
            return None
        if self.type == MediaType.IMAGE:
            return {"type": "image", "public_id": self.image_source.public_id}
        elif self.type == MediaType.VIDEO:
            return {"type": "video", "public_id": self.video_source.public_id}
        return None

    @property
    def cloudinary_resource(self):
        return self.image_source or self.video_source

    @property
    def admin_thumbnail_url(self):
        return self.image_source.build_url(transformation=[{'width': 120, 'crop': "fit"}])

    def delete(self, using=None, keep_parents=False):
        bulk_cloudinary_media_invalidation.delay([self.cloudinary_public_info])
        return super().delete(using, keep_parents)
