from django.contrib import admin
from django.utils.safestring import mark_safe

from apps.media.tasks import bulk_cloudinary_media_invalidation


class MediaAdminBase:
    readonly_fields = ('admin_thumbnail',)

    def admin_thumbnail(self, obj):
        if obj and obj.admin_thumbnail_url:
            return mark_safe(f'<img src="{obj.admin_thumbnail_url}" alt="{obj.id}" />')
        return ''

    admin_thumbnail.short_description = "Thumbnail"


class MediaAdmin(MediaAdminBase, admin.ModelAdmin):
    def delete_queryset(self, request, queryset):
        media_info = []
        for media in queryset:
            media_info.append(media.cloudinary_public_info)
        bulk_cloudinary_media_invalidation.delay(media_info)
        return super().delete_queryset(request, queryset)


class MediaInline(MediaAdminBase, admin.TabularInline):
    extra = 0
    fields = (
        'admin_thumbnail',
        'type',
        'image_source',
        'text',
    )


class MediaReadonlyInline(MediaInline):
    max_num = 0

    def has_add_permission(self, *args, **kwargs):
        return False

    def has_change_permission(self, *args, **kwargs):
        return False
