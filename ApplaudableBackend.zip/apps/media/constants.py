from django.utils.translation import gettext_lazy as _


class MediaType:
    IMAGE = "image"
    VIDEO = "video"
    TEXT = "text"

    @classmethod
    def choices(cls):
        return (
            (cls.IMAGE, _("Image")),
            (cls.VIDEO, _("Video")),
            (cls.TEXT, _("Text")),
        )

    @classmethod
    def valid_upload_options(cls):
        return (cls.IMAGE, cls.VIDEO, cls.TEXT)
