from celery import shared_task

from .utils import cloudinary_media_invalidation


@shared_task
def bulk_cloudinary_media_invalidation(public_info_list: list):
    for public_info in public_info_list:
        cloudinary_media_invalidation(public_info)
