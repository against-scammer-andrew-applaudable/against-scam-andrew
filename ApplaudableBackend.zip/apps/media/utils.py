from cloudinary import uploader
from .constants import MediaType


def cloudinary_media_invalidation(media_info: dict):
    public_id = media_info["public_id"]
    if media_info["type"] == "image":
        uploader.destroy(public_id, invalidate=True)
    elif media_info["type"] == "video":
        uploader.destroy(public_id, invalidate=True, resource_type="video")


def cloudinary_resource_to_dict(cloudinary_resource, metadata=None) -> dict:
    resp = {'cloudinary_resource': None, 'media_source': None, 'type': None}
    if cloudinary_resource:
        resp['cloudinary_resource'] = cloudinary_resource
        resp['media_source'] = cloudinary_resource.url
        resp['type'] = MediaType.IMAGE
    if metadata:
        resp['metadata'] = metadata
    return resp
