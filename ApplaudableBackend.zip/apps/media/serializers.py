from rest_framework import serializers

from apps.core.serializers import BJSONMediaField, MediaField


class MediaSerializer(serializers.Serializer):
    media_detail = MediaField(source="cloudinary_resource")
    url = serializers.CharField(source="media_source")
    type = serializers.CharField()
    height = serializers.SerializerMethodField()
    width = serializers.SerializerMethodField()
    duration = serializers.SerializerMethodField()
    
    @staticmethod
    def get_height(obj):
        try:
            return obj.metadata.get("height", None)
        except AttributeError:
            if isinstance(obj, dict):
                try:
                    return obj['metadata'].get("height", None)
                except KeyError:
                    pass
            return

    @staticmethod
    def get_width(obj):
        try:
            return obj.metadata.get("width", None)
        except AttributeError:
            if isinstance(obj, dict):
                try:
                    return obj['metadata'].get("width", None)
                except KeyError:
                    pass
            return
        
    @staticmethod
    def get_duration(obj):
        try:
            return obj.metadata.get("duration", None)
        except AttributeError:
            if isinstance(obj, dict):
                try:
                    return obj['metadata'].get("duration", None)
                except KeyError:
                    pass
            return


class BJSONMediaSerializer(serializers.Serializer):
    media_detail = BJSONMediaField(source="metadata")
    url = serializers.CharField(source="metadata.url", default=None)
    type = serializers.CharField()
    height = serializers.IntegerField(source='metadata.height', default=None)
    width = serializers.IntegerField(source='metadata.width', default=None)
