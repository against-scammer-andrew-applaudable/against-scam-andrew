"""
API V1 Base URLs.
"""

from django.conf.urls import include
from django.urls import path
from fcm_django.api.rest_framework import FCMDeviceAuthorizedViewSet
from rest_framework import routers

from apps.users.api.views import LoginViewSet, SignUpViewSet

app_name = "apps.api.v1"

router = routers.SimpleRouter()
router.register(r"devices", FCMDeviceAuthorizedViewSet, "fcm-devices")
router.register(r"login", LoginViewSet, "login")
router.register(r"signup", SignUpViewSet, "signup")

urlpatterns = [
    path("auth/", include("apps.user_auth.api.urls", "auth")),
    path("collections/", include("apps.collection.api.urls", "collections")),
    path("content/", include("apps.content.api.urls", "content")),
    path("mention/", include("apps.mention.api.urls", "mention")),
    path("notifications/", include("apps.notifications.api.urls", "notifications")),
    path("nupp/", include("apps.nupp.api.urls", "nupp")),
    path("posts/", include("apps.posts.api.urls", "posts")),
    path("user/", include("apps.users.api.urls", "user")),
    path("influences/", include("apps.influence.api.urls", "influences")),
    path("story/", include("apps.life_story.api.urls", "life_story")),
    path("experience/", include("apps.experience.api.urls", "experience")),
    path("autocomplete/", include("apps.autocomplete.api.urls", "autocomplete")),
    path("location/", include("apps.location.api.urls", "location")),
    path("version/", include("apps.version.api.urls", "version")),
    path("prompt/", include("apps.prompt.api.urls", "prompt")),
    path("circles/", include("apps.circle.api.urls", "circle")),
    path("highlights/", include("apps.highlights.api.urls", "highlights")),
    path("", include("apps.onboarding.api.urls", "onboarding")),
] + router.urls
