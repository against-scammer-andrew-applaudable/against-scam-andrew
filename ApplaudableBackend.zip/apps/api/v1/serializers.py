"""
API V1 base serializers.
"""

from phonenumber_field.serializerfields import PhoneNumberField
from rest_framework import serializers


class SuccessIndicatorSerializer(serializers.Serializer):
    """
    Serializer to return a success value.
    """

    success = serializers.BooleanField()


class PhoneNumberSerializer(serializers.Serializer):
    phone_number = PhoneNumberField()

    def to_representation(self, instance: dict) -> dict:
        """
        Format phone number to e164 format.

        :param instance: serialized data

        :return: formatted serialized data
        """

        instance["phone_number"] = instance["phone_number"].as_e164
        return instance


class EmailSerializer(serializers.Serializer):
    email = serializers.EmailField()
