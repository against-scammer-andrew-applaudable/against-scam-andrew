"""
API Pagination settings.
"""

from collections import OrderedDict
from typing import Union

from rest_framework.pagination import LimitOffsetPagination as BaseLimitOffsetPagination
from rest_framework.response import Response


class LimitOffsetPagination(BaseLimitOffsetPagination):
    """
    Paginate settings for API responses.
    """

    def get_paginated_response(
        self, data: Union[dict, list], extra_context: tuple = ()
    ) -> Response:
        """
        Return a paginated response.

        :param data: data from API view
        :param extra_context: extra data to be displayed

        :return: paginated response

        [Override BaseLimitOffsetPagination.get_paginated_response]
        """

        return Response(
            OrderedDict(
                [
                    ("count", self.get_count(data)),
                    ("next", self.get_next_link()),
                    ("previous", self.get_previous_link()),
                    ("results", data),
                    *extra_context,
                ]
            )
        )
