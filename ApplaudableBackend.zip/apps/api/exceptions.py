"""
Custom API Exceptions
"""

from django.utils.translation import gettext_lazy as _
from rest_framework import status
from rest_framework.exceptions import APIException


class InvalidPincode(APIException):
    """
    Exception for invalid SMS pincode submission.
    """

    status_code = status.HTTP_401_UNAUTHORIZED
    default_detail = _("Invalid Pincode.")
    default_code = "invalid-pincode"
    
    
class InvalidCode(APIException):
    """
    Exception for validation SMS pincode submission.
    """

    status_code = status.HTTP_404_NOT_FOUND
    default_detail = _("Invalid code.")
    default_code = "invalid-code"


class InvalidCredentials(APIException):
    """
    Exception for invalid login credentials.
    """

    status_code = status.HTTP_401_UNAUTHORIZED
    default_detail = _("Invalid Credentials.")
    default_code = "invalid-credentials"


class UnprocessableEntityError(APIException):
    """
    Exception for invalid user.
    """

    status_code = status.HTTP_422_UNPROCESSABLE_ENTITY
    default_detail = _("Unprocessable Entity.")
    default_code = "unprocessable-entity"
