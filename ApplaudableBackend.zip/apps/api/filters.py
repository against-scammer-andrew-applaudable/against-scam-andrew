from django_filters import rest_framework as filters


class NameTrigramSimilarityFilter(filters.FilterSet):
    """
    Returns results with trigram similarity.
    """

    name = filters.CharFilter(method="name__trigram_similar", help_text="Filter by word similarity (3 chars minimum)")

    def name__trigram_similar(self, queryset, value, *args, **kwargs):
        try:
            if args:
                name = args[0]
                return queryset.filter(name__trigram_similar=name)
        except (IndexError, TypeError, ValueError):
            pass
        return queryset


class UsernameTrigramSimilarityFilter(filters.FilterSet):
    """
    Returns results with trigram similarity.
    """

    username = filters.CharFilter(method="username__trigram_similar", help_text="Filter by word similarity (3 chars minimum)")

    def username__trigram_similar(self, queryset, value, *args, **kwargs):
        try:
            if args:
                username = args[0]
                return queryset.filter(username__trigram_similar=username)
        except (IndexError, TypeError, ValueError):
            pass
        return queryset


class DynamicLookupFilter(filters.FilterSet):
    """
    Filter queryset by selected lookup.
    """

    user_field_name = "user"
    active_filters = tuple()

    type = filters.CharFilter(method="filter_by_selected_lookup", help_text="Filter by selected lookup (LOOKUPS)")

    @property
    def lookups(self):
        return {}

    def filter_by_selected_lookup(self, queryset, value, *args, **kwargs):
        try:
            filter_type = args[0]
            if filter_type and filter_type in self.active_filters:
                filter = {}
                filter = self.lookups.get(filter_type, {})
                return queryset.filter(**filter).distinct()
        except (IndexError, TypeError, ValueError):
            pass
        return queryset
