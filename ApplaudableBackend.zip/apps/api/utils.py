"""
API Utils.
"""

import logging
from typing import Optional

from rest_framework.exceptions import APIException
from rest_framework.response import Response
from rest_framework.views import exception_handler

from .error_codes import ERROR_CODES


def get_exception_error_code(exc: APIException, status_code: str) -> str:
    """
    Get exception code and return it formatted.

    :param exc: APIException from API request
    :param status_code: API response status code

    :return: formatted status code
    """

    exc_code = getattr(exc, "error_code", "000")
    error_codes = ERROR_CODES.get(type(exc))
    if error_codes:
        error_code = f"{status_code}{error_codes[0]}"
        if error_code != error_codes[1]:
            logging.warning(
                f"EXCEPTION ERROR CODE MISMATCH [{type(exc)} \
                    error_code: {error_code}, expected {error_codes[1]}]"
            )
        return error_code
    return f"{status_code}{exc_code}"


def exception_response(exc: APIException, obj: dict, status_code: str) -> None:
    """
    Modify response data object values.

    :param exc: APIException from API request
    :param obj: API response data
    :param status_code: API response status code

    :return: None
    """

    obj["error_code"] = int(get_exception_error_code(exc, status_code))
    obj["success"] = False
    if hasattr(exc, "default_code"):
        obj["code"] = exc.default_code


def api_exception_handler(exc: APIException, context: dict) -> Optional[Response]:
    """
    Call REST framework's default exception handler to get the standard error response.
    Then add the HTTP status code to the response.
    If multiples error are raised, classify each of it.

    :param exc: APIException from API request
    :param context: API response data

    :return: modified response if valid API response, else None
    """

    response = exception_handler(exc, context)
    if response is not None:
        try:
            exception_response(exc, response.data, response.status_code)
        except TypeError:
            for obj in response.data:
                exception_response(exc, obj, response.status_code)
    return response
