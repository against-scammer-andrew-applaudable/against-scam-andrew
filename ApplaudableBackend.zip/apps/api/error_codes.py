"""
API Error codes mapper.
"""

from rest_framework import exceptions
from rest_framework_simplejwt import exceptions as jwt_exceptions

ERROR_CODES = {
    exceptions.ValidationError: ("001", "400001"),
    exceptions.NotAuthenticated: ("001", "401001"),
    jwt_exceptions.InvalidToken: ("002", "401002"),
}
