"""
API Base URLs.
"""

from django.conf.urls import include
from django.urls import path

from apps.api.views import health_check

# API V1 ROOTS          
urlpatterns = [
    # API V1 URLS
    path("v1/", include("apps.api.v1.urls", namespace="v1")),
    # API COMMONS
    path("status/", health_check, name="health-check"),
]
