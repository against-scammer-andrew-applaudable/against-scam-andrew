"""
API Tests.
"""

from django.test import TestCase
from rest_framework.test import APITestCase

from apps.api.v1.serializers import SuccessIndicatorSerializer


class SuccessIndicatorSerializerTestCase(TestCase):
    """
    Test the success indicator serializer.
    """

    def test_success_indicator_serializer(self):
        """
        Test the success indicator serializer.
        """

        serializer = SuccessIndicatorSerializer(data={"success": True})
        serializer.is_valid(raise_exception=True)
        self.assertEqual({"success": True}, serializer.data)


class APIHealthCheckTestCase(APITestCase):
    """
    Test the API health check.
    """

    def test_api_health_check(self):
        """
        Test the API health check.
        """

        response = self.client.get("/api/status/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data, "ok")
