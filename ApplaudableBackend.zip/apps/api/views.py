"""
API base views.
"""

from rest_framework import permissions, status
from rest_framework.decorators import api_view, permission_classes, schema
from rest_framework.request import Request
from rest_framework.response import Response


@api_view(["GET"])
@schema(None)
@permission_classes((permissions.AllowAny,))
def health_check(request: Request) -> Response:
    """
    API Health check view.

    :param request: API request

    :return: API response
    """

    return Response("ok", status=status.HTTP_200_OK)
