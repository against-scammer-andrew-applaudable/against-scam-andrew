import 'dart:async';

import 'package:applaudable/core/constants/constant_values.dart';
import 'package:country_codes/country_codes.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:logger/logger.dart';
import 'package:path_provider/path_provider.dart';

import 'app_widget.dart';
import 'core/api/api_env.dart';
import 'core/api/remote_api_service.dart';
import 'core/bloc/dng_base_bloc.dart';
import 'core/controllers/dng_links_controller.dart';
import 'features/auth/data/datasources/local_source.dart';
import 'features/auth/presentation/controllers/controller.dart';
import 'features/create_post/presentation/pages/create_post_media_selector.dart';
import 'features/notifications/presentation/controllers/notification_controller.dart';

/// Blocs Map State Management
mixin AppModuleBlocsState {
  /// Storage map for storing [DNGBaseBloc] instances
  late final Map<String, DNGBaseBloc> blocs;

  void initBlocs() {
    blocs = <String, DNGBaseBloc>{};
  }

  /// Register a [DNGBaseBloc] instance
  /// using the instance hashcode as the [key]
  ///
  /// Mandatory Params
  ///  ** [key] instance hashcode as String
  ///  ** [bloc] as an DNGBaseBloc instance
  void registerBloc<Bloc extends DNGBaseBloc>(String key, Bloc bloc) =>
      blocs.putIfAbsent(key, () => bloc);

  /// Check if a [DNGBaseBloc] instance is already registered
  bool isRegistered(String key) => blocs.containsKey(key);

  /// Unregister a [DNGBaseBloc] instance
  ///
  /// Optionally call a [onRemove] callback
  /// that will send the removed instance
  void unregisterBloc(String key, {void Function(DNGBaseBloc b)? onRemove}) {
    if (!isRegistered(key)) {
      return;
    }

    if (onRemove != null) onRemove(blocs[key]!);
    blocs.remove(key);
  }

  /// Clears all the blocs map
  void clearBlocs() => blocs.clear();
}

class AppModule with AppModuleBlocsState {
  static final AppModule _mainModule = AppModule._();

  static AppModule get instance => _mainModule;

  static AppModule get I => _mainModule;

  /// App Features
  /// Enable the Profile Story and Add to Profile Collection Story
  bool enableProfileStory = false;

  /// Enable the SOMEONE flow on Post Create Flow
  bool enableSomeoneFlow = true;

  /// Enable the Influences measures that appears on the Post Feed
  bool enableInfluencesMeasures = false;

  /// Enable the Applauds Rank Level that appears on the Post Feed
  bool enableApplaudRankLevel = false;

  /// Enable the Post Highlights
  bool enablePostHighlights = false;

  /// Enable the Post Pinch Zoom
  bool enablePostPinchZoom = true;

  /// Enable the Google Places Search for Story Post Location
  bool enableStoryLocationGPSearch = true;

  /// Enable the Post Applauds List View
  bool enablePostApplaudsListView = true;

  /// Enable the Native Gallery View In Media Picker
  bool enableNativeMediaGallery = true;

  /// Enable the Native Gallery View In Media Picker
  bool enableNativeMediaCamera = true;

  /// Default Media Picker Option
  MediaOption defaultMediaPickerOption = MediaOption.camera;

  AppModule._() {
    navigatorKey = GlobalKey<NavigatorState>();
    scaffoldMessengerKey = GlobalKey<ScaffoldMessengerState>();
    routeObserver = RouteObserver<ModalRoute<void>>();

    logger = Logger();

    /// Main app Controller
    controller = Controller();

    /// Initialize blocs map state
    initBlocs();

    /// Init Analytics
    analytics = FirebaseAnalytics.instance;
    analyticsObserver = FirebaseAnalyticsObserver(
      analytics: analytics,
    );
  }

  late final Logger logger;
  late final GlobalKey<NavigatorState> navigatorKey;
  late final GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey;
  late final RouteObserver routeObserver;
  late final BaseController controller;

  late final FirebaseAnalytics analytics;
  late final FirebaseAnalyticsObserver analyticsObserver;

  late final ApiEnv api;

  Future<void> initModules() async {
    /// Get Flavor
    logger.i("environmentFlavor: ${ConstantValues.environment.name}");

    /// Load API Flavor
    api = ConstantValues.environment.apiEnv;

    /// Set API Flavor
    RemoteApiService.api
      ..locale = "en"
      ..setApi(api: api)
      ..clearSession();

    /// Set Socket API Flavor
    await Future.wait([
      SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]),

      if (!kIsWeb)
        getApplicationSupportDirectory().then((dir) => Hive.init(dir.path)),
      //PreferencesService.init(),

      CountryCodes.init()
    ]);

    /// Check for Session token
    var session = await AppLocalDataSource.instance.getSession();
    if (session != null) {
      RemoteApiService.api.token = session.token.access;
    }

    /// Setting the timezone for the user in the APIs header
    RemoteApiService.api.date = DateTime.now().toLocal();

    // /// Set `isDevMode` to true to see reports while in debug mode
    // /// This is only to be used for confirming that reports are being
    // /// submitted as expected. It is not intended to be used for everyday
    // /// development.
    // // FirebaseCrashlytics.instance.setCrashlyticsCollectionEnabled(kDebugMode);
    //
    // /// Pass all uncaught errors from the framework to Crashlytics.
    // // FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterFatalError;
    // FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterError;
    //
    // PlatformDispatcher.instance.onError = (error, stack) {
    //   FirebaseCrashlytics.instance.recordError(error, stack, fatal: false);
    //   return true;
    // };
    // Google fonts licence
    /*LicenseRegistry.addLicense(() async* {
    final license = await rootBundle.loadString('google_fonts/LICENSE.txt');
    yield LicenseEntryWithLineBreaks(['google_fonts'], license);
    });*/

    /// Initialize deeplinks controller
    DngLinksController.I;

    /// Initialize Push Notifications
    NotificationController.I.init();
  }

  void handleErrors(Object error, StackTrace stackTrace) {
    /// Register and sends error
    FirebaseCrashlytics.instance.recordError(error, stackTrace);

    /// for debug:
    if (ConstantValues.environment.isStaging) {
      logger.e('[Error] ${error.toString()}');
      logger.e('[Stacktrace] ${stackTrace.toString()}');
    }
  }

  void startApp() async => runApp(MyApp(controller: controller));
}
