import 'package:applaudable/core/utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/controllers/scroll_gesture_controller.dart';
import 'features/auth/presentation/controllers/controller.dart';
import 'features/onboarding/presentation/blocs/user_avatar_cubit/user_avatar_cubit.dart';
import 'injection_container.dart';
import 'platform_app.dart';

class MyApp extends StatelessWidget {
  const MyApp({Key? key, required this.controller}) : super(key: key);

  final BaseController controller;

  @override
  Widget build(BuildContext context) {
    AppUtils().screenWidth = AppUtils().screenSize(context).width;
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<BaseController>(create: (_) => controller),
        Provider<UserAvatarCubit>.value(value: servLocator<UserAvatarCubit>()),
        ChangeNotifierProvider<ScrollGestureController>.value(
          value: servLocator<ScrollGestureController>(),
        ),
      ],
      child: const PlatformApp(),
    );
  }
}
