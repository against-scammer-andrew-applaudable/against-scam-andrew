import 'package:flutter/material.dart';
import 'package:flutter_contacts/contact.dart';

import '../../../../core/extensions/contact_extensions.dart';
import '../../../../core/theme/dimensions.dart';
import 'contact_phone_view.dart';

class ContactPhonesOverviewList extends StatelessWidget {
  final Contact contact;

  const ContactPhonesOverviewList({super.key, required this.contact});

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      physics: const BouncingScrollPhysics(),
      itemCount: contact.phones.length,
      separatorBuilder: (_, __) => const SizedBox(
        height: AppDimensions.defaultSidePadding,
      ),
      itemBuilder: (ctx, index) {
        return ContactPhoneView(
          fullname: contact.fullname,
          phone: contact.phones[index],
        );
      },
    );
  }
}
