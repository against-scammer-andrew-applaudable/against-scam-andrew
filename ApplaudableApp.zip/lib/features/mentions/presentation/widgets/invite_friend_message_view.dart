import 'package:flutter/material.dart';

import '../../../../app_module.dart';
import '../../../../core/constants/constant_values.dart';
import '../../../../core/extensions/app_module_extensions.dart';
import '../../../../core/extensions/build_context_extensions.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/styles.dart';
import '../../../../core/widgets/optional_wrapper.dart';
import '../../../../generated/l10n.dart';
import '../../../auth/domain/entities/user.dart';
import '../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../../domain/entities/friend_invite.dart';
import '../pages/invite_user_page.dart';
import '../pages/select_invite_option_page.dart';

class InviteFriendMessageView extends StatelessWidget {
  final String userName;

  const InviteFriendMessageView({super.key, this.userName = ''});

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    final user = AppModule.I.controller.currentUser;

    return OptionalWrapper(
      showWrapper: (user?.invitationsCount ?? 0) > 0,
      wrapper: (child) => SingleChildScrollView(child: child),
      child: Center(
        child: AppSideMargins(
          marginValue: 25,
          child: Column(
            // mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 35),
              Text(
                translations.no_mentions_msg,
                style: AppStyles.text2(color: AppColors.darkGrey).copyWith(
                  fontSize: 18,
                  fontWeight: FontWeight.w400,
                ),
              ),
              const SizedBox(height: 15),
              Text(
                translations.invite_a_friend,
                style: AppStyles.text2(color: context.textColor).copyWith(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 15),
              OptionalWrapper(
                showWrapper: (user?.invitationsCount ?? 0) == 0,
                wrapper: (child) => Expanded(child: child),
                child: InviteUserOptionsView(
                  args: InviteUserPageArgs(name: userName),
                  openInviteByEmailFlow: (_) =>
                      _openInviteWithEmailFlow(context),
                  openUserContactsPage: (_) =>
                      _openUserContactsPageFlow(context),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openInviteWithEmailFlow(BuildContext context) async {
    final invite = await AppModule.I.navigateToNamed(
      InviteUserPage.routeName,
      arguments: InviteUserPageArgs(
        name: userName,
        inviteOption: InviteOption.inviteByEmail,
      ),
    );

    if (invite != null && invite is FriendInvite) {
      context.pop(
        HiveUser(
          id: invite.id,
          name: '@${invite.name}${ConstantValues.mentionSeparator}',
          username: '',
          mentionSource: 'invite',
        ),
      );
    }
  }

  void _openUserContactsPageFlow(BuildContext context) async {
    final invite = await AppModule.I.navigateToNamed(
      InviteUserPage.routeName,
      arguments: InviteUserPageArgs(name: userName),
    );

    if (invite != null && invite is FriendInvite) {
      context.pop(
        HiveUser(
          id: invite.id,
          name: '@${invite.name}${ConstantValues.mentionSeparator}',
          username: '',
          mentionSource: 'invite',
        ),
      );
    }
  }
}
