import 'dart:developer';

import 'package:country_picker/country_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_contacts/properties/phone.dart';
import 'package:flutter_sim_country_code/flutter_sim_country_code.dart';

import '../../../../app_module.dart';
import '../../../../core/bloc/widgets/base_stateless_page.dart';
import '../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../core/extensions/app_module_extensions.dart';
import '../../../../core/extensions/contact_extensions.dart';
import '../../../../core/extensions/string_extensions.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/styles.dart';
import '../../../../core/widgets/toast/app_toast.dart';
import '../../../../generated/l10n.dart';
import '../../../auth/presentation/widgets/buttons/action_button.dart';
import '../blocs/friend_invite_bloc/friend_invite_bloc.dart';

// ignore: must_be_immutable
class ContactPhoneView
    extends BaseStatelessPage<FriendInviteBloc, FriendInviteState> {
  final String fullname;
  final Phone phone;

  ContactPhoneView({super.key, required this.fullname, required this.phone});

  @override
  Widget build(BuildContext context) {
    registerBloc(context);

    final translations = S.of(context);

    return ColoredBox(
      color: AppColors.white,
      child: ListTile(
        title: Text(phone.label.name.capitalize()),
        subtitle: Text(
          phone.number,
          style: AppStyles.text2(
            color: AppColors.searchFieldHintColor,
          ).copyWith(fontSize: 14),
        ),
        trailing: DNGBlocBuilder<FriendInviteBloc, FriendInviteState>(
          bloc: bloc,
          builder: (context, state) {
            return AppActionButton.submit(
              text: translations.send,
              fitsFullWidth: false,
              width: 80,
              height: 35,
              padding: EdgeInsets.zero,
              actionTextSize: 16,
              actionTextWeight: FontWeight.w600,
              showLoading: state is FriendInviteLoadingState &&
                  state.phone == phone.abstractNumber,
              onPressed:
                  state is FriendInviteLoadingState ? null : _sendUserInvite,
            );
          },
        ),
      ),
    );
  }

  void _sendUserInvite() async {
    final phoneNumber = phone.abstractNumber;

    if (phoneNumber.trim().startsWith('+') ||
        phoneNumber.trim().startsWith('00')) {
      bloc.add(InviteUserEvent(name: fullname, phone: phoneNumber));
    } else {
      await _getSIMCountryCode();

      log(_countryCode.toString(), name: 'Country Code');

      if (_countryCode != null) {
        final phoneCode = Country.tryParse(_countryCode!)?.phoneCode ?? '';

        bloc.add(
          InviteUserEvent(name: fullname, phone: '+$phoneCode$phoneNumber'),
        );
      }
    }
  }

  String? _countryCode;

  _getSIMCountryCode() async {
    if (_countryCode != null) return _countryCode;

    _countryCode = await FlutterSimCountryCode.simCountryCode;
  }

  @override
  Stream<FriendInviteState>? get onStateListener => bloc.stream;

  @override
  void onStateResultListener(BuildContext context, FriendInviteState state) {
    if (state.phone != phone.abstractNumber) return;

    if (state is FriendInviteErrorState) {
      AppToast().build(context, state.message, mode: AppToastMode.error);
    } else if (state is UserInvitedState) {
      AppModule.I.pop(state.invite);
    }
  }
}
