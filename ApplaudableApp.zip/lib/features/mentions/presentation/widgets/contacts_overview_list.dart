import 'package:flutter/material.dart';
import 'package:flutter_contacts/contact.dart';
import 'package:provider/provider.dart';

import '../../../../app_module.dart';
import '../../../../core/extensions/app_module_extensions.dart';
import '../../../../core/extensions/build_context_extensions.dart';
import '../../../../core/extensions/contact_extensions.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/theme/styles.dart';
import '../../../../core/widgets/svg_icons.dart';
import '../../../../generated/l10n.dart';
import '../../domain/entities/contacts_response.dart';
import '../../domain/entities/friend_invite.dart';
import '../controllers/contacts_search_controller.dart';
import '../pages/contact_details_page.dart';

class ContactsOverviewList extends StatelessWidget {
  final List<CharacterContacts> charContacts;

  const ContactsOverviewList({super.key, required this.charContacts});

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return RawScrollbar(
      radius: const Radius.circular(20),
      thickness: 3,
      thumbColor: AppColors.lightGrey,
      child: Consumer<ContactsSearchController>(
        builder: (context, provider, child) {
          if (provider.searchedContacts.isEmpty) {
            return Center(child: Text(translations.no_contacts));
          }
          return ListView.separated(
            padding: const EdgeInsets.symmetric(
              vertical: 5,
            ),
            itemCount: provider.searchedContacts.length,
            separatorBuilder: (_, __) => const SizedBox(
              height: AppDimensions.defaultSideMargin,
            ),
            physics: const BouncingScrollPhysics(),
            itemBuilder: (ctx, index) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    provider.searchedContacts[index].character,
                    style: AppStyles.text2(
                      color: AppColors.darkGrey,
                    ).copyWith(
                      fontSize: 18,
                      height: 0.8,
                    ),
                  ),
                  const Divider(color: AppColors.lightGrey),
                  ListView.builder(
                    itemCount: provider.searchedContacts[index].contacts.length,
                    shrinkWrap: true,
                    primary: false,
                    itemBuilder: (ctx, i) {
                      final contact =
                          provider.searchedContacts[index].contacts[i];

                      return ListTile(
                        onTap: () => _openContactDetialsPage(context, contact),
                        leading: ClipRRect(
                          borderRadius: BorderRadius.circular(50),
                          child: CircleAvatar(
                            backgroundColor: AppColors.lightPeach,
                            radius: 23,
                            child: contact.photo != null
                                ? Image.memory(
                                    contact.photo!,
                                    fit: BoxFit.cover,
                                    height: double.infinity,
                                    width: double.infinity,
                                  )
                                : SvgIcons.applaudRatingFilled(
                                    height: 22,
                                    color: AppColors.darkPeach2,
                                  ),
                          ),
                        ),
                        title: Text(
                          contact.fullname,
                          style: AppStyles.text2(color: context.textColor),
                        ),
                        subtitle: Text(
                          contact.phones.map((e) => e.number).join(', '),
                          style: AppStyles.text1(
                            color: AppColors.searchFieldHintColor,
                          ).copyWith(
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      );
                    },
                  ),
                ],
              );
            },
          );
        },
      ),
    );
  }

  void _openContactDetialsPage(BuildContext context, Contact contact) async {
    final invite = await AppModule.I.navigateToNamed(
      ContactDetailsPage.routeName,
      arguments: contact,
    );

    if (invite != null && invite is FriendInvite) {
      context.pop(invite);
    }
  }
}
