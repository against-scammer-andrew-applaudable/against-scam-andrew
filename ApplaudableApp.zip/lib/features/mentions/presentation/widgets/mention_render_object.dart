import 'dart:developer';

import 'package:flutter/material.dart';

import '../../../../core/extensions/list_extensions.dart';
import '../../../../core/utils/emoji.dart';
import '../../../post/domain/entities/post_entities.dart';
import '../../../post/domain/enums/post_enums.dart';
import '../../../post/presentation/widgets/mention_view.dart';

/// Handles the User and Invite mentions
mixin MentionRenderUserObject {
  /// Render span for the Mention User
  /// Receives a [element] instance [PostElement]
  /// And the [textToRender]
  ///
  /// Optionally can override the [id] by
  /// using the optional param
  TextSpan mentionUser(
    PostElement element,
    String textToRender, {
    String? id,
    TextStyle? style,
  }) =>
      TextSpan(
        style: style,
        children: <InlineSpan>[
          WidgetSpan(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(MentionView.atSignSymbol, style: style),
                MentionView.user(
                  text: textToRender,
                  id: id ?? element.id,
                  style: style,
                ),
              ],
            ),
            baseline: TextBaseline.alphabetic,
            alignment: PlaceholderAlignment.baseline,
          )
        ],
      );

  /// In case this invite object has a [user]
  /// then render it has a mention user
  TextSpan? mentionUserFromInvite(
    List<PostMention>? mentions,
    PostElement element,
    String textToRender,
    TextStyle? style,
  ) {
    PostUser? user = getUserByElement(element: element, mentions: mentions);

    if (user == null) {
      return null;
    }

    return mentionUser(element, textToRender, id: user.id, style: style);
  }

  PostUser? getUserByElement({
    required PostElement element,
    List<PostMention>? mentions,
  }) {
    return mentions
        ?.firstWhereOrNull((mention) =>
            mention.id == element.id && mention.type.name == element.type.name)
        ?.user;
  }
}

/// Handles the NUPP mention
mixin MentionRenderNuppObject {
  TextSpan mentionNupp(
    PostElement element,
    String textToRender, {
    bool enableMentionsAction = true,
    String? preloadedNuppId,
    TextStyle? style,
  }) {
    return TextSpan(
      style: style,
      children: <InlineSpan>[
        WidgetSpan(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(MentionView.hashSignSymbol, style: style),
              MentionView.nupp(
                text: textToRender,
                id: element.id,
                enableAction: enableMentionsAction,
                preloadedNuppId: preloadedNuppId,
                style: style,
              ),
            ],
          ),
          baseline: TextBaseline.alphabetic,
          alignment: PlaceholderAlignment.baseline,
        )
      ],
    );
  }

  bool isPublicNupp(List<PostMention>? mentions, PostElement element) {
    final mention = mentions?.firstWhereOrNull((mention) =>
        mention.id == element.id && mention.type.name == element.type.name);
    return mention != null && mention.isPublic;
  }
}

/// Handles the emoji
mixin MentionRenderEmojiObject {
  String mentionEmoji(EmojiHandler? emoji, PostElement element) =>
      element.text != null
          ? emoji?.parse(element.text!, unicode: element.unicode) ?? ""
          : "";
}

class MentionRenderObject
    with
        MentionRenderUserObject,
        MentionRenderNuppObject,
        MentionRenderEmojiObject {
  final List<PostElement>? elements;
  final List<PostMention>? mentions;

  const MentionRenderObject({this.elements, this.mentions});

  String getLabelByElement({required PostElement element}) =>
      mentions
          ?.firstWhereOrNull((mention) =>
              mention.id == element.id &&
              mention.type.name == element.type.name)
          ?.label ??
      "";

  /// This method will validate all the mentions types
  /// and returns the computed string
  ///
  /// Optional can pass:
  ///  ** a [style] TextStyle
  ///  ** a [emoji] handler
  String renderOnlyText({TextStyle? style, EmojiHandler? emoji}) {
    return elements?.map<String>((e) {
          String textToRender = "";

          switch (e.type) {
            case PostElementType.text:
              textToRender = e.text ?? "";
              break;
            case PostElementType.user:
              textToRender = getLabelByElement(element: e);
              textToRender = "${MentionView.atSignSymbol}$textToRender";
              break;
            case PostElementType.nupp:
              textToRender = getLabelByElement(element: e);
              textToRender = "${MentionView.hashSignSymbol}$textToRender";
              break;
            case PostElementType.invite:
              textToRender = getLabelByElement(element: e);
              var mentionUserSpan =
                  mentionUserFromInvite(mentions, e, textToRender, style);
              if (mentionUserSpan != null) {
                textToRender = "${MentionView.atSignSymbol}$textToRender";
              }
              break;
            case PostElementType.emoji:
              textToRender = mentionEmoji(emoji, e);
              break;
            case PostElementType.richText:
              break;
          }
          log('${textToRender}rer');
          return textToRender;
        }).join("") ??
        "";
  }

  /// This method validates and creates the list os spans
  /// related to each mention type to be added to a RichText
  List<InlineSpan>? renderSpans({TextStyle? style, EmojiHandler? emoji}) {
    return elements?.map<InlineSpan>((e) {
      String textToRender = "";

      switch (e.type) {
        case PostElementType.user:
          textToRender = getLabelByElement(element: e);
          if (textToRender.isNotEmpty) {
            return mentionUser(e, textToRender, style: style);
          }
          break;
        case PostElementType.nupp:
          textToRender = getLabelByElement(element: e);
          final isPublic = isPublicNupp(mentions, e);
          if (isPublic) return mentionNupp(e, textToRender);
          break;
        case PostElementType.invite:
          textToRender = getLabelByElement(element: e);
          var mentionUserSpan =
              mentionUserFromInvite(mentions, e, textToRender, style);
          if (mentionUserSpan != null) {
            return mentionUserSpan;
          }
          break;
        case PostElementType.emoji:
          textToRender = mentionEmoji(emoji, e);
          break;
        case PostElementType.text:
          textToRender = e.text ?? "";
          break;
        case PostElementType.richText:
          break;
      }
      return TextSpan(text: textToRender, style: style);
    }).toList();
  }
}
