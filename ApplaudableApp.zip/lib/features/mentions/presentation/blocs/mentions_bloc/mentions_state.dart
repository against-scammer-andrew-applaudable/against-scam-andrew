part of 'mentions_bloc.dart';

abstract class MentionsState extends Equatable {
  const MentionsState();

  @override
  List<Object?> get props => [];
}

class MentionsInitialState extends MentionsState {}

class MentionsLoadingState extends MentionsState {}

class MentionsNextPageLoadingState extends MentionsState {}

class MentionsErrorState extends MentionsState {
  final String message;

  const MentionsErrorState({required this.message});

  @override
  List<Object?> get props => [message];
}

class MentionsPaginationErrorState extends MentionsState {
  final String message;

  const MentionsPaginationErrorState({required this.message});

  @override
  List<Object?> get props => [message];
}

class MentionsFetchedState extends MentionsState {
  final List<Mention> mentions;

  const MentionsFetchedState({required this.mentions});

  @override
  List<Object?> get props => [mentions];
}
