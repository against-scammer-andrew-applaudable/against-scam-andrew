part of 'mentions_bloc.dart';

abstract class MentionsEvent extends Equatable {
  const MentionsEvent();
}

class SearchForMentionsEvent extends MentionsEvent {
  final String query;
  final bool fetchFirstPage;
  final int pageSize;

  const SearchForMentionsEvent({
    required this.query,
    this.fetchFirstPage = true,
    this.pageSize = 15,
  });

  @override
  List<Object?> get props => [query, fetchFirstPage, pageSize];
}
