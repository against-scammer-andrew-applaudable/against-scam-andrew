import 'package:equatable/equatable.dart';

import '../../../../../core/bloc/dng_base_bloc.dart';
import '../../../../../core/entities/pagination_params.dart';
import '../../../../../core/entities/search_params.dart';
import '../../../domain/entities/mention.dart';
import '../../../domain/usecases/search_for_mentions.dart';

part 'mentions_event.dart';
part 'mentions_state.dart';

class MentionsBloc extends DNGBloc<MentionsEvent, MentionsState> {
  final SearchForMentions searchForMentions;

  MentionsBloc({required this.searchForMentions})
      : super(MentionsInitialState());

  final List<Mention> _mentions = [];

  int _pageNo = 1;
  bool _allowNewPaginationRequests = true;

  @override
  void mapEventToState(MentionsEvent event) async {
    if (event is SearchForMentionsEvent) {
      await _handleSearchForMentionsEvent(event);
    }
  }

  Future<void> _handleSearchForMentionsEvent(
    SearchForMentionsEvent event,
  ) async {
    if (!event.fetchFirstPage && !_allowNewPaginationRequests) return;

    _allowNewPaginationRequests = false;

    emit(
      event.fetchFirstPage
          ? MentionsLoadingState()
          : MentionsNextPageLoadingState(),
    );

    final result = await searchForMentions(
      SearchParams(
        query: event.query,
        pageInfo: PaginationParams(
          pageNo: event.fetchFirstPage ? _pageNo = 1 : ++_pageNo,
          pageSize: event.pageSize,
        ),
      ),
    );

    emit(
      result.fold(
        (failure) {
          if (!event.fetchFirstPage) _pageNo--;

          return event.fetchFirstPage
              ? MentionsErrorState(message: failure.message)
              : MentionsPaginationErrorState(message: failure.message);
        },
        (response) {
          if (event.fetchFirstPage) {
            _mentions.clear();
          }

          if (response.results.length < event.pageSize) _pageNo--;

          // _allowNewPaginationRequests =
          //     response.results.length == event.pageSize;

          _mentions.addAll(response.results);

          return MentionsFetchedState(
            mentions: _mentions.toSet().toList(),
          );
        },
      ),
    );

    _allowNewPaginationRequests = true;
  }
}
