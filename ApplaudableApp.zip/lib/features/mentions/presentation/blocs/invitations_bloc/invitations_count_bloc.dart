import 'package:equatable/equatable.dart';

import '../../../../../core/bloc/dng_base_bloc.dart';
import '../../../../../core/usecase/usecase.dart';
import '../../../domain/entities/invitations_count.dart';
import '../../../domain/usecases/get_invitations_count.dart';

part 'invitations_count_event.dart';
part 'invitations_count_state.dart';

class InvitationsCountBloc
    extends DNGBloc<InvitationsCountEvent, InvitationsCountState> {
  final GetInvitationsCount getInvitationsCount;

  InvitationsCountBloc({
    required this.getInvitationsCount,
  }) : super(InvitationsCountInitialState());

  @override
  void mapEventToState(InvitationsCountEvent event) async {
    if (event is GetUserInvitationsCountEvent) {
      await _handleGetUserInvitationsCountEvent(event);
    }
  }

  Future<void> _handleGetUserInvitationsCountEvent(
    GetUserInvitationsCountEvent event,
  ) async {
    emit(InvitationsCountLoadingState());

    final result = await getInvitationsCount(NoParams());

    emit(
      result.fold(
        (failure) => InvitationsCountErrorState(message: failure.message),
        (count) => InvitationsCountFetchedState(inviteDetails: count),
      ),
    );
  }
}
