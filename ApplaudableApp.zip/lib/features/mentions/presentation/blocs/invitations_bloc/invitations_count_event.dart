part of 'invitations_count_bloc.dart';

abstract class InvitationsCountEvent extends Equatable {
  const InvitationsCountEvent();

  @override
  List<Object> get props => [];
}

class GetUserInvitationsCountEvent extends InvitationsCountEvent {}
