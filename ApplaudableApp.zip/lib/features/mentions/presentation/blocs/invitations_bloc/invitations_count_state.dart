part of 'invitations_count_bloc.dart';

abstract class InvitationsCountState extends Equatable {
  const InvitationsCountState();

  @override
  List<Object> get props => [];
}

class InvitationsCountInitialState extends InvitationsCountState {}

class InvitationsCountLoadingState extends InvitationsCountState {}

class InvitationsCountErrorState extends InvitationsCountState {
  final String message;

  const InvitationsCountErrorState({required this.message});

  @override
  List<Object> get props => [message];
}

class InvitationsCountFetchedState extends InvitationsCountState {
  final InvitationsCount inviteDetails;

  const InvitationsCountFetchedState({required this.inviteDetails});

  @override
  List<Object> get props => [inviteDetails];
}

class InvitationsDoNothingState extends InvitationsCountState {}
