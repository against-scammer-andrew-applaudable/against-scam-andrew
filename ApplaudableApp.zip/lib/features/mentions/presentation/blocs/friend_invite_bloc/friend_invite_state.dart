part of 'friend_invite_bloc.dart';

abstract class FriendInviteState extends Equatable {
  final String? phone;

  const FriendInviteState({this.phone});

  @override
  List<Object?> get props => [phone];
}

class FriendInviteInitialState extends FriendInviteState {}

class FriendInviteLoadingState extends FriendInviteState {
  const FriendInviteLoadingState({super.phone});
}

class FriendInviteErrorState extends FriendInviteState {
  final String message;

  const FriendInviteErrorState({required this.message, super.phone});

  @override
  List<Object?> get props => [message, phone];
}

class UserInvitedState extends FriendInviteState {
  final FriendInvite invite;

  const UserInvitedState({required this.invite, super.phone});

  @override
  List<Object?> get props => [invite, phone];
}

class FriendInviteDoNothingState extends FriendInviteState {}
