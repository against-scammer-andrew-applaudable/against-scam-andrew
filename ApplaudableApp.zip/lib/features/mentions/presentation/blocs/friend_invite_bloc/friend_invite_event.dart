part of 'friend_invite_bloc.dart';

abstract class FriendInviteEvent extends Equatable {
  const FriendInviteEvent();
}

class InviteUserEvent extends FriendInviteEvent {
  final String name;
  final String? email;
  final String? phone;
  final bool notify;

  const InviteUserEvent({
    required this.name,
    this.email,
    this.phone,
    this.notify = false,
  });

  @override
  List<Object?> get props => [name, email, phone, notify];
}
