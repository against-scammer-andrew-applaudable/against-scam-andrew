import 'package:equatable/equatable.dart';

import '../../../../../core/bloc/dng_base_bloc.dart';
import '../../../domain/entities/friend_invite.dart';
import '../../../domain/usecases/invite_user.dart';

part 'friend_invite_event.dart';
part 'friend_invite_state.dart';

class FriendInviteBloc extends DNGBloc<FriendInviteEvent, FriendInviteState> {
  final InviteUser inviteUser;

  FriendInviteBloc({required this.inviteUser})
      : super(FriendInviteInitialState());

  @override
  void mapEventToState(FriendInviteEvent event) async {
    if (event is InviteUserEvent) {
      await _handleInviteUserEvent(event);
    }
  }

  Future<void> _handleInviteUserEvent(InviteUserEvent event) async {
    emit(FriendInviteLoadingState(phone: event.phone));

    final result = await inviteUser(InviteUserParams(
      name: event.name,
      email: event.email,
      phone: event.phone,
      notify: event.notify,
    ));

    emit(result.fold(
      (failure) =>
          FriendInviteErrorState(message: failure.message, phone: event.phone),
      (inviteData) => UserInvitedState(invite: inviteData, phone: event.phone),
    ));

    emit(FriendInviteDoNothingState());
  }
}
