part of 'user_contacts_bloc.dart';

abstract class UserContactsEvent extends Equatable {
  const UserContactsEvent();

  @override
  List<Object?> get props => [];
}

class GetUserContactsEvent extends UserContactsEvent {}
