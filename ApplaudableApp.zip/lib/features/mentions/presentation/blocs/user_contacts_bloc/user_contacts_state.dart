part of 'user_contacts_bloc.dart';

abstract class UserContactsState extends Equatable {
  const UserContactsState();

  @override
  List<Object?> get props => [];
}

class UserContactsInitialState extends UserContactsState {}

class UserContactsLoadingState extends UserContactsState {}

class UserContactsPermissionsDeniedState extends UserContactsState {}

class UserContactsErrorState extends UserContactsState {
  final String message;

  const UserContactsErrorState({required this.message});

  @override
  List<Object?> get props => [message];
}

class UserContactsFetchedState extends UserContactsState {
  final ContactsResponse response;

  const UserContactsFetchedState({required this.response});

  @override
  List<Object?> get props => [response];
}

class UserContactsDoNothingState extends UserContactsState {}
