import 'package:equatable/equatable.dart';

import '../../../../../core/bloc/dng_base_bloc.dart';
import '../../../../../core/errors/failures.dart';
import '../../../../../core/usecase/usecase.dart';
import '../../../domain/entities/contacts_response.dart';
import '../../../domain/usecases/get_user_contacts.dart';

part 'user_contacts_event.dart';
part 'user_contacts_state.dart';

class UserContactsBloc extends DNGBloc<UserContactsEvent, UserContactsState> {
  final GetUserContacts getUserContacts;

  UserContactsBloc({required this.getUserContacts})
      : super(UserContactsInitialState());

  @override
  void mapEventToState(UserContactsEvent event) async {
    if (event is GetUserContactsEvent) {
      emit(UserContactsLoadingState());

      final result = await getUserContacts(NoParams());

      emit(
        result.fold(
          (failure) {
            if (failure is DevicePermissionDeniedFailure) {
              emit(UserContactsPermissionsDeniedState());

              return UserContactsDoNothingState();
            }
            return UserContactsErrorState(message: failure.message);
          },
          (contacts) => UserContactsFetchedState(response: contacts),
        ),
      );
    }
  }
}
