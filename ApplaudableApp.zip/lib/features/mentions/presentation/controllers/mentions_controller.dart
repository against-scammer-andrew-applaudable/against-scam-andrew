import 'dart:developer';

import 'package:flutter/widgets.dart';

import '../../../../core/constants/constant_values.dart';
import '../../../../core/utils/app_regex.dart';
import '../../../post/data/models/post_response_models.dart';
import '../../../post/domain/entities/post_entities.dart';
import '../../../post/domain/enums/post_enums.dart';

class MentionsController {
  final List<Map<String, String?>> _mentions = [];

  List<Map<String, String?>> get mentionsIds => [..._mentions];

  void insertMention(int index, String mentionId, String? source) {
    _mentions.insert(index, {'id': mentionId, 'source': source});
  }

  void addMention(String mentionId, String? source) {
    _mentions.add({'id': mentionId, 'source': source});
  }

  void removeMentionAt(int index) {
    if (_mentions.isNotEmpty) _mentions.removeAt(index);
  }

  void removeMentionOf(String? id) {
    if (_mentions.isNotEmpty) _mentions.removeWhere((e) => e['id'] == id);
  }

  Map<String, String?> elementAt(int index) => _mentions[index];

  bool isMentioned(String? id) {
    return _mentions.any((e) => e['id'] == id);
  }

  List<PostElement> mapDescriptionToElements(String text) {
    final regex = AppRegex.mentionRegex;
    final spans = <PostElementModel>[];
    final ids = mentionsIds;

    String currentText = text;

    while (currentText.isNotEmpty) {
      final match = regex.firstMatch(currentText);

      if (match != null) {
        final range = TextRange(start: match.start, end: match.end);

        String temp = range.textInside(text);
        temp = temp.replaceFirst('@', '')
          ..replaceFirst(ConstantValues.mentionSeparator, '');

        log(temp);

        String textBefore = range.textBefore(currentText);

        spans.addAll([
          if (textBefore.isNotEmpty)
            PostElementModel(type: PostElementType.text, text: textBefore),
          _getRelatedElementFromSource(ids.first),
        ]);

        ids.removeAt(0);
        currentText = currentText.substring(match.end);
      } else if (currentText.hasContent) {
        spans.add(
            PostElementModel(type: PostElementType.text, text: currentText));
        currentText = '';
      } else {
        currentText = '';
      }
    }

    return [
      if (text.trim().isNotEmpty)
        PostElementModel(
          type: PostElementType.richText,
          elements: spans,
          //     [
          //   PostElementModel(type: 'text', text: text),
          // ],
        )
    ];
  }

  PostElementModel _getRelatedElementFromSource(Map<String, String?> mention) {
    if (mention['source'] == 'user') {
      return PostElementModel(
          type: PostElementType.user, userId: mention['id']);
    }

    if (mention['source'] == 'invite') {
      return PostElementModel(
          type: PostElementType.invite, inviteId: mention['id']);
    }

    return PostElementModel(type: PostElementType.nupp, nuppId: mention['id']);
  }

  List<PostElementModel> getAllMentions() {
    final elements = <PostElementModel>[];

    for (final mention in _mentions) {
      elements.addAll([
        _getRelatedElementFromSource(mention),
        const PostElementModel(type: PostElementType.text, text: ' ')
      ]);
    }

    return elements;
  }

  void clear() {
    _mentions.clear();
  }
}

extension TextExtensions on String {
  bool get hasContent {
    return replaceAll(ConstantValues.mentionSeparator, '').trim().isNotEmpty;
  }

  String get normalize {
    return replaceAll("\u200b", "").trim();
  }
}
