import 'package:flutter/material.dart';
import 'package:flutter_contacts/contact.dart';

import '../../../../core/extensions/contact_extensions.dart';
import '../../data/models/contacts_response_model.dart';
import '../../domain/entities/contacts_response.dart';

class ContactsSearchController with ChangeNotifier {
  final List<CharacterContacts> _charContacts = [];
  final List<CharacterContacts> _searchedContacts = [];

  void init(List<CharacterContacts> contacts) {
    _charContacts.clear();
    _searchedContacts.clear();

    _charContacts.addAll(contacts);
    _searchedContacts.addAll(contacts);
  }

  void searchForContact(String nameOrPhone) {
    final numRegex = RegExp(r'\d+$');
    final isPhone = numRegex.hasMatch(nameOrPhone);

    _searchedContacts.clear();
    final searchResult = <CharacterContacts>[];

    if (isPhone) {
      for (final charContact in _charContacts) {
        final result = charContact.contacts
            .where((e) => _searchByPhone(e, nameOrPhone))
            .toList();

        if (result.isNotEmpty) {
          searchResult.add(
            CharacterContactsModel(
              character: charContact.character,
              contacts: result,
            ),
          );
        }
      }
    } else {
      for (final charContact in _charContacts) {
        final result = charContact.contacts
            .where((e) => _searchByName(e, nameOrPhone))
            .toList();

        if (result.isNotEmpty) {
          searchResult.add(
            CharacterContactsModel(
              character: charContact.character,
              contacts: result,
            ),
          );
        }
      }
    }

    _searchedContacts.clear();
    _searchedContacts.addAll(searchResult);

    notifyListeners();
  }

  bool _searchByName(Contact contact, String query) {
    return contact.fullname.toLowerCase().contains(query.toLowerCase()) ||
        query.toLowerCase().contains(contact.fullname.toLowerCase());
  }

  bool _searchByPhone(Contact contact, String query) {
    return contact.phones.any((e) => e.abstractNumber.contains(query));
  }

  List<CharacterContacts> get searchedContacts => [..._searchedContacts];
}
