import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../app_module.dart';
import '../../../../core/bloc/widgets/base_stateless_page.dart';
import '../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../core/extensions/app_module_extensions.dart';
import '../../../../core/extensions/build_context_extensions.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/widgets/app_bar.dart';
import '../../../../core/widgets/app_default_error_view.dart';
import '../../../../core/widgets/app_permissions_denied_view.dart';
import '../../../../core/widgets/app_scaffold.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../../../../core/widgets/svg_icons.dart';
import '../../../../generated/l10n.dart';
import '../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../../../profile/presentation/widgets/users_tiles_loading_view.dart';
import '../../domain/entities/friend_invite.dart';
import '../blocs/user_contacts_bloc/user_contacts_bloc.dart';
import '../controllers/contacts_search_controller.dart';
import '../widgets/contacts_overview_list.dart';
import 'invite_user_page.dart';

// ignore: must_be_immutable
class UserContactsPage
    extends BaseStatelessPage<UserContactsBloc, UserContactsState> {
  static const String routeName = '/user-contacts-page';

  final InviteUserPageArgs args;

  UserContactsPage({super.key, this.args = const InviteUserPageArgs()});

  final TextEditingController _queryController = TextEditingController();

  @override
  void initBloc(BuildContext context, UserContactsBloc bloc) {
    bloc.add(GetUserContactsEvent());
  }

  @override
  Widget build(BuildContext context) {
    registerBloc(context);

    final translations = S.of(context);
    final provider = context.read<ContactsSearchController>();

    return AppScaffold(
      appBar: NavigationPageBar(
        title: translations.invite_a_friend,
        actions: [
          IconButton(
            icon: SvgIcons.plus(),
            onPressed: () => _openInviteWithPhoneFlow(context),
          ),
        ],
      ),
      body: AppSideMargins(
        margin: const EdgeInsets.only(
          top: 20,
          left: 20,
          right: 20,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            CurvedTextField(
              controller: _queryController,
              fillColor: AppColors.white,
              filled: true,
              hintText: translations.searchHint,
              prefixIcon: const SearchFieldPrefix(),
              onChanged: (value) {
                provider.searchForContact(value.trim());
              },
            ),
            const SizedBox(height: AppDimensions.defaultSidePadding),
            Expanded(
              child: DNGBlocBuilder<UserContactsBloc, UserContactsState>(
                bloc: bloc,
                buildWhen: (state) =>
                    state is UserContactsLoadingState ||
                    state is UserContactsErrorState ||
                    state is UserContactsFetchedState ||
                    state is UserContactsPermissionsDeniedState,
                builder: (ctx, state) {
                  if (state is UserContactsLoadingState) {
                    return const UsersTilesLoadingView(
                      showFollowActions: false,
                    );
                  } else if (state is UserContactsPermissionsDeniedState) {
                    return AppDefaultErrorView(
                      message: translations.permissions_denied_text,
                      onRefresh: () => _openPermissionDeniedDialog(context),
                    );
                  } else if (state is UserContactsErrorState) {
                    return AppDefaultErrorView(
                      message: state.message,
                      onRefresh: () => bloc.add(GetUserContactsEvent()),
                    );
                  } else if (state is UserContactsFetchedState) {
                    provider.init(state.response.charContacts);

                    return ContactsOverviewList(
                      charContacts: state.response.charContacts,
                    );
                  }

                  return const SizedBox();
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _openInviteWithPhoneFlow(BuildContext context) async {
    final invite = await AppModule.I.navigateToNamed(
      InviteUserPage.routeName,
      arguments: InviteUserPageArgs(name: args.name),
    );

    if (invite != null && invite is FriendInvite) {
      context.pop(invite);
    }
  }

  void _openPermissionDeniedDialog(BuildContext context) {
    // ignore: use_build_context_synchronously
    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppDimensions.radius_15),
          ),
          content: SizedBox(
            height: 200,
            child: AppPermissionDeniedView(
              onOpeningSettings: AppModule.I.pop,
            ),
          ),
        );
      },
    );
  }

  @override
  Stream<UserContactsState>? get onStateListener => bloc.stream;

  @override
  void onStateResultListener(BuildContext context, UserContactsState state) {
    if (state is UserContactsPermissionsDeniedState) {
      _openPermissionDeniedDialog(context);
    }
  }
}
