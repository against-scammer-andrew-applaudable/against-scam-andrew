import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../../app_module.dart';
import '../../../../core/bloc/widgets/base_stateless_page.dart';
import '../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../core/extensions/app_module_extensions.dart';
import '../../../../core/extensions/build_context_extensions.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/theme/styles.dart';
import '../../../../core/widgets/app_bar.dart';
import '../../../../core/widgets/app_scaffold.dart';
import '../../../../core/widgets/toast/app_toast.dart';
import '../../../../generated/l10n.dart';
import '../../../auth/presentation/validator/validator_service.dart';
import '../../../auth/presentation/widgets/buttons/action_button.dart';
import '../../../auth/presentation/widgets/inputs/country_field/country_field.dart';
import '../../../auth/presentation/widgets/inputs/text_field.dart';
import '../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../blocs/friend_invite_bloc/friend_invite_bloc.dart';

enum InviteOption { inviteByPhone, inviteByEmail }

class InviteUserPageArgs {
  final String name;
  final InviteOption inviteOption;

  const InviteUserPageArgs({
    this.name = '',
    this.inviteOption = InviteOption.inviteByPhone,
  });
}

// ignore: must_be_immutable
class InviteUserPage
    extends BaseStatelessPage<FriendInviteBloc, FriendInviteState> {
  static const String routeName = '/invite-user-page';

  final InviteUserPageArgs args;

  InviteUserPage({super.key, this.args = const InviteUserPageArgs()});

  // Form Key and Controllers
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _emailController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  String _countryCode = '+1';

  /// Invite Option Controller to controll the way to invite the user
  final _inviteOptionController = StreamController<InviteOption>();

  @override
  Widget build(BuildContext context) {
    registerBloc(context);

    final translations = S.of(context);

    return AppScaffold(
      appBar: NavigationPageBar(title: translations.invite_a_friend),
      body: AppSideMargins(
        marginValue: 20,
        child: Form(
          key: _formKey,
          child: StreamBuilder<InviteOption>(
            initialData: args.inviteOption,
            stream: _inviteOptionController.stream,
            builder: (context, snapshot) {
              return Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  AppTextField(
                    initialValue: args.name,
                    controller: _nameController,
                    labelText: translations.name,
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return translations.invalid_name_msg;
                      }

                      return null;
                    },
                  ),
                  if (snapshot.data == InviteOption.inviteByPhone)
                    const SizedBox(height: AppDimensions.defaultSidePadding),
                  if (snapshot.data == InviteOption.inviteByPhone)
                    AppCountryField(
                      onSaved: (String? value) {
                        if (value != null) _countryCode = value;
                      },
                    ),
                  const SizedBox(height: 25),
                  if (snapshot.data == InviteOption.inviteByPhone)
                    AppTextField(
                      controller: _phoneController,
                      labelText: translations.phoneNumber,
                      autoCorrect: false,
                      textCapitalization: TextCapitalization.none,
                      textInputType: TextInputType.phone,
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        FilteringTextInputFormatter.digitsOnly,
                      ],
                      validator: (String? value) {
                        final isValidPhone = ValidatorService.hasText(value);

                        if (!isValidPhone) {
                          return translations.invalid_phone_msg;
                        }

                        return null;
                      },
                      onSaved: (String? value) {
                        return;
                      },
                    ),
                  (snapshot.data == InviteOption.inviteByEmail)
                      ? AppTextField.email(
                          controller: _emailController,
                          labelText: translations.email,
                          validator: (String? value) {
                            final isValidEmail =
                                ValidatorService.isEmailValid(value);

                            if (!isValidEmail) {
                              return translations.invalid_email_msg;
                            }

                            return null;
                          },
                        )
                      : Container(),
                  const SizedBox(height: 30),
                  DNGBlocBuilder<FriendInviteBloc, FriendInviteState>(
                    bloc: bloc,
                    builder: (context, state) {
                      return AppActionButton.submit(
                        text: translations.invite,
                        boxShadow: [AppShadows.submitButtonDefaultShadow],
                        showLoading: state is FriendInviteLoadingState,
                        onPressed: () {
                          _formKey.currentState!.save();
                          final isValid = _formKey.currentState!.validate();

                          if (isValid) {
                            final name = _nameController.text;
                            final email = _emailController.text;
                            final phone = _countryCode + _phoneController.text;

                            bloc.add(
                              InviteUserEvent(
                                name: name,
                                phone:
                                    snapshot.data == InviteOption.inviteByPhone
                                        ? phone
                                        : null,
                                email:
                                    snapshot.data == InviteOption.inviteByEmail
                                        ? email
                                        : null,
                                notify: true,
                              ),
                            );
                          }
                        },
                      );
                    },
                  ),
                  const SizedBox(height: 22),
                  // const OrTextDivider(),
                  // const SizedBox(height: AppDimensions.defaultSidePadding),
                  // AppActionButton.submitWithBorder(
                  //   leadingIcon: snapshot.data == InviteOption.inviteByPhone
                  //       ? SvgIcons.email
                  //       : const Icon(Icons.phone_android,
                  //           color: AppColors.darkGrey),
                  //   text: snapshot.data == InviteOption.inviteByPhone
                  //       ? translations.buttonInviteWithEmailLabel
                  //       : translations.buttonInviteWithPhoneLabel,
                  //   onPressed: () {
                  //     if (snapshot.data == InviteOption.inviteByPhone) {
                  //       _inviteOptionController.sink
                  //           .add(InviteOption.inviteByEmail);
                  //     } else {
                  //       _inviteOptionController.sink
                  //           .add(InviteOption.inviteByPhone);
                  //     }
                  //   },
                  // ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  @override
  Stream<FriendInviteState> get onStateListener => bloc.stream;

  @override
  void onStateResultListener(BuildContext context, FriendInviteState state) {
    if (state is FriendInviteErrorState) {
      AppModule.I.notify(context, state.message, mode: AppToastMode.error);
    } else if (state is UserInvitedState) {
      context.pop(state.invite);
    }
  }
}
