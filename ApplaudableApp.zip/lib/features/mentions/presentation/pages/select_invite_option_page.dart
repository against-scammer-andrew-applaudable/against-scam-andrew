// ignore_for_file: deprecated_member_use, use_build_context_synchronously

import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../../app_module.dart';
import '../../../../core/bloc/widgets/base_stateless_page.dart';
import '../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../core/extensions/app_module_extensions.dart';
import '../../../../core/extensions/build_context_extensions.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/theme/styles.dart';
import '../../../../core/widgets/animations/pagination_loading_view.dart';
import '../../../../core/widgets/app_bar.dart';
import '../../../../core/widgets/app_default_error_view.dart';
import '../../../../core/widgets/app_scaffold.dart';
import '../../../../core/widgets/or_text_divider.dart';
import '../../../../core/widgets/svg_icons.dart';
import '../../../../core/widgets/toast/app_toast.dart';
import '../../../../generated/l10n.dart';
import '../../../auth/presentation/widgets/buttons/action_button.dart';
import '../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../../../create_post/presentation/pages/select_story_question_page.dart';
import '../../domain/entities/friend_invite.dart';
import '../blocs/invitations_bloc/invitations_count_bloc.dart';
import 'invite_user_page.dart';
import 'user_contacts_page.dart';

class SelectInviteOptionPage extends StatelessWidget {
  static const String routeName = '/select-invite-option-page';

  final InviteUserPageArgs args;

  const SelectInviteOptionPage({
    super.key,
    this.args = const InviteUserPageArgs(),
  });

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return AppScaffold(
      appBar: NavigationPageBar(title: translations.invite_a_friend),
      body: AppSideMargins(
        marginValue: 25,
        child: InviteUserOptionsView(),
      ),
    );
  }
}

// ignore: must_be_immutable
class InviteUserOptionsView
    extends BaseStatelessPage<InvitationsCountBloc, InvitationsCountState> {
  final InviteUserPageArgs args;
  final Function(String)? openUserContactsPage;
  final Function(String)? openInviteByEmailFlow;

  InviteUserOptionsView({
    super.key,
    this.args = const InviteUserPageArgs(),
    this.openUserContactsPage,
    this.openInviteByEmailFlow,
  });

  @override
  void initBloc(BuildContext context, InvitationsCountBloc bloc) {
    bloc.add(GetUserInvitationsCountEvent());
  }

  @override
  Widget build(BuildContext context) {
    registerBloc(context);
    final translations = S.of(context);

    final user = AppModule.I.controller.currentUser;

    return DNGBlocBuilder<InvitationsCountBloc, InvitationsCountState>(
      bloc: bloc,
      builder: (context, state) {
        if (state is InvitationsCountLoadingState) {
          return const Center(child: PaginationLoadingView());
        } else if (state is InvitationsCountErrorState) {
          return AppDefaultErrorView(message: state.message);
        } else if (state is InvitationsCountFetchedState) {
          if (state.inviteDetails.invitationsCount == 0) {
            return Center(
              child: SafeArea(
                child: LayoutBuilder(
                  builder: (ctx, constraints) {
                    return SingleChildScrollView(
                      child: ConstrainedBox(
                        constraints: BoxConstraints(
                          maxHeight: constraints.maxHeight,
                        ),
                        child: Column(
                          children: [
                            const Spacer(),
                            SvgPicture.asset(
                              'assets/icons/ic_error_x.svg',
                              color: AppColors.primaryColor,
                              height: 120,
                            ),
                            const Spacer(),
                            const SizedBox(height: 20),
                            Text(
                              translations.you_have_used_all_invitations,
                              style: AppStyles.header2(color: context.textColor).copyWith(
                                fontSize: 18,
                              ),
                            ),
                            const SizedBox(height: 20),
                            Text(
                              translations.create_story_reward_desc_msg,
                              style: AppStyles.text2(color: context.textColor),
                              textAlign: TextAlign.center,
                            ),
                            const Spacer(flex: 3),
                            AppActionButton.submit(
                              text: translations.add_life_story_post,
                              onPressed: () {
                                SelectStoryQuestionPage
                                    .getSuggestedStoryQuestions(context);

                                // AppModule.I.navigateToNamedAndRemoveUntil(
                                AppModule.I.navigateToNamed(
                                  SelectStoryQuestionPage.routeName,
                                  // (route) => route.settings.name == Routes.home,
                                );
                              },
                            ),
                            const SizedBox(height: 50),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            );
          }

          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                AppSideMargins(
                  marginValue: 10,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      user != null
                          ? Text(
                              translations.youHaveCountInvitations(
                                state.inviteDetails.invitationsCount,
                              ),
                              style: AppStyles.header2(color: context.textColor).copyWith(
                                fontSize: 20,
                              ),
                              textAlign: TextAlign.center,
                            )
                          : const PaginationLoadingView(),
                      const SizedBox(height: 30),
                      Text(
                        translations.account_created_confirm_msg,
                        style: AppStyles.text2(color: context.textColor),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: AppDimensions.defaultSidePadding),
                      Text(
                        translations.share_invitation_code_msg,
                        style: AppStyles.text2(color: context.textColor),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 40),
                    ],
                  ),
                ),
                AppActionButton.submit(
                  text: translations.open_your_contacts_list,
                  fitsFullWidth: false,
                  splashColor: AppColors.lightPeach,
                  onPressed: () => _openUserContactsPage(context),
                ),
                const SizedBox(height: 30),
                const OrTextDivider(),
                const SizedBox(height: 30),
                AppActionButton.submitWithBorder(
                  leadingIcon: SvgIcons.email,
                  text: translations.buttonInviteWithEmailLabel,
                  onPressed: () => _openInviteWithEmailFlow(context),
                ),
                const SizedBox(height: 50),
                GestureDetector(
                  onTap: () async {
                    await Clipboard.setData(
                      ClipboardData(text: user?.invitationCode ?? ''),
                    );

                    AppToast().build(
                      context,
                      translations.invitation_code_copied,
                    );
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(
                        width: 2,
                        color: Colors.black12,
                      ),
                      borderRadius: BorderRadius.circular(
                        6,
                      ),
                    ),
                    alignment: Alignment.center,
                    padding: const EdgeInsets.all(
                      25,
                    ),
                    child: Column(
                      children: [
                        Text(
                          state.inviteDetails.invitationCode.isNotEmpty
                              ? state.inviteDetails.invitationCode
                              : user?.invitationCode ?? '',
                          style: AppStyles.header2(color: context.textColor).copyWith(
                            fontSize: 20,
                            height: 1,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(translations.share_this_code),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        }

        return Container();
      },
    );
  }

  void _openInviteWithEmailFlow(BuildContext context) async {
    if (openInviteByEmailFlow != null) {
      openInviteByEmailFlow!(args.name);
      return;
    }

    final invite = await AppModule.I.navigateToNamed(
      InviteUserPage.routeName,
      arguments: InviteUserPageArgs(
        name: args.name,
        inviteOption: InviteOption.inviteByEmail,
      ),
    );

    if (invite != null && invite is FriendInvite) {
      context.pop(invite);
    }
  }

  void _openUserContactsPage(BuildContext context) async {
    if (openUserContactsPage != null) {
      openUserContactsPage!(args.name);
      return;
    }

    final invite = await AppModule.I.navigateToNamed(
      UserContactsPage.routeName,
      arguments: InviteUserPageArgs(name: args.name),
    );

    log(invite.toString());

    if (invite != null && invite is FriendInvite) {
      context.pop(invite);
    }
  }
}
