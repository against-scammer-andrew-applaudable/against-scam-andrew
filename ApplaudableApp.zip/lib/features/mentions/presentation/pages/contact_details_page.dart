import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';
import 'package:flutter_contacts/contact.dart';

import '../../../../app_module.dart';
import '../../../../core/extensions/app_module_extensions.dart';
import '../../../../core/extensions/contact_extensions.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/theme/styles.dart';
import '../../../../core/widgets/app_bar.dart';
import '../../../../core/widgets/app_scaffold.dart';
import '../../../../core/widgets/svg_icons.dart';
import '../../../../generated/l10n.dart';
import '../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../../domain/entities/friend_invite.dart';
import '../widgets/contact_phones_overview_list.dart';
import 'invite_user_page.dart';

class ContactDetailsPage extends StatelessWidget {
  static const String routeName = '/contct-details-page';

  final Contact contact;

  const ContactDetailsPage({super.key, required this.contact});

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return AppScaffold(
      appBar: NavigationPageBar(
        title: translations.invite_a_friend,
        actions: [
          IconButton(icon: SvgIcons.plus(), onPressed: _openInviteByPhonePage),
        ],
      ),
      body: AppSideMargins(
        marginValue: 25,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 35),
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(50),
                child: CircleAvatar(
                  backgroundColor: AppColors.lightPeach,
                  radius: 40,
                  child: contact.photo != null
                      ? Image.memory(
                          contact.photo!,
                          fit: BoxFit.cover,
                          height: double.infinity,
                          width: double.infinity,
                        )
                      : SvgIcons.applaudRatingFilled(
                          height: 22,
                          color: AppColors.darkPeach2,
                        ),
                ),
              ),
            ),
            const SizedBox(height: AppDimensions.defaultSidePadding),
            Text(
              contact.fullname,
              textAlign: TextAlign.center,
              style: AppStyles.text2(color: context.textColor).copyWith(
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 50),
            Expanded(child: ContactPhonesOverviewList(contact: contact)),
          ],
        ),
      ),
    );
  }

  void _openInviteByPhonePage() async {
    final invite = await AppModule.I.navigateToNamed(
      InviteUserPage.routeName,
      arguments: const InviteUserPageArgs(
        inviteOption: InviteOption.inviteByPhone,
      ),
    );

    if (invite != null && invite is FriendInvite) {
      AppModule.I.pop(invite);
    }
  }
}
