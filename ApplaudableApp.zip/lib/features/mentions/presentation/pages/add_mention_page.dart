import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';

import '../../../../app_module.dart';
import '../../../../core/bloc/widgets/base_stateless_page.dart';
import '../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../core/constants/constant_values.dart';
import '../../../../core/extensions/app_module_extensions.dart';
import '../../../../core/extensions/build_context_extensions.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/widgets/app_bar.dart';
import '../../../../core/widgets/app_listview.dart';
import '../../../../core/widgets/app_scaffold.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../../../../generated/l10n.dart';
import '../../../auth/domain/entities/user.dart';
import '../../../auth/presentation/widgets/buttons/action_button.dart';
import '../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../../../profile/presentation/widgets/user_tile_item.dart';
import '../../../profile/presentation/widgets/users_tiles_loading_view.dart';
import '../../domain/entities/friend_invite.dart';
import '../blocs/mentions_bloc/mentions_bloc.dart';
import '../controllers/mentions_controller.dart';
import '../widgets/invite_friend_message_view.dart';
import 'invite_user_page.dart';
import 'select_invite_option_page.dart';

class AddMentionPageArgs {
  final bool allowRemovingMentions;
  final Function(HiveUser)? onRemovingMention;

  const AddMentionPageArgs({
    this.allowRemovingMentions = false,
    this.onRemovingMention,
  });
}

// ignore: must_be_immutable
class AddMentionPage extends BaseStatelessPage<MentionsBloc, MentionsState> {
  static const String routeName = '/add-mention-page';

  final AddMentionPageArgs args;

  AddMentionPage({super.key, this.args = const AddMentionPageArgs()});

  final _queryController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    registerBloc(context);

    final translations = S.of(context);

    return AppScaffold(
      appBar: NavigationPageBar(
        title: translations.mention,
        actions: [
          Row(
            children: [
              AppActionButton.submit(
                text: translations.invite,
                fitsFullWidth: false,
                height: 40,
                backgroundColor: AppColors.transparent,
                actionTextColor: AppColors.primaryColor,
                padding: const EdgeInsets.symmetric(
                  horizontal: AppDimensions.mediumSidePadding,
                ),
                onPressed: () => _openInviteUserFlow(context),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          AppSideMargins(
            margin: const EdgeInsets.only(
              top: 20,
              left: 20,
              right: 20,
            ),
            child: CurvedTextField(
              controller: _queryController,
              fillColor: AppColors.white,
              filled: true,
              hintText: translations.searchHint,
              prefixIcon: const SearchFieldPrefix(),
              onChanged: (value) {
                bloc.add(SearchForMentionsEvent(query: _queryController.text));
              },
            ),
          ),
          const SizedBox(height: AppDimensions.mediumSidePadding),
          Expanded(
            child: DNGBlocBuilder<MentionsBloc, MentionsState>(
              bloc: bloc,
              buildWhen: (state) =>
                  state is MentionsLoadingState ||
                  state is MentionsErrorState ||
                  state is MentionsFetchedState,
              builder: (context, state) {
                if (state is MentionsLoadingState) {
                  return const UsersTilesLoadingView(showFollowActions: false);
                } else if (state is MentionsErrorState) {
                  return Center(
                    child: Text(state.message, textAlign: TextAlign.center),
                  );
                } else if (state is MentionsFetchedState) {
                  if (state.mentions.isEmpty) {
                    return InviteFriendMessageView(
                      userName: _queryController.text,
                    );
                  }

                  return Consumer<MentionsController>(
                    builder: (ctx, provider, child) {
                      return AppListView.builder(
                        itemCount: state.mentions.length,
                        padding: const EdgeInsets.only(
                          left: 5,
                          right: 5,
                          bottom: 80,
                        ),
                        allowPaginationHandling: true,
                        onPaginate: () {
                          bloc.add(
                            SearchForMentionsEvent(
                              query: _queryController.text,
                              fetchFirstPage: false,
                            ),
                          );
                        },
                        itemBuilder: (ctx, index) {
                          final user = HiveUser(
                            id: state.mentions[index].sourceRef ??
                                state.mentions[index].nuppId ??
                                '',
                            name: state.mentions[index].mainText,
                            username: state.mentions[index].metadata.username ??
                                state.mentions[index].secondaryText,
                            mentionSource: state.mentions[index].source,
                          );

                          return Column(
                            children: [
                              UserTileItem(
                                leadingShape:
                                    state.mentions[index].source == 'user'
                                        ? BoxShape.circle
                                        : BoxShape.rectangle,
                                user: user,
                                showFollowButton: false,
                                trailing: args.allowRemovingMentions &&
                                        provider.isMentioned(user.id)
                                    ? ConstrainedBox(
                                        constraints: const BoxConstraints(
                                          maxWidth: 80,
                                        ),
                                        child: FittedBox(
                                          child: AppActionButton.submit(
                                            text: translations.remove,
                                            height: 45,
                                            padding: const EdgeInsets.symmetric(
                                              horizontal:
                                                  15,
                                            ),
                                            fitsFullWidth: false,
                                            borderRadius: BorderRadius.circular(
                                              AppDimensions.defaultRadius,
                                            ),
                                            onPressed: args.onRemovingMention ==
                                                    null
                                                ? null
                                                : () => args
                                                    .onRemovingMention!(user),
                                          ),
                                        ),
                                      )
                                    : null,
                                onTap: args.allowRemovingMentions &&
                                        provider.isMentioned(user.id)
                                    ? null
                                    : (user) {
                                        context.pop(
                                          user
                                            ..name =
                                                '${state.mentions[index].source == 'user' ? '@' : '#'}${user.name}${ConstantValues.mentionSeparator}',
                                        );
                                      },
                              ),
                              DNGBlocBuilder<MentionsBloc, MentionsState>(
                                bloc: bloc,
                                builder: (ctx, mentionsState) {
                                  if (index != state.mentions.length - 1 ||
                                      mentionsState
                                          is! MentionsNextPageLoadingState) {
                                    return Container();
                                  }

                                  return Shimmer.fromColors(
                                    baseColor: AppColors.darkPeach2,
                                    highlightColor: AppColors.peach,
                                    child: const UserTilePlaceholder(
                                      showFollowButton: false,
                                    ),
                                  );
                                },
                              ),
                            ],
                          );
                        },
                      );
                    },
                  );
                }

                return Container();
              },
            ),
          ),
        ],
      ),
    );
  }

  @override
  void initBloc(BuildContext context, MentionsBloc bloc) {
    bloc.add(const SearchForMentionsEvent(query: ''));
  }

  void _openInviteUserFlow(BuildContext context) async {
    final invite = await AppModule.I.navigateToNamed(
      SelectInviteOptionPage.routeName,
      arguments: InviteUserPageArgs(name: _queryController.text),
    );

    if (invite != null && invite is FriendInvite) {
      context.pop(
        HiveUser(
          id: invite.id,
          name: '@${invite.name}${ConstantValues.mentionSeparator}',
          username: '',
          mentionSource: 'invite',
        ),
      );
    }
  }
}
