import 'package:equatable/equatable.dart';
import 'package:flutter_contacts/contact.dart';

abstract class ContactsResponse extends Equatable {
  final List<CharacterContacts> charContacts;

  const ContactsResponse({required this.charContacts});
}

abstract class CharacterContacts extends Equatable {
  final String character;
  final List<Contact> contacts;

  const CharacterContacts({required this.character, required this.contacts});
}
