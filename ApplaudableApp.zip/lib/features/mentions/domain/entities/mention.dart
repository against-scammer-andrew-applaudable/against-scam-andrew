import '../../../create_post/domain/entities/nupp.dart';

abstract class Mention extends Nupp {
  final bool following;

  const Mention({
    required super.description,
    required super.nuppId,
    required super.sourceRef,
    required super.source,
    required super.categoryId,
    required super.tags,
    required super.mainText,
    required super.secondaryText,
    required super.metadata,
    this.following = false,
    super.media,
  });
}
