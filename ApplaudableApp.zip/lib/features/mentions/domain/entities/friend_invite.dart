import 'package:equatable/equatable.dart';

import '../../../auth/domain/entities/user.dart';

abstract class FriendInvite extends Equatable {
  final String id;
  final String name;
  final HiveUser invitedBy;
  final HiveUser? user;
  final String? inviteCode;
  final String createdAt;

  const FriendInvite({
    required this.id,
    required this.name,
    required this.invitedBy,
    required this.user,
    this.inviteCode,
    required this.createdAt,
  });
}
