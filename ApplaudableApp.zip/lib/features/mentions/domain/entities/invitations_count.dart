import 'package:equatable/equatable.dart';

abstract class InvitationsCount extends Equatable {
  final int invitationsCount;
  final String invitationCode;

  const InvitationsCount({
    required this.invitationsCount,
    required this.invitationCode,
  });
}
