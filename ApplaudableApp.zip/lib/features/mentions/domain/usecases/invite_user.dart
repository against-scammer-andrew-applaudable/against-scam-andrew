import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../entities/friend_invite.dart';
import '../repositories/mentions_repository.dart';

class InviteUser extends UseCase<FriendInvite, InviteUserParams> {
  final MentionsRepository repository;

  InviteUser({required this.repository});

  @override
  Future<Either<Failure, FriendInvite>> call(InviteUserParams params) {
    return repository.inviteUser(
        name: params.name,
        email: params.email,
        phone: params.phone,
        notify: params.notify);
  }
}

class InviteUserParams extends Equatable {
  final String name;
  final String? email;
  final String? phone;
  final bool? notify;

  const InviteUserParams(
      {required this.name, this.email, this.phone, this.notify});

  @override
  List<Object?> get props => [name, email, phone, notify];
}
