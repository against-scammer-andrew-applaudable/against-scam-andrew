import 'package:dartz/dartz.dart';

import '../../../../core/entities/pagination_response.dart';
import '../../../../core/entities/search_params.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../entities/mention.dart';
import '../repositories/mentions_repository.dart';

class SearchForMentions
    extends UseCase<PaginationResponse<Mention>, SearchParams> {
  final MentionsRepository repository;

  SearchForMentions({required this.repository});

  @override
  Future<Either<Failure, PaginationResponse<Mention>>> call(
    SearchParams params,
  ) {
    return repository.searchForMentions(
      query: params.query,
      pageInfo: params.pageInfo,
    );
  }
}
