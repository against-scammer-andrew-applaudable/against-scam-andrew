import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../entities/contacts_response.dart';
import '../repositories/user_contacts_repository.dart';

class GetUserContacts extends UseCase<ContactsResponse, NoParams> {
  final UserContactsRepository repository;

  GetUserContacts({required this.repository});

  @override
  Future<Either<Failure, ContactsResponse>> call(NoParams params) {
    return repository.getUserContacts();
  }
}
