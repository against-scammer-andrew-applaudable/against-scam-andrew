import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../entities/invitations_count.dart';
import '../repositories/mentions_repository.dart';

class GetInvitationsCount extends UseCase<InvitationsCount, NoParams> {
  final MentionsRepository repository;

  GetInvitationsCount({required this.repository});

  @override
  Future<Either<Failure, InvitationsCount>> call(NoParams params) {
    return repository.getInvitationsCount();
  }
}
