import 'package:dartz/dartz.dart';

import '../../../../core/entities/pagination_params.dart';
import '../../../../core/entities/pagination_response.dart';
import '../../../../core/errors/failures.dart';
import '../entities/friend_invite.dart';
import '../entities/invitations_count.dart';
import '../entities/mention.dart';

abstract class MentionsRepository {
  PaginatedResults<Mention> searchForMentions({
    required String query,
    required PaginationParams pageInfo,
  });

  Future<Either<Failure, FriendInvite>> inviteUser({
    required String name,
    required String? email,
    required String? phone,
    bool? notify,
  });

  Future<Either<Failure, InvitationsCount>> getInvitationsCount();
}
