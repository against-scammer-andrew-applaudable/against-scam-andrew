import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/contacts_response.dart';

abstract class UserContactsRepository {
  Future<Either<Failure, ContactsResponse>> getUserContacts();
}
