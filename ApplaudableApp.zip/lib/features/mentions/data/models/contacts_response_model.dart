import 'package:flutter_contacts/contact.dart';

import '../../domain/entities/contacts_response.dart';

class ContactsResponseModel extends ContactsResponse {
  const ContactsResponseModel({required super.charContacts});

  factory ContactsResponseModel.fromJson(Map<String, dynamic> parsedJson) {
    return ContactsResponseModel(
      charContacts: ((parsedJson['charContacts'] ?? []) as List<dynamic>)
          .map((e) => CharacterContactsModel.fromJson(e))
          .toList(),
    );
  }

  @override
  List<Object?> get props => [charContacts];
}

class CharacterContactsModel extends CharacterContacts {
  const CharacterContactsModel({
    required super.character,
    required super.contacts,
  });

  factory CharacterContactsModel.fromJson(Map<String, dynamic> parsedJson) {
    return CharacterContactsModel(
      character: parsedJson['character'] ?? '',
      contacts: ((parsedJson['contacts'] ?? []) as List<dynamic>)
          .map((e) => Contact.fromJson(e))
          .toList(),
    );
  }

  @override
  List<Object?> get props => [character, contacts];
}
