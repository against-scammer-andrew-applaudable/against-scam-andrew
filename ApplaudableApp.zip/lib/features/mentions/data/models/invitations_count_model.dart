import '../../domain/entities/invitations_count.dart';

class InvitationsCountModel extends InvitationsCount {
  const InvitationsCountModel({
    required super.invitationsCount,
    required super.invitationCode,
  });

  factory InvitationsCountModel.fromJson(Map<String, dynamic> parsedJson) {
    return InvitationsCountModel(
      invitationCode: parsedJson['invitation_code'] ?? '',
      invitationsCount: parsedJson['number_invites'],
    );
  }

  @override
  List<Object?> get props => [invitationCode, invitationsCount];
}
