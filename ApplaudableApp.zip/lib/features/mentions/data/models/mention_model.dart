import '../../../../core/entities/pagination_response.dart';
import '../../../create_post/data/models/nupps_response_model.dart';
import '../../../create_post/data/models/post_feed_model.dart';
import '../../domain/entities/mention.dart';

class MentionModel extends Mention {
  const MentionModel({
    required super.description,
    required super.nuppId,
    required super.sourceRef,
    required super.source,
    required super.categoryId,
    required super.tags,
    required super.mainText,
    required super.secondaryText,
    required super.metadata,
    super.following = false,
    super.media,
  });

  factory MentionModel.fromJson(Map<String, dynamic> parsedJson) {
    return MentionModel(
      description: parsedJson['description'],
      nuppId: parsedJson['nupp_id'],
      source: parsedJson['source'],
      sourceRef: parsedJson['source_ref'],
      categoryId: parsedJson['category_id'],
      tags: List<String>.from(parsedJson['tags'] ?? []),
      mainText: parsedJson['structured_formatting']['main_text'],
      secondaryText:
          parsedJson['structured_formatting']['secondary_text'] ?? '',
      metadata: NuppMetaDataModel.fromJson(parsedJson['metadata']),
      media: parsedJson['media'] != null
          ? PostMediaModel.fromJson(parsedJson['media'])
          : null,
      following: parsedJson['engagement']?['following'] ?? false,
    );
  }

  @override
  List<Object?> get props => [
        description,
        nuppId,
        sourceRef,
        source,
        categoryId,
        tags,
        mainText,
        secondaryText,
        metadata,
        media,
        following
      ];
}

class MentionsResponseModel extends PaginationResponse<MentionModel> {
  const MentionsResponseModel({
    required super.count,
    required super.next,
    required super.previous,
    required super.results,
  });

  factory MentionsResponseModel.fromJson(Map<String, dynamic> parsedJson) {
    return MentionsResponseModel(
      count: parsedJson["count"] ?? 0,
      next: parsedJson["next"],
      previous: parsedJson["previous"],
      results: ((parsedJson["results"] ?? []) as List<dynamic>)
          .map((e) => MentionModel.fromJson(e))
          .toList(),
    );
  }
}
