import '../../../../core/mappers/auth_mappers.dart';
import '../../../auth/data/models/user_response_model.dart';
import '../../domain/entities/friend_invite.dart';

class FriendInviteModel extends FriendInvite {
  const FriendInviteModel({
    required super.id,
    required super.name,
    required super.invitedBy,
    required super.user,
    super.inviteCode,
    required super.createdAt,
  });

  factory FriendInviteModel.fromJson(Map<String, dynamic> parsedJson) {
    return FriendInviteModel(
      id: parsedJson['id'],
      name: parsedJson['name'],
      invitedBy: UserResponseModel.fromFriendInviteJson(
        parsedJson['invited_by'],
      ).toEntity(),
      user: parsedJson['user'] == null
          ? null
          : UserResponseModel.fromJson(parsedJson['user']).toEntity(),
      inviteCode: parsedJson['invite_code'],
      createdAt: parsedJson['created_at'],
    );
  }

  @override
  List<Object?> get props => [id, name, invitedBy, user, inviteCode, createdAt];
}
