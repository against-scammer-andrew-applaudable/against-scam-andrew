import 'package:flutter_contacts/flutter_contacts.dart';

import '../../../../core/errors/exeptions.dart';
import '../../../../core/extensions/contact_extensions.dart';
import '../models/contacts_response_model.dart';

abstract class UserContactsLocalDataSource {
  Future<ContactsResponseModel> getUserContacts();
}

class AppUserContactsLocalDataSource extends UserContactsLocalDataSource {
  @override
  Future<ContactsResponseModel> getUserContacts() async {
    // Request contact permission
    if (await FlutterContacts.requestPermission()) {
      // Get all contacts (fully fetched)
      final contacts = await FlutterContacts.getContacts(
        withProperties: true,
        withPhoto: true,
      );

      contacts.sort(_sortByName);

      final characters =
          contacts.map(_getFirstCharacterOfContactName).toSet().toList();
      characters.remove(' ');
      characters.sort((a, b) => a.compareTo(b));

      List<CharacterContactsModel> charContacts = [];

      for (final char in characters) {
        final contactsByChar = contacts
            .where((e) => _checkIfContactNameStartsWithCharacter(e, char))
            .toList();

        charContacts.add(
          CharacterContactsModel(character: char, contacts: contactsByChar),
        );
      }

      return ContactsResponseModel(charContacts: charContacts);
    }

    throw const DevicePermissionDeniedException(message: '');
  }

  int _sortByName(Contact a, Contact b) {
    final fullnameA = a.fullname;
    final fullnameB = b.fullname;

    return fullnameA.compareTo(fullnameB);
  }

  String _getFirstCharacterOfContactName(Contact contact) {
    if (contact.name.first.trim().isNotEmpty) {
      return contact.name.first.trim()[0].toUpperCase();
    }

    if (contact.name.prefix.trim().isNotEmpty) {
      return contact.name.prefix.trim()[0].toUpperCase();
    }

    if (contact.name.middle.trim().isNotEmpty) {
      return contact.name.middle.trim()[0].toUpperCase();
    }

    if (contact.name.last.trim().isNotEmpty) {
      return contact.name.last.trim()[0].toUpperCase();
    }

    if (contact.name.suffix.trim().isNotEmpty) {
      return contact.name.suffix.trim()[0].toUpperCase();
    }

    if (contact.name.nickname.trim().isNotEmpty) {
      return contact.name.nickname.trim()[0].toUpperCase();
    }

    return ' ';
  }

  bool _checkIfContactNameStartsWithCharacter(Contact contact, String char) {
    final charLowerCase = char.toLowerCase();

    if (contact.name.first.trim().isNotEmpty) {
      return contact.name.first.trim().toLowerCase().startsWith(charLowerCase);
    }

    if (contact.name.prefix.trim().isNotEmpty) {
      return contact.name.prefix.trim().toLowerCase().startsWith(charLowerCase);
    }

    if (contact.name.middle.trim().isNotEmpty) {
      return contact.name.middle.trim().toLowerCase().startsWith(charLowerCase);
    }

    if (contact.name.last.trim().isNotEmpty) {
      return contact.name.last.trim().toLowerCase().startsWith(charLowerCase);
    }

    if (contact.name.suffix.trim().isNotEmpty) {
      return contact.name.suffix.trim().toLowerCase().startsWith(charLowerCase);
    }

    if (contact.name.nickname.trim().isNotEmpty) {
      return contact.name.nickname
          .trim()
          .toLowerCase()
          .startsWith(charLowerCase);
    }

    return false;
  }
}
