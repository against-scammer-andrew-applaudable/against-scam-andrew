import 'package:flutter/foundation.dart';

import '../../../../core/api/api_config.dart';
import '../../../../core/api/api_service.dart';
import '../../../../core/api/remote_api_service.dart';
import '../../../../core/entities/pagination_params.dart';
import '../models/friend_invite_model.dart';
import '../models/invitations_count_model.dart';
import '../models/mention_model.dart';

abstract class MentionsRemoteDataSource {
  Future<MentionsResponseModel> searchForMentions({
    required String query,
    required PaginationParams pageInfo,
  });

  Future<FriendInviteModel> inviteUser({
    required String name,
    required String? email,
    required String? phone,
    bool? notify,
  });

  Future<InvitationsCountModel> getInvitationsCount();
}

class AppMentionsRemoteDataSource extends MentionsRemoteDataSource {
  ApiService _httpClient = RemoteApiService.api;

  @visibleForTesting
  set setMockApiClient(ApiService apiService) => _httpClient = apiService;

  @override
  Future<MentionsResponseModel> searchForMentions({
    required String query,
    required PaginationParams pageInfo,
  }) async {
    final parsedJson = await _httpClient.get(
      url: ApiResource.searchForMentions(query: query, pageInfo: pageInfo),
    );

    return MentionsResponseModel.fromJson(parsedJson);
  }

  @override
  Future<FriendInviteModel> inviteUser({
    required String name,
    required String? email,
    required String? phone,
    bool? notify,
  }) async {
    final parsedJson = await _httpClient.post(
      url: ApiResource.inviteUserEndpoint,
      body: {
        'name': name,
        if (email != null) 'email': email,
        if (phone != null) 'phone_number': phone,
        if (notify != null) 'notify': notify
      },
    );

    return FriendInviteModel.fromJson(parsedJson);
  }

  @override
  Future<InvitationsCountModel> getInvitationsCount() async {
    final parsedJson =
        await _httpClient.get(url: ApiResource.getUserInvitationsCount);

    return InvitationsCountModel.fromJson(parsedJson);
  }
}
