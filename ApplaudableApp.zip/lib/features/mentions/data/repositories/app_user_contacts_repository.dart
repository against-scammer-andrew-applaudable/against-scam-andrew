import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/errors/repository_call_handler.dart';
import '../../domain/entities/contacts_response.dart';
import '../../domain/repositories/user_contacts_repository.dart';
import '../datasources/user_contacts_local_data_source.dart';

class AppUserContactsRepository extends UserContactsRepository {
  final UserContactsLocalDataSource localDataSource;
  final RepositoryCallHandler callHandler;

  AppUserContactsRepository(
      {required this.localDataSource, required this.callHandler});

  @override
  Future<Either<Failure, ContactsResponse>> getUserContacts() {
    return callHandler.handleCall<ContactsResponse>(
      () => localDataSource.getUserContacts(),
    );
  }
}
