import 'package:dartz/dartz.dart';

import '../../../../core/entities/pagination_params.dart';
import '../../../../core/entities/pagination_response.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/errors/repository_call_handler.dart';
import '../../domain/entities/friend_invite.dart';
import '../../domain/entities/invitations_count.dart';
import '../../domain/entities/mention.dart';
import '../../domain/repositories/mentions_repository.dart';
import '../datasources/mentions_remote_data_source.dart';

class AppMentionsRepository extends MentionsRepository {
  final RepositoryCallHandler callHandler;
  final MentionsRemoteDataSource remoteDataSource;

  AppMentionsRepository({
    required this.callHandler,
    required this.remoteDataSource,
  });

  @override
  PaginatedResults<Mention> searchForMentions({
    required String query,
    required PaginationParams pageInfo,
  }) {
    return callHandler.handleCall<PaginationResponse<Mention>>(
      () => remoteDataSource.searchForMentions(
        query: query,
        pageInfo: pageInfo,
      ),
    );
  }

  @override
  Future<Either<Failure, FriendInvite>> inviteUser({
    required String name,
    required String? email,
    required String? phone,
    bool? notify,
  }) {
    return callHandler.handleCall<FriendInvite>(
      () => remoteDataSource.inviteUser(
          name: name, email: email, phone: phone, notify: notify),
    );
  }

  @override
  Future<Either<Failure, InvitationsCount>> getInvitationsCount() {
    return callHandler.handleCall<InvitationsCount>(
      () => remoteDataSource.getInvitationsCount(),
    );
  }
}
