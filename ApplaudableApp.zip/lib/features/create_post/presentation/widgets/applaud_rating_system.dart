import 'package:flutter/material.dart';

import '../../../../core/widgets/svg_icons.dart';
import '../../../../core/theme/dimensions.dart';

class ApplaudRatingSystem extends StatefulWidget {
  final TextEditingController controller;

  const ApplaudRatingSystem({super.key, required this.controller});

  @override
  State<ApplaudRatingSystem> createState() => _ApplaudRatingSystemState();
}

class _ApplaudRatingSystemState extends State<ApplaudRatingSystem> {
  int _rating = -1;
  //final ratingWiggleKey = GlobalKey<WiggleState>();

  @override
  void initState() {
    if (widget.controller.text.trim().isNotEmpty) {
      _rating = int.parse(widget.controller.text.trim());
    }

    widget.controller.addListener(_onNewRatingSelected);

    super.initState();
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onNewRatingSelected);

    super.dispose();
  }

  void _onNewRatingSelected() {
    if (_rating.toString() != widget.controller.text.trim()) {
      _rating = int.parse(widget.controller.text.trim());
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    /// request to be removed for now
    /*return Wiggle(
      key: ratingWiggleKey,
      child: ,
    );*/

    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        GestureDetector(
          onTap: () => _onRatingSelected('1'),
          child: _rating >= 1
              ? SvgIcons.applaudRatingFilled()
              : SvgIcons.applaudRating(),
        ),
        const SizedBox(width: AppDimensions.defaultSidePadding),
        GestureDetector(
          onTap: () => _onRatingSelected('2'),
          child: _rating >= 2
              ? SvgIcons.applaudRatingFilled()
              : SvgIcons.applaudRating(),
        ),
        const SizedBox(width: AppDimensions.defaultSidePadding),
        GestureDetector(
          onTap: () => _onRatingSelected('3'),
          child: _rating == 3
              ? SvgIcons.applaudRatingFilled()
              : SvgIcons.applaudRating(),
        ),
      ],
    );
  }

  void _onRatingSelected(String rating) {
    widget.controller.text = rating;
    //ratingWiggleKey.currentState?.wiggle();
  }
}
