import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../generated/l10n.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../auth/presentation/widgets/buttons/action_button.dart';
import '../cubit/create_post_cubit.dart';
import '../pages/post_published_confirmation_page.dart';

class PostMediaErrorView extends StatelessWidget {
  final PostConfirmationArgs args;

  const PostMediaErrorView({super.key, required this.args});

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return Padding(
      padding: const EdgeInsets.all(AppDimensions.mediumSidePadding),
      child: Column(
        children: [
          // Text(
          //   translations.post_media_upload_err_msg,
          //   textAlign: TextAlign.center,
          //   style: AppStyles.text2(color: AppColors.red).copyWith(fontSize: 15),
          // ),
          const SizedBox(height: 60),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AppActionButton.submit(
                text: translations.retry,
                fitsFullWidth: false,
                width: 160,
                onPressed: () => _retryPostMediaUpload(context),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _retryPostMediaUpload(BuildContext context) {
    final bloc = context.read<CreatePostCubit>();
    bloc.addMediaToPost(postId: args.postId, media: args.postMedia!);
  }
}
