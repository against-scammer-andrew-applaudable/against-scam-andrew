import 'dart:async';
import 'dart:convert';
import 'dart:developer';

import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';

import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/theme/styles.dart';
import '../../../../generated/l10n.dart';

class PostMentionsSection extends StatefulWidget {
  final TextEditingController? controller;
  final FutureOr<List<String>> Function()? handleAddMentionCallback;

  const PostMentionsSection({
    super.key,
    this.handleAddMentionCallback,
    this.controller,
  });

  @override
  State<PostMentionsSection> createState() => _PostMentionsSectionState();
}

class _PostMentionsSectionState extends State<PostMentionsSection> {
  List<String> _mentions = [];

  @override
  void initState() {
    final mentionsString = widget.controller?.text.trim() ?? '';

    log(mentionsString, name: 'postMentions');

    if (mentionsString.isNotEmpty) {
      _mentions = List<String>.from(json.decode(mentionsString));
    }

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return GestureDetector(
      onTap: () async {
        if (widget.handleAddMentionCallback != null) {
          _mentions = await widget.handleAddMentionCallback!();
          setState(() {});
        }
      },
      child: Card(
        elevation: 0,
        shadowColor: AppColors.lightGrey.withOpacity(0.15),
        margin: EdgeInsets.zero,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.zero,
        ),
        color: context.backgroundColor,
        child: Padding(
          padding: const EdgeInsets.all(
            AppDimensions.defaultSidePadding,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                translations.who_made_experience_great,
                style: AppStyles.text2(color: context.textColor).copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: AppDimensions.defaultSidePadding),
              if (_mentions.isNotEmpty)
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: _mentions
                      .map(
                        (e) => Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 3,
                          ),
                          decoration: BoxDecoration(
                            color: AppColors.lightGrey.withOpacity(0.45),
                          ),
                          child: Text(
                            e,
                            style: AppStyles.textSmall(
                              color: AppColors.dark,
                            ).copyWith(height: 1.1),
                          ),
                        ),
                      )
                      .toList(),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
