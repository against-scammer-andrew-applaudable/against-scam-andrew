import 'package:applaudable/core/pages/select_media_option_page.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../app_module.dart';
import '../../../../core/extensions/app_module_extensions.dart';
import '../../../../core/extensions/build_context_extensions.dart';
import '../../../../core/pages/image_gallery/camera_view.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/theme/styles.dart';
import '../../../../core/utils/formatters/capitalize_text_formatter.dart';
import '../../../../core/widgets/svg_icons.dart';
import '../../../../generated/l10n.dart';
import '../../../auth/domain/entities/user.dart';
import '../../../auth/presentation/widgets/buttons/action_button.dart';
import '../../../auth/presentation/widgets/inputs/text_field.dart';
import '../../../mentions/presentation/controllers/mentions_controller.dart';
import '../../../mentions/presentation/pages/add_mention_page.dart';
import '../pages/create_post_media_selector.dart';

class MediaPickerView extends StatefulWidget {
  final SelectedMedia? selectedMedia;
  final Function(SelectedMedia)? onMediaSelected;
  final TextEditingController? descriptionTextController;
  final GlobalKey<FormState>? descriptionFormKey;
  final List<MediaOption> options;
  final int? textMediaMaxLength;
  final bool enableMentions;

  const MediaPickerView({
    Key? key,
    required this.selectedMedia,
    this.descriptionTextController,
    this.descriptionFormKey,
    this.onMediaSelected,
    this.options = MediaOption.values,
    this.textMediaMaxLength,
    this.enableMentions = true,
  }) : super(key: key);

  @override
  State<MediaPickerView> createState() => _MediaPickerViewState();
}

class _MediaPickerViewState extends State<MediaPickerView> {
  SelectedMedia? _selectedMedia;
  final FocusNode _focusNode = FocusNode();

  @override
  void initState() {
    _selectedMedia = widget.selectedMedia;

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    final mentionsController = context.read<MentionsController>();

    return GestureDetector(
      onTap: _openGalleryToSelectMedia,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              _buildView(),
              if (widget.descriptionTextController != null)
                Expanded(
                  child: Form(
                    key: widget.descriptionFormKey,
                    child: widget.enableMentions
                        ? AppTextField.withMentions(
                            controller: widget.descriptionTextController,
                            focusNode: _focusNode,
                            hintText: translations.post_description_hint,
                            fillColor: Colors.transparent,
                            maxLines: 4,
                            textColor: AppColors.darkGrey,
                            hintColor: AppColors.darkGrey,
                            alignLabelWithHint: true,
                            maxLength: widget.textMediaMaxLength,
                            useDefaultHeight: false,
                            onMentionAdded: mentionsController.insertMention,
                            onMentionRemoved:
                                mentionsController.removeMentionAt,
                            inputFormatters: [
                              CapitalizeTextFormatter(
                                capitalization: TextCapitalization.sentences,
                              )
                            ],
                            validator: (value) {
                              if ((value == null || value.trim().isEmpty) &&
                                  _selectedMedia == null) {
                                return translations
                                    .description_is_required_err_msg;
                              }

                              return null;
                            },
                          )
                        : AppTextField(
                            controller: widget.descriptionTextController,
                            focusNode: _focusNode,
                            hintText: translations.post_description_hint,
                            fillColor: Colors.transparent,
                            maxLines: 4,
                            textColor: AppColors.darkGrey,
                            hintColor: AppColors.darkGrey,
                            alignLabelWithHint: true,
                            maxLength: widget.textMediaMaxLength,
                            useDefaultHeight: false,
                            onMentionAdded: mentionsController.insertMention,
                            onMentionRemoved:
                                mentionsController.removeMentionAt,
                            inputFormatters: [
                              CapitalizeTextFormatter(
                                capitalization: TextCapitalization.sentences,
                              )
                            ],
                            validator: (value) {
                              if ((value == null || value.trim().isEmpty) &&
                                  _selectedMedia == null) {
                                return translations
                                    .description_is_required_err_msg;
                              }

                              return null;
                            },
                          ),
                  ),
                ),
            ],
          ),
          if (widget.descriptionTextController != null && widget.enableMentions)
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AppActionButton.submitWithBorder(
                  text: translations.mention,
                  onPressed: () async {
                    context.unfocus();

                    final user = await AppModule.I
                        .navigateToNamed(AddMentionPage.routeName);

                    if (user != null && user is HiveUser) {
                      widget.descriptionTextController?.text =
                          '${widget.descriptionTextController?.text.trimRight()} ${user.name} '
                              .trimLeft();
                      mentionsController.addMention(
                          user.id, user.mentionSource);
                      _focusNode.requestFocus();
                    }
                  },
                  fitsFullWidth: false,
                  padding: const EdgeInsets.symmetric(
                    horizontal: AppDimensions.mediumSidePadding,
                  ),
                  height: 30,
                  actionTextSize: 14,
                  actionTextWeight: FontWeight.w400,
                  actionTextColor: AppColors.darkGrey,
                  borderColor: AppColors.mediumGrey,
                ),
              ],
            ),
        ],
      ),
    );
  }

  Widget _buildView() {
    if (_selectedMedia != null) {
      switch (_selectedMedia!.type) {
        case MediaType.image:
          return Image.file(
            _selectedMedia!.file,
            height: 100,
            width: 90,
            fit: BoxFit.cover,
          );
        case MediaType.video:
          // TODO: Handle this case.
          return const Center(child: Text('Video'));
        case MediaType.text:
          return ColoredBox(
            color: AppColors.darkPeach2,
            child: SizedBox(
              height: 100,
              width: 90,
              child: Padding(
                padding: const EdgeInsets.all(
                  10,
                ),
                child: Center(
                  child: Text(
                    _selectedMedia!.text,
                    style: AppStyles.text2(
                      color: AppColors.white,
                    ).copyWith(
                      fontWeight: FontWeight.bold,
                      fontSize: 8,
                    ),
                  ),
                ),
              ),
            ),
          );
      }
    }

    final translations = S.of(context);

    return DottedBorder(
      color: AppColors.darkPeach2,
      child: Container(
        color: context.scaffoldBackgroundColor,
        padding: const EdgeInsets.symmetric(
          horizontal: AppDimensions.smallSidePadding,
          vertical: 25,
        ),
        child: Column(
          children: [
            SvgIcons.plus(),
            const SizedBox(height: 12),
            Text(translations.add_media),
          ],
        ),
      ),
    );
  }

  void _openGalleryToSelectMedia() async {
    final selectedMedia = await AppModule.I.navigateToNamed(
      SelectMediaOptionPage.routeName,
      arguments: MediaSelectorArgs(
        selectedMedia: _selectedMedia,
        options: widget.options,
      ),
    );

    if (selectedMedia != null && selectedMedia is SelectedMedia?) {
      _selectedMedia = selectedMedia as SelectedMedia;

      setState(() {});

      if (widget.onMediaSelected != null) {
        widget.onMediaSelected!(selectedMedia);
      }
    }
  }
}
