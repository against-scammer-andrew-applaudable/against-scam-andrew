import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

import '../../../../core/widgets/loading/shimmer_placeholder_box.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';

class PostNuppsLoadingView extends StatelessWidget {
  const PostNuppsLoadingView({super.key});

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: AppColors.lightPeach,
      highlightColor: AppColors.darkPeach,
      child: ListView.separated(
        itemCount: 10,
        separatorBuilder: (_, __) =>
            const SizedBox(height: 12),
        itemBuilder: (_, __) {
          return const NuppLoadingView();
        },
      ),
    );
  }
}

class NuppLoadingView extends StatelessWidget {
  const NuppLoadingView({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return IntrinsicHeight(
      child: Row(
        children: [
          Container(
            height: 70,
            width: 60,
            color: Colors.white,
          ),
          const SizedBox(width: AppDimensions.smallSidePadding),
          const Expanded(
            child: Padding(
              padding: EdgeInsets.symmetric(
                vertical: AppDimensions.smallSidePadding,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: ShimmerPlaceholderBox(
                      height: 10,
                      width: 150,
                    ),
                  ),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: ShimmerPlaceholderBox(
                      height: 10,
                      width: 100,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(right: 10),
                    child: ShimmerPlaceholderBox(
                      height: 10,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
