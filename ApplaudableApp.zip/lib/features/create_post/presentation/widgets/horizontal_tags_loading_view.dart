import 'package:flutter/material.dart';

import '../../../../core/widgets/animations/shimmer_loading_chip.dart';
import '../../../../core/theme/dimensions.dart';

class HorizontalTagsLoadingView extends StatelessWidget {
  const HorizontalTagsLoadingView({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 50,
      child: ListView.separated(
        itemCount: 8,
        scrollDirection: Axis.horizontal,
        separatorBuilder: (_, __) =>
            const SizedBox(width: AppDimensions.smallSidePadding),
        itemBuilder: (ctx, idnex) {
          return const ShimmerLoadingChip();
        },
      ),
    );
  }
}
