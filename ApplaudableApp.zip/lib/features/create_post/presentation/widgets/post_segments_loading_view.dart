import 'package:flutter/material.dart';

import '../../../../core/theme/dimensions.dart';
import '../../../../core/widgets/animations/pagination_loading_view.dart';
import '../../../../core/widgets/app_listview.dart';

class PostSegmentsLoadingView extends StatelessWidget {
  const PostSegmentsLoadingView({super.key});

  @override
  Widget build(BuildContext context) {
    return AppListView.separated(
      separatorBuilder: (_, __) => const SizedBox(
        height: AppDimensions.defaultSidePadding,
      ),
      itemCount: 6,
      itemBuilder: (_, __) {
        return const PaginationLoadingView(
          minHeight: 50,
          radius: 15,
        );
      },
    );
  }
}
