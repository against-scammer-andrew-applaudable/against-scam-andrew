import 'dart:math';

import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

import '../../../../core/theme/colors.dart';
import '../../../../core/theme/styles.dart';
import '../../../../generated/l10n.dart';
import 'story_question_item_loading_container.dart';

class StoryQuestionsShimmerLoadingView extends StatelessWidget {
  const StoryQuestionsShimmerLoadingView({super.key});

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return Shimmer.fromColors(
      baseColor: AppColors.darkPeach2.withOpacity(0.5),
      highlightColor: AppColors.darkPeach,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Text(
              translations.select_a_question,
              style: AppStyles.header1(color: context.textColor),
            ),
          ),
          Expanded(
            child: ListView.builder(
              physics: const NeverScrollableScrollPhysics(),
              itemCount: 15,
              itemBuilder: (context, index) {
                final transformVal = Random().nextDouble() * 16;

                return Transform.translate(
                  offset: index.isOdd
                      ? Offset(transformVal, 0)
                      : Offset(-transformVal, 0),
                  child: Row(
                    mainAxisAlignment: index.isOdd
                        ? MainAxisAlignment.end
                        : MainAxisAlignment.start,
                    children: const [
                      Flexible(
                        child: StoryQuestionItemLoadingContainer(),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
