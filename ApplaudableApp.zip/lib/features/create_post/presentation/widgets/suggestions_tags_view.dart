import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../core/widgets/animations/shimmer_loading_chip.dart';
import '../../../../core/widgets/app_chip.dart';
import '../../../../generated/l10n.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/theme/styles.dart';
import '../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../../domain/enums/create_post_enums.dart';
import '../providers/selected_post_tags_controller.dart';

class SuggestionsTagsView extends StatelessWidget {
  final String postId;

  const SuggestionsTagsView({super.key, required this.postId});

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return Consumer<SelectedPostTagsController>(
      builder: (context, provider, child) {
        return Visibility(
          maintainSize: true,
          maintainAnimation: true,
          maintainState: true,
          visible: provider.shouldShowTagsOnConfirmation,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              if (provider.suggestions.isNotEmpty)
                AppSideMargins(
                  marginValue: AppDimensions.extraLargeSidePadding,
                  child: Text(
                    translations.post_confirmation_desc,
                    style: AppStyles.text2(color: AppColors.darkGrey),
                    textAlign: TextAlign.center,
                  ),
                ),
              const SizedBox(height: AppDimensions.largeSidePadding),
              Wrap(
                spacing: AppDimensions.smallSidePadding,
                alignment: WrapAlignment.center,
                children: List.generate(
                  provider.suggestions.length,
                  (index) => provider.statesIds
                              .contains(provider.suggestions[index].id) &&
                          provider
                                  .stateOf(provider.suggestions[index].id)
                                  .status ==
                              UpdateTagStatus.loading
                      ? ShimmerLoadingChip(
                          label: provider.suggestions[index].label,
                        )
                      : AppChip(
                          title: provider.suggestions[index].label,
                          titleColor: AppColors.darkPeach2,
                          padding: EdgeInsets.zero,
                          selectionColor: AppColors.darkPeach2,
                          borderColor: AppColors.darkPeach.shade100,
                          isSelected:
                              provider.isSelected(provider.suggestions[index]),
                          onTap: () => provider.updatePostTagOnServer(
                            postId: postId,
                            tag: provider.suggestions[index],
                            mode:
                                provider.isSelected(provider.suggestions[index])
                                    ? PostTagMode.remove
                                    : PostTagMode.add,
                          ),
                        ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
