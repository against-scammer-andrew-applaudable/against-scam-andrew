import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:applaudable/core/extensions/string_extensions.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/theme/styles.dart';
import '../../../../core/widgets/buttons/app_checkbox.dart';
import '../../../../core/widgets/svg_icons.dart';
import '../../../../injection_container.dart';
import '../../../post_categories/domain/entities/post_category.dart';
import '../providers/post_segment_categories_controller.dart';
import '../providers/selected_post_tags_controller.dart';

class SegmentTileView extends StatelessWidget {
  final PostFeedSegment segmentData;
  final VoidCallback? onSegmentSelected;

  const SegmentTileView({
    super.key,
    required this.segmentData,
    this.onSegmentSelected,
  });

  @override
  Widget build(BuildContext context) {
    final controller = context.read<PostSegmentCategoriesController>();
    final tagsController = servLocator<SelectedPostTagsController>();

    return GestureDetector(
      onTap: () {
        controller.selectSegment(segmentData.segment);

        if (onSegmentSelected != null) onSegmentSelected!();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 500),
        decoration: BoxDecoration(
          color: context.backgroundColor,
          border: Border.all(color: AppColors.mediumGrey),
          borderRadius: BorderRadius.circular(
            AppDimensions.radius_15,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 25,
                vertical: 20,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    segmentData.segmentDisplay.capitalize(),
                    style: AppStyles.text2(color: context.textColor).copyWith(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      height: 1,
                    ),
                  ),
                  if (controller.isSelected(segmentData.segment))
                    SvgIcons.checkConfirm(
                      height: 12,
                      color: AppColors.primaryColor,
                    ),
                ],
              ),
            ),
            if (controller.isSelected(segmentData.segment)) ...[
              const Divider(
                color: AppColors.darkPeach,
                height: AppDimensions.zero,
                indent: 15,
                endIndent: 15,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 25,
                  vertical: 20,
                ),
                child: ListView.separated(
                  separatorBuilder: (_, __) {
                    return const SizedBox(
                      height: 10,
                    );
                  },
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: segmentData.categories.length,
                  itemBuilder: (ctx, catIndex) {
                    final category = segmentData.categories[catIndex];

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Text(
                          category.name,
                          style: AppStyles.text2(
                            color: AppColors.darkGrey,
                          ).copyWith(
                            fontWeight: FontWeight.bold,
                            height: 1,
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: List.generate(
                            category.tags.length,
                            (tagIndex) {
                              final tag = category.tags[tagIndex];

                              return AppCheckbox(
                                value: controller.isTagSelected(tag.id),
                                label: Text(
                                  tag.label,
                                  style: AppStyles.text2(
                                    color: AppColors.darkGrey,
                                  ).copyWith(
                                    fontSize: 14,
                                    height: 1,
                                  ),
                                ),
                                onChanged: (_) {
                                  controller.selectTag(tag.id);
                                  tagsController.selectTag(tag);
                                },
                                margin: const EdgeInsets.symmetric(
                                  vertical: AppDimensions.smallSidePadding,
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
