import 'package:flutter/material.dart';

import '../../../../core/widgets/media_avatar_placeholder.dart';
import '../../../../core/widgets/optimized_cached_network_image.dart';
import '../../domain/entities/nupp.dart';

class NuppMediaAvatar extends StatelessWidget {
  const NuppMediaAvatar({
    Key? key,
    required this.nupp,
    required this.segment,
  }) : super(key: key);

  final Nupp nupp;
  final String segment;

  @override
  Widget build(BuildContext context) {
    return OptimizedCachedNetworkImage(
      imageUrl: nupp.media?.url,
      imageBuilder: (context, imageProvider) {
        return MediaAvatarContainer(
          shape: segment == 'someone' || segment == 'people'
              ? BoxShape.circle
              : BoxShape.rectangle,
          color: Colors.white60,
          image: nupp.media != null
              ? DecorationImage(
                  image: imageProvider,
                  fit: BoxFit.cover,
                )
              : null,
        );
      },
      defaultProgressViewShape: segment == 'someone' || segment == 'people'
          ? BoxShape.circle
          : BoxShape.rectangle,
      defaultProgressIconHeight: 25,
    );
  }
}
