import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';

import '../../../../core/pages/image_gallery/camera_view.dart';
import '../../../../generated/l10n.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/styles.dart';
import '../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../pages/create_post_media_selector.dart';

class PostTextEditor extends StatefulWidget {
  final SelectedMedia? selectedMedia;
  final TextEditingController controller;
  final Function(MediaStatus)? onMediaStatusChanged;

  const PostTextEditor({
    Key? key,
    required this.controller,
    this.onMediaStatusChanged,
    this.selectedMedia,
  }) : super(key: key);

  @override
  State<PostTextEditor> createState() => PostTextEditorState();
}

class PostTextEditorState extends State<PostTextEditor>
    with AutomaticKeepAliveClientMixin {
  bool _isTyping = false;
  final _focusNode = FocusNode();
  late S translations;

  @override
  void initState() {
    if (widget.selectedMedia != null &&
        widget.selectedMedia!.source == MediaSource.textEditor) {
      widget.controller.text = widget.selectedMedia!.text;

      if (widget.onMediaStatusChanged != null) {
        widget.onMediaStatusChanged!(MediaStatus.editingMedia);
      }
    }

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    translations = S.of(context);

    return AppSideMargins(
      child: GestureDetector(
        onTap: onCanvasTapped,
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.darkPeach2,
            borderRadius: BorderRadius.circular(12),
          ),
          child: AppSideMargins(
            marginValue: 50,
            child: Center(
              child: _isTyping
                  ? TextField(
                      controller: widget.controller,
                      focusNode: _focusNode,
                      style: AppStyles.text1(color: AppColors.white).copyWith(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        height: 1.2,
                      ),
                      maxLines: null,
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: translations.post_text_editor_hint,
                        hintStyle: AppStyles.text1(color: context.textColor).copyWith(
                          fontSize: 18,
                          color: AppColors.darkPeach,
                          fontWeight: FontWeight.normal,
                          height: 1,
                        ),
                      ),
                      cursorColor: Colors.black,
                      cursorHeight: 23,
                      cursorWidth: 1,
                      maxLength: 240,
                      buildCounter: (
                        context, {
                        required int currentLength,
                        required bool isFocused,
                        int? maxLength,
                      }) {
                        return const SizedBox();
                      },
                    )
                  : Padding(
                      padding: widget.controller.text.trim().isEmpty
                          ? const EdgeInsets.symmetric(
                              horizontal: 50,
                            )
                          : EdgeInsets.zero,
                      child: Text(
                        widget.controller.text.trim().isEmpty
                            ? translations.tap_to_write_hint
                            : widget.controller.text.trim(),
                        style: AppStyles.text1(color: AppColors.white).copyWith(
                          fontSize: widget.controller.text.trim().isEmpty
                              ? 20
                              : 28,
                          fontStyle: FontStyle.italic,
                          height: 1.2,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
            ),
          ),
        ),
      ),
    );
  }

  void onCanvasTapped() {
    _isTyping = !_isTyping;
    setState(() {});

    if (!_isTyping) {
      if (widget.controller.text.trim().isNotEmpty) {
        if (widget.onMediaStatusChanged != null) {
          widget.onMediaStatusChanged!(MediaStatus.textOrCameraPreview);
        }
      } else {
        if (widget.onMediaStatusChanged != null) {
          widget.onMediaStatusChanged!(MediaStatus.error);
        }
      }
    } else {
      if (widget.onMediaStatusChanged != null) {
        widget.onMediaStatusChanged!(MediaStatus.typing);
      }
    }

    _focusNode.requestFocus();
  }

  @override
  bool get wantKeepAlive => true;
}
