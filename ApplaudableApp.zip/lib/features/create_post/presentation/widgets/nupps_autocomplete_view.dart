import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../core/bloc/widgets/base_stateless_page.dart';
import '../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../core/widgets/app_listview.dart';
import '../../../../core/widgets/svg_icons.dart';
import '../../../../generated/l10n.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/theme/styles.dart';
import '../../data/models/post_feed_model.dart';
import '../blocs/nupps_bloc/nupps_bloc.dart';
import '../pages/create_post_page/steps/post_name_or_title_step.dart';
import '../providers/selected_nupp_controller.dart';
import '../providers/selected_post_tags_controller.dart';
import 'post_nupp_item.dart';
import 'post_nupps_loading_view.dart';

// ignore: must_be_immutable
class AutocompleteNuppsView extends BaseStatelessPage<NuppsBloc, NuppsState> {
  final TextEditingController nameTextController;
  final Function(SelectedNuppData)? onNuppSelected;
  final Function(String)? onLocationSelected;
  final bool isSelectingLocation;

  AutocompleteNuppsView({
    Key? key,
    required this.nameTextController,
    this.onNuppSelected,
    this.onLocationSelected,
    this.isSelectingLocation = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    registerBloc(context);

    final translations = S.of(context);

    return DNGBlocBuilder<NuppsBloc, NuppsState>(
      bloc: bloc,
      buildWhen: (state) =>
          state is NuppsInitialState ||
          state is NuppsLoadingState ||
          state is NuppsErrorState ||
          state is NuppsFetchedState,
      builder: (context, state) {
        if (state is NuppsLoadingState) {
          return const PostNuppsLoadingView();
        } else if (state is NuppsErrorState) {
          return Padding(
            padding: const EdgeInsets.all(AppDimensions.defaultSidePadding),
            child: Center(
              child: Text(state.message, textAlign: TextAlign.center),
            ),
          );
        } else if (state is NuppsFetchedState && nameTextController.text.trim().isNotEmpty) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // if (state.segment != 'someone' && state.segment != 'people') ...[
              if (!isSelectingLocation)
                ColoredBox(
                  color:
                      // state.segment == 'someone' || state.segment == 'people'
                      //     ? AppColors.lightGrey.withOpacity(0.3)
                      //     :
                      AppColors.transparent,
                  child: InkWell(
                    onTap:
                        //  state.segment == 'someone' || state.segment == 'people'
                        //     ? null
                        //     :
                        () {
                      context.read<SelectedNuppController>().reset();

                      _createNewPostTextNupp(
                        SelectedNuppData(
                          type: PostNuppType.newNupp,
                          nupp: CreatePostNuppDataModel(
                            type: 'nupp',
                            name: nameTextController.text,
                          ),
                        ),
                      );
                    },
                    child: IntrinsicHeight(
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              border: Border.all(
                                color:
                                    //  state.segment == 'someone' || state.segment == 'people'
                                    //     ? AppColors.darkPeach
                                    //     :
                                    AppColors.darkPeach2,
                              ),
                            ),
                            constraints: const BoxConstraints(maxWidth: 70),
                            child: AspectRatio(
                              aspectRatio: 0.88,
                              child: Container(
                                color: Colors.white60,
                                child: Center(
                                  child: SvgIcons.plus(
                                    color: AppColors.darkPeach2,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: AppDimensions.smallSidePadding),
                          Expanded(
                            child: ConstrainedBox(
                              constraints: const BoxConstraints(minHeight: 65),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Text(
                                      // state.segment == 'someone' || state.segment == 'people'
                                      //     ? translations.cant_invite_users_msg
                                      //     :
                                      '${translations.continue_with} ${nameTextController.text.trim()}',
                                      style: AppStyles.header2(
                                        color:
                                            //  state.segment == 'someone' || state.segment == 'people'
                                            //     ? AppColors.darkGrey.withOpacity(0.6)
                                            //     :
                                            // AppColors.dark,
                                        context.textColor
                                      ),
                                      maxLines: 3,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              const SizedBox(height: 12),
              // ],
              Flexible(
                child: AppListView.separated(
                  itemCount: state.nupps.length,
                  allowPaginationHandling: true,
                  paginationThreshold: 100,
                  padding: const EdgeInsets.only(bottom: 100),
                  onPaginate: () {
                    final tagsController =
                        context.read<SelectedPostTagsController>();
                    bloc.add(
                      GetAutocompleteNuppsEvent(
                        segment: state.segment,
                        query: nameTextController.text.trim(),
                        categoryId: tagsController.selectedCategory?.id,
                        fetchFirstPage: false,
                      ),
                    );
                  },
                  separatorBuilder: (_, __) =>
                      const SizedBox(height: 12),
                  itemBuilder: (ctx, index) {
                    return Column(
                      children: [
                        GestureDetector(
                          onTap: isSelectingLocation
                              ? (onLocationSelected == null
                                  ? null
                                  : () => onLocationSelected!(
                                        state.nupps[index].mainText,
                                      ))
                              : null,
                          child: PostNuppItem(
                            nupp: state.nupps[index],
                            segment: state.segment,
                            onNameOrTitleSelected: onNuppSelected,
                          ),
                        ),
                        DNGBlocBuilder<NuppsBloc, NuppsState>(
                          bloc: bloc,
                          builder: (ctx, nuppsState) {
                            if (index != state.nupps.length - 1 ||
                                nuppsState is! NuppsNextPageLoadingState) {
                              return Container();
                            }

                            return const Padding(
                              padding: EdgeInsets.symmetric(
                                vertical: 12,
                              ),
                              child: NuppLoadingView(),
                            );
                          },
                        ),
                      ],
                    );
                  },
                ),
              ),
            ],
          );
        }

        return Container();
      },
    );
  }

  void _createNewPostTextNupp(SelectedNuppData collection) {
    if (onNuppSelected != null) onNuppSelected!(collection);
  }
}
