import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../core/theme/colors.dart';
import '../providers/selected_nupp_controller.dart';
import 'post_nupp_item.dart';

class PostMediaUploadView extends StatelessWidget {
  final int progress;
  final int total;

  const PostMediaUploadView({
    super.key,
    required this.progress,
    required this.total,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Consumer<SelectedNuppController>(
          builder: (context, provider, child) {
            if (provider.selectedNupp == null) {
              return Container();
            }

            return PostNuppItem(nupp: provider.selectedNupp!);
          },
        ),
        const SizedBox(height: 20),
        Container(
          height: 4.5,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: AppColors.darkPeach2,
          ),
          alignment: Alignment.centerLeft,
          child: FractionallySizedBox(
            widthFactor: total == 0 ? 0 : progress / total,
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(
                  12,
                ),
                color: AppColors.primaryColor,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
