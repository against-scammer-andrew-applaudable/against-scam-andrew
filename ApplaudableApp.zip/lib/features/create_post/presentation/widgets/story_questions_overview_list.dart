import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../core/widgets/app_listview.dart';
import '../../domain/entities/story_question.dart';
import '../blocs/story_questions_bloc/story_questions_bloc.dart';
import '../pages/create_post_page/create_post_page.dart';
import 'story_question_pagination_loading_view.dart';
import 'story_question_view.dart';

class StoryQuestionsOverviewList extends StatelessWidget {
  final List<StoryQuestion> questions;
  final StoryQuestionCollection? collection;
  final CreatePostFrom from;

  const StoryQuestionsOverviewList(
      {super.key,
      required this.questions,
      this.collection,
      this.from = CreatePostFrom.home});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        AppListView.builder(
          itemCount: questions.length,
          allowPaginationHandling: true,
          onPaginate: () {
            final bloc = context.read<StoryQuestionsBloc>();

            bloc.add(
              const GetSuggestedStoryQuestionsEvent(
                paginate: true,
              ),
            );
          },
          itemBuilder: (ctx, index) {
            final transformVal = Random().nextDouble() * 16;

            return Transform.translate(
              offset: index.isOdd
                  ? Offset(transformVal, 0)
                  : Offset(-transformVal, 0),
              child: Row(
                mainAxisAlignment: index.isOdd
                    ? MainAxisAlignment.end
                    : MainAxisAlignment.start,
                children: [
                  StoryQuestionView(
                    question: questions[index],
                    isOdd: index.isOdd,
                    from: from,
                    collection: collection,
                  )
                ],
              ),
            );
          },
        ),
        const StoryQuestionsPaginationLoadingView(),
      ],
    );
  }
}
