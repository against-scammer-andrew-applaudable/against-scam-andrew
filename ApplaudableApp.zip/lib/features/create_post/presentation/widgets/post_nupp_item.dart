import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/theme/styles.dart';
import '../../data/models/post_feed_model.dart';
import '../../domain/entities/nupp.dart';
import '../pages/create_post_page/steps/post_name_or_title_step.dart';
import '../providers/selected_nupp_controller.dart';
import 'nupp_media_avatar.dart';

class PostNuppItem extends StatelessWidget {
  final Nupp nupp;
  final String segment;
  final Function(SelectedNuppData)? onNameOrTitleSelected;

  const PostNuppItem({
    super.key,
    required this.nupp,
    this.segment = '',
    this.onNameOrTitleSelected,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onNameOrTitleSelected == null
          ? null
          : () {
              context.read<SelectedNuppController>().selectNupp(nupp, segment);

              onNameOrTitleSelected!(
                SelectedNuppData(
                  type: nupp.nuppId == null
                      ? PostNuppType.fetchedFromGPlaces
                      : PostNuppType.exsitingNupp,
                  nupp: nupp.nuppId == null
                      ? CreatePostNuppDataModel(
                          type: 'nupp',
                          name: nupp.mainText.isNotEmpty
                              ? nupp.mainText
                              : nupp.description,
                          source: nupp.source,
                          sourceRef: nupp.sourceRef,
                        )
                      : null,
                  useNuppId: (segment == 'someone' || segment == 'people') &&
                      nupp.sourceRef == null,
                  nuppId: (segment == 'someone' || segment == 'people')
                      ? nupp.sourceRef ?? nupp.nuppId
                      : nupp.nuppId,
                ),
              );
            },
      child: IntrinsicHeight(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 70, minHeight: 65),
              child: AspectRatio(
                aspectRatio: 0.88,
                child: NuppMediaAvatar(nupp: nupp, segment: segment),
              ),
            ),
            const SizedBox(width: AppDimensions.smallSidePadding),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    nupp.mainText,
                    style:
                        AppStyles.text2(color: context.textColor).copyWith(fontWeight: FontWeight.w600),
                    maxLines: 1,
                  ),
                  if (nupp.secondaryText.isNotEmpty)
                    Text(
                      nupp.secondaryText,
                      style: AppStyles.text2(color: AppColors.darkGrey)
                          .copyWith(fontWeight: FontWeight.w400, fontSize: 15),
                      maxLines: 1,
                    ),
                  Text(
                    nupp.description,
                    style: AppStyles.text2(color: AppColors.mediumGrey)
                        .copyWith(fontWeight: FontWeight.w400, fontSize: 15),
                    maxLines: 1,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
