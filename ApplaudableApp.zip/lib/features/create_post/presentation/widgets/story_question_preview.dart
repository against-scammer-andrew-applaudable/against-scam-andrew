import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';

import '../../../../app_module.dart';
import '../../../../core/constants/constant_keys.dart';
import '../../../../core/extensions/app_module_extensions.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/theme/styles.dart';
import '../../../../generated/l10n.dart';
import '../../../../injection_container.dart';
import '../../../auth/presentation/widgets/buttons/action_button.dart';
import '../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../blocs/improve_story_text_bloc/improve_story_text_bloc.dart';
import '../pages/create_story_confirmation_page.dart';
import '../pages/edit_story_question_page.dart';
import '../providers/selected_tones_controller.dart';
import 'improve_text_with_ai_bottom_sheet.dart';

class StoryQuestionPreview extends StatefulWidget {
  final CreateStoryConfirmationPageArgs args;

  const StoryQuestionPreview({super.key, required this.args});

  @override
  State<StoryQuestionPreview> createState() => _StoryQuestionPreviewState();
}

class _StoryQuestionPreviewState extends State<StoryQuestionPreview> {
  late String _title;
  late String _text;

  @override
  void initState() {
    _title = widget.args.postTitleController.text;
    _text = widget.args.userAnswerController.text;

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return AppSideMargins(
      marginValue: 20,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Flexible(child: Text(_title, style: AppStyles.header1(color: context.textColor))),
                  // const SizedBox(width: 10),
                  IconButton(
                    key: ConstantKeys.storyConfirmationEditQuesBtnKey,
                    onPressed: () async {
                      final result = await AppModule.I.navigateToNamed(
                        EditStoryQuestionPage.routeName,
                        arguments: EditStoryQuestionPageArgs(
                          title: _title,
                          text: _text,
                        ),
                      );

                      if (result != null &&
                          result is EditStoryQuestionPageArgs) {
                        widget.args.userAnswerController.text = result.text;
                        widget.args.postTitleController.text = result.title;

                        setState(() {
                          _title = result.title;
                          _text = result.text;
                        });
                      }
                    },
                    icon: SvgPicture.asset('assets/icons/ic_edit.svg'),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(_text, style: AppStyles.text2(color: AppColors.darkGrey)),
            ],
          ),
          const SizedBox(height: 15),
          Row(
            children: [
              AppActionButton.submitWithBorder(
                key: ConstantKeys.improveWithAIBtnKey,
                backgroundColor: Colors.transparent,
                borderColor: AppColors.primaryColor,
                actionTextColor: AppColors.primaryColor,
                fitsFullWidth: false,
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                ),
                height: 40,
                text: translations.ai_improve_my_text,
                onPressed: () async {
                  final collectionId = widget.args.storyQuestion.collection.id;

                  final improveWithAPISheet = MultiProvider(
                    providers: [
                      Provider.value(
                        value: servLocator<ImproveStoryTextBloc>(),
                      ),
                      ChangeNotifierProvider.value(
                        value: servLocator<SelectedTonesController>(),
                      )
                    ],
                    child: ImproveTextWithAIBottomSheet(
                      args: ImproveTextWithAIBottomSheetArgs(
                        question: widget.args.storyQuestion.question,
                        title: widget.args.postTitleController.text,
                        text: _text,
                        tones: widget.args.storyQuestion.tones,
                        collections: [collectionId],
                      ),
                    ),
                  );

                  final improvedText = await showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    backgroundColor: AppColors.lightPeach,
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(AppDimensions.radius_24),
                        topRight: Radius.circular(AppDimensions.radius_24),
                      ),
                    ),
                    builder: (ctx) {
                      return improveWithAPISheet;
                    },
                  );

                  if (improvedText != null && improvedText is String) {
                    widget.args.userAnswerController.text = improvedText;
                    setState(() {
                      _text = improvedText;
                    });
                  }
                },
              ),
            ],
          ),
        ],
      ),
    );
  }
}
