import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../core/bloc/widgets/base_stateless_page.dart';
import '../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../core/extensions/build_context_extensions.dart';
import '../../../../core/widgets/app_chip.dart';
import '../../../../core/widgets/app_listview.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../post_categories/domain/entities/post_category.dart';
import '../../../post_categories/presentation/blocs/post_categories_bloc/post_categories_bloc.dart';
import '../providers/selected_post_tags_controller.dart';
import 'horizontal_tags_loading_view.dart';

// ignore: must_be_immutable
class PostCategoriesSelector
    extends BaseStatelessPage<PostCategoriesBloc, PostCategoriesState> {
  PostCategoriesSelector({super.key});

  @override
  Widget build(BuildContext context) {
    registerBloc(context);

    return DNGBlocBuilder<PostCategoriesBloc, PostCategoriesState>(
      bloc: bloc,
      buildWhen: (state) =>
          state is PostCategoriesLoadingState ||
          state is PostCategoriesErrorState ||
          state is PostCategoriesFetchedState,
      builder: (context, state) {
        if (state is PostCategoriesLoadingState) {
          return const HorizontalTagsLoadingView();
        } else if (state is PostCategoriesErrorState) {
          return Center(
            child: Text(state.message, textAlign: TextAlign.center),
          );
        } else if (state is PostCategoriesFetchedState) {
          return Consumer<SelectedPostTagsController>(
            builder: (context, provider, child) {
              var isShowingTags = provider.selectedCategory != null;

              final tags = <PostTag>[];
              for (final category in state.categories) {
                tags.addAll(category.tags);
              }
              if (tags.length > 10) {
                provider.setSuggestionsTags(tags.sublist(0, 11));
              } else {
                provider.setSuggestionsTags(tags);
              }

              return SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    maxHeight: 50,
                    maxWidth: context.screenWidth,
                  ),
                  child: Row(
                    children: [
                      if (isShowingTags)
                        SizedBox(
                          width: provider.selectedCategory!.label.length >= 9
                              ? 90
                              : null,
                          child: Row(
                            children: [
                              Flexible(
                                flex:
                                    provider.selectedCategory!.label.length >= 9
                                        ? 1
                                        : 0,
                                child: AppChip(
                                  title: provider.selectedCategory!.label,
                                  titleColor: AppColors.darkPeach2,
                                  padding: EdgeInsets.zero,
                                  borderColor: AppColors.darkPeach2,
                                  isSelected: true,
                                  onTap: provider.unselectPostCategory,
                                ),
                              ),
                              const SizedBox(
                                width: AppDimensions.smallSidePadding,
                              ),
                            ],
                          ),
                        ),
                      Expanded(
                        child: AppListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: isShowingTags
                              ? provider.selectedCategory!.tags.length
                              : state.categories.length,
                          padding: const EdgeInsets.only(
                            right: 80,
                          ),
                          separatorBuilder: (_, __) => const SizedBox(
                            width: AppDimensions.smallSidePadding,
                          ),
                          itemBuilder: (context, index) {
                            final tag = provider.selectedCategory?.tags[index];

                            final chipLabel = isShowingTags
                                ? tag!.label
                                : state.categories[index].label;

                            return AppChip(
                              title: chipLabel,
                              titleColor: AppColors.darkPeach2,
                              padding: EdgeInsets.zero,
                              borderColor: AppColors.darkPeach2,
                              selectionColor: AppColors.darkPeach2,
                              isSelected: isShowingTags
                                  ? provider.isSelected(
                                      provider.selectedCategory!.tags[index])
                                  : false,
                              onTap: () => isShowingTags
                                  ? provider.selectTag(tag!)
                                  : provider.selectPostCategory(
                                      state.categories[index],
                                    ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        }

        return Text(state.toString());
      },
    );
  }
}
