import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

import '../../../../core/theme/colors.dart';
import '../../../../core/widgets/loading/shimmer_placeholder_box.dart';

class ImprovedStoryTextLoadingView extends StatelessWidget {
  const ImprovedStoryTextLoadingView({super.key});

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: AppColors.peach,
      highlightColor: AppColors.darkPeach,
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          ShimmerPlaceholderBox(),
          SizedBox(height: 5),
          ShimmerPlaceholderBox(),
          SizedBox(height: 5),
          ShimmerPlaceholderBox(),
          SizedBox(height: 5),
          ShimmerPlaceholderBox(),
          SizedBox(height: 5),
          ShimmerPlaceholderBox(),
        ],
      ),
    );
  }
}
