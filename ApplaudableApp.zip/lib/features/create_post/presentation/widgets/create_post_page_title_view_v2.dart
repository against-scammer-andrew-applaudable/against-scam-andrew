import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';

import '../../../../app_module.dart';
import '../../../../core/extensions/app_module_extensions.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/theme/styles.dart';
import '../../../../core/widgets/svg_icons.dart';
import '../../../../generated/l10n.dart';
import '../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../../../profile/domain/entities/profile_story_response.dart';
import '../providers/selected_post_tags_controller.dart';

class CreatePostPageTitleViewV2 extends StatelessWidget {
  final PageController pageController;
  final StoryCollectionVisual visual;

  const CreatePostPageTitleViewV2({
    super.key,
    required this.pageController,
    this.visual = StoryCollectionVisual.post,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        FutureBuilder<bool>(
          future: Future.value(true),
          builder: (_, __) {
            return AnimatedBuilder(
              animation: pageController,
              builder: (context, snapshot) {
                int stepNo = 0;

                if (pageController.positions.isNotEmpty) {
                  stepNo = pageController.page?.round() ?? 0;
                }

                return Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        GestureDetector(
                          child: Container(
                            color: AppColors.transparent,
                            margin: const EdgeInsets.only(
                              top: 12,
                              left: AppDimensions.mediumSidePadding,
                              right: AppDimensions.mediumSidePadding,
                            ),
                            width: 32,
                            height: 32,
                            alignment: Alignment.center,
                            child: _buildStepRelatedIcon(stepNo),
                          ),
                          onTap: () =>
                              _onStepUpperActionTapped(context, stepNo),
                        ),
                        if (stepNo < 3)
                          Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 20,
                            ),
                            child: Text(
                              '${stepNo + 1}/3',
                              style: AppStyles.text1(
                                color: AppColors.primaryColor,
                              ).copyWith(height: 2.2),
                            ),
                          ),
                      ],
                    ),
                    AppSideMargins(
                      margin: const EdgeInsets.only(
                        bottom: 20,
                        left: 20,
                        right: 20,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          const SizedBox(
                            height: AppDimensions.defaultSidePadding,
                          ),
                          Text(
                            _getStepRelatedTitle(context, stepNo),
                            style: AppStyles.header1(
                              color: context.textColor,
                            ).copyWith(
                              fontWeight: FontWeight.bold,
                              fontSize: 20,
                            ),
                          ),
                          const SizedBox(height: 5),
                          Text(
                            _getStepRelatedSubtitle(context, stepNo),
                            style: AppStyles.text2(color: AppColors.darkGrey),
                          ),
                          const SizedBox(
                            height: AppDimensions.smallSidePadding,
                          ),
                          // if (stepNo == 2)
                          //   Consumer<SelectedNuppController>(
                          //     builder: (context, provider, child) {
                          //       if (provider.selectedNupp == null) {
                          //         return Container();
                          //       }

                          //       return PostNuppItem(
                          //         nupp: provider.selectedNupp!,
                          //         segment: provider.selectedSegment,
                          //       );
                          //     },
                          //   ),
                        ],
                      ),
                    ),
                  ],
                );
              },
            );
          },
        ),
      ],
    );
  }

  SvgPicture _buildStepRelatedIcon(int stepNo) {
    switch (stepNo) {
      case 0:
        return SvgIcons.close();
      default:
        return SvgIcons.backArrow();
    }
  }

  String _getStepRelatedTitle(context, int stepNo) {
    final translations = S.of(context);

    switch (stepNo) {
      case 0:
        return translations.create_post_step_1_v2_title;
      case 1:
        return translations.create_post_step_2_v2_title;
      case 2:
        return translations.create_post_step_3_v2_title;
      case 3:
        return translations.review_a_post;
      default:
        return '';
    }
  }

  String _getStepRelatedSubtitle(BuildContext context, int stepNo) {
    final translations = S.of(context);

    switch (stepNo) {
      case 0:
        return translations.create_post_step_1_v2_subtitle;
      case 1:
        return translations.create_post_step_2_v2_subtitle;
      case 2:
        return translations.create_post_step_3_v2_subtitle;
      default:
        return '';
    }
  }

  void _onStepUpperActionTapped(BuildContext context, int stepNo) {
    switch (stepNo) {
      case 0:
        AppModule.I.pop();
        break;

      default:
        if (stepNo == 1) context.read<SelectedPostTagsController>().reset();

        if (stepNo == 1 && visual != StoryCollectionVisual.post) {
          AppModule.I.pop();
        }

        pageController.previousPage(
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeInOut,
        );
    }
  }
}
