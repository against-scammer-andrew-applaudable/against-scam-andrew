import 'dart:developer';

import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';

import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/theme/styles.dart';
import '../../../../core/widgets/svg_icons.dart';
import '../../../post_collections/data/model/post_collections_response_model.dart';

class TitledAction extends StatefulWidget {
  final String title;
  final TextEditingController valueController;
  final ValueNotifier<List<PostCollectionModel>>? collections;
  final Function()? onTap;
  final String Function(String value)? formatNewSelectedValue;
  final String Function()? formatInitialValue;

  const TitledAction({
    super.key,
    required this.title,
    required this.valueController,
    this.collections,
    this.onTap,
    this.formatNewSelectedValue,
    this.formatInitialValue,
  });

  @override
  State<TitledAction> createState() => _TitledActionState();
}

class _TitledActionState extends State<TitledAction> {
  String _value = '';

  @override
  void initState() {
    if (widget.formatInitialValue != null) {
      _value = widget.formatInitialValue!();
    }

    if (widget.formatNewSelectedValue != null) {
      widget.valueController.addListener(_onValueChanged);
    }

    super.initState();
  }

  @override
  void dispose() {
    if (widget.formatNewSelectedValue != null) {
      widget.valueController.removeListener(_onValueChanged);
    }

    super.dispose();
  }

  void _onValueChanged() {
    log('change');
    // if (_value != widget.valueController.text) {
      _value = widget.formatNewSelectedValue!(widget.valueController.text);
      setState(() {});
    // }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.collections != null) {
      return ValueListenableBuilder<List<PostCollectionModel>>(
        valueListenable: widget.collections!,
        builder: (ctx, collections, child) {
          debugPrint("========== collections : $collections");
          return _child(collections);
        },
      );
    }
    return _child([]);
  }
  Widget _child(List<PostCollectionModel> collections) {
    return InkWell(
      onTap: widget.onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: AppDimensions.defaultSidePadding,
          vertical: 20,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  widget.title,
                  style: AppStyles.text2(color: context.textColor).copyWith(fontWeight: FontWeight.w600),
                ),
                const SizedBox(width: 8),
                Flexible(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Flexible(
                        child: Text(
                          _value,
                          style: AppStyles.text2(color: AppColors.mediumGrey),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      const SizedBox(width: AppDimensions.defaultSidePadding),
                      SvgIcons.forwardArrow(color: AppColors.mediumGrey),
                    ],
                  ),
                ),
              ],
            ),
            if (collections.isNotEmpty)
              ...[
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: collections
                      .map(
                        (e) => Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: AppColors.lightGrey.withOpacity(0.45),
                      ),
                      child: Text(
                        e.name,
                        style: AppStyles.textSmall(
                          color: AppColors.dark,
                        ).copyWith(height: 1.1),
                      ),
                    ),
                  )
                      .toList(),
                ),

              ]
          ],
        ),
      ),
    );
  }
}
