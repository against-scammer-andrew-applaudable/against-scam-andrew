import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_lorem/flutter_lorem.dart';

class StoryQuestionItemLoadingContainer extends StatefulWidget {
  final bool isOdd;
  final int? words;

  const StoryQuestionItemLoadingContainer({
    super.key,
    this.isOdd = false,
    this.words,
  });

  @override
  State<StoryQuestionItemLoadingContainer> createState() =>
      _StoryQuestionItemLoadingContainerState();
}

class _StoryQuestionItemLoadingContainerState
    extends State<StoryQuestionItemLoadingContainer>
    with SingleTickerProviderStateMixin {
  late final Animation<double> _animation;
  late final AnimationController _controller;

  @override
  void initState() {
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    );

    _animation = (widget.isOdd
            ? Tween(
                begin: Random().nextDouble() * 15.0,
                end: -Random().nextDouble() * 15.0,
              )
            : Tween(
                begin: -Random().nextDouble() * 15.0,
                end: Random().nextDouble() * 15.0,
              ))
        .animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    _controller.addStatusListener(_onAnimationStatusChanged);
    _controller.forward();

    super.initState();
  }

  @override
  void dispose() {
    _controller.removeStatusListener(_onAnimationStatusChanged);
    _controller.dispose();

    super.dispose();
  }

  void _onAnimationStatusChanged(AnimationStatus status) {
    if (status == AnimationStatus.completed) {
      _controller.reverse();
    } else if (status == AnimationStatus.dismissed) {
      _controller.forward();
    }
  }

  @override
  Widget build(BuildContext context) {
    final text = lorem(
      paragraphs: 1,
      words: widget.words ?? Random().nextInt(7) + 3,
    );

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, snapshot) {
        return Transform.translate(
          offset: Offset(0, _animation.value),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(
                100,
              ),
            ),
            padding: const EdgeInsets.symmetric(
              horizontal: 25,
              vertical: 15,
            ),
            margin: const EdgeInsets.symmetric(
              vertical: 15,
            ),
            child: Text(text),
          ),
        );
      },
    );
  }
}
