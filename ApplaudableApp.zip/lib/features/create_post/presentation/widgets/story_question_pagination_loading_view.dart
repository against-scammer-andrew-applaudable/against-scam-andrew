import 'package:flutter/material.dart';

import '../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../core/widgets/loading/floating_loading_indicator.dart';
import '../blocs/story_questions_bloc/story_questions_bloc.dart';

class StoryQuestionsPaginationLoadingView extends StatelessWidget {
  const StoryQuestionsPaginationLoadingView({super.key});

  @override
  Widget build(BuildContext context) {
    return DNGBlocBuilder<StoryQuestionsBloc, StoryQuestionsState>(
      builder: (context, state) {
        return Visibility(
          visible: state is StoryQuestionsNextPageLoadingState,
          child: const Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                FloatingLoadingIndicator(),
              ],
            ),
          ),
        );
      },
    );
  }
}
