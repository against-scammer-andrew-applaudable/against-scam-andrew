import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';

import '../../../../core/bloc/widgets/base_stateless_page.dart';
import '../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../core/extensions/build_context_extensions.dart';
import '../../../../core/extensions/string_extensions.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/styles.dart';
import '../../../../core/widgets/app_chip.dart';
import '../../../auth/presentation/widgets/buttons/action_button.dart';
import '../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../blocs/improve_story_text_bloc/improve_story_text_bloc.dart';
import '../providers/selected_tones_controller.dart';
import 'improved_story_text_loading_view.dart';

class ImproveTextWithAIBottomSheetArgs {
  final String question;
  final String text;
  final String title;
  final List<String> tones;
  final List<String> collections;

  ImproveTextWithAIBottomSheetArgs({
    required this.question,
    required this.title,
    required this.text,
    required this.tones,
    required this.collections,
  });
}

// ignore: must_be_immutable
class ImproveTextWithAIBottomSheet
    extends BaseStatelessPage<ImproveStoryTextBloc, ImproveStoryTextState> {
  final ImproveTextWithAIBottomSheetArgs args;

  ImproveTextWithAIBottomSheet({super.key, required this.args});

  String? _improvedText;

  @override
  void initBloc(BuildContext context, ImproveStoryTextBloc bloc) {
    _performImproveStoryTextCallback(context);
  }

  void _performImproveStoryTextCallback(BuildContext context) {
    final provider = context.read<SelectedTonesController>();

    bloc.add(
      ImproveStoryQuestionTextEvent(
        question: args.question,
        title: args.title,
        text: args.text,
        tones: provider.selectedTones,
        collections: args.collections,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    registerBloc(context);

    return SingleChildScrollView(
      child: AppSideMargins(
        margin: const EdgeInsets.symmetric(
          horizontal: 20,
          vertical: 35,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(args.title, style: AppStyles.header1(color: context.textColor)),
            const SizedBox(height: 12),
            Text(
              args.text,
              style: AppStyles.text2(color: AppColors.darkGrey),
            ),
            const SizedBox(height: 30),
            Text(
              translations.voice_tone,
              style: AppStyles.text2(
                color: AppColors.darkGrey,
              ).copyWith(fontWeight: FontWeight.w600),
            ),
            if (args.tones.isNotEmpty) ...[
              const SizedBox(height: 12),
              Consumer<SelectedTonesController>(
                builder: (ctx, provider, child) {
                  return Wrap(
                    spacing: 12,
                    runSpacing: 12,
                    children: List.generate(
                      args.tones.length,
                      (index) => AppChip(
                        title: args.tones[index].capitalize(),
                        backgroundColor: AppColors.buttonBGColor,
                        selectionColor: AppColors.primaryColor,
                        titleColor: AppColors.white,
                        isSelected: provider.isSelected(args.tones[index]),
                        onTap: () {
                          provider.selectTone(args.tones[index]);
                          _performImproveStoryTextCallback(context);
                        },
                      ),
                    ),
                  );
                },
              ),
            ],
            const SizedBox(height: 40),
            Container(
              decoration: BoxDecoration(
                color: AppColors.white,
                border: Border.all(
                  color: AppColors.darkPeach2,
                ),
              ),
              padding: const EdgeInsets.symmetric(
                horizontal: 20,
                vertical: 22,
              ),
              child:
                  DNGBlocBuilder<ImproveStoryTextBloc, ImproveStoryTextState>(
                builder: (context, state) {
                  if (state is ImproveStoryTextLoadingState) {
                    return const ImprovedStoryTextLoadingView();
                  } else if (state is ImproveStoryTextErrorState) {
                    return Center(
                      child: Text(
                        state.message,
                        style: AppStyles.text2(color: AppColors.red),
                      ),
                    );
                  } else if (state is ImprovedStoryTextFetchedState) {
                    _improvedText = state.text;

                    return Text(
                      state.text,
                      style: AppStyles.text2(
                        color: AppColors.darkGrey,
                      ).copyWith(
                        fontSize: 14,
                      ),
                    );
                  }

                  return Container();
                },
              ),
            ),
            const SizedBox(height: 10),
            GestureDetector(
              onTap: () => _performImproveStoryTextCallback(context),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  SvgPicture.asset('assets/icons/ic_refresh.svg'),
                  const SizedBox(width: 8),
                  Text(
                    translations.refresh,
                    style: AppStyles.text2(color: context.textColor).copyWith(
                      fontWeight: FontWeight.w600,
                      decoration: TextDecoration.underline,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 70),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                ),
                child: Row(
                  children: [
                    Flexible(
                      flex: 1,
                      child: AppActionButton.submitWithBorder(
                        text: translations.cancel,
                        backgroundColor: Colors.transparent,
                        borderColor: AppColors.primaryColor,
                        actionTextColor: AppColors.primaryColor,
                        actionTextSize: 18,
                        actionTextWeight: FontWeight.w600,
                        onPressed: context.pop,
                      ),
                    ),
                    const SizedBox(width: 15),
                    Flexible(
                      flex: 2,
                      child: AppActionButton.submit(
                        text: translations.improve,
                        actionTextSize: 18,
                        actionTextWeight: FontWeight.w600,
                        onPressed: () {
                          context.pop(_improvedText);
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
