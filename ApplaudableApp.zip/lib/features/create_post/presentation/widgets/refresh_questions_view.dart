import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';

import '../../../../core/constants/constant_keys.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/styles.dart';
import '../../../../generated/l10n.dart';
import '../blocs/story_questions_bloc/story_questions_bloc.dart';

class RefreshQuestionsView extends StatelessWidget {
  final String? collection;

  const RefreshQuestionsView({super.key, this.collection});

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return GestureDetector(
      key: ConstantKeys.refreshQuestionsBtnViewKey,
      onTap: () {
        final bloc = context.read<StoryQuestionsBloc>();

        bloc.add(GetSuggestedStoryQuestionsEvent(collection: collection));
      },
      child: Container(
        color: AppColors.transparent,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.all(
                  15,
                ),
                child: Row(
                  children: [
                    SvgPicture.asset(
                      'assets/icons/ic_refresh.svg',
                    ),
                    const SizedBox(
                      width: 8,
                    ),
                    Text(
                      translations.refresh_questions,
                      style: AppStyles.text2(color: context.textColor).copyWith(
                        fontWeight: FontWeight.w600,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
