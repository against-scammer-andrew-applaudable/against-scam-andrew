part of 'create_post_cubit.dart';

abstract class CreatePostState extends Equatable {
  const CreatePostState();

  @override
  List<Object?> get props => [];
}

class CreatePostInitialState extends CreatePostState {}

class CreatePostLoadingState extends CreatePostState {}

class CreatePostErrorState extends CreatePostState {
  final String message;

  const CreatePostErrorState({required this.message});

  @override
  List<Object> get props => [message];
}

class PostCreatedState extends CreatePostState {
  final String postId;

  const PostCreatedState({required this.postId});

  @override
  List<Object> get props => [postId];
}

class AddPostMediaLoadingState extends CreatePostState {
  final int current;
  final int total;

  const AddPostMediaLoadingState({this.current = 0, this.total = 0});

  @override
  List<Object> get props => [current, total];
}

class AddPostMediaErrorState extends CreatePostState {
  final String message;

  const AddPostMediaErrorState({required this.message});

  @override
  List<Object> get props => [message];
}

class MediaAddedToPostState extends CreatePostState {
  final PostMedia media;

  const MediaAddedToPostState({required this.media});

  @override
  List<Object> get props => [media];
}
