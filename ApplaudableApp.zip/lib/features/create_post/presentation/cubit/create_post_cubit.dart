import 'dart:convert';

import 'package:equatable/equatable.dart';

import '../../../../core/bloc/dng_base_bloc.dart';
import '../../../../core/pages/image_gallery/camera_view.dart';
import '../../../onboarding/domain/usecases/upload_user_avatar.dart';
import '../../../post/domain/entities/post_entities.dart';
import '../../data/models/post_feed_model.dart';
import '../../domain/entities/post_feed.dart';
import '../../domain/usecases/add_post_media.dart';
import '../../domain/usecases/create_post.dart';

part 'create_post_state.dart';

class CreatePostCubit extends DNGCubit<CreatePostState> {
  final CreatePostFeed createPost;
  final AddPostMedia addPostMedia;

  CreatePostCubit({
    required this.createPost,
    required this.addPostMedia,
  }) : super(CreatePostInitialState());

  Future<String?> createPostFeed({
    required String when,
    required String text,
    required String type,
    String whenFormat = 'DMY',
    PostRanking? ranking,
    String? segment,
    List<String> tags = const [],
    List<PostElement> elements = const [],
    String? collectionsString,
    String? categoryId,
    String? nupp,
    String? relatedPostId,
    String? user,
    CreatePostNuppData? createNuppData,
    String? location,
    String? title,
  }) async {
    try {
      emit(CreatePostLoadingState());

      final collections = collectionsString != null
          ? List<String>.from(json.decode(collectionsString))
          : null;

      final post = PostFeedModel.prepareForCreatePost(
        when: when,
        whenFormat: whenFormat,
        ranking: ranking,
        text: text,
        type: type,
        segment: segment,
        tags: tags,
        elements: elements,
        categoryId: categoryId,
        collections: collections,
        relatedPostId: relatedPostId,
        user: user,
        nupp: nupp,
        createNuppData: createNuppData,
        location: location,
        title: title,
      );

      final result = await createPost(post);

      return result.fold(
        (failure) {
          emit(CreatePostErrorState(message: failure.message));
          emit(CreatePostInitialState());
          return null;
        },
        (postId) {
          emit(PostCreatedState(postId: postId));
          return postId;
        },
      );
    } catch (err) {
      emit(CreatePostErrorState(message: err.toString()));
      emit(CreatePostInitialState());
    }

    return null;
  }

  void addMediaToPost({
    required String postId,
    required SelectedMedia media,
  }) async {
    emit(const AddPostMediaLoadingState());

    final result = await addPostMedia(
      PostMediaParams(
        postId: postId,
        source: AvatarParams(
          mediaFile: media.file,
          onSendProgress: (current, total) {
            emit(AddPostMediaLoadingState(current: current, total: total));
          },
        ),
        type: media.type.name,
        text: media.text,
      ),
    );

    emit(result.fold(
      (failure) => AddPostMediaErrorState(message: failure.message),
      (media) => MediaAddedToPostState(media: media),
    ));
  }
}
