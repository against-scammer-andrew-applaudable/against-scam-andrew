import 'package:equatable/equatable.dart';

import '../../../../../core/bloc/dng_base_bloc.dart';
import '../../../../../core/entities/pagination_params.dart';
import '../../../domain/entities/story_question.dart';
import '../../../domain/usecases/get_suggested_story_questions.dart';

part 'story_questions_event.dart';
part 'story_questions_state.dart';

class StoryQuestionsBloc
    extends DNGBloc<StoryQuestionsEvent, StoryQuestionsState> {
  final GetSuggestedStoryQuestions getSuggestedStoryQuestions;

  StoryQuestionsBloc({
    required this.getSuggestedStoryQuestions,
  }) : super(StoryQuestionsInitialState());

  List<StoryQuestion> _questions = [];
  int _pageNo = 1;

  @override
  void mapEventToState(StoryQuestionsEvent event) async {
    if (event is GetSuggestedStoryQuestionsEvent) {
      await _handleGetSuggestedStoryQuestionsEvent(event);
    }
  }

  Future<void> _handleGetSuggestedStoryQuestionsEvent(
    GetSuggestedStoryQuestionsEvent event,
  ) async {
    _pageNo = event.paginate ? _pageNo : 1;

    if (_pageNo == 1) {
      _questions.clear();
      emit(StoryQuestionsLoadingState());
    } else {
      emit(StoryQuestionsNextPageLoadingState());
    }

    final result = await getSuggestedStoryQuestions(
      StoryPaginationParams(
        collection: event.collection,
        pageInfo: PaginationParams(pageNo: _pageNo, pageSize: event.pageSize),
      ),
    );

    emit(
      result.fold(
        (failure) {
          if (_pageNo == 1) {
            emit(StoryQuestionsErrorState(message: failure.message));
          } else {
            emit(StoryQuestionsNextPageErrorState(message: failure.message));
          }

          return StoryQuestionsDoNothingState();
        },
        (response) {
          if (response.results.length == event.pageSize) _pageNo++;

          _questions.addAll(response.results);

          _questions = _questions.toSet().toList();

          return StoryQuestionsFetchedState(questions: _questions);
        },
      ),
    );

    emit(StoryQuestionsDoNothingState());
  }
}
