part of 'story_questions_bloc.dart';

abstract class StoryQuestionsEvent extends Equatable {
  const StoryQuestionsEvent();
}

class GetSuggestedStoryQuestionsEvent extends StoryQuestionsEvent {
  final String? collection;
  final bool paginate;
  final int pageSize;

  const GetSuggestedStoryQuestionsEvent({
    this.collection,
    this.paginate = false,
    this.pageSize = 15,
  });

  @override
  List<Object?> get props => [collection, paginate, pageSize];
}
