part of 'story_questions_bloc.dart';

class StoryQuestionsState extends Equatable {
  const StoryQuestionsState();

  @override
  List<Object?> get props => [];
}

class StoryQuestionsInitialState extends StoryQuestionsState {}

class StoryQuestionsLoadingState extends StoryQuestionsState {}

class StoryQuestionsNextPageLoadingState extends StoryQuestionsState {}

class StoryQuestionsErrorState extends StoryQuestionsState {
  final String message;

  const StoryQuestionsErrorState({required this.message});

  @override
  List<Object?> get props => [message];
}

class StoryQuestionsNextPageErrorState extends StoryQuestionsState {
  final String message;

  const StoryQuestionsNextPageErrorState({required this.message});

  @override
  List<Object?> get props => [message];
}

class StoryQuestionsFetchedState extends StoryQuestionsState {
  final List<StoryQuestion> questions;

  const StoryQuestionsFetchedState({required this.questions});

  @override
  List<Object?> get props => [questions];
}

class StoryQuestionsDoNothingState extends StoryQuestionsState {}
