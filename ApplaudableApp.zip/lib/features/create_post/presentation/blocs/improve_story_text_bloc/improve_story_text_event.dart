part of 'improve_story_text_bloc.dart';

abstract class ImproveStoryTextEvent extends Equatable {
  const ImproveStoryTextEvent();
}

class ImproveStoryQuestionTextEvent extends ImproveStoryTextEvent {
  final String question;
  final String title;
  final String text;
  final List<String> tones;
  final List<String> collections;

  const ImproveStoryQuestionTextEvent({
    required this.question,
    required this.title,
    required this.text,
    required this.tones,
    required this.collections,
  });

  @override
  List<Object?> get props => [question, title, text, tones, collections];
}
