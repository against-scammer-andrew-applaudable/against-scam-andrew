import 'package:equatable/equatable.dart';

import '../../../../../core/bloc/dng_base_bloc.dart';
import '../../../domain/params/improve_story_text_params.dart';
import '../../../domain/usecases/improve_story_text.dart';

part 'improve_story_text_event.dart';
part 'improve_story_text_state.dart';

class ImproveStoryTextBloc
    extends DNGBloc<ImproveStoryTextEvent, ImproveStoryTextState> {
  final ImproveStoryText improveStoryText;

  ImproveStoryTextBloc({
    required this.improveStoryText,
  }) : super(ImproveStoryTextInitialState());

  @override
  void mapEventToState(ImproveStoryTextEvent event) async {
    if (event is ImproveStoryQuestionTextEvent) {
      await _handleImproveStoryQuestionTextEvent(event);
    }
  }

  Future<void> _handleImproveStoryQuestionTextEvent(
    ImproveStoryQuestionTextEvent event,
  ) async {
    emit(ImproveStoryTextLoadingState());

    final result = await improveStoryText(
      ImproveStoryTextParams(
        question: event.question,
        title: event.title,
        text: event.text,
        tones: event.tones,
        collections: event.collections,
      ),
    );

    emit(
      result.fold(
        (failure) => ImproveStoryTextErrorState(message: failure.message),
        (text) => ImprovedStoryTextFetchedState(text: text),
      ),
    );
  }
}
