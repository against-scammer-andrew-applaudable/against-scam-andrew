part of 'improve_story_text_bloc.dart';

abstract class ImproveStoryTextState extends Equatable {
  const ImproveStoryTextState();

  @override
  List<Object?> get props => [];
}

class ImproveStoryTextInitialState extends ImproveStoryTextState {}

class ImproveStoryTextLoadingState extends ImproveStoryTextState {}

class ImproveStoryTextErrorState extends ImproveStoryTextState {
  final String message;

  const ImproveStoryTextErrorState({required this.message});

  @override
  List<Object?> get props => [message];
}

class ImprovedStoryTextFetchedState extends ImproveStoryTextState {
  final String text;

  const ImprovedStoryTextFetchedState({required this.text});

  @override
  List<Object?> get props => [text];
}
