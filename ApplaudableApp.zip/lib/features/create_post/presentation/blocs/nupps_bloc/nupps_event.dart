part of 'nupps_bloc.dart';

abstract class NuppsEvent extends Equatable {
  const NuppsEvent();
}

class GetAutocompleteNuppsEvent extends NuppsEvent {
  final String segment;
  final String query;
  final String? categoryId;
  final String? location;
  final bool fetchFirstPage;
  final int pageSize;

  const GetAutocompleteNuppsEvent({
    required this.segment,
    required this.query,
    this.categoryId,
    this.location,
    this.fetchFirstPage = true,
    this.pageSize = 10,
  });

  @override
  List<Object?> get props =>
      [segment, query, categoryId, location, fetchFirstPage, pageSize];
}
