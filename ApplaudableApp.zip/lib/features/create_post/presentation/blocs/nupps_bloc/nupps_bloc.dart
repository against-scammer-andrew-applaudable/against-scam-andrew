import 'dart:async';
import 'dart:developer';

import 'package:equatable/equatable.dart';
import 'package:flutter/widgets.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../../../../../core/bloc/dng_base_bloc.dart';
import '../../../../../core/entities/pagination_params.dart';
import '../../../../../core/mixins/location_mixin.dart';
import '../../../domain/entities/nupp.dart';
import '../../../domain/usecases/get_autocomplete_nupps.dart';

part 'nupps_event.dart';
part 'nupps_state.dart';

class NuppsBloc extends DNGBloc<NuppsEvent, NuppsState> with LocationMixin {
  final GetAutocompleteNupps getAutocompleteNupps;

  NuppsBloc({required this.getAutocompleteNupps}) : super(NuppsInitialState());

  final List<Nupp> _nupps = [];

  int _pageNo = 1;
  bool _allowNewPaginationRequests = true;

  @override
  void mapEventToState(NuppsEvent event) async {
    if (event is GetAutocompleteNuppsEvent) {
      await _handleGetAutocompleteNuppsEventWithPageination(event);
    }
  }

  Future<void> _handleGetAutocompleteNuppsEventWithPageination(
    GetAutocompleteNuppsEvent event,
  ) async {
    if (!event.fetchFirstPage && !_allowNewPaginationRequests) return;

    _allowNewPaginationRequests = false;

    emit(
      NuppsNextPageLoadingState(),
      // event.fetchFirstPage ? NuppsLoadingState() : NuppsNextPageLoadingState(),
    );

    LatLng? location;

    if (event.segment == 'somewhere' || event.segment == 'places') {
      try {
        location = await getLocationOnlyIfPermissionAccepted()
            .timeout(const Duration(seconds: 5));
      } catch (err) {
        log('Failed to get user current location');
        log(err.toString());
      }
    }

    final result = await getAutocompleteNupps(
      AutocompleteNuppsParams(
        segment: event.segment,
        query: event.query,
        categoryId: event.categoryId,
        location: event.location ?? location?.asParamValue(),
        pageInfo: PaginationParams(
          pageNo: event.fetchFirstPage ? _pageNo = 1 : ++_pageNo,
          pageSize: event.pageSize,
        ),
      ),
    );

    emit(
      result.fold(
        (failure) {
          if (!event.fetchFirstPage) _pageNo--;

          return event.fetchFirstPage
              ? NuppsErrorState(message: failure.message)
              : NuppsPaginationErrorState(message: failure.message);
        },
        (response) {
          if (event.fetchFirstPage) {
            _nupps.clear();
          }

          if (response.results.length < event.pageSize) _pageNo--;

          // _allowNewPaginationRequests =
          //     response.results.length == event.pageSize;

          _nupps.addAll(response.results);
          debugPrint("========== event.query : ${event.query}");
          return NuppsFetchedState(
            name: event.query,
            segment: event.segment,
            nupps: _nupps.toSet().toList(),
          );
        },
      ),
    );

    _allowNewPaginationRequests = true;
  }

  void clearResult() {
    _nupps.clear();
    emit(NuppsInitialState());
  }
}
