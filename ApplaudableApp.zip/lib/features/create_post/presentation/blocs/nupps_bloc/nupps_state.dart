part of 'nupps_bloc.dart';

abstract class NuppsState extends Equatable {
  const NuppsState();

  @override
  List<Object?> get props => [];
}

class NuppsInitialState extends NuppsState {}

class NuppsLoadingState extends NuppsState {}

class NuppsNextPageLoadingState extends NuppsState {}

class NuppsErrorState extends NuppsState {
  final String message;

  const NuppsErrorState({required this.message});

  @override
  List<Object?> get props => [message];
}

class NuppsPaginationErrorState extends NuppsState {
  final String message;

  const NuppsPaginationErrorState({required this.message});

  @override
  List<Object?> get props => [message];
}

class NuppsFetchedState extends NuppsState {
  final String name;
  final String segment;
  final List<Nupp> nupps;

  const NuppsFetchedState(
      {required this.nupps, required this.segment, required this.name});

  @override
  List<Object?> get props => [nupps, name, segment];
}
