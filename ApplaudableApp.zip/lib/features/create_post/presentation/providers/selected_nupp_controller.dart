import 'package:flutter/foundation.dart';

import '../../domain/entities/nupp.dart';

class SelectedNuppController with ChangeNotifier {
  Nupp? _selectedNupp;
  String _segment = '';

  void selectNupp(Nupp nupp, String segment) {
    _selectedNupp = nupp;
    _segment = segment;
  }

  void reset() => _selectedNupp = null;

  Nupp? get selectedNupp => _selectedNupp;
  String get selectedSegment => _segment;
}
