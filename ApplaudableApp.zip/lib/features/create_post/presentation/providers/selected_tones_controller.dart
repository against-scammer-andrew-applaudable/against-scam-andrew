import 'package:flutter/material.dart';

class SelectedTonesController with ChangeNotifier {
  final List<String> _selectedTones = [];

  void selectTone(String tone) {
    if (_selectedTones.contains(tone)) {
      _unselectTone(tone);
      return;
    }

    _selectedTones.add(tone);
    notifyListeners();
  }

  void _unselectTone(String tone) {
    if (!_selectedTones.contains(tone)) {
      selectTone(tone);
      return;
    }

    _selectedTones.remove(tone);
    notifyListeners();
  }

  bool isSelected(String tone) {
    return _selectedTones.contains(tone);
  }

  void clear() {
    _selectedTones.clear();
  }

  List<String> get selectedTones => _selectedTones;
}
