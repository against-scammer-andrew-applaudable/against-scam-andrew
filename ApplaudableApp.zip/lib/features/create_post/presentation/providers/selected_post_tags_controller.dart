import 'dart:developer';

import 'package:equatable/equatable.dart';
import 'package:flutter/foundation.dart';

import '../../../post_categories/domain/entities/post_category.dart';
import '../../domain/enums/create_post_enums.dart';
import '../../domain/usecases/update_post_tags.dart';

enum UpdateTagStatus { initial, loading, error, updated }

class UpdateTagState extends Equatable {
  final String tagId;
  final UpdateTagStatus status;
  final String? error;

  const UpdateTagState({
    this.tagId = '',
    this.status = UpdateTagStatus.initial,
    this.error,
  });

  UpdateTagState copyWith({
    String? tagId,
    UpdateTagStatus? status,
    String? error,
  }) {
    return UpdateTagState(
      tagId: tagId ?? this.tagId,
      status: status ?? this.status,
      error: error,
    );
  }

  @override
  List<Object?> get props => [tagId, status, error];
}

class SelectedPostTagsController with ChangeNotifier {
  final UpdatePostTag updatePostTag;

  SelectedPostTagsController({required this.updatePostTag});

  PostCategory? _selectedCategory;
  final List<PostTag> _selectedTags = [];
  List<PostTag> _tagsSuggestions = [];
  final List<UpdateTagState> _processingStates = [];

  void setSuggestionsTags(List<PostTag> tags) {
    _tagsSuggestions = tags;
  }

  void selectPostCategory(PostCategory category) {
    _selectedCategory = category;

    notifyListeners();
  }

  void unselectPostCategory() {
    if (_selectedCategory == null) return;

    _selectedTags.clear();
    _selectedCategory = null;
    notifyListeners();
  }

  void selectTag(PostTag tag) {
    if (_selectedTags.contains(tag)) {
      unselectTag(tag);
      return;
    }

    _selectedTags.add(tag);

    notifyListeners();
  }

  void unselectTag(PostTag tag) {
    if (!_selectedTags.contains(tag)) return;

    _selectedTags.remove(tag);
    notifyListeners();
  }

  void updatePostTagOnServer({
    required String postId,
    required PostTag tag,
    PostTagMode mode = PostTagMode.add,
  }) async {
    var currentState =
        UpdateTagState(tagId: tag.id, status: UpdateTagStatus.loading);

    _processingStates.add(currentState);
    notifyListeners();

    if (mode == PostTagMode.remove) {
      _selectedTags.remove(tag);
    } else {
      _selectedTags.add(tag);
    }

    final result = await updatePostTag(
      PostTagParams(
        postId: postId,
        tags: selectedTags,
        mode: mode,
      ),
    );

    try {
      currentState = result.fold(
        (failure) => UpdateTagState(
          tagId: tag.id,
          status: UpdateTagStatus.error,
          error: failure.message,
        ),
        (_) => UpdateTagState(
          tagId: tag.id,
          status: UpdateTagStatus.updated,
          error: null,
        ),
      );

      final index = _processingStates.indexWhere((e) => e.tagId == tag.id);
      if (index != -1) {
        _processingStates.removeAt(index);
        _processingStates.insert(index, currentState);
      }
    } catch (err) {
      log(err.toString());
    }

    log(_processingStates.toString());

    if (currentState.status == UpdateTagStatus.updated) {
      notifyListeners();
    } else {
      switch (mode) {
        case PostTagMode.add:
          unselectTag(tag);
          break;
        case PostTagMode.remove:
          selectTag(tag);
          break;
        case PostTagMode.update:
          //TODO: handle this when it is nedded
          break;
      }
    }

    _processingStates.remove(currentState);
  }

  bool isSelected(PostTag tag) => _selectedTags.contains(tag);

  bool? _shouldShowTags;
  bool get shouldShowTagsOnConfirmation {
    if (_shouldShowTags != null) return _shouldShowTags!;

    return _shouldShowTags = _selectedCategory == null || _selectedTags.isEmpty;
  }

  UpdateTagState stateOf(String id) {
    return _processingStates.firstWhere(
      (e) => e.tagId == id,
      orElse: () => UpdateTagState(tagId: id),
    );
  }

  void reset() {
    _shouldShowTags = null;
    _selectedCategory = null;
    _selectedTags.clear();
    _tagsSuggestions.clear();
    _processingStates.clear();
  }

  // Getters ...
  PostCategory? get selectedCategory => _selectedCategory;
  List<String> get selectedTags => _selectedTags.map((e) => e.id).toList();
  List<PostTag> get suggestions => _tagsSuggestions.toSet().toList();
  List<UpdateTagState> get states => [..._processingStates];
  List<String> get statesIds => _processingStates.map((e) => e.tagId).toList();
}
