import 'package:flutter/foundation.dart';

class PostSegmentCategoriesController with ChangeNotifier {
  String? _selectedSegment;
  final List<String> _selectedTags = [];

  void selectSegment(String segment) {
    if (_selectedSegment == segment) return;

    _selectedSegment = segment;
    _selectedTags.clear();
    notifyListeners();
  }

  void selectTag(String tagId) {
    if (_selectedTags.contains(tagId)) {
      unselectTag(tagId);
      return;
    }

    _selectedTags.add(tagId);
    notifyListeners();
  }

  void unselectTag(String tagId) {
    if (!_selectedTags.contains(tagId)) {
      selectTag(tagId);
      return;
    }

    _selectedTags.remove(tagId);
    notifyListeners();
  }

  void clear() {
    _selectedSegment = null;
    _selectedTags.clear();
  }

  bool isTagSelected(String tagId) => _selectedTags.contains(tagId);
  bool isSelected(String segment) => _selectedSegment == segment;
  bool get isSegmentSelected => _selectedSegment != null;

  List<String> get selectedTags => [..._selectedTags];
}
