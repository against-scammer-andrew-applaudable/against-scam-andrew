import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';

import '../../../../app_module.dart';
import '../../../../core/extensions/app_module_extensions.dart';
import '../../../../core/extensions/build_context_extensions.dart';
import '../../../../core/pages/image_gallery/camera_view.dart';
import '../../../../core/pages/image_gallery/media_gallery_page.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/theme/styles.dart';
import '../../../../core/widgets/app_custom_tab.dart';
import '../../../../core/widgets/app_scaffold.dart';
import '../../../../core/widgets/svg_icons.dart';
import '../../../../generated/l10n.dart';
import '../../../auth/presentation/widgets/buttons/action_button.dart';
import '../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../widgets/post_text_editor.dart';

enum MediaStatus {
  picking,
  error,
  typing,
  galleryPreview,
  textOrCameraPreview,
  editingMedia
}

enum MediaOption { gallery, camera, text }

class MediaSelectorArgs {
  final SelectedMedia? selectedMedia;
  final List<MediaOption> options;

  const MediaSelectorArgs({
    this.selectedMedia,
    this.options = MediaOption.values,
  });
}

class CreatePostMediaSelectorPage extends StatefulWidget {
  static const String routeName = '/create-post-media-selector';

  final MediaSelectorArgs args;

  const CreatePostMediaSelectorPage({
    super.key,
    this.args = const MediaSelectorArgs(),
  });

  @override
  State<CreatePostMediaSelectorPage> createState() =>
      _CreatePostMediaSelectorPageState();
}

class _CreatePostMediaSelectorPageState
    extends State<CreatePostMediaSelectorPage>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;
  final _postTextController = TextEditingController();
  final _mediaPreviewController = StreamController<MediaStatus>.broadcast();

  final _mediaGalleryKey = GlobalKey<MediaGalleryPageState>();
  final _postTextEditorKey = GlobalKey<PostTextEditorState>();
  final _cameraViewKey = GlobalKey<AppCameraViewState>();

  SelectedMedia? _imageOrVideoFile;
  late S translations;

  @override
  void initState() {
    _tabController = TabController(
      length: widget.args.options.length,
      vsync: this,
      initialIndex: widget.args.selectedMedia?.source.index ??
          AppModule.I.defaultMediaPickerOption.index,
    );

    Future(() {
      _cameraViewKey.currentState?.openCameraToCaptureAnImage();
    });

    super.initState();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _postTextController.dispose();
    _mediaPreviewController.close();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    translations = S.of(context);

    return AppScaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: AppColors.peach,
      body: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SafeArea(
                bottom: false,
                child: AppSideMargins(
                  margin: const EdgeInsets.only(
                    left: AppDimensions.defaultSidePadding,
                    right: AppDimensions.mediumSidePadding,
                  ),
                  child: AnimatedBuilder(
                    animation: _tabController,
                    builder: (context, child) {
                      return StreamBuilder<MediaStatus>(
                        initialData: MediaStatus.picking,
                        stream: _mediaPreviewController.stream,
                        builder: (context, snapshot) {
                          return Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              GestureDetector(
                                onTap: () =>
                                    _onLeadingIconPresses(snapshot.data!),
                                child: Container(
                                  padding: const EdgeInsets.all(
                                    AppDimensions.smallSidePadding,
                                  ),
                                  color: AppColors.transparent,
                                  child: _getLeadingIcon(snapshot.data!),
                                ),
                              ),
                              Text(
                                translations.new_applaud,
                                style:
                                    AppStyles.header2(color: context.textColor).copyWith(fontSize: 20),
                              ),
                              AppActionButton.submit(
                                text:
                                    _getMediaSelectorActionText(snapshot.data!),
                                fitsFullWidth: false,
                                padding: EdgeInsets.zero,
                                backgroundColor: Colors.transparent,
                                actionTextColor: enableAction(snapshot.data!)
                                    ? AppColors.primaryColor
                                    : AppColors.primaryColor.withOpacity(0.4),
                                onPressed: enableAction(snapshot.data!)
                                    ? () => _onAddActionPressed(snapshot.data!)
                                    : null,
                              ),
                            ],
                          );
                        },
                      );
                    },
                  ),
                ),
              ),
              Expanded(
                child: TabBarView(
                  physics: const NeverScrollableScrollPhysics(),
                  controller: _tabController,
                  children: [
                    if (widget.args.options.contains(MediaOption.gallery))
                      MediaGalleryPage(
                        key: _mediaGalleryKey,
                        selectedMedia: widget.args.selectedMedia,
                        onImageSelected: (image) {
                          _imageOrVideoFile = image;
                        },
                        onMediaStatusChanged: _mediaPreviewController.sink.add,
                        useNative: AppModule.I.enableNativeMediaGallery,
                      ),
                    if (widget.args.options.contains(MediaOption.camera))
                      AppCameraView(
                        key: _cameraViewKey,
                        selectedMedia: widget.args.selectedMedia,
                        onImageCaptured: (image) {
                          _imageOrVideoFile = image;
                        },
                        useNative: AppModule.I.enableNativeMediaCamera,
                        onMediaStatusChanged: (status) {
                          _mediaPreviewController.sink.add(status);

                          switch (status) {
                            case MediaStatus.picking:
                              _imageOrVideoFile = null;
                              break;
                            case MediaStatus.error:
                            case MediaStatus.galleryPreview:
                            case MediaStatus.textOrCameraPreview:
                            case MediaStatus.typing:
                            case MediaStatus.editingMedia:
                              break;
                          }
                        },
                        navigatorWidget: const Padding(
                          padding: EdgeInsets.only(
                            top: 20,
                            bottom: AppDimensions.defaultSidePadding,
                          ),
                          child: SizedBox(height: 50),
                        ),
                      ),
                    if (widget.args.options.contains(MediaOption.text))
                      PostTextEditor(
                        key: _postTextEditorKey,
                        selectedMedia: widget.args.selectedMedia,
                        controller: _postTextController,
                        onMediaStatusChanged: _mediaPreviewController.sink.add,
                      ),
                  ],
                ),
              ),
              AnimatedBuilder(
                animation: _tabController,
                builder: (context, snapshot) {
                  return Visibility(
                    visible: _tabController.index == 2,
                    child: const SafeArea(
                      top: false,
                      child: SizedBox(height: 100),
                    ),
                  );
                },
              ),
            ],
          ),
          Positioned(
            bottom: AppDimensions.defaultSidePadding,
            left: 0,
            right: 0,
            child: SafeArea(
              top: false,
              child: AnimatedBuilder(
                animation: _tabController,
                builder: (context, snapshot) {
                  final selectedTabIndex = _tabController.index;

                  return SelectorTabsNavigator(
                    mediaPreviewController: _mediaPreviewController,
                    selectedTabIndex: selectedTabIndex,
                    options: widget.args.options,
                    onTap: (index) {
                      // _imageOrVideoFile = null;
                      _tabController.animateTo(index);

                      if (index == 0) {
                        _mediaPreviewController.sink.add(
                          _imageOrVideoFile == null
                              ? MediaStatus.picking
                              : MediaStatus.galleryPreview,
                        );
                        Future.delayed(const Duration(milliseconds: 100), () {
                          _mediaGalleryKey.currentState
                              ?.openImageGalleryToSelectImage();
                        });
                      } else if (index == 1) {
                        _mediaPreviewController.sink.add(
                          _imageOrVideoFile == null
                              ? MediaStatus.picking
                              : MediaStatus.textOrCameraPreview,
                        );
                        Future.delayed(const Duration(milliseconds: 100), () {
                          _cameraViewKey.currentState
                              ?.openCameraToCaptureAnImage();
                        });
                      } else {
                        _mediaPreviewController.sink.add(MediaStatus.picking);
                      }
                    },
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _getLeadingIcon(MediaStatus status) {
    if (_tabController.index == 1 &&
        status == MediaStatus.textOrCameraPreview) {
      return SvgIcons.backArrow();
    }

    return SvgIcons.close(color: AppColors.primaryColor);
  }

  void _onLeadingIconPresses(MediaStatus status) {
    switch (status) {
      case MediaStatus.picking:
      case MediaStatus.error:
      case MediaStatus.typing:
        AppModule.I.pop();
        break;
      case MediaStatus.galleryPreview:
      case MediaStatus.textOrCameraPreview:
      case MediaStatus.editingMedia:
        if (_tabController.index == 1) {
          _cameraViewKey.currentState?.closePreview();
        } else {
          AppModule.I.pop();
        }
        break;
    }
  }

  void _onAddActionPressed(MediaStatus status) {
    switch (status) {
      case MediaStatus.picking:
        _cameraViewKey.currentState?.pickImage();
        break;
      case MediaStatus.error:
        break;
      case MediaStatus.typing:
        _postTextEditorKey.currentState?.onCanvasTapped();
        break;
      case MediaStatus.galleryPreview:
      case MediaStatus.textOrCameraPreview:
        _selectMediaAndCloseMediaSelector();
        break;
      case MediaStatus.editingMedia:
        context.pop();
        break;
    }
  }

  void _selectMediaAndCloseMediaSelector() {
    if (_tabController.index == 2) {
      AppModule.I.pop(
        SelectedMedia(
          file: File('Temp'),
          text: _postTextController.text,
          type: MediaType.text,
          source: MediaSource.textEditor,
        ),
      );
    } else {
      if (_imageOrVideoFile != null) {
        AppModule.I.pop(_imageOrVideoFile);
      }
    }
  }

  bool enableAction(MediaStatus status) {
    switch (status) {
      case MediaStatus.picking:
        return _tabController.index == 1 ? true : false;

      case MediaStatus.error:
        return false;
      case MediaStatus.typing:
        return _tabController.index == 2 ? true : false;
      case MediaStatus.galleryPreview:
      case MediaStatus.textOrCameraPreview:
      case MediaStatus.editingMedia:
        return true;
    }
  }

  String _getMediaSelectorActionText(MediaStatus status) {
    if (_tabController.index == 0) return translations.add;

    switch (status) {
      case MediaStatus.typing:
      case MediaStatus.picking:
        return translations.next;
      case MediaStatus.error:
      case MediaStatus.galleryPreview:
      case MediaStatus.textOrCameraPreview:
      case MediaStatus.editingMedia:
        return translations.add;
    }
  }
}

class SelectorTabsNavigator extends StatelessWidget {
  final StreamController<MediaStatus> mediaPreviewController;
  final int selectedTabIndex;
  final List<MediaOption> options;
  final Function(int)? onTap;

  const SelectorTabsNavigator({
    Key? key,
    required this.mediaPreviewController,
    required this.selectedTabIndex,
    this.options = MediaOption.values,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return StreamBuilder<MediaStatus>(
      initialData: MediaStatus.picking,
      stream: mediaPreviewController.stream,
      builder: (context, snapshot) {
        return Opacity(
          opacity: selectedTabIndex == 0 ||
                  snapshot.data != MediaStatus.textOrCameraPreview
              ? 1
              : 0,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(50),
                  color: AppColors.dark,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (options.contains(MediaOption.gallery))
                      AppCustomTab(
                        label: translations.library,
                        isSelected: selectedTabIndex == 0,
                        onTap: onTap != null ? () => onTap!(0) : null,
                      ),
                    if (options.contains(MediaOption.camera))
                      AppCustomTab(
                        label: translations.camera,
                        isSelected: selectedTabIndex == 1,
                        onTap: onTap != null ? () => onTap!(1) : null,
                      ),
                    if (options.contains(MediaOption.text))
                      AppCustomTab(
                        label: translations.text,
                        isSelected: selectedTabIndex == 2,
                        onTap: onTap != null ? () => onTap!(2) : null,
                      ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
