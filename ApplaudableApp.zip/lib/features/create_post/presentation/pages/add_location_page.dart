import 'package:applaudable/features/create_post/presentation/widgets/nupps_autocomplete_view.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../app_module.dart';
import '../../../../core/extensions/app_module_extensions.dart';
import '../../../../core/utils/formatters/capitalize_text_formatter.dart';
import '../../../../core/widgets/app_bar.dart';
import '../../../../core/widgets/app_scaffold.dart';
import '../../../../generated/l10n.dart';
import '../../../auth/presentation/widgets/buttons/action_button.dart';
import '../../../auth/presentation/widgets/inputs/text_field.dart';
import '../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../blocs/nupps_bloc/nupps_bloc.dart';

class AddLocationPageArgs {
  final String? location;

  const AddLocationPageArgs({this.location});
}

class AddLocationPage extends StatelessWidget {
  static const String routeName = '/add-location-page';

  final AddLocationPageArgs args;

  AddLocationPage({super.key, this.args = const AddLocationPageArgs()});

  final _locationController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return AppScaffold(
      appBar: const NavigationPageBar(),
      body: AppSideMargins(
        child: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              AppTextField(
                controller: _locationController..text = args.location ?? '',
                labelText: translations.location,
                inputFormatters: [
                  CapitalizeTextFormatter(
                    capitalization: TextCapitalization.words,
                  )
                ],
                onChanged: AppModule.I.enableStoryLocationGPSearch
                    ? (query) {
                        if (query.trim().isEmpty) return;

                        final bloc = context.read<NuppsBloc>();
                        bloc.add(
                          GetAutocompleteNuppsEvent(
                            segment: 'places',
                            query: query,
                          ),
                        );
                      }
                    : null,
              ),
              Expanded(
                child: AutocompleteNuppsView(
                  nameTextController: _locationController,
                  isSelectingLocation: true,
                  onLocationSelected: (location) {
                    AppModule.I.pop(location);
                  },
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  AppActionButton.submit(
                    text: translations.submit,
                    onPressed: () => AppModule.I.pop(
                      _locationController.text.trim(),
                    ),
                  ),
                  const SizedBox(height: 15),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
