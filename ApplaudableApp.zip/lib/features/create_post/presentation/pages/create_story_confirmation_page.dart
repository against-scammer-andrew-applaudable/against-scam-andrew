import 'dart:async';
import 'dart:convert';

import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:applaudable/ui/page/main/profile_settings/profile.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';

import '../../../../app_module.dart';
import '../../../../core/bloc/widgets/base_stateless_page.dart';
import '../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../core/constants/constant_keys.dart';
import '../../../../core/constants/constant_values.dart';
import '../../../../core/extensions/app_module_extensions.dart';
import '../../../../core/mixins/location_mixin.dart';
import '../../../../core/pages/image_gallery/camera_view.dart';
import '../../../../core/providers/dng_date_picker_provider.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/theme/styles.dart';
import '../../../../core/widgets/app_confirmation_dialog.dart';
import '../../../../core/widgets/app_scaffold.dart';
import '../../../../core/widgets/pickers/dng_date_picker.dart';
import '../../../../core/widgets/toast/app_toast.dart';
import '../../../../injection_container.dart';
import '../../../../routes.dart';
import '../../../auth/domain/entities/user.dart';
import '../../../auth/presentation/widgets/buttons/action_button.dart';
import '../../../feed/presentation/widgets/feed_view.dart';
import '../../../mentions/presentation/controllers/mentions_controller.dart';
import '../../../mentions/presentation/pages/add_mention_page.dart';
import '../../../post/data/models/post_response_models.dart';
import '../../../post/domain/enums/post_enums.dart';
import '../../../post_collections/presentation/pages/post_collections_page.dart';
import '../../../post_collections/presentation/providers/post_collections_controller.dart';
import '../../../profile/presentation/pages/profile_page.dart';
import '../../domain/entities/story_question.dart';
import '../blocs/nupps_bloc/nupps_bloc.dart';
import '../cubit/create_post_cubit.dart';
import '../widgets/media_picker_view.dart';
import '../widgets/story_question_preview.dart';
import 'add_location_page.dart';
import 'create_post_media_selector.dart';
import 'create_post_page/create_post_page.dart';
import 'post_published_confirmation_page.dart';

class CreateStoryConfirmationPageArgs {
  final StoryQuestion storyQuestion;
  final TextEditingController userAnswerController;
  final TextEditingController postTitleController;
  final StoryQuestionCollection? collection;
  final CreatePostFrom from;

  CreateStoryConfirmationPageArgs({
    required this.storyQuestion,
    required this.postTitleController,
    required this.userAnswerController,
    this.collection,
    this.from = CreatePostFrom.home,
  });
}

// ignore: must_be_immutable
class CreateStoryConfirmationPage
    extends BaseStatelessPage<CreatePostCubit, CreatePostState>
    with LocationMixin {
  static const String routeName = '/create-story-confirmation-page';

  final CreateStoryConfirmationPageArgs args;

  CreateStoryConfirmationPage({super.key, required this.args});

  final _mentions = <String>[];
  final _locationController = TextEditingController();
  final _whenItHappenedController = TextEditingController();
  final _whenDateFormatController = TextEditingController();
  final _categoriesController = TextEditingController();
  SelectedMedia? _selectedStoryMedia;

  String initialCollection = "";

  @override
  void initBloc(BuildContext context, CreatePostCubit bloc) {
    _useInitialQuestionCollection();
  }

  @override
  Widget build(BuildContext context) {
    registerBloc(context);

    return WillPopScope(
      onWillPop: () {
        onDiscardAction(context);

        return Future.value(false);
      },
      child: AppScaffold(
        body: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              return SingleChildScrollView(
                child: ConstrainedBox(
                  constraints: BoxConstraints(minHeight: constraints.maxHeight),
                  child: IntrinsicHeight(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const SizedBox(height: 15),
                        StoryQuestionPreview(args: args),
                        const SizedBox(height: 35),
                        Container(
                          color: context.backgroundColor,
                          padding: const EdgeInsets.symmetric(
                            vertical: 15,
                          ),
                          child: Column(
                            children: [
                              KeyValueItem(
                                key: ConstantKeys.storyWhenItHappenedOptionKey,
                                title: translations.when,
                                onTap: ({String? currentValue}) =>
                                    _handleSelectWhenItHappenCallback(
                                  context,
                                  currentValue,
                                ),
                              ),
                              KeyValueItem(
                                key: ConstantKeys.storyCategoryOptionKey,
                                title: translations.category,
                                value: initialCollection,
                                onTap: _handleSelectCategoriesCallback,
                              ),
                              KeyValueItem(
                                key: ConstantKeys.storyMentionOptionKey,
                                title: translations.mention,
                                onTap: _handleAddMentionCallback,
                              ),
                              KeyValueItem(
                                key: ConstantKeys.storyLocationOptionKey,
                                title: translations.location,
                                onTap: ({String? currentValue}) {
                                  return _handleGetLocationCallback(
                                    context,
                                    currentValue: currentValue,
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 20,
                          ),
                          child: MediaPickerView(
                            key: ConstantKeys.storyAddMediaViewKey,
                            selectedMedia: _selectedStoryMedia,
                            options: const [
                              MediaOption.gallery,
                              MediaOption.camera
                            ],
                            onMediaSelected: (media) {
                              _selectedStoryMedia = media;
                            },
                          ),
                        ),
                        const SizedBox(height: 30),
                        const Spacer(),
                        SafeArea(
                          top: false,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 20,
                            ),
                            child: Row(
                              children: [
                                Flexible(
                                  flex: 1,
                                  child: AppActionButton.submitWithBorder(
                                    key: ConstantKeys.storyDiscardBtnKey,
                                    text: translations.discard,
                                    backgroundColor: Colors.transparent,
                                    borderColor: AppColors.primaryColor,
                                    actionTextColor: AppColors.primaryColor,
                                    actionTextSize: 18,
                                    actionTextWeight: FontWeight.w600,
                                    onPressed: () => onDiscardAction(context),
                                  ),
                                ),
                                const SizedBox(width: 15),
                                Flexible(
                                  flex: 2,
                                  child: DNGBlocBuilder<CreatePostCubit,
                                      CreatePostState>(
                                    bloc: bloc,
                                    buildWhen: (state) =>
                                        state is CreatePostLoadingState ||
                                        state is CreatePostErrorState,
                                    builder: (context, state) {
                                      return AppActionButton.submit(
                                        key: ConstantKeys
                                            .storyConfirmationSubmitBtnKey,
                                        text: translations.submit,
                                        actionTextSize: 18,
                                        actionTextWeight: FontWeight.w600,
                                        showLoading:
                                            state is CreatePostLoadingState,
                                        onPressed: () =>
                                            _publishPostToServer(context),
                                      );
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 15),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  void _publishPostToServer(BuildContext context) async {
    final mentionsController = context.read<MentionsController>();
    final bloc = context.read<CreatePostCubit>();

    // if (_whenItHappenedController.text.trim().isEmpty) {
    //   AppToast().build(context, translations.when_field_required_msg);
    //   return;
    // }

    final collectionsString = _categoriesController.text;
    if (collectionsString.trim().isEmpty) {
      AppToast().build(context, translations.category_field_required_msg);
      return;
    }

    final descElements = [
      PostElementModel(
          type: PostElementType.text,
          text: '${args.userAnswerController.text}\n'),
      ...mentionsController.getAllMentions(),
    ];

    final whenTimeValue = _whenItHappenedController.text.trim();
    final whenFormatValue = _whenDateFormatController.text.trim();

    final postId = await bloc.createPostFeed(
      title: args.postTitleController.text,
      when: whenTimeValue.isNotEmpty
          ? whenTimeValue
          : DateTime.now().toIso8601String(),
      whenFormat: whenFormatValue,
      text: args.userAnswerController.text,
      type: 'story',
      elements: descElements,
      collectionsString:
          collectionsString.trim().isNotEmpty ? collectionsString : null,
      location: _locationController.text,
    );

    /// postId != null means that the post is successfully published and a valid id
    /// is fetched from the API response.
    if (postId != null) {
      final categoriesController = servLocator<PostCollectionsController>();

      mentionsController.clear();
      categoriesController.clear();

      switch (args.from) {
        case CreatePostFrom.home:
          if (_selectedStoryMedia != null) {
            AppModule.I.navigateToNamedAndRemoveUntil(
              PostPublishedConfirmationPage.routeName,
              arguments: PostConfirmationArgs(
                postId: postId, postMedia: _selectedStoryMedia,
                from: args.from,
                isStoryPost: true,
                // ??
                //     SelectedMedia(
                //       type: MediaType.text,
                //       text: args.userAnswerController.text.trim(),
                //       file: File('Temp'),
                //       source: MediaSource.textEditor,
                //     ),
              ),
              (route) => route.settings.name == Routes.home,
            );
            return;
          }

          /// Update Home Feeds
          if (context.mounted) {
            FeedView2.update(context);
            servLocator<PostCollectionsController>().clear();
          }

          AppModule.I.popUntil((r) => r.settings.name == Routes.home);

          break;
        case CreatePostFrom.profile:
          if (_selectedStoryMedia != null) {
            AppModule.I.navigateToNamedAndRemoveUntil(
              PostPublishedConfirmationPage.routeName,
              arguments: PostConfirmationArgs(
                postId: postId, postMedia: _selectedStoryMedia,
                from: args.from,
                isStoryPost: true,
                // ??
                //     SelectedMedia(
                //       type: MediaType.text,
                //       text: args.userAnswerController.text.trim(),
                //       file: File('Temp'),
                //       source: MediaSource.textEditor,
                //     ),
              ),
              (route) => route.settings.name == AppProfilePage.routeName,
            );
            return;
          }

          /// Update Profile Story
          if (context.mounted) {
            ProfilePage.update(context);
            servLocator<PostCollectionsController>().clear();
          }

          AppModule.I.popUntil((r) => r.settings.name == AppProfilePage.routeName);
          break;
      }
    }
  }

  FutureOr<String?> _handleGetLocationCallback(
    BuildContext context, {
    String? currentValue,
  }) async {
    final currentLoc = _locationController.text.trim();

    final bloc = context.read<NuppsBloc>();
    if (currentLoc.isEmpty) {
      bloc.clearResult();
    } else {
      if (AppModule.I.enableStoryLocationGPSearch) {
        bloc.add(
          GetAutocompleteNuppsEvent(segment: 'places', query: currentLoc),
        );
      }
    }

    final location = await AppModule.I.navigateToNamed(
      AddLocationPage.routeName,
      arguments: AddLocationPageArgs(location: _locationController.text),
    );

    if (location != null) {
      _locationController.text = location.toString();
      return location.toString();
    }

    return null;
  }

  Future<String?> _handleSelectCategoriesCallback({
    String? currentValue,
  }) async {
    final collections = await AppModule.I.navigateToNamed(
      PostCollectionsPage.routeName,
      arguments: const PostCollectionsPageArgs(
        showCustomCollectionsOnly: false,
      ),
    );

    /// In case user do not select any collection (Category in UI),
    /// it defaults to the question collection
    /// to make sure always one collection is associated when posting story
    if (collections == null || (collections is List && collections.isEmpty)) {
      return _useInitialQuestionCollection();
    }

    _categoriesController.text = json.encode(collections);

    final controller = servLocator<PostCollectionsController>();

    final categories =
        controller.selectedLifeCategories.map((e) => e.name).join(', ');
    return categories;
  }

  FutureOr<String?> _handleAddMentionCallback({String? currentValue}) async {
    final controller = servLocator<MentionsController>();

    final user = await AppModule.I.navigateToNamed(
      AddMentionPage.routeName,
      arguments: AddMentionPageArgs(
        allowRemovingMentions: true,
        onRemovingMention: (HiveUser user) {
          _mentions.remove('@${user.name}${ConstantValues.mentionSeparator}');
          controller.removeMentionOf(user.id);
          AppModule.I.pop(_mentions);
        },
      ),
    );

    /// For Removing Mention
    if (user is List<String>) {
      return user.join(', ');
    }

    if (user != null && user is HiveUser) {
      controller.addMention(user.id, user.mentionSource);

      _mentions.add(user.name);

      return _mentions.join(', ');
    }

    return null;
  }

  FutureOr<String?> _handleSelectWhenItHappenCallback(
    BuildContext context,
    String? currentValue,
  ) async {
    final selectedDate = await showDNGDatePicker(
      context: context,
      initial: currentValue,
    );

    if (selectedDate != null) {
      _whenItHappenedController.text = selectedDate.date.toIso8601String();
      _whenDateFormatController.text = selectedDate.dateFormat;
      return selectedDate.formattedDate;
    }

    return null;
  }

  String _useInitialQuestionCollection() {
    final StoryQuestionCollection collection =
        args.collection ?? args.storyQuestion.collection;

    _categoriesController.text = json.encode([collection.id]);
    initialCollection = collection.name;

    /// add to collections notifier
    final collectionsBloc = servLocator<PostCollectionsController>();
    collectionsBloc.selectItem(collection);

    return initialCollection;
  }

  void onDiscardAction(BuildContext context) async {
    // final isConfirmed = await showDialog(
    //   context: context,
    //   builder: (ctx) {
    //     return AppConfirmationDialog(
    //       alignment: Axis.horizontal,
    //       title: translations.discard_post_confirm_msg,
    //       confirmActionText: translations.discard,
    //       cancelTextColor: AppColors.primaryColor,
    //       hasSeparator: true,
    //       cancelBorderColor: AppColors.primaryColor,
    //       titleStyle: AppStyles.text2(color: context.textColor).copyWith(
    //         fontWeight: FontWeight.w700,
    //       ),
    //       titlePadding: const EdgeInsets.symmetric(
    //         horizontal: 25,
    //       ),
    //       padding: const EdgeInsets.symmetric(
    //         horizontal: 40,
    //         vertical: 35,
    //       ),
    //       radius: BorderRadius.circular(
    //         AppDimensions.radius_15,
    //       ),
    //     );
    //   },
    // );
    //
    // if (isConfirmed != null && isConfirmed is bool) {
    //   AppModule.I.popUntil(
    //     (r) => r.settings.name == Routes.home,
    //   );
    // }
  }

  @override
  Stream<CreatePostState>? get onStateListener => bloc.stream;

  @override
  onStateResultListener(BuildContext context, CreatePostState state) {
    if (state is CreatePostErrorState) {
      AppModule.I.notify(context, state.message, mode: AppToastMode.error);
    }
  }

  @override
  void dispose() {
    final mentionsController = servLocator<MentionsController>();
    final collectionsController = servLocator<PostCollectionsController>();
    final dngDatePickerController = servLocator<DNGDatePickerProvider>();

    mentionsController.clear();
    collectionsController.clear();
    dngDatePickerController.reset();

    super.dispose();
  }
}

class KeyValueItem extends StatefulWidget {
  final String title;
  final String? value;
  final FutureOr<String?> Function({String? currentValue})? onTap;

  const KeyValueItem({
    super.key,
    required this.title,
    this.value,
    this.onTap,
  });

  @override
  State<KeyValueItem> createState() => _KeyValueItemState();
}

class _KeyValueItemState extends State<KeyValueItem> {
  String _currentValue = '';

  @override
  void initState() {
    _currentValue = widget.value ?? '';

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap == null
          ? null
          : () async {
              final newVal = await widget.onTap!(currentValue: _currentValue);

              if (newVal != null) {
                _currentValue = newVal;
                setState(() {});
              }
            },
      child: Container(
        color: Colors.transparent,
        padding: const EdgeInsets.all(20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              widget.title,
              style: AppStyles.text2(color: context.textColor).copyWith(fontWeight: FontWeight.w600),
            ),
            Row(
              children: [
                SizedBox(
                  width: 150,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Flexible(
                        child: Text(
                          _currentValue,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: AppStyles.text2(color: context.textColor).copyWith(
                            fontSize: 14,
                            height: 0.9,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: AppDimensions.defaultSidePadding),
                SvgPicture.asset('assets/icons/ic_forward.svg'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
