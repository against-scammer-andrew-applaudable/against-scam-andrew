import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../core/bloc/widgets/base_stateless_page.dart';
import '../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../core/constants/constant_keys.dart';
import '../../../../core/extensions/build_context_extensions.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/theme/styles.dart';
import '../../../../core/widgets/app_bar.dart';
import '../../../../core/widgets/app_default_error_view.dart';
import '../../../../core/widgets/app_scaffold.dart';
import '../../../../core/widgets/svg_icons.dart';
import '../../../../core/widgets/toast/app_toast.dart';
import '../blocs/story_questions_bloc/story_questions_bloc.dart';
import '../widgets/refresh_questions_view.dart';
import '../widgets/story_questions_overview_list.dart';
import '../widgets/story_questions_shimmer_loading_view.dart';
import 'create_post_page/create_post_page.dart';

// ignore: must_be_immutable
class SelectStoryQuestionPage
    extends BaseStatelessPage<StoryQuestionsBloc, StoryQuestionsState> {
  static const String routeName = '/select-story-question-page';

  /// Query API to get Story Questions
  /// [collection] is optional to filter and get all the story questions
  /// related to the collection argument
  static getSuggestedStoryQuestions(
    BuildContext context, {
    String? collection,
  }) {
    final questionsBloc = context.read<StoryQuestionsBloc>();
    questionsBloc.add(GetSuggestedStoryQuestionsEvent(collection: collection));
  }

  final CreatePostPageArgs args;

  SelectStoryQuestionPage({super.key, this.args = const CreatePostPageArgs()});

  @override
  Widget build(BuildContext context) {
    registerBloc(context);

    return AppScaffold(
      appBar: NavigationPageBar(
        leadingWidgetKey: ConstantKeys.selectStoryQuestionBackBtnKey,
        actions: [
          Padding(
            key: ConstantKeys.selectStoryQuestionCloseBtnKey,
            padding: const EdgeInsets.only(
              right: AppDimensions.smallSidePadding,
            ),
            child: IconButton(icon: SvgIcons.close(), onPressed: context.pop),
          ),
        ],
      ),
      body: DNGBlocBuilder<StoryQuestionsBloc, StoryQuestionsState>(
        bloc: bloc,
        buildWhen: (state) =>
            state is StoryQuestionsLoadingState ||
            state is StoryQuestionsErrorState ||
            state is StoryQuestionsFetchedState,
        builder: (context, state) {
          if (state is StoryQuestionsLoadingState) {
            return const StoryQuestionsShimmerLoadingView();
          } else if (state is StoryQuestionsErrorState) {
            return AppDefaultErrorView(
              message: state.message,
              onRefresh: () => _refreshPage(context),
            );
          } else if (state is StoryQuestionsFetchedState) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                    left: 20,
                    right: 20,
                    bottom: 8,
                    top: 20,
                  ),
                  child: Text(
                    key: ConstantKeys.selectAQuestionTextKey,
                    translations.select_a_question,
                    style: AppStyles.header1(color: context.textColor),
                  ),
                ),
                if (args.mapToStoryCollection != null) ...[
                  Padding(
                    padding: const EdgeInsets.only(
                      left: 20,
                      right: 20,
                      bottom: 20,
                      top: 2,
                    ),
                    child: Text(
                      "${args.mapToStoryCollection?.collectionsType.name} - ${args.mapToStoryCollection?.name}",
                      style: AppStyles.header3(color: context.textColor),
                    ),
                  ),
                ],
                Expanded(
                  child: (state.questions.isNotEmpty)
                      ? StoryQuestionsOverviewList(
                          key: ConstantKeys.storyQuestionsListViewKey,
                          questions: state.questions,
                          from: args.createPostFrom,
                          collection: args.mapToStoryCollection,
                        )
                      : AppDefaultErrorView(
                          message: translations.no_questions_msg,
                          onRefresh: () => _refreshPage(context),
                        ),
                ),
                RefreshQuestionsView(
                  collection: args.mapToStoryCollection?.id,
                ),
              ],
            );
          }

          return Container();
        },
      ),
    );
  }

  void _refreshPage(BuildContext context) {
    final bloc = context.read<StoryQuestionsBloc>();

    bloc.add(GetSuggestedStoryQuestionsEvent(
        collection: args.mapToStoryCollection?.id));
  }

  @override
  Stream<StoryQuestionsState>? get onStateListener => bloc.stream;

  @override
  void onStateResultListener(BuildContext context, StoryQuestionsState state) {
    if (state is StoryQuestionsNextPageErrorState) {
      AppToast().build(context, state.message, mode: AppToastMode.error);
    }
  }
}
