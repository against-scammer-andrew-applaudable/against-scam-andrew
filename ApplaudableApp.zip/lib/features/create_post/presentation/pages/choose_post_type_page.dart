import 'package:applaudable/core/constants/constant_keys.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../../app_module.dart';
import '../../../../core/extensions/app_module_extensions.dart';
import '../../../../core/extensions/build_context_extensions.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/theme/styles.dart';
import '../../../../core/widgets/app_bar.dart';
import '../../../../core/widgets/app_scaffold.dart';
import '../../../../core/widgets/or_text_divider.dart';
import '../../../../core/widgets/svg_icons.dart';
import '../../../../generated/l10n.dart';
import '../../../auth/presentation/widgets/background.dart';
import '../../../auth/presentation/widgets/buttons/action_button.dart';
import '../../../auth/presentation/widgets/sizing/side_margins.dart';
import 'create_post_page/create_post_page.dart';
import 'select_story_question_page.dart';

class ChoosePostTypePage extends StatelessWidget {
  static const String routeName = '/choose-post-type-page';

  const ChoosePostTypePage({super.key});

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return AppScaffold(
      appBar: NavigationPageBar(
        leading: GestureDetector(
          key: ConstantKeys.closeChoosePostTypePageBtnKey,
          onTap: context.pop,
          child: Container(
            color: AppColors.transparent,
            margin: const EdgeInsets.only(
              top: 12,
              left: AppDimensions.mediumSidePadding,
              right: AppDimensions.mediumSidePadding,
            ),
            width: 32,
            height: 32,
            alignment: Alignment.center,
            child: SvgIcons.close(),
          ),
        ),
      ),
      body: AppBackground(
        showTopLogo: false,
        fitBottomWidth: true,
        bottomLogo: SvgPicture.asset(
          'assets/images/choose_post_type_bg_logo.svg',
          fit: BoxFit.fill,
        ),
        child: AppSideMargins(
          marginValue: 20,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AppActionButton.submit(
                key: ConstantKeys.createRegularPostBtnKey,
                text: translations.create_regular_post,
                backgroundColor: Colors.white,
                enableGradient: false,
                actionTextColor: Colors.black,
                padding: const EdgeInsets.symmetric(
                  vertical: AppDimensions.largeSidePadding,
                ),
                onPressed: () {
                  AppModule.I.navigateToNamed(CreatePostPage.routeName);
                },
                boxShadow: [AppShadows.createPostSegmentShadow],
              ),
              const SizedBox(height: AppDimensions.extraLargeSidePadding),
              const OrTextDivider(),
              const SizedBox(height: AppDimensions.extraLargeSidePadding),
              AppActionButton.submit(
                key: ConstantKeys.createLifeStoryPostBtnKey,
                text: translations.create_life_story_experience,
                backgroundColor: Colors.white,
                enableGradient: false,
                actionTextColor: Colors.black,
                padding: const EdgeInsets.symmetric(
                  vertical: AppDimensions.largeSidePadding,
                ),
                onPressed: () {
                  SelectStoryQuestionPage.getSuggestedStoryQuestions(context);

                  AppModule.I
                      .navigateToNamed(SelectStoryQuestionPage.routeName);
                },
                boxShadow: [AppShadows.createPostSegmentShadow],
              ),
              const SizedBox(height: 50),
            ],
          ),
        ),
      ),
    );
  }
}
