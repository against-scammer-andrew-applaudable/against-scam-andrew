import 'package:applaudable/core/extensions/build_context_extensions.dart';

import '../../../../core/constants/constant_keys.dart';
import 'package:flutter/material.dart';

import '../../../../app_module.dart';
import '../../../../core/extensions/app_module_extensions.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/styles.dart';
import '../../../../core/utils/formatters/capitalize_text_formatter.dart';
import '../../../../core/widgets/app_bar.dart';
import '../../../../core/widgets/app_scaffold.dart';
import '../../../../generated/l10n.dart';
import '../../../auth/presentation/widgets/buttons/action_button.dart';
import '../../../auth/presentation/widgets/inputs/text_field.dart';
import '../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../../domain/entities/story_question.dart';
import 'create_post_page/create_post_page.dart';
import 'create_story_confirmation_page.dart';

class CreateStoryDetailsPageArgs {
  final StoryQuestion storyQuestion;
  final StoryQuestionCollection? collection;
  final CreatePostFrom from;

  CreateStoryDetailsPageArgs(
      {required this.storyQuestion,
      this.collection,
      this.from = CreatePostFrom.home});
}

class CreateStoryDetailsPage extends StatelessWidget {
  static const String routeName = '/create-story-details-page';

  final CreateStoryDetailsPageArgs args;

  CreateStoryDetailsPage({super.key, required this.args});

  final _userAnswerController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return AppScaffold(
      appBar: const NavigationPageBar(
        leadingWidgetKey: ConstantKeys.createStoryDetailsBackBtnKey,
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          return SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: ConstrainedBox(
                constraints: BoxConstraints(minHeight: constraints.maxHeight),
                child: IntrinsicHeight(
                  child: AppSideMargins(
                    marginValue: 25,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const SizedBox(height: 15),
                        Text(
                          key: ConstantKeys.createStoryQuestionTextKey,
                          args.storyQuestion.question,
                          style: AppStyles.header1(color: context.textColor),
                        ),
                        const SizedBox(height: 15),
                        Text(
                          translations.answer_example,
                          style: AppStyles.text2(color: AppColors.darkGrey)
                              .copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 15),
                        Text(
                          key: ConstantKeys.createStoryAnswerExampleTextKey,
                          args.storyQuestion.answerExample,
                          style: AppStyles.text2(color: AppColors.darkGrey)
                              .copyWith(
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        const SizedBox(height: 35),
                        AppTextField(
                          key: ConstantKeys.createStoryAnswerFieldKey,
                          controller: _userAnswerController,
                          maxLines: 8,
                          hintText: translations.type_here_hint,
                          hintColor: AppColors.mediumGrey,
                          textInputType: TextInputType.multiline,
                          border: const OutlineInputBorder(
                            borderSide: BorderSide(color: AppColors.darkPeach2),
                            borderRadius: BorderRadius.zero,
                          ),
                          padding: const EdgeInsets.symmetric(
                            vertical: 15,
                            horizontal: 20,
                          ),
                          inputFormatters: [
                            CapitalizeTextFormatter(
                              capitalization: TextCapitalization.sentences,
                            )
                          ],
                          validator: (value) =>
                              _validateStoryAnswer(context, value),
                        ),
                        const Spacer(),
                        const SizedBox(height: 10),
                        SafeArea(
                          child: AppActionButton.submit(
                            key: ConstantKeys.createStoryContinueBtnKey,
                            text: translations.continueLabel,
                            onPressed: _proceedToStoryConfirmationPage,
                          ),
                        ),
                        const SizedBox(height: 15),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  void _proceedToStoryConfirmationPage() {
    final isValid = _formKey.currentState!.validate();

    if (!isValid) return;

    AppModule.I.navigateToNamed(
      CreateStoryConfirmationPage.routeName,
      arguments: CreateStoryConfirmationPageArgs(
          storyQuestion: args.storyQuestion,
          userAnswerController: _userAnswerController,
          postTitleController: TextEditingController()
            ..text = args.storyQuestion.title,
          from: args.from,
          collection: args.collection),
    );
  }

  String? _validateStoryAnswer(BuildContext context, String? value) {
    if (value == null || value.isEmpty) {
      final translations = S.of(context);
      return translations.answer_field_required_msg;
    }

    return null;
  }
}
