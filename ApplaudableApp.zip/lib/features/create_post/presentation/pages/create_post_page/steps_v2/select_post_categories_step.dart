import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../../../core/theme/colors.dart';
import '../../../../../../core/theme/dimensions.dart';
import '../../../../../../core/widgets/animations/pagination_loading_view.dart';
import '../../../../../../core/widgets/app_default_error_view.dart';
import '../../../../../../core/widgets/app_listview.dart';
import '../../../../../../generated/l10n.dart';
import '../../../../../../injection_container.dart';
import '../../../../../auth/presentation/widgets/buttons/action_button.dart';
import '../../../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../../../../../post_categories/domain/entities/post_category.dart';
import '../../../../../post_categories/presentation/blocs/post_segments_bloc/post_segments_bloc.dart';
import '../../../cubit/create_post_cubit.dart';
import '../../../providers/post_segment_categories_controller.dart';
import '../../../providers/selected_post_tags_controller.dart';
import '../../../widgets/post_segment_tile_view.dart';
import '../../../widgets/post_segments_loading_view.dart';

class SelectPostCategoriesStep extends StatelessWidget {
  final TextEditingController segmentController;
  final Function()? onContinue;
  final Function()? onPublishPost;

  const SelectPostCategoriesStep({
    super.key,
    this.onContinue,
    this.onPublishPost,
    required this.segmentController,
  });

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return AppSideMargins(
      marginValue: 20,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Expanded(
            child: Center(
              child: DNGBlocBuilder<PostSegmentsBloc, PostSegmentsState>(
                buildWhen: (state) =>
                    state is PostSegmentsLoadingState ||
                    state is PostSegmentsErrorState ||
                    state is PostSegmentsFetchedState,
                builder: (context, state) {
                  if (state is PostSegmentsLoadingState) {
                    return const PostSegmentsLoadingView();
                  } else if (state is PostSegmentsErrorState) {
                    return AppDefaultErrorView(message: state.message);
                  } else if (state is PostSegmentsFetchedState) {
                    final provider = servLocator<SelectedPostTagsController>();

                    return Consumer<PostSegmentCategoriesController>(
                      builder: (ctx, _, __) {
                        return AppListView.separated(
                          separatorBuilder: (_, __) => const SizedBox(
                            height: AppDimensions.defaultSidePadding,
                          ),
                          allowPaginationHandling: true,
                          onPaginate: () {
                            final bloc = context.read<PostSegmentsBloc>();

                            bloc.add(
                              const GetPostFeedSegmentsEvent(paginate: true),
                            );
                          },
                          itemCount: state.segments.length,
                          itemBuilder: (ctx, index) {
                            final segmentData = state.segments[index];

                            return Column(
                              children: [
                                SegmentTileView(
                                  segmentData: segmentData,
                                  onSegmentSelected: () {
                                    segmentController.text =
                                        segmentData.segment;

                                    final tags = <PostTag>[];
                                    for (final category
                                        in segmentData.categories) {
                                      tags.addAll(category.tags);
                                    }

                                    if (tags.length > 10) {
                                      provider.setSuggestionsTags(
                                          tags.sublist(0, 11));
                                    } else {
                                      provider.setSuggestionsTags(tags);
                                    }
                                  },
                                ),
                                DNGBlocBuilder<PostSegmentsBloc,
                                    PostSegmentsState>(
                                  builder: (context, s) {
                                    return Visibility(
                                      visible:
                                          s is PostSegmentsNextPageLoadingState &&
                                              index ==
                                                  state.segments.length - 1,
                                      child: const Padding(
                                        padding: EdgeInsets.only(
                                          top: AppDimensions.smallSidePadding,
                                        ),
                                        child: PaginationLoadingView(),
                                      ),
                                    );
                                  },
                                )
                              ],
                            );
                          },
                        );
                      },
                    );
                  }

                  return Container();
                },
              ),
            ),
          ),
          const SizedBox(height: AppDimensions.defaultSidePadding),
          SafeArea(
            child: DNGBlocBuilder<CreatePostCubit, CreatePostState>(
              buildWhen: (state) =>
                  state is CreatePostLoadingState ||
                  state is CreatePostErrorState,
              builder: (context, state) {
                return Consumer<PostSegmentCategoriesController>(
                  builder: (ctx, provider, _) {
                    return Row(
                      children: [
                        Expanded(
                          child: AppActionButton.submitWithBorder(
                            text: translations.post,
                            backgroundColor: AppColors.transparent,
                            borderColor: AppColors.primaryColor,
                            actionTextColor: AppColors.primaryColor,
                            loaderColor: AppColors.primaryColor,
                            showLoading: state is CreatePostLoadingState,
                            onPressed: onPublishPost,
                          ),
                        ),
                        const SizedBox(width: AppDimensions.defaultSidePadding),
                        Expanded(
                          child: AppActionButton.submit(
                            text: translations.continueLabel,
                            // showLoading: state is CreatePostLoadingState,
                            // onPressed: _publishPostToFeeds,
                            onPressed: state is CreatePostLoadingState ||
                                    !provider.isSegmentSelected
                                ? null
                                : onContinue,
                          ),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
