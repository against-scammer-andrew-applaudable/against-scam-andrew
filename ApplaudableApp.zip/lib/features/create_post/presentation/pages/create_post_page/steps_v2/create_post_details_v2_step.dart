import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../../../../../../app_module.dart';
import '../../../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../../../core/constants/constant_keys.dart';
import '../../../../../../core/constants/constant_values.dart';
import '../../../../../../core/extensions/app_module_extensions.dart';
import '../../../../../../core/extensions/build_context_extensions.dart';
import '../../../../../../core/pages/image_gallery/camera_view.dart';
import '../../../../../../core/theme/colors.dart';
import '../../../../../../core/theme/dimensions.dart';
import '../../../../../../generated/l10n.dart';
import '../../../../../../injection_container.dart';
import '../../../../../auth/domain/entities/user.dart';
import '../../../../../auth/presentation/widgets/buttons/action_button.dart';
import '../../../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../../../../../mentions/presentation/controllers/mentions_controller.dart';
import '../../../../../mentions/presentation/pages/add_mention_page.dart';
import '../../../../../post_collections/data/model/post_collections_response_model.dart';
import '../../../../../post_collections/presentation/pages/post_collections_page.dart';
import '../../../blocs/nupps_bloc/nupps_bloc.dart';
import '../../../cubit/create_post_cubit.dart';
import '../../../widgets/media_picker_view.dart';
import '../../../widgets/post_mentions_section.dart';
import '../../../widgets/titled_action.dart';
import '../../add_location_page.dart';

class CreatePostDetailsV2Step extends StatelessWidget {
  final TextEditingController descriptionTextController;
  final TextEditingController whenItHappenedController;
  final TextEditingController addToCollectionController;
  final TextEditingController applaudRatingController;
  final TextEditingController locationController;
  final SelectedMedia? selectedMedia;
  final Function(SelectedMedia)? onMediaSelected;
  final Function()? onContinue;
  final Function()? onDiscardPost;
  final Function()? onPublishPost;
  final GlobalKey<FormState>? descriptionFormKey;
  final bool isReviewing;
  final TextEditingController mentionsController;

  CreatePostDetailsV2Step({
    super.key,
    required this.descriptionTextController,
    required this.whenItHappenedController,
    required this.addToCollectionController,
    required this.applaudRatingController,
    required this.locationController,
    required this.mentionsController,
    this.selectedMedia,
    this.onMediaSelected,
    this.descriptionFormKey,
    this.onPublishPost,
    this.onContinue,
    this.onDiscardPost,
    this.isReviewing = false,
  });

  final _mentions = <String>[];
  final _collections = ValueNotifier<List<PostCollectionModel>>([]);

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return LayoutBuilder(
      builder: (context, constraints) {
        return SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minHeight: constraints.maxHeight,
            ),
            child: IntrinsicHeight(
              child: AppSideMargins(
                marginValue: 20,
                child: Column(
                  children: [
                    IgnorePointer(
                      ignoring: false, //isReviewing,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          const SizedBox(
                            height: AppDimensions.mediumSidePadding,
                          ),
                          Card(
                            elevation: 0,
                            margin: EdgeInsets.zero,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(0),
                            ),
                            shadowColor: AppColors.lightGrey.withOpacity(0.15),
                            color: context.backgroundColor,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(
                                    AppDimensions.defaultSidePadding,
                                  ),
                                  child: MediaPickerView(
                                    selectedMedia: selectedMedia,
                                    onMediaSelected: onMediaSelected,
                                    descriptionTextController:
                                        descriptionTextController,
                                    descriptionFormKey: descriptionFormKey,
                                    textMediaMaxLength: 1500,
                                    enableMentions: false,
                                  ),
                                ),
                                const Padding(
                                  padding: EdgeInsets.symmetric(
                                    horizontal:
                                        AppDimensions.defaultSidePadding,
                                  ),
                                  child: Divider(
                                    color: AppColors.darkPeach,
                                    thickness: 1,
                                    height: 1,
                                  ),
                                ),
                                TitledAction(
                                  title: translations.add_to_a_collection,
                                  valueController: addToCollectionController,
                                  collections: _collections,
                                  onTap: _selectAddToCollectionOption,
                                  formatInitialValue: () {
                                    return addToCollectionController.text
                                            .trim()
                                            .isEmpty
                                        ? translations.no
                                        : translations.yes;
                                  },
                                  formatNewSelectedValue: (newValue) {
                                    return newValue.trim().isEmpty
                                        ? translations.no
                                        : translations.yes;
                                  },
                                ),
                                // AnimatedBuilder(
                                //   animation: addToCollectionController,
                                //   builder: (context, child) {
                                //     if (addToCollectionController.text
                                //         .trim()
                                //         .isEmpty) {
                                //       return Container();
                                //     }

                                //     return child!;
                                //   },
                                //   child: TitledAction(
                                //     title: translations.when_this_happened,
                                //     valueController: whenItHappenedController,
                                //     onTap: () => _selectWhenItHappenedDate(context),
                                //     formatInitialValue:
                                //         _formatInitialWhenItHappenedDate,
                                //     formatNewSelectedValue: (newValue) {
                                //       final date = DateTime.parse(newValue);
                                //       return DateFormat.yMd().format(date);
                                //     },
                                //   ),
                                // ),
                              ],
                            ),
                          ),
                          const SizedBox(
                              height: AppDimensions.largeSidePadding),
                          PostMentionsSection(
                            controller: mentionsController,
                            handleAddMentionCallback: _handleAddMentionCallback,
                          ),
                          const SizedBox(
                            height: AppDimensions.largeSidePadding,
                          ),
                          Container(
                            color: context.backgroundColor,
                            child: Column(
                              children: [
                                TitledAction(
                                  title: translations.when_this_happened,
                                  valueController: whenItHappenedController,
                                  onTap: () =>
                                      _selectWhenItHappenedDate(context),
                                  formatInitialValue:
                                      _formatInitialWhenItHappenedDate,
                                  formatNewSelectedValue: (newValue) {
                                    final date = DateTime.parse(newValue);
                                    return DateFormat.yMd().format(date);
                                  },
                                ),
                                TitledAction(
                                  key: ConstantKeys.storyLocationOptionKey,
                                  title: translations.location,
                                  valueController: locationController,
                                  formatInitialValue: () =>
                                      locationController.text,
                                  formatNewSelectedValue: (value) => value,
                                  onTap: ({String? currentValue}) {
                                    return _handleGetLocationCallback(
                                      context,
                                      currentValue: currentValue,
                                    );
                                  },
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (View.of(context).viewInsets.bottom <= 0) const Spacer(),
                    SafeArea(
                      child: Row(
                        children: [
                          if (isReviewing) ...[
                            Expanded(
                              child: AppActionButton.submitWithBorder(
                                text: translations.discard,
                                backgroundColor: AppColors.transparent,
                                borderColor: AppColors.primaryColor,
                                actionTextColor: AppColors.primaryColor,
                                // showLoading: state is CreatePostLoadingState,
                                // onPressed: _publishPostToFeeds,
                                onPressed: onDiscardPost,
                              ),
                            ),
                            const SizedBox(
                              width: AppDimensions.defaultSidePadding,
                            ),
                          ],
                          Expanded(
                            child: DNGBlocBuilder<CreatePostCubit,
                                CreatePostState>(
                              buildWhen: (state) =>
                                  state is CreatePostLoadingState ||
                                  state is CreatePostErrorState,
                              builder: (context, state) {
                                return AppActionButton.submit(
                                  margin: isReviewing
                                      ? null
                                      : const EdgeInsets.symmetric(
                                          horizontal: 5,
                                        ),
                                  text: isReviewing
                                      ? translations.post
                                      : translations.continueLabel,
                                  showLoading: state is CreatePostLoadingState,
                                  // onPressed: _publishPostToFeeds,
                                  onPressed:
                                      isReviewing ? onPublishPost : onContinue,
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: AppDimensions.defaultSidePadding),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }


  FutureOr<List<String>> _handleAddMentionCallback({
    String? currentValue,
  }) async {
    final controller = servLocator<MentionsController>();

    final user = await AppModule.I.navigateToNamed(
      AddMentionPage.routeName,
      arguments: AddMentionPageArgs(
        allowRemovingMentions: true,
        onRemovingMention: (HiveUser user) {
          _mentions.remove('@${user.name}${ConstantValues.mentionSeparator}');
          controller.removeMentionOf(user.id);

          mentionsController.text = json.encode(_mentions);

          AppModule.I.pop(_mentions);
        },
      ),
    );

    /// For Removing Mention
    if (user is List<String>) return user;

    if (user != null && user is HiveUser) {
      controller.addMention(user.id, user.mentionSource);

      _mentions.add(user.name);

      mentionsController.text = json.encode(_mentions);

      return _mentions;
    }

    return _mentions;
  }

  FutureOr<String?> _handleGetLocationCallback(
    BuildContext context, {
    String? currentValue,
  }) async {
    final currentLoc = locationController.text.trim();

    final bloc = context.read<NuppsBloc>();
    if (currentLoc.isEmpty) {
      bloc.clearResult();
    } else {
      if (AppModule.I.enableStoryLocationGPSearch) {
        bloc.add(
          GetAutocompleteNuppsEvent(segment: 'places', query: currentLoc),
        );
      }
    }

    final location = await AppModule.I.navigateToNamed(
      AddLocationPage.routeName,
      arguments: AddLocationPageArgs(location: locationController.text),
    );

    if (location != null) {
      locationController.text = location.toString();
      return location.toString();
    }

    return null;
  }

  String _formatInitialWhenItHappenedDate() {
    DateTime date;

    if (whenItHappenedController.text.trim().isNotEmpty) {
      date = DateTime.parse(whenItHappenedController.text.trim());
    } else {
      date = DateTime.now();
    }

    return DateFormat.yMd().format(date);
  }

  void _publishPostToFeeds() {
    if (onPublishPost != null) onPublishPost!();
  }

  void _selectWhenItHappenedDate(BuildContext context) async {
    // max age= 100 years
    final DateTime firstDate =
        DateTime.now().subtract(const Duration(days: 365 * 100));
    final DateTime lastDate = DateTime.now();

    var whenItHappenValue = whenItHappenedController.text;
    final chosenDate = whenItHappenValue.trim().isNotEmpty
        ? DateTime.parse(whenItHappenValue)
        : null;

    final selectedDate = await context.showAppDatePicker(
      initialDate: chosenDate ?? lastDate,
      firstDate: firstDate,
      lastDate: lastDate,
    );

    if (selectedDate != null) {
      whenItHappenedController.text = selectedDate.toIso8601String();
    }
  }

  void _selectAddToCollectionOption() async {
    final collections =
        await AppModule.I.navigateToNamed(PostCollectionsPage.routeName);

    debugPrint("========= _selectAddToCollectionOption collections  : $collections");
    if (collections is List<PostCollectionModel>) {
      _collections.value = collections;
      debugPrint("========= _selectAddToCollectionOption collections 1111 : ${_collections.value}");
      if (collections.isEmpty) {
        addToCollectionController.clear();
        whenItHappenedController.text = DateTime.now().toIso8601String();
      } else {
        addToCollectionController.text = json.encode(collections.map((e) => e.id).toList());
      }
    }
  }
}
