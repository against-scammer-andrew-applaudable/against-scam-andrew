import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../../../../app_module.dart';
import '../../../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../../../core/extensions/app_module_extensions.dart';
import '../../../../../../core/extensions/build_context_extensions.dart';
import '../../../../../../core/pages/image_gallery/camera_view.dart';
import '../../../../../../generated/l10n.dart';
import '../../../../../../core/theme/colors.dart';
import '../../../../../../core/theme/dimensions.dart';
import '../../../../../../core/theme/styles.dart';
import '../../../../../auth/presentation/widgets/buttons/action_button.dart';
import '../../../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../../../../../post_collections/presentation/pages/post_collections_page.dart';
import '../../../cubit/create_post_cubit.dart';
import '../../../widgets/applaud_rating_system.dart';
import '../../../widgets/media_picker_view.dart';
import '../../../widgets/titled_action.dart';

class CreatePostDetailsStep extends StatelessWidget {
  final TextEditingController descriptionTextController;
  final TextEditingController whenItHappenedController;
  final TextEditingController addToCollectionController;
  final TextEditingController applaudRatingController;
  final SelectedMedia? selectedMedia;
  final Function(SelectedMedia)? onMediaSelected;
  final Function()? onPublishPost;
  final GlobalKey<FormState>? descriptionFormKey;

  const CreatePostDetailsStep({
    super.key,
    required this.descriptionTextController,
    required this.whenItHappenedController,
    required this.addToCollectionController,
    required this.applaudRatingController,
    this.selectedMedia,
    this.onMediaSelected,
    this.onPublishPost,
    this.descriptionFormKey,
  });

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return LayoutBuilder(
      builder: (context, constraints) {
        return SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minHeight: constraints.maxHeight,
            ),
            child: IntrinsicHeight(
              child: Column(
                children: [
                  const SizedBox(height: AppDimensions.mediumSidePadding),
                  AppSideMargins(
                    marginValue: 20,
                    child: Card(
                      elevation: 0,
                      margin: EdgeInsets.zero,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(0),
                      ),
                      shadowColor: AppColors.lightGrey.withOpacity(0.15),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(
                              AppDimensions.defaultSidePadding,
                            ),
                            child: MediaPickerView(
                              selectedMedia: selectedMedia,
                              onMediaSelected: onMediaSelected,
                              descriptionTextController:
                                  descriptionTextController,
                              descriptionFormKey: descriptionFormKey,
                              textMediaMaxLength: 1500,
                            ),
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(
                              horizontal: AppDimensions.defaultSidePadding,
                            ),
                            child: Divider(
                              color: AppColors.darkPeach,
                              thickness: 1,
                              height: 1,
                            ),
                          ),
                          TitledAction(
                            title: translations.add_to_a_collection,
                            valueController: addToCollectionController,
                            onTap: _selectAddToCollectionOption,
                            formatInitialValue: () {
                              return addToCollectionController.text
                                      .trim()
                                      .isEmpty
                                  ? translations.no
                                  : translations.yes;
                            },
                            formatNewSelectedValue: (newValue) {
                              return newValue.trim().isEmpty
                                  ? translations.no
                                  : translations.yes;
                            },
                          ),
                          AnimatedBuilder(
                            animation: addToCollectionController,
                            builder: (context, child) {
                              if (addToCollectionController.text
                                  .trim()
                                  .isEmpty) {
                                return Container();
                              }

                              return child!;
                            },
                            child: TitledAction(
                              title: translations.when_this_happened,
                              valueController: whenItHappenedController,
                              onTap: () => _selectWhenItHappenedDate(context),
                              formatInitialValue:
                                  _formatInitialWhenItHappenedDate,
                              formatNewSelectedValue: (newValue) {
                                final date = DateTime.parse(newValue);
                                return DateFormat.yMd().format(date);
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 40),
                  if (AppModule.I.enableApplaudRankLevel) ...[
                    ApplaudRatingSystem(controller: applaudRatingController),
                    const SizedBox(height: AppDimensions.defaultSidePadding),
                    Center(
                      child: Text(
                        translations.tap_to_rank,
                        style: AppStyles.text2(color: AppColors.darkPeach2),
                      ),
                    ),
                  ],
                  if (View.of(context).viewInsets.bottom <= 0) const Spacer(),
                  SafeArea(
                    child: DNGBlocBuilder<CreatePostCubit, CreatePostState>(
                      buildWhen: (state) =>
                          state is CreatePostLoadingState ||
                          state is CreatePostErrorState,
                      builder: (context, state) {
                        return AppActionButton.submit(
                          text: translations.publish,
                          margin: const EdgeInsets.symmetric(
                            horizontal: 25,
                          ),
                          showLoading: state is CreatePostLoadingState,
                          onPressed: _publishPostToFeeds,
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: AppDimensions.defaultSidePadding),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  String _formatInitialWhenItHappenedDate() {
    DateTime date;

    if (whenItHappenedController.text.trim().isNotEmpty) {
      date = DateTime.parse(whenItHappenedController.text.trim());
    } else {
      date = DateTime.now();
    }

    return DateFormat.yMd().format(date);
  }

  void _publishPostToFeeds() {
    if (onPublishPost != null) onPublishPost!();
  }

  void _selectWhenItHappenedDate(BuildContext context) async {
    // max age= 100 years
    final DateTime firstDate =
        DateTime.now().subtract(const Duration(days: 365 * 100));
    final DateTime lastDate = DateTime.now();

    var whenItHappenValue = whenItHappenedController.text;
    final chosenDate = whenItHappenValue.trim().isNotEmpty
        ? DateTime.parse(whenItHappenValue)
        : null;

    final selectedDate = await context.showAppDatePicker(
      initialDate: chosenDate ?? lastDate,
      firstDate: firstDate,
      lastDate: lastDate,
    );

    if (selectedDate != null) {
      whenItHappenedController.text = selectedDate.toIso8601String();
    }
  }

  void _selectAddToCollectionOption() async {
    final collections =
        await AppModule.I.navigateToNamed(PostCollectionsPage.routeName);

    if (collections != null && collections is List) {
      if (collections.isEmpty) {
        addToCollectionController.clear();
        whenItHappenedController.text = DateTime.now().toIso8601String();
      } else {
        addToCollectionController.text = json.encode(collections);
      }
    }
  }
}
