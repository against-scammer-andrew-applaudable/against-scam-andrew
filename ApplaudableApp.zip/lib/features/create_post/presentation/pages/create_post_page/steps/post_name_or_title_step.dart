import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../../../core/utils/formatters/capitalize_text_formatter.dart';
import '../../../../../../generated/l10n.dart';
import '../../../../../../core/theme/colors.dart';
import '../../../../../../core/theme/dimensions.dart';
import '../../../../../auth/presentation/widgets/inputs/text_field.dart';
import '../../../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../../../../domain/entities/post_feed.dart';
import '../../../blocs/nupps_bloc/nupps_bloc.dart';
import '../../../providers/selected_post_tags_controller.dart';
import '../../../widgets/nupps_autocomplete_view.dart';
import '../../../widgets/post_categories_selector.dart';

enum PostNuppType { newNupp, exsitingNupp, fetchedFromGPlaces }

class SelectedNuppData {
  final PostNuppType type;
  final CreatePostNuppData? nupp;
  final String? nuppId;
  final bool useNuppId;

  SelectedNuppData({
    required this.type,
    this.nupp,
    this.nuppId,
    this.useNuppId = false,
  });
}

class PostNameOrTitleStep extends StatelessWidget {
  final TextEditingController nameTextController;
  final TextEditingController segmentController;
  final Function(SelectedNuppData)? onNuppSelected;
  final bool showCategories;

  const PostNameOrTitleStep({
    super.key,
    required this.nameTextController,
    required this.segmentController,
    this.onNuppSelected,
    this.showCategories = true,
  });

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return AppSideMargins(
      marginValue: 20,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(3),
            ),
            margin: EdgeInsets.zero,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                AppTextField(
                  controller: nameTextController,
                  labelText: translations.name_label,
                  onChanged: (query) => _onNameEntered(context, query),
                  useDebouncer: true,
                  useDefaultHeight: false,
                  inputFormatters: [
                    CapitalizeTextFormatter(
                      capitalization: TextCapitalization.words,
                    )
                  ],
                ),
                if (showCategories) ...[
                  Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: AppDimensions.defaultSidePadding,
                    ),
                    child: Divider(color: AppColors.darkPeach.shade100),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: AppDimensions.defaultSidePadding,
                    ),
                    child: PostCategoriesSelector(),
                  ),
                  const SizedBox(height: 10),
                ],
              ],
            ),
          ),
          const SizedBox(height: 20),
          Flexible(
            child: AutocompleteNuppsView(
              nameTextController: nameTextController,
              onNuppSelected: onNuppSelected,
            ),
          ),
        ],
      ),
    );
  }

  void _onNameEntered(BuildContext context, String query) {

    final bloc = Provider.of<NuppsBloc>(context, listen: false);
    final tagsController = context.read<SelectedPostTagsController>();
    if (query.trim().isEmpty) {
      bloc.clearResult();
      return;
    }
    bloc.add(
      GetAutocompleteNuppsEvent(
        segment: segmentController.text,
        query: query,
        categoryId: tagsController.selectedCategory?.id,
      ),
    );
  }
}
