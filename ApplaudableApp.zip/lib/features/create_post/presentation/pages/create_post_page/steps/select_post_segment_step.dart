import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../../../../app_module.dart';
import '../../../../../../core/widgets/svg_icons.dart';
import '../../../../../../generated/l10n.dart';
import '../../../../../../core/theme/dimensions.dart';
import '../../../../../../core/theme/styles.dart';
import '../../../../../auth/presentation/widgets/background.dart';
import '../../../../../auth/presentation/widgets/buttons/action_button.dart';
import '../../../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../../../../domain/enums/create_post_enums.dart';

// ignore: must_be_immutable
class SelectPostSegmentStep extends StatelessWidget {
  final Function(PostSegment)? onSegmentSelected;

  SelectPostSegmentStep({super.key, this.onSegmentSelected});

  late S translations;

  @override
  Widget build(BuildContext context) {
    translations = S.of(context);

    return AppBackground(
      showTopLogo: false,
      fitBottomWidth: true,
      bottomLogo: SvgPicture.asset('assets/images/post_segments_bg_logo.svg'),
      child: SafeArea(
        bottom: false,
        child: AppSideMargins(
          margin: const EdgeInsets.all(AppDimensions.largeSidePadding),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: AppDimensions.largeSidePadding),
              AppActionButton.submit(
                text: translations.something,
                leadingIcon: SvgIcons.something(),
                backgroundColor: Colors.white,
                enableGradient: false,
                actionTextColor: Colors.black,
                padding: const EdgeInsets.symmetric(
                  vertical: AppDimensions.largeSidePadding,
                ),
                onPressed: () => _selectCreatePostType(PostSegment.something),
                boxShadow: [AppShadows.createPostSegmentShadow],
              ),
              const SizedBox(height: AppDimensions.largeSidePadding),
              AppActionButton.submit(
                text: translations.somewhere,
                leadingIcon: SvgIcons.somewhere(),
                backgroundColor: Colors.white,
                enableGradient: false,
                actionTextColor: Colors.black,
                padding: const EdgeInsets.symmetric(
                  vertical: AppDimensions.largeSidePadding,
                ),
                onPressed: () => _selectCreatePostType(PostSegment.somewhere),
                boxShadow: [AppShadows.createPostSegmentShadow],
              ),
              if (AppModule.I.enableSomeoneFlow) ...[
                const SizedBox(height: AppDimensions.largeSidePadding),
                AppActionButton.submit(
                  text: translations.someone,
                  leadingIcon: SvgIcons.someone(),
                  backgroundColor: Colors.white,
                  enableGradient: false,
                  actionTextColor: Colors.black,
                  padding: const EdgeInsets.symmetric(
                    vertical: AppDimensions.largeSidePadding,
                  ),
                  onPressed: () => _selectCreatePostType(PostSegment.someone),
                  boxShadow: [AppShadows.createPostSegmentShadow],
                ),
              ],
              const Spacer(flex: 4),
            ],
          ),
        ),
      ),
    );
  }

  void _selectCreatePostType(PostSegment type) {
    if (onSegmentSelected != null) onSegmentSelected!(type);
  }
}
