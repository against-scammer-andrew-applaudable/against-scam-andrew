// ignore_for_file: use_build_context_synchronously

import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../../app_module.dart';
import '../../../../../core/bloc/widgets/base_stateless_page.dart';
import '../../../../../core/extensions/app_module_extensions.dart';
import '../../../../../core/extensions/build_context_extensions.dart';
import '../../../../../core/pages/image_gallery/camera_view.dart';
import '../../../../../core/theme/colors.dart';
import '../../../../../core/theme/dimensions.dart';
import '../../../../../core/theme/styles.dart';
import '../../../../../core/widgets/app_confirmation_dialog.dart';
import '../../../../../core/widgets/app_scaffold.dart';
import '../../../../../core/widgets/toast/app_toast.dart';
import '../../../../../injection_container.dart';
import '../../../../../routes.dart';
import '../../../../feed/presentation/widgets/feed_view.dart';
import '../../../../mentions/presentation/controllers/mentions_controller.dart';
import '../../../../post/data/models/post_response_models.dart';
import '../../../../post/domain/enums/post_enums.dart';
import '../../../../post_categories/presentation/blocs/post_categories_bloc/post_categories_bloc.dart';
import '../../../../post_categories/presentation/blocs/post_segments_bloc/post_segments_bloc.dart';
import '../../../../post_collections/presentation/providers/post_collections_controller.dart';
import '../../../../profile/domain/entities/profile_story_response.dart';
import '../../../data/models/post_feed_model.dart';
import '../../../data/models/story_question_model.dart';
import '../../../domain/entities/post_feed.dart';
import '../../blocs/nupps_bloc/nupps_bloc.dart';
import '../../cubit/create_post_cubit.dart';
import '../../providers/post_segment_categories_controller.dart';
import '../../providers/selected_post_tags_controller.dart';
import '../../widgets/create_post_page_title_view_v2.dart';
import '../post_published_confirmation_page.dart';
import 'steps/post_name_or_title_step.dart';
import 'steps_v2/create_post_details_v2_step.dart';
import 'steps_v2/select_post_categories_step.dart';

enum CreatePostFrom { home, profile }

class CreatePostPageArgs {
  final String? relatedPostId;
  final ProfileStory? profileStory;
  final ProfileStoryCollection? collection;
  final CreatePostFrom createPostFrom;

  const CreatePostPageArgs(
      {this.relatedPostId,
      this.profileStory,
      this.collection,
      this.createPostFrom = CreatePostFrom.home});

  StoryQuestionCollectionModel? get mapToStoryCollection {
    if (collection == null) {
      return null;
    }
    return StoryQuestionCollectionModel(
        id: collection!.id,
        name: collection!.name,
        collectionsType: StoryQuestionCollectionTypeModel(
            id: profileStory!.id, name: profileStory!.name));
  }
}

// ignore: must_be_immutable
class CreatePostPage
    extends BaseStatelessPage<CreatePostCubit, CreatePostState> {
  static const String routeName = '/create-post-page';

  final CreatePostPageArgs args;

  CreatePostPage({super.key, this.args = const CreatePostPageArgs()});

  final _pageController = PageController();

  final _segmentController = TextEditingController();
  final _nameTextController = TextEditingController();
  final _descriptionTextController = TextEditingController();
  // PostDescriptionTextController();
  final _whenItHappenedController =
      TextEditingController(text: DateTime.now().toIso8601String());
  final _addToCollectionController = TextEditingController();
  final _applaudRatingController = TextEditingController();
  final _locationController = TextEditingController();
  final _mentionsController = TextEditingController();

  final _descriptionFormKey = GlobalKey<FormState>();
  MentionsController? _mentionsControllerForMention;

  SelectedMedia? _selectedPostMedia;
  SelectedNuppData? _selectedNuppData;

  @override
  void initBloc(BuildContext context, CreatePostCubit bloc) {
    Future(() {
      final storyCollection = args.collection;

      if (storyCollection != null) {
        List<String> collectionsIds = [];

        if (storyCollection.type == StoryCollectionType.group &&
            storyCollection.visual == StoryCollectionVisual.bubble) {
          collectionsIds =
              storyCollection.collections.map((e) => e.id).toList();
          _onSegmentSelected(context, 'people');
        } else if (storyCollection.visual == StoryCollectionVisual.map) {
          collectionsIds = [storyCollection.id];
          _onSegmentSelected(context, 'places');
        } else {
          collectionsIds = [storyCollection.id];
        }

        servLocator<PostCollectionsController>().preSelectedIds =
            collectionsIds;
        _addToCollectionController.text = json.encode(collectionsIds);
      }
    });
  }

  @override
  void dispose() {
    super.dispose();
    _mentionsControllerForMention?.clear();
    servLocator<PostCollectionsController>().clear();
    servLocator<SelectedPostTagsController>().reset();
  }
  @override
  Widget build(BuildContext context) {
    registerBloc(context);
    _mentionsControllerForMention = context.read<MentionsController>();

    return WillPopScope(
      onWillPop: () {
        if (_pageController.page == 0) {
          context.read<SelectedPostTagsController>().reset();
          return Future.value(true);
        }

        _pageController.previousPage(
            duration: const Duration(milliseconds: 200),
            curve: Curves.easeInOut);

        return Future.value(false);
      },
      child: AppScaffold(
        body: SafeArea(
          bottom: false,
          child: SingleChildScrollView(
            child: SizedBox(
              height: context.screenHeight - context.paddingTop,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  CreatePostPageTitleViewV2(
                    pageController: _pageController,
                    visual:
                        args.collection?.visual ?? StoryCollectionVisual.post,
                  ),
                  Expanded(
                    child: PageView(
                      controller: _pageController,
                      physics: const NeverScrollableScrollPhysics(),
                      children: [
                        AnimatedBuilder(
                          animation: _pageController,
                          builder: (context, child) {
                            return CreatePostDetailsV2Step(
                              descriptionFormKey: _descriptionFormKey,
                              descriptionTextController:
                                  _descriptionTextController,
                              whenItHappenedController:
                                  _whenItHappenedController,
                              addToCollectionController:
                                  _addToCollectionController,
                              applaudRatingController: _applaudRatingController,
                              locationController: _locationController,
                              mentionsController: _mentionsController,
                              selectedMedia: _selectedPostMedia,
                              onMediaSelected: (media) {
                                _selectedPostMedia = media;
                                _descriptionFormKey.currentState!.validate();
                              },
                              onContinue: () => _navigateToNextStep(context),
                            );
                          },
                        ),
                        // PostNameOrTitleStep(
                        //   nameTextController: _nameTextController,
                        //   segmentController: _segmentController,
                        //   onNuppSelected: (postNupp) {
                        //     context.unfocus();
                        //     _selectedNuppData = postNupp;

                        //     _navigateToNextStep();
                        //   },
                        // ),
                        SelectPostCategoriesStep(
                          segmentController: _segmentController,
                          onContinue: () => _onSegmentSelected(
                            context,
                            _segmentController.text.trim(),
                          ),
                          onPublishPost: () => _publishPostToServer(context),
                        ),
                        PostNameOrTitleStep(
                          nameTextController: _nameTextController,
                          segmentController: _segmentController,
                          showCategories: false,
                          onNuppSelected: (postNupp) {
                            context.unfocus();
                            _selectedNuppData = postNupp;

                            _navigateToNextStep(context);
                          },
                        ),
                        AnimatedBuilder(
                          animation: _pageController,
                          builder: (context, child) {
                            return CreatePostDetailsV2Step(
                              descriptionFormKey: _descriptionFormKey,
                              descriptionTextController:
                                  _descriptionTextController,
                              whenItHappenedController:
                                  _whenItHappenedController,
                              addToCollectionController:
                                  _addToCollectionController,
                              applaudRatingController: _applaudRatingController,
                              locationController: _locationController,
                              mentionsController: _mentionsController,
                              selectedMedia: _selectedPostMedia,
                              onMediaSelected: (media) {
                                _selectedPostMedia = media;
                                _descriptionFormKey.currentState!.validate();
                              },
                              onPublishPost: () =>
                                  _publishPostToServer(context),
                              onDiscardPost: () => onDiscardAction(context),
                              isReviewing: true,
                            );
                          },
                        ),
                        // AnimatedBuilder(
                        //   animation: _pageController,
                        //   builder: (context, child) {
                        //     return CreatePostDetailsStep(
                        //       descriptionFormKey: _descriptionFormKey,
                        //       descriptionTextController:
                        //           _descriptionTextController,
                        //       whenItHappenedController:
                        //           _whenItHappenedController,
                        //       addToCollectionController:
                        //           _addToCollectionController,
                        //       applaudRatingController: _applaudRatingController,
                        //       selectedMedia: _selectedPostMedia,
                        //       onMediaSelected: (media) {
                        //         _selectedPostMedia = media;
                        //         _descriptionFormKey.currentState!.validate();
                        //       },
                        //       onPublishPost: () =>
                        //           _publishPostToServer(context),
                        //     );
                        //   },
                        // ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void onDiscardAction(BuildContext context) async {
    // final isConfirmed = await showDialog(
    //   context: context,
    //   builder: (ctx) {
    //     return AppConfirmationDialog(
    //       alignment: Axis.horizontal,
    //       title: translations.discard_post_confirm_msg,
    //       confirmActionText: translations.discard,
    //       cancelTextColor: AppColors.primaryColor,
    //       hasSeparator: true,
    //       cancelBorderColor: AppColors.primaryColor,
    //       titleStyle: AppStyles.text2(color: context.textColor).copyWith(
    //         fontWeight: FontWeight.w700,
    //       ),
    //       titlePadding: const EdgeInsets.symmetric(
    //         horizontal: 25,
    //       ),
    //       padding: const EdgeInsets.symmetric(
    //         horizontal: 40,
    //         vertical: 35,
    //       ),
    //       radius: BorderRadius.circular(
    //         AppDimensions.radius_15,
    //       ),
    //     );
    //   },
    // );
    //
    // if (isConfirmed != null && isConfirmed is bool) {
    //   AppModule.I.popUntil(
    //     (r) => r.settings.name == Routes.home,
    //   );
    // }
  }

  void _publishPostToServer(BuildContext context) async {
    debugPrint('Name: ${_nameTextController.text}');
    debugPrint('Description: ${_descriptionTextController.text}');
    debugPrint('WhenItHappened: ${_whenItHappenedController.text}');
    debugPrint('AddToCollection: ${_addToCollectionController.text}');
    debugPrint('Rating ${_applaudRatingController.text}');

    if (_pageController.page != 1 &&
        !_descriptionFormKey.currentState!.validate()) return;

    int postRankingIndex = 0;

    if (_applaudRatingController.text.trim().isNotEmpty) {
      postRankingIndex = int.parse(_applaudRatingController.text.trim()) - 1;
    }

    final tagsProvider = context.read<SelectedPostTagsController>();
    _mentionsControllerForMention ??= context.read<MentionsController>();

    final collectionsString = _addToCollectionController.text;
    // final descElements = mentionsController
    //     .mapDescriptionToElements(_descriptionTextController.text.trim());

    final descElements = [
      PostElementModel(
          type: PostElementType.text,
          text: '${_descriptionTextController.text}\n'),
      ..._mentionsControllerForMention!.getAllMentions(),
    ];

    log(_segmentController.text.toString(), name: 'Segment');

    final newNuppName =
        _selectedNuppData?.nupp?.name ?? _nameTextController.text.trim();

    final postId = await bloc.createPostFeed(
      when: _whenItHappenedController.text.trim(),
      ranking: PostRanking.values[postRankingIndex],
      text: _descriptionTextController.text,
      relatedPostId: args.relatedPostId,
      type: args.relatedPostId != null && args.relatedPostId!.isNotEmpty
          ? 'highlight'
          : 'post',
      segment: _segmentController.text.isEmpty ? null : _segmentController.text,
      tags: tagsProvider.selectedTags,
      categoryId: tagsProvider.selectedCategory?.id,
      elements: descElements,
      collectionsString:
          collectionsString.trim().isNotEmpty ? collectionsString : null,
      nupp: (_segmentController.text == 'someone' ||
                  _segmentController.text == 'people') &&
              _selectedNuppData?.useNuppId == false
          ? null
          : _selectedNuppData?.nuppId,
      user: (_segmentController.text == 'someone' ||
                  _segmentController.text == 'people') &&
              _selectedNuppData?.useNuppId == false
          ? _selectedNuppData?.nuppId
          : null,
      createNuppData: _selectedNuppData?.nuppId != null || newNuppName.isEmpty
          ? null
          : CreatePostNuppDataModel(
              type: _selectedNuppData?.nupp?.type ?? 'nupp',
              name: newNuppName,
              source: _selectedNuppData?.nupp?.source,
              sourceRef: _selectedNuppData?.nupp?.sourceRef,
            ),
      location: _locationController.text.trim().isNotEmpty
          ? _locationController.text
          : null,
    );

    /// postId != null means that the post is successfully published and a valid id
    /// is fetched from the API response.
    if (postId != null) {
      context.read<NuppsBloc>().clearResult();
      _mentionsControllerForMention?.clear();
      servLocator<PostSegmentCategoriesController>().clear();

      if (_selectedPostMedia != null) {
        AppModule.I.navigateToNamedAndRemoveUntil(
          PostPublishedConfirmationPage.routeName,
          arguments: PostConfirmationArgs(
            postId: postId,
            postMedia: _selectedPostMedia ??
                SelectedMedia(
                  type: MediaType.text,
                  text: _descriptionTextController.text.trim(),
                  file: File('Temp'),
                  source: MediaSource.textEditor,
                ),
          ),
          (route) => route.settings.name == Routes.home,
        );
      } else {
        /// Update Home Feeds
        if (context.mounted) {
          FeedView2.update(context);
          servLocator<PostCollectionsController>().clear();
          servLocator<SelectedPostTagsController>().reset();
        }

        AppModule.I.popUntil((r) => r.settings.name == Routes.home);
      }
    }
  }

  void _onSegmentSelected(BuildContext context, String segment) {
    _segmentController.text = segment;

    final categoriesBloc = context.read<PostCategoriesBloc>();
    categoriesBloc.add(GetPostCategoriesBySegmentEvent(segment: segment));

    final nuppsBloc = context.read<NuppsBloc>();

    if (_nameTextController.text.trim().isNotEmpty) {
      nuppsBloc.add(
        GetAutocompleteNuppsEvent(
          segment: segment,
          query: _nameTextController.text.trim(),
        ),
      );
    } else {
      nuppsBloc.clearResult();
    }

    _navigateToNextStep(context);
  }

  void _navigateToNextStep(BuildContext context) {
    if (_pageController.page == 0) {
      if (!_descriptionFormKey.currentState!.validate()) return;

      final bloc = context.read<PostSegmentsBloc>();
      bloc.add(const GetPostFeedSegmentsEvent());
    }

    _pageController.nextPage(
      duration: const Duration(milliseconds: 200),
      curve: Curves.easeInOut,
    );
  }

  void _navigateToReviewStep() {
    _pageController.animateToPage(
      0,
      duration: const Duration(milliseconds: 200),
      curve: Curves.easeInOut,
    );
  }

  @override
  Stream<CreatePostState>? get onStateListener => bloc.stream;

  @override
  onStateResultListener(BuildContext context, CreatePostState state) {
    if (state is CreatePostErrorState) {
      AppModule.I.notify(context, state.message, mode: AppToastMode.error);
    }
  }
}
