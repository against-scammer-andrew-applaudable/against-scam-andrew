import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../app_module.dart';
import '../../../../core/bloc/widgets/base_stateless_page.dart';
import '../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../core/extensions/app_module_extensions.dart';
import '../../../../core/extensions/build_context_extensions.dart';
import '../../../../core/pages/image_gallery/camera_view.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/theme/styles.dart';
import '../../../../core/widgets/svg_icons.dart';
import '../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../../../feed/presentation/widgets/feed_view.dart';
import '../../../post_collections/presentation/providers/post_collections_controller.dart';
import '../../../profile/presentation/pages/profile_page.dart';
import '../cubit/create_post_cubit.dart';
import '../providers/selected_post_tags_controller.dart';
import '../widgets/post_media_upload_error_view.dart';
import '../widgets/post_media_upload_view.dart';
import '../widgets/suggestions_tags_view.dart';
import 'create_post_page/create_post_page.dart';

class PostConfirmationArgs {
  final String postId;
  final SelectedMedia? postMedia;
  final CreatePostFrom from;
  final bool isStoryPost;

  PostConfirmationArgs({
    required this.postId,
    this.postMedia,
    this.from = CreatePostFrom.home,
    this.isStoryPost = false,
  });
}

// ignore: must_be_immutable
class PostPublishedConfirmationPage
    extends BaseStatelessPage<CreatePostCubit, CreatePostState> {
  static const String routeName = '/post-published-confirmation-page';

  final PostConfirmationArgs args;

  PostPublishedConfirmationPage({super.key, required this.args});

  @override
  Widget build(BuildContext context) {
    registerBloc(context);

    final suggestionsCount =
        context.read<SelectedPostTagsController>().suggestions.length;

    return Scaffold(
      body: DNGBlocBuilder<CreatePostCubit, CreatePostState>(
        bloc: bloc,
        builder: (context, state) {
          return SafeArea(
            child: Stack(
              children: [
                // Positioned(
                //   top: context.screenHeight * 0.15,
                //   left: 0,
                //   right: 0,
                //   child: SvgIcons.centerBGLogo(),
                // ),
                AppSideMargins(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const SizedBox(height: AppDimensions.largeSidePadding),
                      (state is AddPostMediaLoadingState)
                          ? Container()
                          : Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                GestureDetector(
                                  child: Container(
                                    color: Colors.transparent,
                                    padding: const EdgeInsets.all(
                                      AppDimensions.smallSidePadding,
                                    ),
                                    child: SvgIcons.close(
                                      color: AppColors.primaryColor,
                                    ),
                                  ),
                                  onTap: () {
                                    _resetTagsAndRefreshFeeds(context);

                                    AppModule.I.pop();
                                  },
                                ),
                              ],
                            ),
                      const SizedBox(height: 25),
                      Expanded(
                        child: Center(
                          child: SingleChildScrollView(
                            padding: EdgeInsets.only(
                              top: suggestionsCount > 5
                                  ? context.screenHeight * 0.12
                                  : 0,
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                const SizedBox(height: 20),
                                (state is AddPostMediaErrorState)
                                    ? SvgIcons.mediaErrorLogo()
                                    : SvgIcons.postConfirmLogo(),
                                const SizedBox(height: 25),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: AppDimensions.smallSidePadding,
                                  ),
                                  child: Text(
                                    state is AddPostMediaErrorState
                                        ? translations.post_media_upload_err_msg
                                        : translations.post_confirmation_msg,
                                    style: AppStyles.header1(color: context.textColor),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                                const SizedBox(height: 35),
                                WillPopScope(
                                  onWillPop: () {
                                    if (args.postMedia != null &&
                                        state is AddPostMediaLoadingState) {
                                      return Future.value(false);
                                    }

                                    _resetTagsAndRefreshFeeds(context);

                                    return Future.value(true);
                                  },
                                  child: _buildPostUploadView(context, state),
                                ),
                                const SizedBox(
                                  height: AppDimensions.defaultSidePadding,
                                ),
                                Visibility(
                                  maintainSize: true,
                                  maintainAnimation: true,
                                  maintainState: true,
                                  visible: state is! AddPostMediaErrorState,
                                  child: SuggestionsTagsView(
                                    postId: args.postId,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  void _resetTagsAndRefreshFeeds(BuildContext context) {
    /// The goal is on success create a new post
    /// update the feed to get the initial page
    FeedView2.update(context);

    /// Reset used selection controllers
    context.read<SelectedPostTagsController>().reset();
    context.read<PostCollectionsController>().clear();
  }

  @override
  void initBloc(BuildContext context, CreatePostCubit bloc) {
    if (args.postMedia != null) {
      bloc.addMediaToPost(postId: args.postId, media: args.postMedia!);
    }
  }

  @override
  Stream<CreatePostState>? get onStateListener => bloc.stream;

  @override
  onStateResultListener(BuildContext context, CreatePostState state) {
    if (state is MediaAddedToPostState) {
      if (args.from == CreatePostFrom.profile) {
        /// Update Profile Story
        if (context.mounted) {
          ProfilePage.update(context, updateProfileStory: true);
        }
        AppModule.I.pop();
      } else if (args.from == CreatePostFrom.home && args.isStoryPost) {
        /// Update Home Feeds
        if (context.mounted) {
          FeedView2.update(context);
        }
        AppModule.I.pop();
      }
    }
  }

  Widget _buildPostUploadView(BuildContext context, CreatePostState state) {
    if (state is AddPostMediaLoadingState) {
      return PostMediaUploadView(
        progress: state.current,
        total: state.total,
      );
    } else if (state is AddPostMediaErrorState) {
      return PostMediaErrorView(args: args);
    }

    return Center(
      child: Container(
        width: 26,
        height: 2,
        margin: EdgeInsets.only(
          top: context.screenHeight * 0.08,
        ),
        color: AppColors.darkPeach2,
      ),
    );
  }
}
