import 'package:flutter/material.dart';

import '../../../../core/extensions/build_context_extensions.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/styles.dart';
import '../../../../core/utils/formatters/capitalize_text_formatter.dart';
import '../../../../core/widgets/app_bar.dart';
import '../../../../core/widgets/app_scaffold.dart';
import '../../../../generated/l10n.dart';
import '../../../auth/presentation/widgets/buttons/action_button.dart';
import '../../../auth/presentation/widgets/inputs/text_field.dart';
import '../../../auth/presentation/widgets/sizing/side_margins.dart';

class EditStoryQuestionPageArgs {
  final String title;
  final String text;

  EditStoryQuestionPageArgs({required this.title, required this.text});
}

class EditStoryQuestionPage extends StatelessWidget {
  static const String routeName = '/edit-story-question-page';

  final EditStoryQuestionPageArgs args;

  EditStoryQuestionPage({super.key, required this.args});

  final _titleController = TextEditingController();
  final _textController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return AppScaffold(
      appBar: const NavigationPageBar(),
      body: AppSideMargins(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                decoration: BoxDecoration(
                  border: Border.all(color: AppColors.darkPeach2),
                ),
                child: AppTextField(
                  controller: _titleController..text = args.title,
                  labelText: translations.title,
                  labelColor: AppColors.mediumGrey,
                  style: AppStyles.header1(color: context.textColor),
                  padding: const EdgeInsets.all(20),
                  maxLines: null,
                  textInputType: TextInputType.multiline,
                  inputFormatters: [
                    CapitalizeTextFormatter(
                      capitalization: TextCapitalization.words,
                    )
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Container(
                decoration: BoxDecoration(
                  border: Border.all(color: AppColors.darkPeach2),
                ),
                child: AppTextField(
                  controller: _textController..text = args.text,
                  labelText: translations.text,
                  initialValue: args.text,
                  labelColor: AppColors.mediumGrey,
                  style: AppStyles.text2(color: AppColors.darkGrey),
                  padding: const EdgeInsets.all(20),
                  maxLines: null,
                  textInputType: TextInputType.multiline,
                  inputFormatters: [
                    CapitalizeTextFormatter(
                      capitalization: TextCapitalization.sentences,
                    )
                  ],
                ),
              ),
              const SizedBox(height: 25),
              Row(
                children: [
                  Flexible(
                    child: AppActionButton.submitWithBorder(
                      backgroundColor: AppColors.transparent,
                      borderColor: AppColors.primaryColor,
                      actionTextColor: AppColors.primaryColor,
                      text: translations.cancel,
                      onPressed: context.pop,
                    ),
                  ),
                  const SizedBox(width: 15),
                  Flexible(
                    flex: 2,
                    child: AppActionButton.submit(
                      text: translations.save,
                      actionTextWeight: FontWeight.w600,
                      actionTextSize: 18,
                      onPressed: () {
                        final updatedArgs = EditStoryQuestionPageArgs(
                          title: _titleController.text,
                          text: _textController.text,
                        );

                        context.pop(updatedArgs);
                      },
                    ),
                  ),
                ],
              ),
              const SafeArea(child: SizedBox()),
            ],
          ),
        ),
      ),
    );
  }
}
