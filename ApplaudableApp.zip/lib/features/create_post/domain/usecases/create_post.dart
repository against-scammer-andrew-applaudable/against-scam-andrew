import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../entities/post_feed.dart';
import '../repositories/post_feed_repository.dart';

class CreatePostFeed extends UseCase<String, PostFeed> {
  final PostFeedRepository repository;

  CreatePostFeed({required this.repository});

  @override
  Future<Either<Failure, String>> call(PostFeed params) {
    return repository.createPost(params);
  }
}
