import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/entities/pagination_params.dart';
import '../../../../core/entities/pagination_response.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../entities/story_question.dart';
import '../repositories/post_feed_repository.dart';

class GetSuggestedStoryQuestions
    extends UseCase<PaginationResponse<StoryQuestion>, StoryPaginationParams> {
  final PostFeedRepository repository;

  GetSuggestedStoryQuestions({required this.repository});

  @override
  Future<Either<Failure, PaginationResponse<StoryQuestion>>> call(
    StoryPaginationParams params,
  ) {
    return repository.getSuggestedStoryQuestions(
      collection: params.collection,
      pageInfo: params.pageInfo,
    );
  }
}

class StoryPaginationParams extends Equatable {
  final String? collection;
  final PaginationParams pageInfo;

  const StoryPaginationParams({
    this.collection,
    this.pageInfo = const PaginationParams(),
  });

  @override
  List<Object?> get props => [collection, pageInfo];
}
