import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../params/improve_story_text_params.dart';
import '../repositories/post_feed_repository.dart';

class ImproveStoryText extends UseCase<String, ImproveStoryTextParams> {
  final PostFeedRepository repository;

  ImproveStoryText({required this.repository});

  @override
  Future<Either<Failure, String>> call(ImproveStoryTextParams params) {
    return repository.improveStoryText(params: params);
  }
}
