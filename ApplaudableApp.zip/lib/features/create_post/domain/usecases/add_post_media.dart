import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../../../onboarding/domain/usecases/upload_user_avatar.dart';
import '../entities/post_feed.dart';
import '../repositories/post_feed_repository.dart';

class AddPostMedia extends UseCase<PostMedia, PostMediaParams> {
  final PostFeedRepository repository;

  AddPostMedia({required this.repository});

  @override
  Future<Either<Failure, PostMedia>> call(PostMediaParams params) {
    return repository.addPostMedia(
      postId: params.postId,
      source: params.source,
      type: params.type,
      text: params.text,
    );
  }
}

class PostMediaParams extends Equatable {
  final String postId;
  final AvatarParams source;
  final String type;
  final String? text;

  const PostMediaParams({
    required this.postId,
    required this.source,
    required this.type,
    this.text,
  });

  @override
  List<Object?> get props => [postId, source, type, text];
}
