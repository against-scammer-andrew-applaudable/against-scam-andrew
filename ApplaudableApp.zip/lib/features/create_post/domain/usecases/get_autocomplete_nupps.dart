import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/entities/pagination_params.dart';
import '../../../../core/entities/pagination_response.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../entities/nupp.dart';
import '../repositories/post_feed_repository.dart';

class GetAutocompleteNupps
    extends UseCase<PaginationResponse<Nupp>, AutocompleteNuppsParams> {
  final PostFeedRepository repository;

  GetAutocompleteNupps({required this.repository});

  @override
  Future<Either<Failure, PaginationResponse<Nupp>>> call(
    AutocompleteNuppsParams params,
  ) {
    return repository.getAutocompleteNupps(
      segment: params.segment,
      query: params.query,
      categoryId: params.categoryId,
      location: params.location,
      pageInfo: params.pageInfo,
    );
  }
}

class AutocompleteNuppsParams extends Equatable {
  final String segment;
  final String query;
  final String? categoryId;
  final String? location;
  final PaginationParams pageInfo;

  const AutocompleteNuppsParams({
    required this.segment,
    required this.query,
    required this.categoryId,
    required this.location,
    this.pageInfo = const PaginationParams(),
  });

  @override
  List<Object?> get props => [segment, query, categoryId, location, pageInfo];
}
