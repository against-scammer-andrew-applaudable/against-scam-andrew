import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../enums/create_post_enums.dart';
import '../repositories/post_feed_repository.dart';

class UpdatePostTag extends UseCase<bool, PostTagParams> {
  final PostFeedRepository repository;

  UpdatePostTag({required this.repository});

  @override
  Future<Either<Failure, bool>> call(PostTagParams params) {
    return repository.updatePostTags(
      postId: params.postId,
      tags: params.tags,
      mode: params.mode,
    );
  }
}

class PostTagParams extends Equatable {
  final String postId;
  final List<String> tags;
  final PostTagMode mode;

  const PostTagParams({
    required this.postId,
    required this.tags,
    this.mode = PostTagMode.add,
  });

  @override
  List<Object?> get props => [postId, tags, mode];
}
