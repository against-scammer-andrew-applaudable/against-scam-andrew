import 'package:equatable/equatable.dart';

class ImproveStoryTextParams extends Equatable {
  final String question;
  final String title;
  final String text;
  final List<String> tones;
  final List<String> collections;

  const ImproveStoryTextParams({
    required this.question,
    required this.title,
    required this.text,
    required this.tones,
    required this.collections,
  });

  Map<String, dynamic> toJson() {
    return {
      'question': question,
      'title': title,
      'answer': text,
      'tones': tones,
      'collection': collections.first,
    };
  }

  @override
  List<Object?> get props => [question, title, text, tones, collections];
}
