import '../../../../core/extensions/list_extensions.dart';

// @Deprecated(
//   "This enum values are deprecated and replaced by values coming from API",
// )
enum PostSegment {
  someone,
  something,
  somewhere;

  static PostSegment getSegmentByName(String? name) =>
      values.firstWhereOrNull((e) => e.name == name?.trim()) ??
      PostSegment.something;
}

enum PostTagMode { add, remove, update }
