import 'package:equatable/equatable.dart';

import '../../../../core/entities/item.dart';
import '../../data/models/story_question_model.dart';

abstract class StoryQuestion extends Equatable {
  final int id;
  final String question;
  final String title;
  final StoryQuestionCollection collection;
  final String answerExample;
  final List<String> tones;

  const StoryQuestion({
    required this.id,
    required this.question,
    required this.title,
    required this.collection,
    required this.answerExample,
    required this.tones,
  });
}

abstract class StoryQuestionCollection
    with EquatableMixin
    implements Item<StoryQuestionCollectionModel> {
  @override
  final String id;

  @override
  final String name;

  final StoryQuestionCollectionType collectionsType;

  const StoryQuestionCollection({
    required this.id,
    required this.name,
    required this.collectionsType,
  });

  @override
  copyWith();

  @override
  String get value => collectionsType.id;
}

abstract class StoryQuestionCollectionType extends Equatable {
  final String id;
  final String name;

  const StoryQuestionCollectionType({required this.id, required this.name});
}
