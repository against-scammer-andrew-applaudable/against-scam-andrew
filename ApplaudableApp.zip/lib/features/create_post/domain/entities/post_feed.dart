import 'dart:io';

import 'package:equatable/equatable.dart';

import '../../../../core/entities/base_image.dart';
import '../../../post/domain/entities/post_entities.dart';
import '../../../post_categories/domain/entities/post_category.dart';

enum PostRanking { low, medium, high }

abstract class PostFeed extends Equatable {
  final String id;
  final PostOwner owner;
  final String? date;
  final String when;
  final String whenFormat;
  final PostRanking? ranking;
  final PostCounters counters;
  final List<PostMedia> media;
  final String text;
  final List<PostElement> elements;
  final List<PostCollection> collections;
  final String type;
  final String? relatedPostId;
  final String? segment;
  final String? categoryId;
  final List<PostCategory> categories;
  final List<PostTag> tags;
  final String? nupp;
  final String? user;
  final PostEngagement engagement;
  final CreatePostNuppData? createPostNupp;
  final String? location;
  final String? title;

  const PostFeed({
    required this.id,
    required this.owner,
    required this.date,
    required this.when,
    required this.whenFormat,
    required this.ranking,
    required this.counters,
    required this.media,
    required this.text,
    required this.elements,
    required this.collections,
    required this.type,
    required this.relatedPostId,
    required this.segment,
    required this.categoryId,
    required this.categories,
    required this.tags,
    required this.nupp,
    required this.user,
    required this.engagement,
    required this.createPostNupp,
    required this.location,
    required this.title,
  });
}

abstract class PostOwner extends Equatable {
  final String id;
  final String? avatar;
  final String name;

  const PostOwner({required this.id, required this.avatar, required this.name});
}

abstract class PostCounters extends Equatable {
  final int applauds;
  final int shares;
  final int influences;

  const PostCounters({
    required this.applauds,
    required this.shares,
    required this.influences,
  });
}

abstract class PostMedia extends Equatable with BaseImage {
  final String url;
  final String type;
  final String id;
  final String? text;
  final File? source;

  const PostMedia({
    required this.url,
    required this.type,
    required this.id,
    this.text,
    this.source,
  });

  @override
  ImageOptimizationSizes get defaultSize => ImageOptimizationSizes.qAutoBest;

  @override
  String get defaultImage => url;
}

/*abstract class PostElement extends Equatable {
  final String type;
  final String? text;
  final String? userId;
  final String? nuppId;
  final String? inviteId;
  final List<PostElement> elements;

  const PostElement({
    required this.type,
    this.text,
    this.userId,
    this.nuppId,
    this.inviteId,
    this.elements = const [],
  });
}*/

abstract class PostCollection extends Equatable {
  final String id;

  const PostCollection({required this.id});
}

abstract class PostEngagement extends Equatable {
  final bool applauds;
  final bool bookmarked;

  const PostEngagement({required this.applauds, required this.bookmarked});
}

abstract class CreatePostNuppData extends Equatable {
  final String type;
  final String name;
  final String? source;
  final String? sourceRef;

  const CreatePostNuppData({
    required this.type,
    required this.name,
    this.source,
    this.sourceRef,
  });
}
