import 'package:equatable/equatable.dart';

import 'post_feed.dart';

abstract class Nupp extends Equatable {
  final String description;
  final String? nuppId;
  final String? sourceRef;
  final String? source;
  final String? categoryId;
  final List<String> tags;
  final String mainText;
  final String secondaryText;
  final NuppMetaData metadata;
  final PostMedia? media;

  const Nupp(
      {required this.description,
      required this.nuppId,
      required this.sourceRef,
      required this.source,
      required this.categoryId,
      required this.tags,
      required this.mainText,
      required this.secondaryText,
      required this.metadata,
      this.media});
}

abstract class NuppMetaData extends Equatable {
  final String? name;
  final String? username;

  const NuppMetaData({required this.name, required this.username});
}
