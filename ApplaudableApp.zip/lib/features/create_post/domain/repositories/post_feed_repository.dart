import 'package:dartz/dartz.dart';

import '../../../../core/entities/pagination_params.dart';
import '../../../../core/entities/pagination_response.dart';
import '../../../../core/errors/failures.dart';
import '../../../feed/domain/enums/posts_enum.dart';
import '../../../onboarding/domain/usecases/upload_user_avatar.dart';
import '../../../post_categories/domain/entities/post_category.dart';
import '../entities/nupp.dart';
import '../entities/post_feed.dart';
import '../entities/story_question.dart';
import '../enums/create_post_enums.dart';
import '../params/improve_story_text_params.dart';

abstract class PostFeedRepository {
  /// Create Post Actions
  Future<Either<Failure, String>> createPost(PostFeed post);

  Future<Either<Failure, PostMedia>> addPostMedia({
    required String postId,
    required AvatarParams source,
    required String type,
    String? text,
  });

  /// Post Categories and Tags
  PaginatedResults<PostFeedSegment> getPostSegments({
    PaginationParams pageInfo = const PaginationParams(),
  });

  PaginatedResults<PostCategory> getPostCategoriesBySegment({
    required String segment,
    required int pageNo,
    required int pageSize,
    PostsFilterByType? type,
  });

  PaginatedResults<PostTag> getPostTags({
    String categoryId = '',
    required int pageNo,
    required int pageSize,
  });

  Future<Either<Failure, bool>> updatePostTags({
    required String postId,
    required List<String> tags,
    required PostTagMode mode,
  });

  /// Get Autocomplete Nupps
  PaginatedResults<Nupp> getAutocompleteNupps({
    required String segment,
    required String query,
    String? categoryId,
    String? location,
    PaginationParams pageInfo = const PaginationParams(),
  });

  /// Edit Post
  // Future<Either<Failure, bool>> updatePost({required EditPostParams params});

  /// List Story Repository Callbacks
  PaginatedResults<StoryQuestion> getSuggestedStoryQuestions({
    String? collection,
    PaginationParams pageInfo = const PaginationParams(),
  });

  Future<Either<Failure, String>> improveStoryText({
    required ImproveStoryTextParams params,
  });
}
