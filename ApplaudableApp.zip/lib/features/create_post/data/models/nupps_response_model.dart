import '../../../../core/entities/pagination_response.dart';
import '../../domain/entities/nupp.dart';
import 'post_feed_model.dart';

class NuppsResponseModel extends PaginationResponse<NuppModel> {
  const NuppsResponseModel({
    required super.count,
    required super.next,
    required super.previous,
    required super.results,
  });

  factory NuppsResponseModel.fromJson(Map<String, dynamic> parsedJson) {
    return NuppsResponseModel(
      count: parsedJson['count'],
      next: parsedJson['next'],
      previous: parsedJson['previous'],
      results: ((parsedJson['results'] ?? []) as List<dynamic>)
          .map((e) => NuppModel.fromJson(e))
          .toList(),
    );
  }
}

class NuppModel extends Nupp {
  const NuppModel({
    required super.description,
    required super.nuppId,
    required super.sourceRef,
    required super.source,
    required super.categoryId,
    required super.tags,
    required super.mainText,
    required super.secondaryText,
    required super.metadata,
    super.media,
  });

  factory NuppModel.fromJson(Map<String, dynamic> parsedJson) {
    return NuppModel(
      description: parsedJson['description'],
      nuppId: parsedJson['nupp_id'],
      source: parsedJson['source'],
      sourceRef: parsedJson['source_ref'],
      categoryId: parsedJson['category_id'],
      tags: List<String>.from(parsedJson['tags']),
      mainText: parsedJson['structured_formatting']['main_text'],
      secondaryText:
          parsedJson['structured_formatting']['secondary_text'] ?? '',
      metadata: NuppMetaDataModel.fromJson(parsedJson['metadata']),
      media: parsedJson['media'] != null
          ? PostMediaModel.fromJson(parsedJson['media'])
          : null,
    );
  }

  @override
  List<Object?> get props => [
        description,
        nuppId,
        source,
        sourceRef,
        categoryId,
        tags,
        mainText,
        secondaryText,
        metadata,
      ];
}

class NuppMetaDataModel extends NuppMetaData {
  const NuppMetaDataModel({required super.name, required super.username});

  factory NuppMetaDataModel.fromJson(Map<String, dynamic> parsedJson) {
    return NuppMetaDataModel(
      name: parsedJson['name'],
      username: parsedJson['username'],
    );
  }

  Map<String, dynamic> toMap() {
    return {'name': name, 'username': username};
  }

  @override
  List<Object?> get props => [name, username];
}
