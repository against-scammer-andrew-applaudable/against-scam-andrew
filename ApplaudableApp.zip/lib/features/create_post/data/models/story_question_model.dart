import '../../../../core/entities/pagination_response.dart';
import '../../domain/entities/story_question.dart';

class StoryQuestionsResponse extends PaginationResponse<StoryQuestionModel> {
  const StoryQuestionsResponse({
    required super.count,
    required super.next,
    required super.previous,
    required super.results,
  });

  factory StoryQuestionsResponse.fromJson(Map<String, dynamic> parsedJson) {
    return StoryQuestionsResponse(
      count: parsedJson['count'] ?? 0,
      next: parsedJson['next'],
      previous: parsedJson['previous'],
      results: ((parsedJson['results'] ?? []) as List<dynamic>)
          .map((e) => StoryQuestionModel.fromJson(e))
          .toList(),
    );
  }

  @override
  Map<String, dynamic> toMap() {
    return {
      'count': count,
      'next': next,
      'previous': previous,
      'results': results.map((e) => e.toJson()).toList(),
    };
  }
}

class StoryQuestionModel extends StoryQuestion {
  const StoryQuestionModel({
    required super.id,
    required super.question,
    required super.title,
    required super.collection,
    required super.answerExample,
    required super.tones,
  });

  factory StoryQuestionModel.fromJson(Map<String, dynamic> parsedJson) {
    return StoryQuestionModel(
      id: parsedJson['id'] ?? -1,
      question: parsedJson['question'],
      title: parsedJson['title'] ?? '',
      collection:
          // ((parsedJson['collections'] ?? []) as List<dynamic>)
          // .map((e) =>
          StoryQuestionCollectionModel.fromJson(parsedJson['collection']),
      // )
      // .toList(),
      answerExample: parsedJson['answer_example'],
      tones: List<String>.from(((parsedJson['tones'] ?? []) as List<dynamic>)),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'question': question,
      'title': title,
      'collection': (collection as StoryQuestionCollectionModel).toJson(),
      //  )
      // .map((e) => (e
      // .toList(),
      'answer_example': answerExample,
      'tones': tones,
    };
  }

  @override
  List<Object?> get props =>
      [id, question, title, collection, answerExample, tones];
}

class StoryQuestionCollectionModel extends StoryQuestionCollection {
  const StoryQuestionCollectionModel({
    required super.id,
    required super.name,
    required super.collectionsType,
  });

  factory StoryQuestionCollectionModel.fromJson(
    Map<String, dynamic> parsedJson,
  ) {
    return StoryQuestionCollectionModel(
      id: parsedJson['id'],
      name: parsedJson['name'],
      collectionsType: StoryQuestionCollectionTypeModel.fromJson(
        parsedJson['collection_type'],
      ),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'collection_type':
          (collectionsType as StoryQuestionCollectionTypeModel).toJson()
    };
  }

  @override
  List<Object?> get props => [id, name, collectionsType];

  @override
  StoryQuestionCollectionModel copyWith() {
    return StoryQuestionCollectionModel(
        id: id, name: name, collectionsType: collectionsType);
  }
}

class StoryQuestionCollectionTypeModel extends StoryQuestionCollectionType {
  const StoryQuestionCollectionTypeModel({
    required super.id,
    required super.name,
  });

  factory StoryQuestionCollectionTypeModel.fromJson(
    Map<String, dynamic> parsedJson,
  ) {
    return StoryQuestionCollectionTypeModel(
      id: parsedJson['id'],
      name: parsedJson['name'],
    );
  }

  Map<String, dynamic> toJson() {
    return {'id': id, 'name': name};
  }

  @override
  List<Object?> get props => [id, name];
}
