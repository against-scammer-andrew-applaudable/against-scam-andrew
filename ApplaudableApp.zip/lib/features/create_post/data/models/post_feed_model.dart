import '../../../post/data/models/post_response_models.dart';
import '../../../post/domain/entities/post_entities.dart';
import '../../../post_categories/data/models/post_categories_response_model.dart';
import '../../../post_categories/data/models/post_tags_response_model.dart';
import '../../domain/entities/post_feed.dart';

class PostFeedModel extends PostFeed {
  const PostFeedModel({
    required super.id,
    required super.owner,
    required super.date,
    required super.when,
    required super.whenFormat,
    required super.ranking,
    required super.counters,
    required super.media,
    required super.text,
    required super.elements,
    required super.collections,
    required super.type,
    required super.relatedPostId,
    required super.segment,
    required super.categories,
    super.categoryId,
    required super.tags,
    required super.nupp,
    required super.user,
    required super.engagement,
    super.createPostNupp,
    super.location,
    super.title,
  });

  factory PostFeedModel.fromJson(Map<String, dynamic> parsedJson) {
    return PostFeedModel(
      id: parsedJson["id"] ?? '',
      owner: PostOwnerModel.fromJson(parsedJson['owner']),
      date: parsedJson["date"],
      when: parsedJson["when"] ?? '',
      whenFormat: parsedJson["when_date_format"] ?? 'DMY',
      ranking: PostRanking.values[parsedJson["ranking"] - 1],
      counters: PostCountersModel.fromJson(parsedJson['counters'] ?? {}),
      media: ((parsedJson["media"] ?? []) as List<dynamic>)
          .map((e) => PostMediaModel.fromJson(e))
          .toList(),
      text: parsedJson["text"] ?? "",
      elements: ((parsedJson["elements"] ?? []) as List<dynamic>)
          .map((e) => PostElementModel.fromJson(e))
          .toList(),
      collections: ((parsedJson['collections'] ?? []) as List<dynamic>)
          .map((e) => PostCollectionModel.fromJson(e))
          .toList(),
      type: parsedJson['type'] ?? '',
      relatedPostId: parsedJson['related_post_id'],
      segment: parsedJson['segment'],
      categories: ((parsedJson['categories'] ?? []) as List<dynamic>)
          .map((e) => PostCategoryModel.fromJson(e))
          .toList(),
      tags: ((parsedJson['tags'] ?? []) as List<dynamic>)
          .map((e) => PostTagModel.fromJson(e))
          .toList(),
      nupp: parsedJson['nupp'],
      user: parsedJson['user'],
      engagement: PostEngagementModel.fromJson(parsedJson['engagement'] ?? {}),
      createPostNupp: parsedJson['create'] == null
          ? null
          : CreatePostNuppDataModel.fromJson(parsedJson['create']),
    );
  }

  factory PostFeedModel.prepareForCreatePost({
    required String when,
    required String text,
    required String type,
    String whenFormat = '',
    PostRanking? ranking,
    String? segment,
    List<String> tags = const [],
    List<PostElement> elements = const [],
    List<String>? collections,
    String? categoryId,
    String? nupp,
    String? relatedPostId,
    String? user,
    CreatePostNuppData? createNuppData,
    String? location,
    String? title,
  }) {
    return PostFeedModel(
      when: when,
      whenFormat: whenFormat,
      ranking: ranking,
      text: text,
      type: type,
      relatedPostId: relatedPostId,
      segment: segment,
      categories: const [],
      categoryId: categoryId,
      tags: tags.map((e) => PostTagModel(id: e, label: '')).toList(),
      nupp: nupp,
      user: user,
      // redundant data
      id: '',
      date: '',
      collections:
          collections?.map((e) => PostCollectionModel(id: e)).toList() ?? [],
      owner: const PostOwnerModel(id: '', name: '', avatar: ''),
      counters: const PostCountersModel(applauds: 0, shares: 0, influences: 0),
      media: const [],
      elements: elements,
      engagement: const PostEngagementModel(applauds: false, bookmarked: false),
      createPostNupp: createNuppData,
      location: location,
      title: title,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'when': when,
      'when_date_format': whenFormat,
      if (ranking != null) 'ranking': ranking!.index + 1,
      'text': text,
      'type': type,
      if (segment != null) 'segment': segment!,
      if (categoryId != null) 'category': categoryId,
      if (categories.isNotEmpty)
        'categories': categories.map((e) => e.id).toList(),
      if (tags.isNotEmpty) 'tags': tags.map((e) => e.id).toList(),
      if (collections.isNotEmpty)
        'collections': collections.map((e) => e.id).toList(),
      'elements': elements.map((e) => (e as PostElementModel).toMap()).toList(),
      if (relatedPostId != null) 'related_post_id': relatedPostId,
      if (nupp != null) 'nupp': nupp,
      if (user != null) 'user': user,
      if (createPostNupp != null && nupp == null)
        'create': (createPostNupp as CreatePostNuppDataModel).toMap(),
      if (location != null) 'location': location,
      if (title != null) 'title': title,
    };
  }

  @override
  List<Object?> get props => [
        id,
        owner,
        date,
        when,
        whenFormat,
        ranking,
        counters,
        media,
        text,
        elements,
        collections,
        type,
        relatedPostId,
        segment,
        categoryId,
        categories,
        nupp,
        user,
        engagement,
        location,
        title,
      ];
}

class PostOwnerModel extends PostOwner {
  const PostOwnerModel({
    required super.id,
    required super.avatar,
    required super.name,
  });

  factory PostOwnerModel.fromJson(Map<String, dynamic> parsedJson) {
    return PostOwnerModel(
      id: parsedJson['id'],
      avatar: parsedJson['avatar'],
      name: parsedJson['name'],
    );
  }

  @override
  List<Object?> get props => [id, avatar, name];
}

class PostCountersModel extends PostCounters {
  const PostCountersModel({
    required super.applauds,
    required super.shares,
    required super.influences,
  });

  factory PostCountersModel.fromJson(Map<String, dynamic> parsedJson) {
    return PostCountersModel(
      applauds: parsedJson['applauds'] ?? 0,
      shares: parsedJson['shares'] ?? 0,
      influences: parsedJson['influences'] ?? 0,
    );
  }

  @override
  List<Object?> get props => [applauds, shares, influences];
}

class PostMediaModel extends PostMedia {
  const PostMediaModel({
    required super.url,
    required super.type,
    required super.id,
    required super.text,
  });

  factory PostMediaModel.fromJson(Map<String, dynamic> parsedJson) {
    return PostMediaModel(
      id: parsedJson['id'] ?? '',
      type: parsedJson['type'],
      url: parsedJson['url'] ?? '',
      text: parsedJson['text'],
    );
  }

  @override
  List<Object?> get props => [url, type, id];
}

/*@Deprecated("use from Post feature")
class PostElementModel extends PostElement {
  const PostElementModel({
    required super.type,
    super.text,
    super.userId,
    super.nuppId,
    super.elements,
    super.inviteId,
  });

  factory PostElementModel.fromJson(Map<String, dynamic> parsedJson) {
    return PostElementModel(
      type: parsedJson['type'],
      text: parsedJson['text'],
      userId: parsedJson['user_id'],
      nuppId: parsedJson['nupp_id'],
      inviteId: parsedJson['invite_id'],
      elements: ((parsedJson['elements'] ?? []) as List<dynamic>)
          .map((e) => PostElementModel.fromJson(e))
          .toList(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'type': type,
      if (userId != null) 'user_id': userId,
      if (nuppId != null) 'nupp_id': nuppId,
      if (inviteId != null) 'invite_id': inviteId,
      if (text != null) 'text': text,
      if (elements.isNotEmpty)
        'elements':
            elements.map((e) => (e as PostElementModel).toMap()).toList(),
    };
  }

  @override
  List<Object?> get props => [type, text, userId, inviteId, elements];
}*/

class PostCollectionModel extends PostCollection {
  const PostCollectionModel({required super.id});

  factory PostCollectionModel.fromJson(Map<String, dynamic> parsedJson) {
    return PostCollectionModel(id: parsedJson['id']);
  }

  @override
  List<Object?> get props => [id];
}

class PostEngagementModel extends PostEngagement {
  const PostEngagementModel({
    required super.applauds,
    required super.bookmarked,
  });

  factory PostEngagementModel.fromJson(Map<String, dynamic> parsedJson) {
    return PostEngagementModel(
      applauds: parsedJson["applauds"] ?? false,
      bookmarked: parsedJson["bookmarked"] ?? false,
    );
  }

  @override
  List<Object?> get props => [applauds, bookmarked];
}

class CreatePostNuppDataModel extends CreatePostNuppData {
  const CreatePostNuppDataModel({
    required super.type,
    required super.name,
    super.source,
    super.sourceRef,
  });

  factory CreatePostNuppDataModel.fromJson(Map<String, dynamic> parsedJson) {
    return CreatePostNuppDataModel(
      type: parsedJson['type'],
      name: parsedJson['name'],
      source: parsedJson['source'],
      sourceRef: parsedJson['source_ref'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'type': type,
      'name': name,
      if (sourceRef != null) 'source': source,
      if (sourceRef != null) 'source_ref': sourceRef,
    };
  }

  @override
  List<Object?> get props => [type, name, source, sourceRef];
}
