import 'package:flutter/foundation.dart';

import '../../../../core/api/api_config.dart';
import '../../../../core/api/api_service.dart';
import '../../../../core/api/remote_api_service.dart';
import '../../../../core/entities/pagination_params.dart';
import '../../../feed/domain/enums/posts_enum.dart';
import '../../../onboarding/domain/usecases/upload_user_avatar.dart';
import '../../../post_categories/data/models/post_categories_response_model.dart';
import '../../../post_categories/data/models/post_tags_response_model.dart';
import '../../domain/enums/create_post_enums.dart';
import '../../domain/params/improve_story_text_params.dart';
import '../models/nupps_response_model.dart';
import '../models/post_feed_model.dart';
import '../models/story_question_model.dart';

abstract class PostFeedRemoteDataSource {
  /// Create Post Actions
  Future<String> createPostFeed(PostFeedModel post);

  Future<PostMediaModel> addPostMedia({
    required String postId,
    required AvatarParams source,
    required String type,
    String? text,
  });

  /// Get Post Categories and Tags
  Future<PostSegmentsResponse> getPostFeedSegments({
    PaginationParams pageInfo = const PaginationParams(),
  });

  Future<PostCategoriesResponseModel> getPostCategoriesBySegment({
    required String segment,
    required int pageNo,
    required int pageSize,
    PostsFilterByType? type,
  });

  Future<PostTagsResponseModel> getPostTags({
    String categoryId = '',
    required int pageNo,
    required int pageSize,
  });

  Future<bool> updatePostTag({
    required String postId,
    required List<String> tags,
    required PostTagMode mode,
  });

  /// Get Autocomplete Nupps
  Future<NuppsResponseModel> getAutocompleteNupps({
    required String segment,
    required String query,
    String? categoryId,
    String? location,
    PaginationParams pageInfo = const PaginationParams(),
  });

  /// List Story Post Callbacks
  Future<StoryQuestionsResponse> getSuggestedStoryQuestions({
    String? collection,
    PaginationParams pageInfo = const PaginationParams(),
  });

  Future<String> improveStoryText({
    required ImproveStoryTextParams params,
  });
}

class AppPostFeedRemoteDataSource extends PostFeedRemoteDataSource {
  ApiService _apiService = RemoteApiService.api;

  @visibleForTesting
  set setMockApiClient(ApiService service) => _apiService = service;

  @override
  Future<PostMediaModel> addPostMedia({
    required String postId,
    required AvatarParams source,
    required String type,
    String? text,
  }) async {
    final parsedJson = await _apiService.multiPartRequest(
      url: ApiResource.addPostMedia(postId),
      body: {
        'type': type,
        if (text != null) 'text': text,
      },
      filesToUpload:
          type == 'text' ? [] : [MapEntry('source', source.mediaFile)],
      onReceiveProgress: source.onReceiveProgress,
      onSendProgress: source.onSendProgress,
    );

    return PostMediaModel.fromJson(parsedJson);
  }

  @override
  Future<String> createPostFeed(PostFeedModel post) async {
    final parsedJson = await _apiService.post(
      url: ApiResource.createPostFeed,
      body: post.toMap(),
    );

    return parsedJson['id'].toString();
  }

  @override
  Future<PostCategoriesResponseModel> getPostCategoriesBySegment({
    required String segment,
    required int pageNo,
    required int pageSize,
    PostsFilterByType? type,
  }) async {
    final parsedJson = await _apiService.get(
      url: ApiResource.getPostCategories(
        segment: segment,
        pageNo: pageNo,
        pageSize: pageSize,
        type: type,
      ),
    );

    return PostCategoriesResponseModel.fromJson(parsedJson);
  }

  @override
  Future<PostTagsResponseModel> getPostTags({
    String categoryId = '',
    required int pageNo,
    required int pageSize,
  }) async {
    final parsedJson = await _apiService.get(
      url: ApiResource.getPostTags(
        categoryId: categoryId,
        pageNo: pageNo,
        pageSize: pageSize,
      ),
    );

    return PostTagsResponseModel.fromJson(parsedJson);
  }

  @override
  Future<bool> updatePostTag({
    required String postId,
    required List<String> tags,
    required PostTagMode mode,
  }) async {
    await _apiService.patch(
      url: ApiResource.editPost(postId: postId),
      body: {'tags': tags},
    );

    return true;
  }

  @override
  Future<NuppsResponseModel> getAutocompleteNupps({
    required String segment,
    required String query,
    String? categoryId,
    String? location,
    PaginationParams pageInfo = const PaginationParams(),
  }) async {
    final parsedJson = await _apiService.get(
      url: ApiResource.getAutocompleteNupps(
        segment: segment,
        query: query,
        categoryId: categoryId,
        location: location,
        pageInfo: pageInfo,
      ),
    );

    return NuppsResponseModel.fromJson(parsedJson);
  }

  @override
  Future<StoryQuestionsResponse> getSuggestedStoryQuestions({
    String? collection,
    PaginationParams pageInfo = const PaginationParams(),
  }) async {
    final parsedJson = await _apiService.get(
      url: ApiResource.lifeStoryQuestionsEndpoint(
        pageInfo,
        collection: collection,
      ),
    );

    return StoryQuestionsResponse.fromJson(parsedJson);
  }

  @override
  Future<String> improveStoryText({
    required ImproveStoryTextParams params,
  }) async {
    final parsedJson = await _apiService.post(
      url: ApiResource.improveStoryTextWithAIEnpoint,
      body: params.toJson(),
    );

    return parsedJson['text'] ?? params.text;
  }

  @override
  Future<PostSegmentsResponse> getPostFeedSegments({
    PaginationParams pageInfo = const PaginationParams(),
  }) async {
    final parsedJson = await _apiService.get(
      url: ApiResource.getPostSegments(pageInfo: pageInfo),
    );

    return PostSegmentsResponse.fromJson(parsedJson);
  }
}
