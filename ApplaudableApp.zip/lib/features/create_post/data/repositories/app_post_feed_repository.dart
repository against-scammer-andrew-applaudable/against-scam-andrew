import 'package:dartz/dartz.dart';

import '../../../../core/entities/pagination_params.dart';
import '../../../../core/entities/pagination_response.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/errors/repository_call_handler.dart';
import '../../../feed/domain/enums/posts_enum.dart';
import '../../../onboarding/domain/usecases/upload_user_avatar.dart';
import '../../../post_categories/data/models/post_categories_response_model.dart';
import '../../../post_categories/domain/entities/post_category.dart';
import '../../domain/entities/nupp.dart';
import '../../domain/entities/post_feed.dart';
import '../../domain/entities/story_question.dart';
import '../../domain/enums/create_post_enums.dart';
import '../../domain/params/improve_story_text_params.dart';
import '../../domain/repositories/post_feed_repository.dart';
import '../datasources/post_feed_remote_data_source.dart';
import '../models/post_feed_model.dart';

class AppPostFeedRepository extends PostFeedRepository {
  final RepositoryCallHandler callHandler;
  final PostFeedRemoteDataSource remoteDataSource;

  AppPostFeedRepository({
    required this.callHandler,
    required this.remoteDataSource,
  });

  @override
  Future<Either<Failure, String>> createPost(PostFeed post) {
    return callHandler.handleCall<String>(
      () => remoteDataSource.createPostFeed(post as PostFeedModel),
    );
  }

  @override
  Future<Either<Failure, PostMedia>> addPostMedia({
    required String postId,
    required AvatarParams source,
    required String type,
    String? text,
  }) {
    return callHandler.handleCall<PostMedia>(
      () => remoteDataSource.addPostMedia(
        postId: postId,
        source: source,
        type: type,
        text: text,
      ),
    );
  }

  @override
  PaginatedResults<PostCategory> getPostCategoriesBySegment({
    required String segment,
    required int pageNo,
    required int pageSize,
    PostsFilterByType? type,
  }) {
    return callHandler.handleCall<PaginationResponse<PostCategory>>(
      () => remoteDataSource.getPostCategoriesBySegment(
        segment: segment,
        pageNo: pageNo,
        pageSize: pageSize,
        type: type,
      ),
    );
  }

  @override
  PaginatedResults<PostTag> getPostTags({
    String categoryId = '',
    required int pageNo,
    required int pageSize,
  }) {
    return callHandler.handleCall<PaginationResponse<PostTag>>(
      () => remoteDataSource.getPostTags(
        categoryId: categoryId,
        pageNo: pageNo,
        pageSize: pageSize,
      ),
    );
  }

  @override
  Future<Either<Failure, bool>> updatePostTags({
    required String postId,
    required List<String> tags,
    required PostTagMode mode,
  }) {
    return callHandler.handleCall<bool>(
      () => remoteDataSource.updatePostTag(
        postId: postId,
        tags: tags,
        mode: mode,
      ),
    );
  }

  @override
  PaginatedResults<Nupp> getAutocompleteNupps({
    required String segment,
    required String query,
    String? categoryId,
    String? location,
    PaginationParams pageInfo = const PaginationParams(),
  }) {
    remoteDataSource.getAutocompleteNupps(
      segment: segment,
      query: query,
      categoryId: categoryId,
      location: location,
      pageInfo: pageInfo,
    );
    return callHandler.handleCall<PaginationResponse<Nupp>>(
      () => remoteDataSource.getAutocompleteNupps(
        segment: segment,
        query: query,
        categoryId: categoryId,
        location: location,
        pageInfo: pageInfo,
      ),
    );
  }

  @override
  PaginatedResults<StoryQuestion> getSuggestedStoryQuestions({
    String? collection,
    PaginationParams pageInfo = const PaginationParams(),
  }) {
    return callHandler.handleCall<PaginationResponse<StoryQuestion>>(
      () => remoteDataSource.getSuggestedStoryQuestions(
        collection: collection,
        pageInfo: pageInfo,
      ),
    );
  }

  @override
  Future<Either<Failure, String>> improveStoryText({
    required ImproveStoryTextParams params,
  }) {
    return callHandler.handleCall<String>(
      () => remoteDataSource.improveStoryText(params: params),
    );
  }

  @override
  PaginatedResults<PostFeedSegment> getPostSegments({
    PaginationParams pageInfo = const PaginationParams(),
  }) {
    return callHandler.handleCall<PostSegmentsResponse>(
      () => remoteDataSource.getPostFeedSegments(pageInfo: pageInfo),
    );
  }
}
