enum AppContentType {
  privacy,
  terms_and_conditions,
  faqs,
  about_us;

  String get formattedName => name.replaceAll('_', '-');
}
