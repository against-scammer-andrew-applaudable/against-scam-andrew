import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/app_content_response.dart';
import '../enums/app_content_type.dart';

abstract class AppContentRepository {
  Future<Either<Failure, AppContentResponse>> getAppContentOf(
    AppContentType type,
  );
}
