import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../entities/app_content_response.dart';
import '../enums/app_content_type.dart';
import '../repositories/app_content_repository.dart';

class GetAppContent extends UseCase<AppContentResponse, AppContentType> {
  final AppContentRepository repository;

  GetAppContent({required this.repository});

  @override
  Future<Either<Failure, AppContentResponse>> call(AppContentType params) {
    return repository.getAppContentOf(params);
  }
}
