import 'package:equatable/equatable.dart';

abstract class AppContentResponse extends Equatable {
  final String content;
  final String? title;
  final String? updatedAt;

  const AppContentResponse({
    required this.title,
    required this.content,
    required this.updatedAt,
  });
}
