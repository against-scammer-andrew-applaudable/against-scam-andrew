import 'dart:math';

import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

import '../../../../core/extensions/build_context_extensions.dart';
import '../../../../core/widgets/loading/shimmer_placeholder_box.dart';
import '../../../../core/theme/colors.dart';

class AppContentShimmerLoadingView extends StatelessWidget {
  const AppContentShimmerLoadingView({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: AppColors.peach,
      highlightColor: AppColors.darkPeach2.withOpacity(0.5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: List.generate(
          30,
          (index) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ShimmerPlaceholderBox(
                  width: context.screenWidth * (Random().nextDouble() + 0.3),
                ),
                SizedBox(
                    height:
                        8 + (Random().nextBool() ? 20 : 0)),
              ],
            );
          },
        ),
      ),
    );
  }
}
