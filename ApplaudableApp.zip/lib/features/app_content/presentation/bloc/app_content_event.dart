part of 'app_content_bloc.dart';

abstract class AppContentEvent extends Equatable {
  const AppContentEvent();
}

class GetAppContentEvent extends AppContentEvent {
  final AppContentType contentType;

  const GetAppContentEvent({required this.contentType});

  @override
  List<Object?> get props => [contentType];
}
