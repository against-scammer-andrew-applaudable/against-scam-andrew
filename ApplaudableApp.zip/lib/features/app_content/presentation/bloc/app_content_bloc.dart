import 'package:equatable/equatable.dart';

import '../../../../core/bloc/dng_base_bloc.dart';
import '../../domain/entities/app_content_response.dart';
import '../../domain/enums/app_content_type.dart';
import '../../domain/usecases/get_app_content.dart';

part 'app_content_event.dart';
part 'app_content_state.dart';

class AppContentBloc extends DNGBloc<AppContentEvent, AppContentState> {
  final GetAppContent getAppContent;

  AppContentBloc({required this.getAppContent})
      : super(AppContentInitialState());

  @override
  void mapEventToState(AppContentEvent event) async {
    if (event is GetAppContentEvent) {
      await _handleGetAppContentEvent(event);
    }
  }

  Future<void> _handleGetAppContentEvent(GetAppContentEvent event) async {
    emit(AppContentLoadingState());

    final result = await getAppContent(event.contentType);

    emit(
      result.fold(
        (failure) => AppContentErrorState(message: failure.message),
        (response) => AppContentFetchedState(response: response),
      ),
    );
  }
}
