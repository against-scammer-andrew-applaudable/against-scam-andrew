part of 'app_content_bloc.dart';

abstract class AppContentState extends Equatable {
  const AppContentState();

  @override
  List<Object> get props => [];
}

class AppContentInitialState extends AppContentState {}

class AppContentLoadingState extends AppContentState {}

class AppContentErrorState extends AppContentState {
  final String message;

  const AppContentErrorState({required this.message});

  @override
  List<Object> get props => [message];
}

class AppContentFetchedState extends AppContentState {
  final AppContentResponse response;

  const AppContentFetchedState({required this.response});

  @override
  List<Object> get props => [response];
}
