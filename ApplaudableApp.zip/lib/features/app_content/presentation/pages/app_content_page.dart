import 'package:flutter/material.dart';

import '../../../../core/bloc/widgets/base_stateless_page.dart';
import '../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../core/extensions/build_context_extensions.dart';
import '../../../../core/widgets/app_bar.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../../domain/enums/app_content_type.dart';
import '../bloc/app_content_bloc.dart';
import '../widgets/app_content_shimmer_loading_view.dart';

class AppContentPageArgs {
  final AppContentType type;

  const AppContentPageArgs({this.type = AppContentType.privacy});
}

// ignore: must_be_immutable
class AppContentPage
    extends BaseStatelessPage<AppContentBloc, AppContentState> {
  static const String routeName = '/app-content-page';

  final AppContentPageArgs args;

  AppContentPage({super.key, this.args = const AppContentPageArgs()});

  @override
  void initBloc(BuildContext context, AppContentBloc bloc) {
    bloc.add(GetAppContentEvent(contentType: args.type));
  }

  @override
  Widget build(BuildContext context) {
    registerBloc(context);

    return Scaffold(
      appBar: NavigationPageBar(title: _getPageTitleByType()),
      body: SingleChildScrollView(
        padding: const EdgeInsets.only(
          top: AppDimensions.defaultSidePadding,
          bottom: 50,
        ),
        child: AppSideMargins(
          child: DNGBlocBuilder<AppContentBloc, AppContentState>(
            bloc: bloc,
            builder: (context, state) {
              if (state is AppContentLoadingState) {
                return const AppContentShimmerLoadingView();
              } else if (state is AppContentErrorState) {
                return SizedBox(
                  height: context.screenHeight -
                      context.paddingBottom -
                      context.paddingTop,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: AppDimensions.largeSidePadding,
                    ),
                    child: Center(
                      child: Text(state.message, textAlign: TextAlign.center),
                    ),
                  ),
                );
              } else if (state is AppContentFetchedState) {
                return Text(state.response.content);
              }

              return Container();
            },
          ),
        ),
      ),
    );
  }

  String _getPageTitleByType() {
    switch (args.type) {
      case AppContentType.privacy:
        return translations.privacyPolicy;
      case AppContentType.terms_and_conditions:
        return translations.termsAndConditions;
      case AppContentType.faqs:
        return translations.faqs;
      case AppContentType.about_us:
        return translations.about_us;
      default:
        return translations.privacyPolicy;
    }
  }
}
