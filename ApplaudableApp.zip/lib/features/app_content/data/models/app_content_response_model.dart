import '../../domain/entities/app_content_response.dart';

class AppContentResponseModel extends AppContentResponse {
  const AppContentResponseModel({
    required super.title,
    required super.content,
    required super.updatedAt,
  });

  factory AppContentResponseModel.fromJson(Map<String, dynamic> parsedJson) {
    return AppContentResponseModel(
      title: parsedJson['title'],
      content: parsedJson['content'] ?? '',
      updatedAt: parsedJson['updated_at'] ?? '',
    );
  }

  @override
  List<Object?> get props => [title, content, updatedAt];
}
