import 'package:flutter/cupertino.dart';

import '../../../../core/api/api_config.dart';
import '../../../../core/api/api_service.dart';
import '../../../../core/api/remote_api_service.dart';
import '../../domain/enums/app_content_type.dart';
import '../models/app_content_response_model.dart';

abstract class AppContentRemoteDataSource {
  Future<AppContentResponseModel> getAppContentOf(AppContentType type);
}

class AppContentRemoteDataSourceImpl implements AppContentRemoteDataSource {
  ApiService _client = RemoteApiService.api;

  @visibleForTesting
  void setMockApiService(ApiService mockApiService) => _client = mockApiService;

  @override
  Future<AppContentResponseModel> getAppContentOf(AppContentType type) async {
    final parsedJson = await _client.get(
      url: ApiResource.appContentEndpoint(type.formattedName),
    );

    return AppContentResponseModel.fromJson(parsedJson);
  }
}
