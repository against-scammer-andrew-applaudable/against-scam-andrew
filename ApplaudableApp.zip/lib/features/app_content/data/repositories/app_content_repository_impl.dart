import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/errors/repository_call_handler.dart';
import '../../domain/entities/app_content_response.dart';
import '../../domain/enums/app_content_type.dart';
import '../../domain/repositories/app_content_repository.dart';
import '../datasources/app_content_remote_data_source.dart';

class AppContentRepositoryImpl implements AppContentRepository {
  final RepositoryCallHandler callHandler;
  final AppContentRemoteDataSource remoteSource;

  AppContentRepositoryImpl({
    required this.callHandler,
    required this.remoteSource,
  });

  @override
  Future<Either<Failure, AppContentResponse>> getAppContentOf(
    AppContentType type,
  ) {
    return callHandler.handleCall<AppContentResponse>(
      () => remoteSource.getAppContentOf(type),
    );
  }
}
