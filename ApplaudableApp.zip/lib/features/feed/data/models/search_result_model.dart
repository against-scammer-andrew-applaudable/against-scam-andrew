import '../../../../core/entities/pagination_response.dart';
import '../../domain/entities/search_result.dart';
import '../../domain/enums/search_item_type.dart';

class SearchResultResponse extends PaginationResponse<SearchResultModel> {
  const SearchResultResponse({
    required super.count,
    required super.next,
    required super.previous,
    required super.results,
  });

  factory SearchResultResponse.fromJson(Map<String, dynamic> parsedJson) {
    return SearchResultResponse(
      count: parsedJson['count'],
      next: parsedJson['next'],
      previous: parsedJson['previous'],
      results: ((parsedJson['results'] ?? []) as List<dynamic>)
          .map((e) => SearchResultModel.fromJson(e))
          .toList(),
    );
  }

  @override
  Map<String, dynamic> toMap() {
    return {
      'count': count,
      'next': next,
      'previous': previous,
      'results': results.map((e) => (e).toJson()),
    };
  }
}
class SearchUserResultResponse extends PaginationResponse<SearchUserModel> {
  const SearchUserResultResponse({
    required super.count,
    required super.next,
    required super.previous,
    required super.results,
  });

  factory SearchUserResultResponse.fromJson(Map<String, dynamic> parsedJson) {
    return SearchUserResultResponse(
      count: parsedJson['count'],
      next: parsedJson['next'],
      previous: parsedJson['previous'],
      results: ((parsedJson['results'] ?? []) as List<dynamic>)
          .map((e) => SearchUserModel.fromJson(e))
          .toList(),
    );
  }

  @override
  Map<String, dynamic> toMap() {
    return {
      'count': count,
      'next': next,
      'previous': previous,
      'results': results.map((e) => (e).toJson()),
    };
  }
}

class SearchResultModel extends SearchResult {
  const SearchResultModel({
    required super.type,
    required super.value,
    required super.id,
    required super.photo,
  });

  factory SearchResultModel.fromJson(Map<String, dynamic> parsedJson) {
    return SearchResultModel(
      id: parsedJson['id'],
      type: SearchItemType.fromName(parsedJson['type']),
      value: parsedJson['value'],
      photo: parsedJson['photo'],
    );
  }

  Map<String, dynamic> toJson() {
    return {'id': id, 'type': type.name, 'value': value, 'photo': photo};
  }

  @override
  bool get isNupp => type == SearchItemType.nupp;

  @override
  bool get isUser => type == SearchItemType.user;

  @override
  List<Object?> get props => [type, value, id, photo];
}
class SearchUserModel {
  late String id;
  late String name;
  String? username;
  String? avatar;

  SearchUserModel.fromJson(Map<String, dynamic> parsedJson) {
    id = parsedJson["id"] ?? "";
    name = parsedJson["name"] ?? "";
    username = parsedJson["username"];
    avatar = parsedJson["avatar"];
  }

  Map<String, dynamic> toJson() {
    return {'id': id, 'name': name, if (username != null) 'username': username, if (avatar != null) 'avatar': avatar};
  }

  List<Object?> get props => [id, name, username, avatar];
}
