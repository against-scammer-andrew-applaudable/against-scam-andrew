import '../../domain/entities/post_action_response.dart';
import '../../domain/usecases/execute_post_action.dart';
import 'posts_response_model.dart';

class PostActionResponseModel extends PostAction {
  const PostActionResponseModel({
    required super.id,
    super.counters,
    super.engagement,
    super.action = PostActions.none,
  });

  factory PostActionResponseModel.fromJson(Map<String, dynamic> parsedJson) {
    return PostActionResponseModel(
      id: parsedJson['id'],
      counters: parsedJson.containsKey('counters')
          ? PostCountersModel.fromJson(parsedJson['counters'])
          : null,
      engagement: parsedJson.containsKey('engagement')
          ? PostEngagementModel.fromJson(parsedJson['engagement'])
          : null,
      action: parsedJson.containsKey('action')
          ? parsedJson['action']
          : PostActions.none,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'counters': counters,
      'engagement': engagement,
      'action': action,
    };
  }

  @override
  List<Object?> get props => [id, counters, engagement];
}
