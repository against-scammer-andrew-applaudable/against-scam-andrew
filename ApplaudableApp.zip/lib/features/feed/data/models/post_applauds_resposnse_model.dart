import '../../../../core/entities/pagination_response.dart';
import '../../domain/entities/applaud_user.dart';
import 'applaud_user_model.dart';

class PostApplaudsResponse extends PaginationResponse<ApplaudUser> {
  const PostApplaudsResponse({
    required super.count,
    required super.next,
    required super.previous,
    required super.results,
  });

  factory PostApplaudsResponse.fromJson(Map<String, dynamic> parsedJson) {
    return PostApplaudsResponse(
      count: parsedJson['count'] ?? 0,
      next: parsedJson['next'],
      previous: parsedJson['previous'],
      results: ((parsedJson['results'] ?? []) as List<dynamic>)
          .map((e) => ApplaudUserModel.fromJson(e))
          .toList(),
    );
  }
}
