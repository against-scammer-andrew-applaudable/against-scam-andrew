import '../../../../core/entities/pagination_response.dart';
import '../../../../core/utils/json.dart';
import '../../../../core/serializers/date_serializer.dart';
import '../../../post/data/models/post_response_models.dart';
import '../../../post_categories/data/models/post_categories_response_model.dart';
import '../../../post_categories/data/models/post_tags_response_model.dart';
import '../../../post_collections/data/model/post_collections_response_model.dart';
import '../../domain/entities/post_response.dart';
import '../../domain/enums/posts_enum.dart';

class PostsResponseModel<Post> extends PaginationResponse<PostModel> {
  const PostsResponseModel({
    required super.count,
    required super.next,
    required super.previous,
    required super.results,
  });

  factory PostsResponseModel.fromJson(Map<String, dynamic> parsedJson) {
    return PostsResponseModel(
      count: parsedJson['count'],
      next: parsedJson['next'],
      previous: parsedJson['previous'],
      results: ((parsedJson['results'] ?? []) as List<dynamic>)
          .map((e) => PostModel.fromJson(e))
          .toList(),
    );
  }

  @override
  Map<String, dynamic> toMap() {
    return {
      'count': count,
      'next': next,
      'previous': previous,
      'results': results.map((e) => (e).toMap()).toList(),
    };
  }

  @override
  List<Object?> get props => [count, next, previous, results];
}

class PostModel extends Post {
  const PostModel({
    required super.id,
    required super.owner,
    super.createdAt,
    super.when,
    super.whenFormat,
    super.ranking,
    super.counters,
    super.title,
    super.text,
    super.location,
    super.type,
    super.relatedPostId,
    super.segment,
    super.hasHighlights,
    super.engagement,
    super.media,
    super.category,
    super.nupp,
    super.user,
    super.collections = const [],
    super.elements = const [],
    super.mentions = const [],
    super.originalDic,
  });

  factory PostModel.fromJson(Map<String, dynamic> parsedJson) {
    return PostModel(
      id: parsedJson['id'],
      owner: PostUserModel.fromJson(parsedJson['owner']),
      createdAt: jsonConverterFromJson<String, DateTime>(
          parsedJson['created_at'], const OptionalDateSerializer().fromJson),
      when: jsonConverterFromJson<String, DateTime>(
          parsedJson['when'], const OptionalDateSerializer().fromJson),
      whenFormat: parsedJson['when_date_format'] ?? 'DMY',
      ranking: parsedJson['ranking'],
      counters: PostCountersModel.fromJson(parsedJson['counters']),
      title: parsedJson['title'] ?? '',
      text: parsedJson['text'] ?? "",
      location: parsedJson['location'] ?? '',
      type: parsedJson['type'],
      relatedPostId: parsedJson['relatedPostId'],
      segment: parsedJson['segment'],
      hasHighlights: parsedJson['has_highlights'] ?? false,
      engagement: PostEngagementModel.fromJson(parsedJson['engagement']),
      media: ((parsedJson['media'] ?? []) as List<dynamic>)
          .map((e) => PostMediaModel.fromJson(e))
          .toList(),
      category: parsedJson['category'] != null
          ? PostCategoryModel.fromJson(parsedJson['category'])
          : null,
      nupp: parsedJson.containsKey('nupp') && parsedJson['nupp'] != null
          ? PostNuppModel.fromJson(parsedJson['nupp'])
          : null,
      user: parsedJson.containsKey('user') && parsedJson['user'] != null
          ? PostUserModel.fromJson(parsedJson['user'])
          : null,
      collections: ((parsedJson['collections'] ?? []) as List<dynamic>)
          .map((e) => PostCollectionModel.fromJson(e))
          .toList(),
      elements: ((parsedJson['elements'] ?? []) as List<dynamic>)
          .map((e) => PostElementModel.fromJson(e))
          .toList(),
      mentions: ((parsedJson['mentions'] ?? []) as List<dynamic>)
          .map((e) => PostMentionModel.fromJson(e))
          .toList(),
      originalDic: parsedJson,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'owner': (owner as PostUserModel).toMap(),
    };
  }

  @override
  List<Object?> get props => [
        id,
        owner,
      ];

  @override
  get value => throw UnimplementedError();
}

class PostCountersModel extends PostCounters {
  const PostCountersModel({super.applauds, super.shares, super.influences});

  factory PostCountersModel.fromJson(Map<String, dynamic> parsedJson) {
    return PostCountersModel(
        applauds: parsedJson['applauds'] ?? 0,
        shares: parsedJson['shares'] ?? 0,
        influences: parsedJson['influences'] ?? 0);
  }

  Map<String, dynamic> toMap() {
    return {'applauds': applauds, 'shares': shares, 'influences': influences};
  }

  @override
  List<Object?> get props => [applauds, shares, influences];
}

class PostEngagementModel extends PostEngagement {
  const PostEngagementModel({super.applauds, super.bookmarked});

  factory PostEngagementModel.fromJson(Map<String, dynamic> parsedJson) {
    return PostEngagementModel(
        applauds: parsedJson['applauds'] ?? false,
        bookmarked: parsedJson['bookmarked'] ?? false);
  }

  Map<String, dynamic> toMap() {
    return {'applauds': applauds, 'bookmarked': bookmarked};
  }

  @override
  List<Object?> get props => [applauds, bookmarked];
}

class PostMediaModel extends PostMedia {
  const PostMediaModel({
    required super.id,
    required super.url,
    super.type = PostMediaTypes.image,
    super.text,
    super.height,
    super.width,
  });

  factory PostMediaModel.fromJson(Map<String, dynamic> parsedJson) {
    return PostMediaModel(
      id: parsedJson.containsKey('id') ? parsedJson['id'] : "#image",
      url: parsedJson['url'] ?? '',
      type: PostMediaTypes.getTypeByName(parsedJson['type']),
      text: parsedJson['text'] ?? "",
      height: parsedJson.containsKey('height') ? parsedJson['height'] : null,
      width: parsedJson.containsKey('width') ? parsedJson['width'] : null,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'url': url,
      'type': type.name,
      'text': text,
      'height': height,
      'width': width
    };
  }

  @override
  List<Object?> get props => [id, url, type, text, height, width];
}

class PostNuppModel extends PostNupp {
  const PostNuppModel({
    required super.id,
    super.name = "",
    super.text = "",
    super.media,
    super.segment = "",
    super.category,
    super.tags = const [],
    super.isValidated = false,
    super.isPublic = false,
    super.metadata,
  });

  factory PostNuppModel.fromJson(Map<String, dynamic> parsedJson) {
    return PostNuppModel(
      id: parsedJson['id'],
      name: parsedJson['name'],
      text: parsedJson['text'],
      media: ((parsedJson['media'] ?? []) as List<dynamic>)
          .map((e) => PostMediaModel.fromJson(e))
          .toList(),
      segment: parsedJson['segment'],
      category: parsedJson['category'] != null
          ? PostCategoryModel.fromJson(parsedJson['category'])
          : null,
      tags: ((parsedJson['tags'] ?? []) as List<dynamic>)
          .map((e) => PostTagModel.fromJson(e))
          .toList(),
      isValidated: parsedJson['is_validated'] ?? false,
      isPublic: parsedJson['is_public'] ?? false,
      metadata: parsedJson['metadata'] == null
          ? null
          : NuppMetaDataModel.fromJson(parsedJson['metadata']),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'text': text,
      //'category': category,
    };
  }

  @override
  List<Object?> get props => [id, name, text, media];

  @override
  bool get hasLocation =>
      metadata?.location != null &&
      metadata!.location!.lat.isNotEmpty &&
      metadata!.location!.lon.isNotEmpty;

  @override
  NuppLocation? get location => metadata?.location;
}

class NuppMetaDataModel extends NuppMetaData {
  const NuppMetaDataModel({super.address, super.location});

  factory NuppMetaDataModel.fromJson(Map<String, dynamic> parsedJson) {
    return NuppMetaDataModel(
      address: parsedJson['address'] ?? '',
      location: parsedJson['location'] == null
          ? null
          : NuppLocationModel.fromJson(parsedJson['location']),
    );
  }

  @override
  List<Object?> get props => [address, location];
}

class NuppLocationModel extends NuppLocation {
  const NuppLocationModel({
    required super.cc,
    required super.lat,
    required super.lon,
    required super.name,
    required super.admin1,
    required super.admin2,
  });

  factory NuppLocationModel.fromJson(Map<String, dynamic> parsedJson) {
    return NuppLocationModel(
      cc: parsedJson['cc'] ?? '',
      lat: parsedJson['lat'] ?? '',
      lon: parsedJson['lon'] ?? '',
      name: parsedJson['name'] ?? '',
      admin1: parsedJson['admin1'] ?? '',
      admin2: parsedJson['admin2'] ?? '',
    );
  }

  @override
  List<Object?> get props => [cc, lat, lon, name, admin1, admin2];
}

/// Post Model Extensions
extension PostModelListExtensons on List<PostModel> {
  void sortByWhen() => sort(
        (a, b) {
          final aDate = a.when;
          final bDate = b.when;

          if (aDate == null && bDate == null) return 0;
          if (aDate == null) return -1;
          if (bDate == null) return 1;

          return -aDate.compareTo(bDate);
        },
      );
}
