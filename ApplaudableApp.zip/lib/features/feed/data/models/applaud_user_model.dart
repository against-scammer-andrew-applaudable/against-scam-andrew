import '../../domain/entities/applaud_user.dart';

class ApplaudUserModel extends ApplaudUser {
  const ApplaudUserModel({
    required super.id,
    required super.avatar,
    required super.name,
    required super.username,
  });

  factory ApplaudUserModel.fromJson(Map<String, dynamic> parsedJson) {
    return ApplaudUserModel(
      id: parsedJson['id'],
      avatar: parsedJson['avatar'],
      name: parsedJson['name'],
      username: parsedJson['username'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'avatar': avatar,
      'name': name,
      'username': username,
    };
  }

  @override
  List<Object?> get props => [id, avatar, name, username];
}
