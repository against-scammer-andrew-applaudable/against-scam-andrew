import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/errors/repository_call_handler.dart';
import '../../domain/entities/post_response.dart';
import '../../domain/repositories/nupp_repository.dart';
import '../datasources/nupp_remote_data_source.dart';

class AppNuppRepository extends NuppRepository {
  final NuppRemoteDataSource remoteDataSource;
  final RepositoryCallHandler callHandler;

  AppNuppRepository({
    required this.remoteDataSource,
    required this.callHandler,
  });

  @override
  Future<Either<Failure, PostNupp>> getNuppDetails({required String nuppId}) {
    return callHandler.handleCall<PostNupp>(
      () => remoteDataSource.getNuppDetails(nuppId: nuppId),
    );
  }
}
