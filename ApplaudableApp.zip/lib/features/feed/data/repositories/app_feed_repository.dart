import 'package:dartz/dartz.dart';

import '../../../../core/entities/pagination_params.dart';
import '../../../../core/entities/pagination_response.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/errors/repository_call_handler.dart';
import '../../../auth/data/datasources/local_source.dart';
import '../../../post_categories/domain/entities/post_category.dart';
import '../../../post_highlights/domain/entities/post_highlight.dart';
import '../../domain/entities/applaud_user.dart';
import '../../domain/entities/post_action_response.dart';
import '../../domain/entities/post_response.dart';
import '../../domain/enums/posts_enum.dart';
import '../../domain/repositories/feed_repository.dart';
import '../../domain/usecases/execute_post_action.dart';
import '../datasources/feed_remote_data_source.dart';

class AppFeedRepository extends FeedRepository {
  final RepositoryCallHandler callHandler;
  final FeedRemoteDataSource remoteDataSource;
  final AppLocalDataSource localDataSource;

  AppFeedRepository({
    required this.callHandler,
    required this.remoteDataSource,
    required this.localDataSource,
  });

  @override
  PaginatedResults<Post> getPosts(
      {required int pageNo,
      required int pageSize,
      PostsFilterByType type = PostsFilterByType.suggested,
      List<String>? categories,
      String? owner,
      String? id}) {
    return callHandler.handleCall<PaginationResponse<Post>>(
      () async => remoteDataSource.getPosts(
          pageNo: pageNo,
          pageSize: pageSize,
          type: type,
          categories: categories,
          owner: owner,
          id: id),
    );
  }

  @override
  Future<Either<Failure, Post>> getPost({required String postId}) {
    return callHandler.handleCall<Post>(
      () async => remoteDataSource.getPost(postId: postId),
    );
  }

  @override
  Future<Either<Failure, PostAction>> setPostAction(
      {required PostActionParams params}) {
    return callHandler.handleCall<PostAction>(
      () async => remoteDataSource.setPostAction(params: params),
    );
  }

  @override
  PaginatedResults<PostCategory> getPostsCategories(
      {required int pageNo, required int pageSize, PostsFilterByType? type}) {
    return callHandler.handleCall<PaginationResponse<PostCategory>>(
      () async => remoteDataSource.getPostsCategories(
          pageNo: pageNo, pageSize: pageSize, type: type),
    );
  }

  @override
  PaginatedResults<PostHighlight> getPostHighlights(
      {required String postId, required int pageNo, required int pageSize}) {
    return callHandler.handleCall<PaginationResponse<PostHighlight>>(
      () async => remoteDataSource.getPostHighlights(
        postId: postId,
        pageNo: pageNo,
        pageSize: pageSize,
      ),
    );
  }

  @override
  PaginatedResults<ApplaudUser> getPostApplauds({
    required String postId,
    PaginationParams pageInfo = const PaginationParams(),
  }) {
    return callHandler.handleCall<PaginationResponse<ApplaudUser>>(
      () {
        return remoteDataSource.getPostApplauds(
          postId: postId,
          pageInfo: pageInfo,
        );
      },
    );
  }
}
