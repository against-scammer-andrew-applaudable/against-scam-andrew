import '../../../../core/entities/pagination_params.dart';
import '../../../../core/entities/pagination_response.dart';
import '../../../../core/errors/repository_call_handler.dart';
import '../../domain/entities/search_result.dart';
import '../../domain/repositories/search_repository.dart';
import '../datasources/search_remote_data_source.dart';

class AppSearchRepository extends SearchRepository {
  final SearchRemoteDataSource remoteDataSource;
  final RepositoryCallHandler callHandler;

  AppSearchRepository({
    required this.remoteDataSource,
    required this.callHandler,
  });

  @override
  PaginatedResults<SearchResult> searchForNuppsAndUsers({
    required String query,
    PaginationParams pageInfo = const PaginationParams(pageSize: 15),
  }) {
    return callHandler.handleCall<PaginationResponse<SearchResult>>(
      () => remoteDataSource.searchForNuppsAndUsers(
        query: query,
        pageInfo: pageInfo,
      ),
    );
  }
}
