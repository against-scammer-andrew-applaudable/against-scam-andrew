import 'package:flutter/foundation.dart';

import '../../../../core/api/api_config.dart';
import '../../../../core/api/remote_api_service.dart';
import '../../../../core/entities/pagination_params.dart';
import '../models/search_result_model.dart';

abstract class SearchRemoteDataSource {
  Future<SearchResultResponse> searchForNuppsAndUsers({
    required String query,
    PaginationParams pageInfo = const PaginationParams(pageSize: 15),
  });
}

class AppSearchRemoteDataSource extends SearchRemoteDataSource {
  RemoteApiService _client = RemoteApiService.api;

  @visibleForTesting
  set setMockApiClient(RemoteApiService apiService) => _client = apiService;

  @override
  Future<SearchResultResponse> searchForNuppsAndUsers({
    required String query,
    PaginationParams pageInfo = const PaginationParams(pageSize: 15),
  }) async {
    final parsedJson = await _client.get(
      url: ApiResource.searchForNuppsAndUsersEndpoint(query, pageInfo),
    );

    return SearchResultResponse.fromJson(parsedJson);
  }
}
