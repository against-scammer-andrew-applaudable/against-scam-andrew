import 'package:flutter/foundation.dart';

import '../../../../app_module.dart';
import '../../../../core/api/api_config.dart';
import '../../../../core/api/api_service.dart';
import '../../../../core/api/remote_api_service.dart';
import '../../../../core/entities/pagination_params.dart';
import '../../../../core/errors/exeptions.dart';
import '../../../post_categories/data/models/post_categories_response_model.dart';
import '../../../post_highlights/data/models/post_highlights_response_models.dart';
import '../../domain/enums/posts_enum.dart';
import '../../domain/usecases/execute_post_action.dart';
import '../models/post_action_response_model.dart';
import '../models/post_applauds_resposnse_model.dart';
import '../models/posts_response_model.dart';

abstract class FeedRemoteDataSource {
  /// Get Posts
  Future<PostsResponseModel> getPosts({
    required int pageNo,
    required int pageSize,
    PostsFilterByType type = PostsFilterByType.suggested,
    List<String>? categories,
    String? owner,
    String? id,
  });

  /// Get Post
  Future<PostModel> getPost({required String postId});

  // Posts Categories
  Future<PostCategoriesResponseModel> getPostsCategories({
    required int pageNo,
    required int pageSize,
    PostsFilterByType? type,
  });

  // Feed Post Action
  Future<PostActionResponseModel> setPostAction({
    required PostActionParams params,
  });

  // Posts
  Future<PostHighlightsResponseModel> getPostHighlights({
    required String postId,
    required int pageNo,
    required int pageSize,
  });

  // Post Applauds
  Future<PostApplaudsResponse> getPostApplauds({
    required String postId,
    PaginationParams pageInfo = const PaginationParams(),
  });
}

class AppFeedRemoteDataSource extends FeedRemoteDataSource {
  ApiService _httpClient = RemoteApiService.api;

  @visibleForTesting
  set setMockApiClient(ApiService apiService) => _httpClient = apiService;

  @override
  Future<PostsResponseModel> getPosts({
    required int pageNo,
    required int pageSize,
    PostsFilterByType type = PostsFilterByType.suggested,
    List<String>? categories,
    String? owner,
    String? id,
  }) async {
    if (owner != null && type == PostsFilterByType.post) {
      final parsedJson = await _httpClient.get(
        url: ApiResource.userFeedPosts(
          pageNo: pageNo,
          pageSize: pageSize,
          owner: AppModule.I.controller.currentUser?.id == owner ? null : owner,
        ),
      );

      return PostsResponseModel.fromJson(parsedJson);
    }
    final parsedJson = await _httpClient.get(
      url: ApiResource.getPosts(
        pageNo: pageNo,
        pageSize: pageSize,
        type: type,
        categories: categories,
        owner: owner,
        id: id,
      ),
    );

    return PostsResponseModel.fromJson(parsedJson);
  }

  @override
  Future<PostModel> getPost({required String postId}) async {
    final parsedJson = await _httpClient.get(
      url: ApiResource.postById(id: postId),
    );

    return PostModel.fromJson(parsedJson);
  }

  @override
  Future<PostCategoriesResponseModel> getPostsCategories(
      {required int pageNo,
      required int pageSize,
      PostsFilterByType? type}) async {
    final parsedJson = await _httpClient.get(
      url: ApiResource.getPostsCategories(
          pageNo: pageNo, pageSize: pageSize, type: type),
    );

    return PostCategoriesResponseModel.fromJson(parsedJson);
  }

  @override
  Future<PostActionResponseModel> setPostAction(
      {required PostActionParams params}) async {
    Map<String, dynamic>? parsedJson;

    switch (params.postActionType) {
      case PostActions.delete:
        await _httpClient.delete(
          url: ApiResource.deletePost(params.id),
        );

        parsedJson = {"id": params.id, "action": params.postActionType};
        return PostActionResponseModel.fromJson(parsedJson);
      case PostActions.flag:
        await _httpClient.post(
          url: ApiResource.flagPost(params.id),
        );

        parsedJson = {"id": params.id, "action": params.postActionType};
        return PostActionResponseModel.fromJson(parsedJson);
      case PostActions.bookmark:
        parsedJson = await _httpClient.patch(
          url: ApiResource.bookmarkPost(params.id),
        );
        break;
      case PostActions.removeBookmark:
        parsedJson = await _httpClient.delete(
          url: ApiResource.bookmarkPost(params.id),
        );
        break;
      case PostActions.filterBySuggestion:
        break;
      case PostActions.filterByFollowing:
        break;
      case PostActions.applaud:
        parsedJson = await _httpClient.patch(
          url: ApiResource.applaudPost(params.id),
          body: {"id": params.id, "type": "1"},
        );
        break;
      case PostActions.removeApplaud:
        parsedJson = await _httpClient.delete(
          url: ApiResource.applaudPost(params.id),
        );
        break;
      case PostActions.none:
      case PostActions.share:
      case PostActions.comments:
      case PostActions.highlights:
        throw ServerException(
          message: 'NOT IMPLEMENTED',
        );
    }

    return PostActionResponseModel.fromJson((parsedJson as Map<String, dynamic>)
      ..addAll({"action": params.postActionType}));
  }

  @override
  Future<PostHighlightsResponseModel> getPostHighlights({
    required String postId,
    required int pageNo,
    required int pageSize,
  }) async {
    final parsedJson = await _httpClient.get(
      url: ApiResource.getPostHighlights(
        postId,
        pageNo: pageNo,
        pageSize: pageSize,
      ),
    );

    return PostHighlightsResponseModel.fromJson(parsedJson);
  }

  @override
  Future<PostApplaudsResponse> getPostApplauds({
    required String postId,
    PaginationParams pageInfo = const PaginationParams(),
  }) async {
    final parsedJson = await _httpClient.get(
      url: ApiResource.postApplauds(postId, pageInfo: pageInfo),
    );

    return PostApplaudsResponse.fromJson(
      parsedJson is List ? {'results': parsedJson} : parsedJson,
    );
  }
}
