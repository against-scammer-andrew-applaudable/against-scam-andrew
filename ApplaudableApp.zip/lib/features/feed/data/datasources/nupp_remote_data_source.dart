import 'package:flutter/cupertino.dart';

import '../../../../core/api/api_config.dart';
import '../../../../core/api/remote_api_service.dart';
import '../models/posts_response_model.dart';

abstract class NuppRemoteDataSource {
  Future<PostNuppModel> getNuppDetails({required String nuppId});
}

class AppNuppRemoteDataSource extends NuppRemoteDataSource {
  RemoteApiService _client = RemoteApiService.api;

  @visibleForTesting
  set setMockApiClient(RemoteApiService apiService) => _client = apiService;

  @override
  Future<PostNuppModel> getNuppDetails({required String nuppId}) async {
    final parsedJson =
        await _client.get(url: ApiResource.nuppDetailsEndpoint(nuppId));

    return PostNuppModel.fromJson(parsedJson);
  }
}
