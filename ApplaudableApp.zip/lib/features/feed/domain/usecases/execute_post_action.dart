import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../entities/post_action_response.dart';
import '../repositories/feed_repository.dart';

enum PostActions {
  none,
  delete,
  flag,
  bookmark,
  removeBookmark,
  filterBySuggestion,
  filterByFollowing,
  applaud,
  removeApplaud,
  share,
  comments,
  highlights
}

class SetPostAction extends UseCase<PostAction, PostActionParams> {
  final FeedRepository repository;

  SetPostAction({required this.repository});

  @override
  Future<Either<Failure, PostAction>> call(PostActionParams params) {
    return repository.setPostAction(params: params);
  }
}

class PostActionParams extends Equatable {
  final PostActions postActionType;
  final String id;

  const PostActionParams({
    required this.postActionType,
    required this.id,
  });

  @override
  List<Object?> get props => [
        postActionType,
        id,
      ];
}
