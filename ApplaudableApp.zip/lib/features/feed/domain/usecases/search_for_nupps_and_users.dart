import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/entities/pagination_params.dart';
import '../../../../core/entities/pagination_response.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../entities/search_result.dart';
import '../repositories/search_repository.dart';

class SearchForNuppsAndUsers
    extends UseCase<PaginationResponse<SearchResult>, SearchParams> {
  final SearchRepository repository;

  SearchForNuppsAndUsers({required this.repository});

  @override
  Future<Either<Failure, PaginationResponse<SearchResult>>> call(
    SearchParams params,
  ) {
    return repository.searchForNuppsAndUsers(
      query: params.query,
      pageInfo: params.pageInfo,
    );
  }
}

class SearchParams extends Equatable {
  final String query;
  final PaginationParams pageInfo;

  const SearchParams({
    required this.query,
    this.pageInfo = const PaginationParams(pageSize: 15),
  });

  @override
  List<Object?> get props => [query, pageInfo];
}
