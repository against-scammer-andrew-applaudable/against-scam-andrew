import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../entities/post_response.dart';
import '../repositories/nupp_repository.dart';

class GetNuppDetails extends UseCase<PostNupp, String> {
  final NuppRepository repository;

  GetNuppDetails({required this.repository});

  @override
  Future<Either<Failure, PostNupp>> call(String params) {
    return repository.getNuppDetails(nuppId: params);
  }
}
