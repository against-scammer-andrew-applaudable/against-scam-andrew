import 'package:equatable/equatable.dart';

import '../../../../core/entities/pagination_response.dart';
import '../../../../core/usecase/usecase.dart';
import '../entities/post_response.dart';
import '../enums/posts_enum.dart';
import '../repositories/feed_repository.dart';

class GetPosts extends UseCase<PaginationResponse<Post>, FeedPaginationParams> {
  final FeedRepository repository;

  GetPosts({required this.repository});

  @override
  PaginatedResults<Post> call(FeedPaginationParams params) {
    return repository.getPosts(
        pageNo: params.pageNo,
        pageSize: params.pageSize,
        type: params.type,
        categories: params.categories,
        owner: params.owner,
        id: params.id);
  }
}

class FeedPaginationParams extends Equatable {
  final int pageNo;
  final int pageSize;
  final PostsFilterByType type;
  final List<String>? categories;
  final String? owner;
  final String? id;

  const FeedPaginationParams(
      {this.pageNo = 1,
      this.pageSize = 10,
      this.type = PostsFilterByType.suggested,
      this.categories,
      this.owner,
      this.id});

  @override
  List<Object?> get props => [pageNo, pageSize, type, categories, owner, id];
}
