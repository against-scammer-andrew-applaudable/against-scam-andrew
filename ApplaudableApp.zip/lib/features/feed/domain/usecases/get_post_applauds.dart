import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/entities/pagination_params.dart';
import '../../../../core/entities/pagination_response.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../entities/applaud_user.dart';
import '../repositories/feed_repository.dart';

class GetPostApplauds
    extends UseCase<PaginationResponse<ApplaudUser>, GetPostApplaudsParams> {
  final FeedRepository repository;

  GetPostApplauds({required this.repository});

  @override
  Future<Either<Failure, PaginationResponse<ApplaudUser>>> call(
    GetPostApplaudsParams params,
  ) {
    return repository.getPostApplauds(
      postId: params.postId,
      pageInfo: params.pageInfo,
    );
  }
}

class GetPostApplaudsParams extends Equatable {
  final String postId;
  final PaginationParams pageInfo;

  const GetPostApplaudsParams({
    required this.postId,
    this.pageInfo = const PaginationParams(),
  });

  @override
  List<Object?> get props => [postId, pageInfo];
}
