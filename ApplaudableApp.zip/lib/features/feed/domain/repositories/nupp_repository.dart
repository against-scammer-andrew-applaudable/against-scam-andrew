import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/post_response.dart';

abstract class NuppRepository {
  Future<Either<Failure, PostNupp>> getNuppDetails({required String nuppId});
}
