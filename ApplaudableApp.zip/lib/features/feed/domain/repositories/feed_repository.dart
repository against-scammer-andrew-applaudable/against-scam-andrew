import 'package:dartz/dartz.dart';

import '../../../../core/entities/pagination_params.dart';
import '../../../../core/entities/pagination_response.dart';
import '../../../../core/errors/failures.dart';
import '../../../post_categories/domain/entities/post_category.dart';
import '../../../post_highlights/domain/entities/post_highlight.dart';
import '../entities/applaud_user.dart';
import '../entities/post_action_response.dart';
import '../entities/post_response.dart';
import '../enums/posts_enum.dart';
import '../usecases/execute_post_action.dart';

abstract class FeedRepository {
  // Feed Request a Post Action
  Future<Either<Failure, PostAction>> setPostAction({
    required PostActionParams params,
  });

  PaginatedResults<Post> getPosts({
    required int pageNo,
    required int pageSize,
    PostsFilterByType type = PostsFilterByType.suggested,
    List<String>? categories,
    String? owner,
    String? id,
  });

  PaginatedResults<PostCategory> getPostsCategories({
    required int pageNo,
    required int pageSize,
    PostsFilterByType? type,
  });

  PaginatedResults<PostHighlight> getPostHighlights({
    required String postId,
    required int pageNo,
    required int pageSize,
  });

  Future<Either<Failure, Post>> getPost({required String postId});

  PaginatedResults<ApplaudUser> getPostApplauds({
    required String postId,
    PaginationParams pageInfo = const PaginationParams(),
  });
}
