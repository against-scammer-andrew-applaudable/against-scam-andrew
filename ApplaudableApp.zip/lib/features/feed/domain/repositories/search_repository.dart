import '../../../../core/entities/pagination_params.dart';
import '../../../../core/entities/pagination_response.dart';
import '../entities/search_result.dart';

abstract class SearchRepository {
  PaginatedResults<SearchResult> searchForNuppsAndUsers({
    required String query,
    PaginationParams pageInfo = const PaginationParams(pageSize: 15),
  });
}
