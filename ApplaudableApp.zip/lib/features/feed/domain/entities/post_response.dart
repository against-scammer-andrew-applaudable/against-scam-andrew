import 'package:equatable/equatable.dart';
import 'package:intl/intl.dart';

import '../../../../core/entities/base_image.dart';
import '../../../../core/entities/item.dart';
import '../../../post/domain/entities/post_entities.dart';
import '../../../post_categories/domain/entities/post_category.dart';
import '../../../post_collections/domain/entities/post_collection.dart';
import '../enums/posts_enum.dart';

class Post with EquatableMixin implements Item<Post> {
  @override
  final String id;
  final PostUser owner;

  final DateTime? createdAt;
  final DateTime? when;
  final String whenFormat;

  final int ranking;
  final PostCounters? counters;

  final List<PostMedia> media;

  final String title;
  final String text;
  final String location;

  final List<PostElement> elements;
  final List<PostCollection> collections;

  final String type;
  final String? relatedPostId;
  final String? segment;
  final bool? hasHighlights;

  final PostEngagement? engagement;

  final PostCategory? category;

  final PostNupp? nupp;
  final PostUser? user;

  final List<PostMention>? mentions;

  final Map<String, dynamic>? originalDic;

  const Post({
    required this.id,
    required this.owner,
    this.createdAt,
    this.when,
    this.whenFormat = 'DMY',
    this.ranking = 0,
    this.counters,
    this.title = '',
    this.text = "",
    this.location = '',
    this.elements = const [],
    this.type = "post",
    this.relatedPostId,
    this.segment,
    this.hasHighlights = false,
    this.engagement,
    this.media = const [],
    this.category,
    this.nupp,
    this.user,
    this.collections = const [],
    this.mentions,
    this.originalDic,
  });

  PostMedia? get firstMedia => media.isNotEmpty ? media.first : null;

  bool get isApplauded => engagement?.applauds ?? false;

  String get fullMonthYear {
    final DateFormat formatter = DateFormat('MMMM yyyy');
    return formatter.format(when ?? createdAt ?? DateTime.now());
  }

  String get formattedWhenTime {
    DateFormat formatter;
    if (whenFormat.length == 1) {
      formatter = DateFormat('yyyy');
    } else if (whenFormat.length == 2) {
      formatter = DateFormat('MMMM, yyyy');
    } else {
      formatter = DateFormat('MMMM, dd yyyy');
    }

    return formatter.format(when!);
  }

  double get score {
    return (counters?.applauds ?? 0) +
        (counters?.influences ?? 0) +
        (counters?.shares ?? 0).toDouble();
  }

  List<PostElement> get postElements {
    // if (type == 'story')
    return elements;

    // return elements.isNotEmpty ? elements.first.elements : [];
  }

  @override
  Post copyWith({PostCounters? counters, PostEngagement? engagement, Map<String, dynamic>? originalDic}) => Post(
        id: id,
        owner: owner,
        createdAt: createdAt,
        when: when,
        whenFormat: whenFormat,
        ranking: ranking,
        counters: counters ?? this.counters,
        text: text,
        title: title,
        location: location,
        type: type,
        relatedPostId: relatedPostId,
        segment: segment,
        engagement: engagement ?? this.engagement,
        media: media,
        category: category,
        nupp: nupp,
        user: user,
        collections: collections,
        elements: elements,
        mentions: mentions,
        hasHighlights: hasHighlights,
        originalDic: originalDic,
      );

  @override
  List<Object?> get props => [id, owner, counters, engagement];

  @override
  String get name => nupp?.name ?? user?.name ?? text;

  @override
  get value => throw UnimplementedError();
}

abstract class PostCounters extends Equatable {
  final int applauds;
  final int shares;
  final int influences;

  const PostCounters({this.applauds = 0, this.shares = 0, this.influences = 0});
}

abstract class PostEngagement extends Equatable {
  final bool applauds;
  final bool bookmarked;

  const PostEngagement({this.applauds = false, this.bookmarked = false});
}

/*
"url": "",
"type": "image",
"id": "AM4D2d3WdBj1l",
"text": ""
*/
abstract class PostMedia with BaseImage, EquatableMixin {
  final String id;
  final String url;
  final PostMediaTypes type;
  final String text;

  /// TODO: add parse MediaDetail object
  /// for now is not being used
  // final MediaDetail mediaDetail;

  final int? height;
  final int? width;

  const PostMedia({
    required this.id,
    required this.url,
    this.type = PostMediaTypes.image,
    this.text = "",
    this.height,
    this.width,
  });

  @override
  ImageOptimizationSizes get defaultSize => ImageOptimizationSizes.qAutoBest;

  @override
  String get defaultImage => url;

  bool get shouldResizeImageOnHeight {
    if (width == null || height == null) {
      return false;
    }

    return height! > width!;
  }
}

abstract class PostNupp with EquatableMixin {
  final String id;
  final String name;
  final String text;
  final List<PostMedia>? media;
  final String segment;
  final PostCategory? category;
  final List<PostTag> tags;
  final bool isValidated;
  final bool isPublic;
  final NuppMetaData? metadata;

  const PostNupp({
    required this.id,
    this.name = "",
    this.text = "",
    this.media,
    this.segment = "",
    this.category,
    this.tags = const [],
    this.isValidated = false,
    this.isPublic = false,
    this.metadata,
  });

  bool get hasLocation;
  NuppLocation? get location;

  bool get hasMedia => media != null && media!.isNotEmpty;

  PostMedia? get firstMedia =>
      media != null && media!.isNotEmpty ? media!.first : null;
}

abstract class NuppMetaData extends Equatable {
  final String address;
  final NuppLocation? location;

  const NuppMetaData({this.address = '', this.location});
}

abstract class NuppLocation extends Equatable {
  final String cc;
  final String lat;
  final String lon;
  final String name;
  final String admin1;
  final String admin2;

  const NuppLocation({
    required this.cc,
    required this.lat,
    required this.lon,
    required this.name,
    required this.admin1,
    required this.admin2,
  });
}
