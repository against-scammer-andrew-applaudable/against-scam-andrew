import 'package:equatable/equatable.dart';

import '../../../auth/domain/entities/user.dart';

abstract class ApplaudUser extends Equatable {
  final String id;
  final String? avatar;
  final String name;
  final String username;

  const ApplaudUser({
    required this.id,
    required this.avatar,
    required this.name,
    required this.username,
  });

  HiveUser get asUser =>
      HiveUser(id: id, avatar: avatar, name: name, username: username);
}
