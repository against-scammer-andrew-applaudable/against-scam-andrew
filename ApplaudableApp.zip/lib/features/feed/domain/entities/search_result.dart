import 'package:equatable/equatable.dart';

import '../enums/search_item_type.dart';

abstract class SearchResult extends Equatable {
  final SearchItemType type;
  final String value;
  final String id;
  final String? photo;

  const SearchResult({
    required this.type,
    required this.value,
    required this.id,
    required this.photo,
  });

  bool get isNupp;
  bool get isUser;
}
