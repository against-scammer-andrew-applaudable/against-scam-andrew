import 'package:equatable/equatable.dart';

import '../usecases/execute_post_action.dart';
import 'post_response.dart';

abstract class PostAction extends Equatable {
  final String id;

  final PostCounters? counters;
  final PostEngagement? engagement;

  final PostActions action;

  const PostAction({
    required this.id,
    this.counters,
    this.engagement,
    this.action = PostActions.none,
  });
}
