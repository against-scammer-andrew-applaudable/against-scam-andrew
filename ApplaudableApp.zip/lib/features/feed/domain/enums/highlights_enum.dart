import '../../../../core/extensions/list_extensions.dart';

enum HighlightsFilterByType {
  /// index 0
  suggested,

  /// index 1
  following,

  /// index 2
  bookmark,

  /// index 3
  user,

  /// index 4
  collection,

  /// index 4
  nupp,

  /// index 5
  post,

  /// index 6
  story
}

enum HighlightMediaTypes {
  image,
  video,
  text;

  static HighlightMediaTypes getTypeByName(String? name) =>
      values.firstWhereOrNull((e) => e.name == name?.trim()) ??
          HighlightMediaTypes.image;
}

enum FeedTab {
  highlights,
  glimpses;

  String get title {
    switch (this) {
      case FeedTab.glimpses:
        return "Glimpses";
      case FeedTab.highlights:
        return "Highlights";
    }
  }
}