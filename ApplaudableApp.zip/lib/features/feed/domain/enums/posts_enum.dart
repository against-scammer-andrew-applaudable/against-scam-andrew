import '../../../../core/extensions/list_extensions.dart';

enum PostsFilterByType {
  /// index 0
  suggested,

  /// index 1
  following,

  /// index 2
  bookmark,

  /// index 3
  user,

  /// index 4
  collection,

  /// index 4
  nupp,

  /// index 5
  post,

  /// index 6
  story
}

enum PostMediaTypes {
  image,
  video,
  text;

  static PostMediaTypes getTypeByName(String? name) =>
      values.firstWhereOrNull((e) => e.name == name?.trim()) ??
      PostMediaTypes.image;
}
