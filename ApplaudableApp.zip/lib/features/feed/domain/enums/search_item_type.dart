import '../../../../core/extensions/list_extensions.dart';

enum SearchItemType {
  nupp,
  user;

  static SearchItemType fromName(String? name) {
    final type = values.firstWhereOrNull((e) => e.name == name);

    return type ?? SearchItemType.nupp;
  }
}
