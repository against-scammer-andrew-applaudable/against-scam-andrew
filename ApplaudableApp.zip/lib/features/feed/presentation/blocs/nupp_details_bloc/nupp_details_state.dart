part of 'nupp_details_bloc.dart';

abstract class NuppDetailsState extends Equatable {
  final String? nuppId;

  const NuppDetailsState({required this.nuppId});

  @override
  List<Object?> get props => [nuppId];
}

class NuppDetailsInitialState extends NuppDetailsState {
  const NuppDetailsInitialState({super.nuppId});
}

class NuppDetailsLoadingState extends NuppDetailsState {
  const NuppDetailsLoadingState({super.nuppId});
}

class NuppDetailsErrorState extends NuppDetailsState {
  final String message;

  const NuppDetailsErrorState({super.nuppId, required this.message});

  @override
  List<Object?> get props => [nuppId, message];
}

class NuppDetailsFetchedState extends NuppDetailsState {
  final PostNupp nupp;

  const NuppDetailsFetchedState({super.nuppId, required this.nupp});

  @override
  List<Object?> get props => [nuppId, nupp];
}
