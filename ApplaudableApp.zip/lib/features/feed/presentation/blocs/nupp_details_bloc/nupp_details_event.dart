part of 'nupp_details_bloc.dart';

abstract class NuppDetailsEvent extends Equatable {
  const NuppDetailsEvent();
}

class GetNuppDetailsEvent extends NuppDetailsEvent {
  final String nuppId;

  const GetNuppDetailsEvent({required this.nuppId});

  @override
  List<Object?> get props => [nuppId];
}
