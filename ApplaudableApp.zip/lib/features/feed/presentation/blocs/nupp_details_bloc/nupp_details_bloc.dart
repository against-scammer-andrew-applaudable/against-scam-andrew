import 'package:equatable/equatable.dart';

import '../../../../../core/bloc/dng_base_bloc.dart';
import '../../../domain/entities/post_response.dart';
import '../../../domain/usecases/get_nupp_details.dart';

part 'nupp_details_event.dart';
part 'nupp_details_state.dart';

class NuppDetailsBloc extends DNGBloc<NuppDetailsEvent, NuppDetailsState> {
  final GetNuppDetails getNuppDetails;

  NuppDetailsBloc({
    required this.getNuppDetails,
  }) : super(const NuppDetailsInitialState());

  @override
  void mapEventToState(NuppDetailsEvent event) async {
    if (event is GetNuppDetailsEvent) {
      await _handleGetNuppDetailsEvent(event);
    }
  }

  Future<void> _handleGetNuppDetailsEvent(GetNuppDetailsEvent event) async {
    emit(NuppDetailsLoadingState(nuppId: event.nuppId));

    final result = await getNuppDetails(event.nuppId);

    emit(
      result.fold(
        (failure) => NuppDetailsErrorState(
          nuppId: event.nuppId,
          message: failure.message,
        ),
        (nupp) => NuppDetailsFetchedState(nuppId: event.nuppId, nupp: nupp),
      ),
    );
  }
}
