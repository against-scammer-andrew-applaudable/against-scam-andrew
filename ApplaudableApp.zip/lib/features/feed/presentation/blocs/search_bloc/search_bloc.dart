import 'package:equatable/equatable.dart';

import '../../../../../core/bloc/dng_base_bloc.dart';
import '../../../../../core/entities/pagination_params.dart';
import '../../../domain/entities/search_result.dart';
import '../../../domain/usecases/search_for_nupps_and_users.dart';

part 'search_event.dart';
part 'search_state.dart';

class SearchBloc extends DNGBloc<SearchEvent, SearchState> {
  final SearchForNuppsAndUsers searchForNuppsAndUsers;

  SearchBloc({
    required this.searchForNuppsAndUsers,
  }) : super(SearchInitialState());

  int _pageNo = 1;
  final List<SearchResult> _searchItems = [];

  @override
  void mapEventToState(SearchEvent event) async {
    if (event is SearchForNuppsAndUsersEvent) {
      _pageNo = event.paginate ? _pageNo : 1;

      if (_pageNo == 1) {
        // _searchItems.clear();
        // emit(SearchLoadingState());
      } else {
        emit(SearchPaginationLoadingState());
      }

      final result = await searchForNuppsAndUsers(
        SearchParams(
          query: event.query,
          pageInfo: PaginationParams(
            pageNo: _pageNo,
            pageSize: event.pageSize,
          ),
        ),
      );

      emit(
        result.fold(
          (failure) {
            if (_pageNo == 1) {
              emit(SearchErrorState(message: failure.message));
            } else {
              emit(SearchPaginationErrorState(message: failure.message));
            }

            return SearchDoNothingState();
          },
          (response) {
            if (_pageNo == 1) {
              _searchItems.clear();
            }
            if (response.results.length == event.pageSize) _pageNo++;

            _searchItems.addAll(response.results);

            return SearchResultFetchedState(
              searchResults: _searchItems.toSet().toList(),
            );
          },
        ),
      );
    }
  }
}
