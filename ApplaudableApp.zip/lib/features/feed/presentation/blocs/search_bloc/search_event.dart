part of 'search_bloc.dart';

abstract class SearchEvent extends Equatable {
  const SearchEvent();
}

class SearchForNuppsAndUsersEvent extends SearchEvent {
  final String query;
  final bool paginate;
  final int pageSize;

  const SearchForNuppsAndUsersEvent({
    required this.query,
    this.paginate = false,
    this.pageSize = 15,
  });

  @override
  List<Object?> get props => [query, paginate, pageSize];
}
