part of 'search_bloc.dart';

abstract class SearchState extends Equatable {
  const SearchState();

  @override
  List<Object?> get props => [];
}

class SearchInitialState extends SearchState {}

class SearchLoadingState extends SearchState {}

class SearchErrorState extends SearchState {
  final String message;

  const SearchErrorState({required this.message});

  @override
  List<Object?> get props => [message];
}

class SearchResultFetchedState extends SearchState {
  final List<SearchResult> searchResults;

  const SearchResultFetchedState({required this.searchResults});

  @override
  List<Object?> get props => [searchResults];
}

class SearchPaginationLoadingState extends SearchState {}

class SearchPaginationErrorState extends SearchState {
  final String message;

  const SearchPaginationErrorState({required this.message});

  @override
  List<Object?> get props => [message];
}

class SearchDoNothingState extends SearchState {}
