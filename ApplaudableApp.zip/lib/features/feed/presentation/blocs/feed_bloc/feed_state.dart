part of 'feed_bloc.dart';

abstract class FeedState extends Equatable {
  final String? collectionId;
  final String? nuppId;
  final String? userId;
  final bool isBookmarks;

  const FeedState({
    this.collectionId,
    this.nuppId,
    this.userId,
    this.isBookmarks = false,
  });

  @override
  List<Object?> get props => [collectionId, nuppId, isBookmarks];
}

/// Get Posts
class GetPostsInitialState extends FeedState {}

class GetPostsLoadingState extends FeedState {
  const GetPostsLoadingState({
    super.collectionId,
    super.nuppId,
    super.userId,
    super.isBookmarks = false,
  });
}

class GetPostsFetchedState extends FeedState {
  final PaginationResponse<Post> response;

  const GetPostsFetchedState({required this.response});

  @override
  List<Object?> get props => [response];
}

class GetPostsResultFetchedState extends FeedState {
  final List<Post> posts;
  final int pageNo;
  final int pageSize;
  final PostsFilterByType? type;
  final bool shouldAnimateToTop;
  final int fetchedItemsCount;

  const GetPostsResultFetchedState({
    super.collectionId,
    super.nuppId,
    super.userId,
    super.isBookmarks = false,
    required this.posts,
    this.pageNo = 1,
    this.pageSize = 15,
    this.type,
    this.shouldAnimateToTop = false,
    this.fetchedItemsCount = 15,
  });

  @override
  List<Object?> get props => [
        collectionId,
        userId,
        isBookmarks,
        nuppId,
        posts,
        pageNo,
        pageSize,
        type,
        shouldAnimateToTop,
        fetchedItemsCount
      ];
}

class GetPostsEmptyState extends FeedState {
  const GetPostsEmptyState({
    super.collectionId,
    super.nuppId,
    super.userId,
    super.isBookmarks = false,
  });
}

/// Default error state
class FeedErrorState extends FeedState {
  final String message;

  const FeedErrorState({
    super.collectionId,
    super.nuppId,
    super.userId,
    super.isBookmarks = false,
    required this.message,
  });

  @override
  List<Object?> get props =>
      [collectionId, userId, isBookmarks, nuppId, message];
}
