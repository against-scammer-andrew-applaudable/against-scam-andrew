part of 'feed_bloc.dart';

abstract class FeedEvent extends Equatable {
  const FeedEvent();

  @override
  List<Object?> get props => [];
}

class GetPostsEvent extends FeedEvent {
  final int pageNo;
  final int pageSize;
  final PostsFilterByType type;
  final List<String>? categories;
  final String? owner;
  final String? id;

  const GetPostsEvent({
    this.pageNo = 1,
    this.pageSize = 15,
    this.type = PostsFilterByType.suggested,
    this.categories,
    this.owner,
    this.id,
  });

  @override
  List<Object?> get props => [pageNo, pageSize, type, categories, owner, id];
}
