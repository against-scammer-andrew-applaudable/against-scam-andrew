import 'package:equatable/equatable.dart';

import '../../../../../core/bloc/dng_base_bloc.dart';
import '../../../../../core/entities/item.dart';
import '../../../../../core/entities/pagination_response.dart';
import '../../../../../core/errors/failures.dart';
import '../../../../../core/mixins/collection.dart';
import '../../../../../core/mixins/pagination_mixin.dart';
import '../../../../../injection_container.dart';
import '../../../../profile/presentation/provider/profile_feed_provider.dart';
import '../../../domain/entities/post_response.dart';
import '../../../domain/enums/posts_enum.dart';
import '../../../domain/usecases/execute_post_action.dart';
import '../../../domain/usecases/get_posts.dart';

part 'feed_event.dart';
part 'feed_state.dart';

/// BaseFeedBloc
abstract class BaseFeedBloc<T extends Item<T>>
    extends DNGBloc<FeedEvent, FeedState> with Pagination<T> {
  final GetPosts getPosts;

  BaseFeedBloc({required this.getPosts}) : super(GetPostsInitialState());

  CollectionList<T> collection = CollectionList<T>();

  PostsFilterByType get postsFilterByType => PostsFilterByType.suggested;

  bool shouldCacheItems(event) => false;

  @override
  void mapEventToState(FeedEvent event) async {
    if (event is GetPostsEvent) {
      await handleGetPostsEvent(event);
    }
  }

  FeedState _mapFailureToState(
    Failure failure, {
    String? collectionId,
    String? nuppId,
    String? userId,
    bool isBookmarks = false,
  }) {
    // if (failure is ServerFailure) {
    //   return FeedErrorState(
    //     message: failure.message,
    //     collectionId: collectionId,
    //     nuppId: nuppId,
    //     userId: userId,
    //     isBookmarks: isBookmarks,
    //   );
    // } else if (failure is NetworkFailure) {
    //   return FeedErrorState(
    //     message: failure.message,
    //     collectionId: collectionId,
    //     nuppId: nuppId,
    //     userId: userId,
    //     isBookmarks: isBookmarks,
    //   );
    // } else {
    return FeedErrorState(
      message: failure.message,
      collectionId: collectionId,
      nuppId: nuppId,
      userId: userId,
      isBookmarks: isBookmarks,
    );
    // }
  }

  Future<void> handleGetPostsEvent(GetPostsEvent event) async {}

  void getInitialPostsPage() {
    resetPagination();
    collection.clearItems();

    add(GetPostsEvent(type: postsFilterByType));
  }

  /// To review
  void getCachedPosts() {
    /*if (latestFetchedPosts.hasItems) {
      emit(GetPostsResultFetchedState(
          posts: latestFetchedPosts.items, pageNo: currentPageNo));
      return;
    }*/

    getInitialPostsPage();
  }
}

/// FeedBloc used only for the main Feed
class FeedBloc extends DNGBloc<FeedEvent, FeedState>
    with Pagination<Post>, CollectionListMixin<Post> {
  final GetPosts getPosts;

  CollectionList<Post> latestFetchedPosts = CollectionList<Post>();

  PostsFilterByType _currentPostsFilter = PostsFilterByType.suggested;

  PostsFilterByType get postsFilterByType => _currentPostsFilter;

  final List<String> _currentCategories = [];

  bool shouldAnimateToTop = false;

  bool shouldCachePostItems(event) => event is GetPostsEvent
      ? (event.type == PostsFilterByType.suggested ||
              event.type == PostsFilterByType.following) &&
          event.owner == null
      : false;

  FeedBloc({
    required this.getPosts,
  }) : super(GetPostsInitialState());

  @override
  void mapEventToState(FeedEvent event) async {
    if (event is GetPostsEvent) {
      await _handleGetPostsEvent(event);
    }
  }

  Future<void> _handleGetPostsEvent(GetPostsEvent event) async {
    /// Reset pagination to fetch more pages
    if (_currentPostsFilter.index != event.type.index) {
      allowNewPaginationRequests = true;
    }

    /// If not allowed to request more pages
    if (!allowNewPaginationRequests) return;

    /// Emits Loading state only for the first page
    if (currentPageNo == 1) emit(const GetPostsLoadingState());

    /// If feed filter type changed, reset pagination
    bool hasChangedFilterType = _currentPostsFilter != event.type;
    if (hasChangedFilterType) {
      resetPagination();
      _currentPostsFilter = event.type;

      emit(const GetPostsLoadingState());
    }

    /// Update all the categories to add it to request params
    if (event.categories != null) {
      _currentCategories
        ..clear()
        ..addAll(event.categories!);
    }

    final result = await getPosts(
      FeedPaginationParams(
        pageNo: pageNo,
        pageSize: event.pageSize,
        type: event.type,
        categories: event.categories,
        owner: event.owner,
      ),
    );

    emit(
      result.fold(
        (failure) => _mapFailureToState(failure),
        (response) {
          if (hasChangedFilterType) {
            clearItems();
          }

          if (response.results.isEmpty) {
            allowNewPaginationRequests = false;

            if (currentPageNo == 1) {
              resetPagination();
              return const GetPostsEmptyState();
            }
          }

          if (response.results.isNotEmpty &&
              currentPageNo == 1 &&
              items.isNotEmpty) {
            clearItems();
          }

          shouldAnimateToTop = pageNo == 1 ? shouldAnimateToTop : false;

          updateItems(response.results);
          pageNo++;
          currentPageNo = pageNo;

          /// Cache latest fetched posts
          /*if (shouldCachePostItems(event)) {
            latestFetchedPosts
              ..clearItems()
              ..updateItems(items);
          }*/

          return GetPostsResultFetchedState(
              posts: items,
              pageNo: pageNo,
              type: event.type,
              shouldAnimateToTop: shouldAnimateToTop);
        },
      ),
    );

    //allowNewPaginationRequests = true;
  }

  FeedState _mapFailureToState(Failure failure) {
    if (failure is ServerFailure) {
      return FeedErrorState(message: failure.message);
    } else if (failure is NetworkFailure) {
      return FeedErrorState(message: failure.message);
    } else {
      return FeedErrorState(message: failure.message);
    }
  }

  @override
  void updateItems(List<Post> items) {
    verifyAllowNewPaginationRequests(items);
    super.updateItems(items);
  }

  void getInitialPostsPage({
    PostsFilterByType? type,
    List<String>? categories,
    bool animateToTop = true,
  }) {
    resetPagination();
    clearItems();

    shouldAnimateToTop = animateToTop;

    add(GetPostsEvent(
        type: type ?? _currentPostsFilter, categories: categories));
  }

  void getCachedPosts() {
    if (latestFetchedPosts.hasItems) {
      emit(GetPostsResultFetchedState(
          posts: latestFetchedPosts.items, pageNo: currentPageNo));
      return;
    }

    getInitialPostsPage();
  }

  void updatePost({required Post model, required PostActions action}) {
    replaceItem(
      model.id,
      (element) => element.copyWith(
        counters: model.counters,
        engagement: model.engagement,
      ),
    );

    if (action == PostActions.delete) {
      deleteItem(model.id);
    }

    emit(GetPostsResultFetchedState(
        posts: items, pageNo: pageNo, type: postsFilterByType));
  }

  void deletePost(String id) {
    deleteItem(id);
    emit(GetPostsResultFetchedState(
        posts: items, pageNo: pageNo, type: postsFilterByType));
  }
}

/// FeedGridBloc will be used for the current widgets:
///
///  ** Profile My Posts
class FeedGridBloc extends BaseFeedBloc<Post> {
  FeedGridBloc({required super.getPosts});

  PostsFilterByType _postsFilterByType = PostsFilterByType.user;

  @override
  Future<void> handleGetPostsEvent(GetPostsEvent event) async {
    final feedHandler = servLocator<ProfileFeedsProvider>();

    final profile = feedHandler.getProfileFeedOf(event.owner ?? '');
    // profile.pageNo = event.pageNo;

    /// Emits Loading state only for the first page
    if (profile.pageNo == 1 && !profile.isRefetchingSamePage) {
      emit(GetPostsLoadingState(userId: event.owner));
    }

    final result = await getPosts(
      FeedPaginationParams(
        pageNo: profile.pageNo,
        pageSize: event.pageSize,
        type: event.type,
        owner: event.owner,
        id: event.id,
      ),
    );

    emit(
      result.fold(
        (failure) => _mapFailureToState(failure, userId: event.owner),
        (response) {
          if (response.results.isNotEmpty &&
              profile.pageNo == 1 &&
              profile.posts.isNotEmpty) {
            profile.posts.clear();
          }

          profile.posts.addAll(response.results);
          profile.posts = profile.posts.toSet().toList();

          if (response.results.length == event.pageSize) {
            profile.pageNo++;
            profile.isRefetchingSamePage = false;
          } else {
            profile.isRefetchingSamePage = true;
          }

          // currentPageNo = pageNo;

          _postsFilterByType = event.type;

          feedHandler.updateProfileFeed(event.owner ?? '', profile);

          return GetPostsResultFetchedState(
            posts: profile.posts,
            pageNo: profile.pageNo,
            type: _postsFilterByType,
            userId: event.owner,
            fetchedItemsCount: response.results.length,
            pageSize: event.pageSize,
          );
        },
      ),
    );
  }

  void deletePost(String userId, String postId) {
    final feedHandler = servLocator<ProfileFeedsProvider>();

    final profile = feedHandler.getProfileFeedOf(userId);

    profile.posts.removeWhere((e) => e.id == postId);

    emit(
      GetPostsResultFetchedState(
        posts: profile.posts,
        pageNo: profile.pageNo,
        type: postsFilterByType,
        userId: userId,
      ),
    );
  }
}

/// BookmarksFeedGridBloc will be used for the current widgets:
///
///  ** Profile My Bookmarks
class BookmarksFeedGridBloc extends BaseFeedBloc<Post> {
  BookmarksFeedGridBloc({required super.getPosts});

  PostsFilterByType _postsFilterByType = PostsFilterByType.user;

  @override
  Future<void> handleGetPostsEvent(GetPostsEvent event) async {
    /// If not allowed to request more pages
    // if (!allowNewPaginationRequests) return;

    /// Emits Loading state only for the first page
    if (currentPageNo == 1 && !isRefetchingSamePage) {
      emit(GetPostsLoadingState(
        isBookmarks: event.type == PostsFilterByType.bookmark,
      ));
    }

    final result = await getPosts(
      FeedPaginationParams(
        pageNo: pageNo,
        pageSize: event.pageSize,
        type: event.type,
        id: event.id,
      ),
    );

    emit(
      result.fold(
        (failure) => _mapFailureToState(
          failure,
          isBookmarks: event.type == PostsFilterByType.bookmark,
        ),
        (response) {
          if (response.results.isEmpty) {
            if (currentPageNo == 1) {
              resetPagination();
              // return GetPostsEmptyState(
              //   userId: event.owner,
              //   isBookmarks: event.type == PostsFilterByType.bookmark,
              // );
            }
          }

          if (response.results.isNotEmpty &&
              currentPageNo == 1 &&
              collection.items.isNotEmpty) {
            collection.clearItems();
          }

          collection.updateItems(response.results);

          if (response.results.length == event.pageSize) {
            pageNo++;
            isRefetchingSamePage = false;
          } else {
            isRefetchingSamePage = true;
          }

          currentPageNo = pageNo;

          _postsFilterByType = event.type;

          return GetPostsResultFetchedState(
            posts: collection.items,
            pageNo: pageNo,
            type: _postsFilterByType,
            fetchedItemsCount: response.results.length,
            isBookmarks: event.type == PostsFilterByType.bookmark,
            pageSize: event.pageSize,
          );
        },
      ),
    );
  }

  void updatePost({required Post model, required PostActions action}) {
    collection.replaceItem(
        model.id,
        (element) => element.copyWith(
            counters: model.counters, engagement: model.engagement));

    /// In case we are removing or flagging this from bookmark
    /// then remove it from the list
    if (action == PostActions.removeBookmark ||
        action == PostActions.delete ||
        action == PostActions.flag) {
      collection.deleteItem(model.id);
    }

    /// In case user reverts the action [removeBookmark] then
    /// will add it again
    if (action == PostActions.bookmark && !collection.containsId(model.id)) {
      collection.addItem(model);
    }

    emit(GetPostsResultFetchedState(
        posts: collection.items, pageNo: pageNo, type: _postsFilterByType));
  }
}

/// CollectionPostsBloc will be used for the current widgets:
///
///  ** Post Collection Posts Page
///  ** Manage Post Collection Page
class CollectionPostsBloc extends BaseFeedBloc<Post> {
  CollectionPostsBloc({required super.getPosts});

  @override
  Future<void> handleGetPostsEvent(GetPostsEvent event) async {
    /// If not allowed to request more pages
    if (!allowNewPaginationRequests) return;

    /// Emits Loading state only for the first page
    if (currentPageNo == 1 && !isRefetchingSamePage) {
      emit(GetPostsLoadingState(collectionId: event.id));
    }

    final result = await getPosts(
      FeedPaginationParams(
        pageNo: pageNo,
        pageSize: event.pageSize,
        type: event.type,
        owner: event.owner,
        id: event.id,
      ),
    );

    emit(
      result.fold(
        (failure) => _mapFailureToState(failure, collectionId: event.id),
        (response) {
          if (response.results.isEmpty) {
            if (currentPageNo == 1) {
              resetPagination();
              return GetPostsEmptyState(collectionId: event.id);
            }
          }

          if (response.results.isNotEmpty &&
              currentPageNo == 1 &&
              collection.items.isNotEmpty) {
            collection.clearItems();
          }

          collection.updateItems(response.results);

          if (response.results.length == event.pageSize) {
            pageNo++;
            isRefetchingSamePage = false;
          } else {
            isRefetchingSamePage = true;
          }

          currentPageNo = pageNo;

          return GetPostsResultFetchedState(
            collectionId: event.id,
            posts: collection.items,
            pageNo: pageNo,
            type: event.type,
          );
        },
      ),
    );
  }
}

/// UserPostsBloc will be used for the current widgets:
///
///  ** Manage Post Collection Page(Get All User Posts Tab)
class UserPostsBloc extends BaseFeedBloc<Post> {
  UserPostsBloc({required super.getPosts});

  bool isFirstPageFetched = false;

  @override
  Future<void> handleGetPostsEvent(GetPostsEvent event) async {
    /// If not allowed to request more pages
    if (!allowNewPaginationRequests) return;

    /// Emits Loading state only for the first page
    if (currentPageNo == 1 && !isFirstPageFetched) {
      emit(const GetPostsLoadingState());
    }

    final result = await getPosts(
      FeedPaginationParams(
        pageNo: pageNo,
        pageSize: event.pageSize,
        type: event.type,
        owner: event.owner,
        id: event.id,
      ),
    );

    emit(
      result.fold(
        (failure) => _mapFailureToState(failure),
        (response) {
          if (response.results.isEmpty) {
            if (currentPageNo == 1) {
              resetPagination();
              return const GetPostsEmptyState();
            }
          }

          if (response.results.isNotEmpty &&
              currentPageNo == 1 &&
              collection.items.isNotEmpty) {
            collection.clearItems();
          }

          collection.updateItems(response.results);

          if (response.results.length == event.pageSize) {
            pageNo++;
            isFirstPageFetched = true;
            isRefetchingSamePage = false;
          } else {
            isRefetchingSamePage = true;
          }

          currentPageNo = pageNo;

          return GetPostsResultFetchedState(
            posts: collection.items,
            pageNo: pageNo,
            type: event.type,
          );
        },
      ),
    );
  }
}

/// NuppPostsBloc will be used for the current widgets:
///
///  ** Nupp Page
///  ** Get Nupp Posts in Nupp Page
class NuppPostsBloc extends BaseFeedBloc<Post> {
  NuppPostsBloc({required super.getPosts});

  @override
  Future<void> handleGetPostsEvent(GetPostsEvent event) async {
    /// If not allowed to request more pages
    if (!allowNewPaginationRequests) return;

    /// Emits Loading state only for the first page
    if (currentPageNo == 1 && !isRefetchingSamePage) {
      emit(GetPostsLoadingState(nuppId: event.id));
    }

    final result = await getPosts(
      FeedPaginationParams(
        pageNo: pageNo,
        pageSize: event.pageSize,
        type: event.type,
        id: event.id,
      ),
    );

    emit(
      result.fold(
        (failure) => _mapFailureToState(failure, nuppId: event.id),
        (response) {
          if (response.results.isEmpty) {
            if (currentPageNo == 1) {
              resetPagination();
              return GetPostsEmptyState(nuppId: event.id);
            }
          }

          if (response.results.isNotEmpty &&
              currentPageNo == 1 &&
              collection.items.isNotEmpty) {
            collection.clearItems();
          }

          collection.updateItems(response.results);

          if (response.results.length == event.pageSize) {
            pageNo++;
            isRefetchingSamePage = false;
          } else {
            isRefetchingSamePage = true;
          }

          currentPageNo = pageNo;

          return GetPostsResultFetchedState(
            nuppId: event.id,
            posts: collection.items,
            pageNo: pageNo,
            type: event.type,
          );
        },
      ),
    );
  }
}
