part of 'post_applauds_bloc.dart';

abstract class PostApplaudsEvent extends Equatable {
  const PostApplaudsEvent();
}

class GetPostApplaudsEvent extends PostApplaudsEvent {
  final String postId;
  final int pageSize;
  final bool paginate;

  const GetPostApplaudsEvent({
    required this.postId,
    this.pageSize = 15,
    this.paginate = false,
  });

  @override
  List<Object?> get props => [postId, pageSize, paginate];
}
