part of 'post_applauds_bloc.dart';

abstract class PostApplaudsState extends Equatable {
  final String postId;

  const PostApplaudsState({required this.postId});

  @override
  List<Object?> get props => [postId];
}

class PostApplaudsInitialState extends PostApplaudsState {
  const PostApplaudsInitialState({required super.postId});
}

class PostApplaudsLoadingState extends PostApplaudsState {
  const PostApplaudsLoadingState({required super.postId});
}

class PostApplaudsNextPageLoadingState extends PostApplaudsState {
  const PostApplaudsNextPageLoadingState({required super.postId});
}

class PostApplaudsErrorState extends PostApplaudsState {
  final String message;

  const PostApplaudsErrorState({required super.postId, required this.message});

  @override
  List<Object?> get props => [postId, message];
}

class PostApplaudsNextPageErrorState extends PostApplaudsState {
  final String message;

  const PostApplaudsNextPageErrorState({
    required super.postId,
    required this.message,
  });

  @override
  List<Object?> get props => [postId, message];
}

class PostApplaudsFetchedState extends PostApplaudsState {
  final List<ApplaudUser> applauds;

  const PostApplaudsFetchedState({
    required super.postId,
    required this.applauds,
  });

  @override
  List<Object?> get props => [postId, applauds];
}
