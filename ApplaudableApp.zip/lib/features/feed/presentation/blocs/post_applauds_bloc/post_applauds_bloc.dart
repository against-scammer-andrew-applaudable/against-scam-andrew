import 'package:equatable/equatable.dart';

import '../../../../../core/bloc/dng_base_bloc.dart';
import '../../../../../core/entities/pagination_params.dart';
import '../../../domain/entities/applaud_user.dart';
import '../../../domain/usecases/get_post_applauds.dart';

part 'post_applauds_event.dart';
part 'post_applauds_state.dart';

class PostApplaudsBloc extends DNGBloc<PostApplaudsEvent, PostApplaudsState> {
  final GetPostApplauds getPostApplauds;

  PostApplaudsBloc({
    required this.getPostApplauds,
  }) : super(const PostApplaudsInitialState(postId: ''));

  int _pageNo = 1;
  final Map<String, List<ApplaudUser>> _applauds = {};
  bool _shouldRefreshLastPage = false;

  @override
  void mapEventToState(PostApplaudsEvent event) async {
    if (event is GetPostApplaudsEvent) {
      _pageNo = event.paginate ? _pageNo : 1;

      if (_pageNo == 1 && !_shouldRefreshLastPage) {
        emit(PostApplaudsLoadingState(postId: event.postId));
      } else {
        _shouldRefreshLastPage = false;
        emit(PostApplaudsNextPageLoadingState(postId: event.postId));
      }

      final result = await getPostApplauds(
        GetPostApplaudsParams(
          postId: event.postId,
          pageInfo: PaginationParams(pageNo: _pageNo, pageSize: event.pageSize),
        ),
      );

      emit(
        result.fold(
          (failure) {
            if (_pageNo == 1) {
              return PostApplaudsErrorState(
                postId: event.postId,
                message: failure.message,
              );
            } else {
              return PostApplaudsNextPageErrorState(
                postId: event.postId,
                message: failure.message,
              );
            }
          },
          (response) {
            if (_pageNo == 1) _applauds[event.postId]?.clear();

            if (response.results.length == event.pageSize) {
              _pageNo++;
            } else {
              _shouldRefreshLastPage = true;
            }

            if (_applauds.containsKey(event.postId)) {
              _applauds[event.postId]!.addAll(response.results);
            } else {
              _applauds[event.postId] = response.results;
            }

            _applauds[event.postId] = _applauds[event.postId]!.toSet().toList();

            return PostApplaudsFetchedState(
              postId: event.postId,
              applauds: _applauds[event.postId] ?? [],
            );
          },
        ),
      );
    }
  }
}
