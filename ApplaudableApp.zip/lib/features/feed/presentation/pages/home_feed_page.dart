// import 'package:flutter/material.dart';
// import 'package:scrolls_to_top/scrolls_to_top.dart';
//
// import '../widgets/feed_view.dart';
//
// /// Feed - Base UI
// class HomeFeedPage extends StatelessWidget {
//   const HomeFeedPage({Key? key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return ScrollsToTop(
//       onScrollsToTop: (event) async {
//         ScrollController? scrollController = PrimaryScrollController.of(context);
//         scrollController.animateTo(
//           event.to,
//           duration: event.duration,
//           curve: event.curve,
//         );
//       },
//       child: Scaffold(
//         key: const Key("home-feed-page"),
//         extendBody: true,
//         body: SafeArea(
//           bottom: false,
//           child: FeedView2(
//             key: const Key("feed"),
//           ),
//         ),
//         // bottomNavigationBar: const HomeBottomBar(),
//       ),
//     );
//   }
// }
//
// // class HomeBottomBar extends StatelessWidget {
// //   const HomeBottomBar({super.key});
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return BottomAppBar(
// //       color: Colors.transparent,
// //       elevation: 0,
// //       child: SafeArea(
// //         child: Container(
// //           padding: const EdgeInsets.only(bottom: 6),
// //           alignment: Alignment.center,
// //           child: Container(
// //             height: 52,
// //             padding: const EdgeInsets.only(left: 22, right: 22),
// //             decoration: BoxDecoration(
// //               borderRadius: BorderRadius.circular(52),
// //               color: AppColors.white,
// //               boxShadow: [
// //                 BoxShadow(
// //                   color: AppColors.shadow.withOpacity(0.4),
// //                   spreadRadius: 0,
// //                   blurRadius: 15,
// //                   offset: const Offset(0, 10), // changes position of shadow
// //                 ),
// //               ],
// //             ),
// //             child: Row(
// //               mainAxisAlignment: MainAxisAlignment.center,
// //               mainAxisSize: MainAxisSize.min,
// //               children: [
// //                 AppIconButton.tabBar(
// //                   onTap: () => _onItemTapped(context, 0),
// //                   icon: SvgHomeIcons.home,
// //                 ),
// //                 const SizedBox(width: 15),
// //                 AppIconButton.tabBar(
// //                   onTap: () => _onItemTapped(context, 1),
// //                   icon: SvgHomeIcons.navBarSearch,
// //                 ),
// //                 const SizedBox(width: 15),
// //                 AppIconButton.tabBar(
// //                   onTap: () => _onItemTapped(context, 2),
// //                   icon: SvgHomeIcons.createPost,
// //                 ),
// //                 const SizedBox(width: 15),
// //                 AppIconButton.tabBar(
// //                   onTap: () => _onItemTapped(context, 3),
// //                   icon: SvgHomeIcons.navBarNotifications,
// //                 ),
// //                 const SizedBox(width: 15),
// //                 AppIconButton.tabBar(
// //                   onTap: () => _onItemTapped(context, 4),
// //                   icon: SvgHomeIcons.profile,
// //                 ),
// //               ],
// //             ),
// //           ),
// //         ),
// //       ),
// //     );
// //   }
// //
// //   void _onItemTapped(BuildContext context, int index) async {
// //     switch (index) {
// //       case 0:
// //         FeedView2.update(context);
// //         break;
// //       case 1:
// //         AppModule.I.navigateToNamed(SearchPage.routeName);
// //         break;
// //       case 2:
// //         AppModule.I.navigateToNamed(CreatePostPage.routeName);
// //         break;
// //       case 3:
// //         AppModule.I.navigateToNamed(InAppNotificationsPage.routeName);
// //         break;
// //       case 4:
// //         {
// //           final session = await AppLocalDataSource.instance.getSession();
// //
// //           AppModule.I.navigateToNamed(
// //             ProfilePage.routeName,
// //             arguments: ProfilePageArgs(
// //               userId: session?.user.id ?? '',
// //               user: session?.user,
// //             ),
// //           );
// //           break;
// //         }
// //     }
// //   }
// // }
