import 'package:flutter/material.dart';

import '../../../../core/widgets/app_bar.dart';
import '../../../../generated/l10n.dart';
import '../../domain/enums/posts_enum.dart';
import '../widgets/bookmarks_feed_grid_view.dart';

class FeedBookmarksPage extends StatelessWidget {
  static const String routeName = '/profile-page/mybookmarks';

  const FeedBookmarksPage({super.key});

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return Scaffold(
      appBar: NavigationPageBar(
        title: translations.my_bookmarks_label,
      ),
      body: Column(
        children: [
          Expanded(
            child: BookmarksFeedGridView(
              type: PostsFilterByType.bookmark,
              isFullPage: true,
            ),
          )
        ],
      ),
    );
  }
}
