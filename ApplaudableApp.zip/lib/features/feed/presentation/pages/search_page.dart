import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../core/theme/styles.dart';
import '../../../../core/widgets/app_bar.dart';
import '../../../../core/widgets/app_scaffold.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../../../../generated/l10n.dart';
import '../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../blocs/search_bloc/search_bloc.dart';
import '../widgets/search_result_overview_list.dart';

class SearchPage extends StatelessWidget {
  static const String routeName = '/search-page';

  const SearchPage({super.key});

  @override
  Widget build(BuildContext context) {
    final queryController = TextEditingController();

    final translations = S.of(context);

    return AppScaffold(
      appBar: NavigationPageBar(
        title: translations.search,
        style: AppStyles.header1(color: context.textColor),
        centerTitle: false,
        leading: Container(),
        leadingWidth: 8,
      ),
      body: AppSideMargins(
        marginValue: 20,
        child: Column(
          children: [
            CurvedTextField(
              controller: queryController,
              fillColor: context.backgroundColor,
              filled: true,
              prefixIcon: const SearchFieldPrefix(),
              onChanged: (query) {
                if (query.trim().isEmpty) return;

                final bloc = context.read<SearchBloc>();
                bloc.add(SearchForNuppsAndUsersEvent(query: query.trim()));
              },
            ),
            Expanded(
              child: SearchResultOverviewList(
                queryController: queryController,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
