import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../app_module.dart';
import '../../../../core/bloc/widgets/base_stateless_page.dart';
import '../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../core/extensions/app_module_extensions.dart';
import '../../../../core/widgets/app_bar.dart';
import '../../../../core/widgets/app_grid_view.dart';
import '../../../../core/widgets/app_scaffold.dart';
import '../../../../core/widgets/app_scroller_view.dart';
import '../../../../core/widgets/items/item_image.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/theme/styles.dart';
import '../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../../../post/presentation/pages/post_page.dart';
import '../../../profile/presentation/widgets/collection_posts_loading_view.dart';
import '../../domain/entities/post_response.dart';
import '../../domain/enums/posts_enum.dart';
import '../blocs/feed_bloc/feed_bloc.dart';
import '../blocs/nupp_details_bloc/nupp_details_bloc.dart';
import '../widgets/nupp_page_shimmer_loading_view.dart';
import '../widgets/post_view/widgets/post_media_view.dart';

class NuppPageArgs {
  final String nuppId;
  final String nuppName;

  NuppPageArgs({required this.nuppId, this.nuppName = ''});
}

// ignore: must_be_immutable
class NuppPage extends BaseStatelessPage<NuppDetailsBloc, NuppDetailsState> {
  static const String routeName = '/nupp-page';

  final NuppPageArgs args;

  NuppPage({super.key, required this.args});

  @override
  Widget build(BuildContext context) {
    registerBloc(context);

    return AppScaffold(
      appBar: const NavigationPageBar(),
      body: DNGBlocBuilder<NuppDetailsBloc, NuppDetailsState>(
        bloc: bloc,
        buildWhen: (state) => state.nuppId == args.nuppId,
        builder: (context, state) {
          if (state is NuppDetailsLoadingState) {
            return NuppPageShimmerLoadingView(nuppName: args.nuppName);
          } else if (state is NuppDetailsErrorState) {
            return Center(
              child: AppSideMargins(
                marginValue: 25,
                child: Text(state.message, textAlign: TextAlign.center),
              ),
            );
          } else if (state is NuppDetailsFetchedState) {
            return AppScrollerView(
              useDebouncerToNotifyPagination: true,
              onPaginate: () {
                final postsBloc = context.read<NuppPostsBloc>();

                postsBloc.add(GetPostsEvent(
                  type: PostsFilterByType.nupp,
                  id: args.nuppId,
                ));
              },
              slivers: [
                SliverToBoxAdapter(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const SizedBox(height: AppDimensions.defaultSidePadding),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          // AppChip.tag(
                          //   title: state.nupp.segment.toUpperCase(),
                          // ),
                          ItemImage.profile(
                            source: state.nupp.media != null &&
                                    state.nupp.media!.isNotEmpty
                                ? state.nupp.media!.first.optimizedImage
                                : '',
                            size: 120,
                          ),
                          // Opacity(
                          //   opacity: state.nupp.category == null ? 0 : 1,
                          //   child: AppChip.tag(
                          //     title: state.nupp.category?.name ?? '',
                          //   ),
                          // ),
                        ],
                      ),
                      const SizedBox(height: AppDimensions.defaultSidePadding),
                      AppSideMargins(
                        marginValue: 25,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Text(
                              state.nupp.name,
                              textAlign: TextAlign.center,
                              style: AppStyles.text1(color: context.textColor)
                                  .copyWith(fontWeight: FontWeight.w600),
                            ),
                            if (state.nupp.metadata != null &&
                                state.nupp.metadata!.address.isNotEmpty) ...[
                              const SizedBox(
                                  height: AppDimensions.mediumSidePadding),
                              Text(
                                state.nupp.metadata!.address,
                                textAlign: TextAlign.center,
                                style:
                                    AppStyles.text1(color: AppColors.mediumGrey)
                                        .copyWith(fontSize: 14),
                              ),
                            ],
                            const SizedBox(
                                height: AppDimensions.mediumSidePadding),
                            Text(
                              state.nupp.text,
                              textAlign: TextAlign.center,
                              style: AppStyles.text2(color: context.textColor)
                                  .copyWith(fontSize: 15, height: 1.3),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: AppDimensions.defaultSidePadding),
                      // const SettingsSeparatorTile(
                      //   verticalPadding: AppDimensions.defaultSidePadding,
                      // ),
                      // Wrap(
                      //   alignment: WrapAlignment.center,
                      //   children: List.generate(
                      //     state.nupp.tags.length,
                      //     (index) => AppChip.tag(
                      //       width: max(
                      //           70, state.nupp.tags[index].label.length * 9),
                      //       title: state.nupp.tags[index].label,
                      //       backgroundColor:
                      //           AppColors.primaryColor.withOpacity(0.85),
                      //     ),
                      //   ),
                      // ),

                      DNGBlocBuilder<NuppPostsBloc, FeedState>(
                        buildWhen: (state) =>
                            state.nuppId == args.nuppId &&
                            (state is GetPostsLoadingState ||
                                state is FeedErrorState ||
                                state is GetPostsEmptyState ||
                                state is GetPostsResultFetchedState),
                        builder: (context, state) {
                          if (state is GetPostsLoadingState) {
                            return const FeedsGridShimmerLoadingView(
                              shrinkWrap: true,
                              physics: NeverScrollableScrollPhysics(),
                            );
                          } else if (state is FeedErrorState) {
                            return Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: AppDimensions.largeSidePadding,
                              ),
                              child: Center(
                                child: Text(state.message,
                                    textAlign: TextAlign.center),
                              ),
                            );
                          } else if (state is GetPostsResultFetchedState) {
                            final posts = state.posts;

                            return AppGridView.builder(
                              key: key,
                              itemCount: posts.length,
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 3,
                                childAspectRatio: 0.7,
                                crossAxisSpacing: 2,
                                mainAxisSpacing: 2,
                              ),
                              padding: const EdgeInsets.only(
                                left: 15,
                                right: 15,
                                bottom: 15,
                              ),
                              itemBuilder: (ctx, index) {
                                Post item = posts[index];

                                return GestureDetector(
                                  onTap: () {
                                    AppModule.I.navigateToNamed(
                                      PostPage.routeName,
                                      arguments: PostPageArgs(
                                        post: item,
                                        enableDetailsAction: false,
                                        preloadedNuppId: args.nuppId,
                                      ),
                                    );
                                  },
                                  child: Hero(
                                    tag: item,
                                    child: PostMediaView(
                                      index: index,
                                      item: item,
                                      height: 159,
                                      width:
                                          (MediaQuery.of(context).size.width /
                                                  3) -
                                              4,
                                      isGridItem: true,
                                    ),
                                  ),
                                );
                              },
                            );
                          }

                          return Container();
                        },
                      ),
                    ],
                  ),
                ),
              ],
            );
          }

          return Container();
        },
      ),
    );
  }

  @override
  void initBloc(BuildContext context, NuppDetailsBloc bloc) {
    bloc.add(GetNuppDetailsEvent(nuppId: args.nuppId));

    Future(() {
      final postsBloc = context.read<NuppPostsBloc>();
      postsBloc
        ..resetPagination()
        ..collection.clearItems()
        ..add(GetPostsEvent(type: PostsFilterByType.nupp, id: args.nuppId));
    });
  }
}
