// import 'dart:math';
//
// import 'package:bubble_chart/bubble_chart.dart';
// import 'package:flutter/foundation.dart';
// import 'package:flutter/material.dart';
// import 'package:graphview/GraphView.dart';
//
// import '../../../../core/theme/colors.dart';
//
// /// Experimental
// class A extends CustomPainter {
//   @override
//   void paint(Canvas canvas, Size size) {
//     Offset center = const Offset(0, 0);
//
//     final p1Paint = Paint()
//       ..color = Colors.white
//       ..strokeWidth = 10
//       ..style = PaintingStyle.stroke;
//
//     // final p2Paint = Paint()
//     //   ..color = Colors.amber
//     //   ..style = PaintingStyle.fill;
//
//     Offset o2 = Offset(center.dx + 138, center.dx - 90);
//
//     // Paint paint0 = Paint()
//     //   ..color = Color(0xffE4CFBE)
//     //   ..style = PaintingStyle.fill
//     //   ..strokeWidth = 1;
//
//     Path path0 = Path();
//
//     path0.moveTo(size.width * 0.3802500, size.height * 0.2658500);
//     path0.quadraticBezierTo(size.width * 0.5132900, size.height * 0.3937333,
//         size.width * 0.4590800, size.height * 0.1443833);
//     path0.lineTo(size.width * 0.6143600, size.height * 0.3741667);
//     path0.quadraticBezierTo(size.width * 0.4793100, size.height * 0.3034167,
//         size.width * 0.5398700, size.height * 0.5046167);
//     path0.cubicTo(
//         size.width * 0.5267600,
//         size.height * 0.4824000,
//         size.width * 0.4195800,
//         size.height * 0.3325333,
//         size.width * 0.3802500,
//         size.height * 0.2658500);
//     path0.close();
//
//     var shift = path0.shift(const Offset(-8, -130));
//
//     double radians = 90 * 3.14 / 180;
//     //print("radians: $radians");
//     var matrix4 = Matrix4.identity()..setRotationZ(radians);
//
//     var p = shift.transform(matrix4.storage);
//
//     //c.drawPath(shift, paint0);
//     //c.drawPath(p, paint0);
//
//     canvas.drawCircle(center, 88.0, p1Paint);
//     //c.drawCircle(o2, 58.0, p2Paint);
//
//     if (kDebugMode) {
//       print(center.dx);
//       print(o2.dx);
//       print(p.getBounds().centerRight.dx);
//       print(p.getBounds().bottom);
//       print(p.getBounds().centerLeft.dx);
//       print((p.getBounds().centerLeft.dx / radians).ceilToDouble() *
//           radians.ceilToDouble());
//     }
//
//     double x1 = radians > 1
//         ? -((p.getBounds().centerLeft.dx / radians).ceilToDouble() *
//             radians.ceilToDouble())
//         : 37;
//     // double y1 = 28;
//
//     if (kDebugMode) {
//       print(x1);
//     }
//
//     // Offset o3 = Offset(center.dx + p.getBounds().centerRight.dx + x1,
//     //     center.dx + p.getBounds().bottom + y1);
//
//     //c.drawCircle(o3, 58.0, p2Paint);
//
//     /// Experimental
//
//     var path2 = Path();
//     var center2 = const Offset(0, 0);
//     var rect = Rect.fromCenter(center: center2, width: 190.0, height: 190.0);
//
//     //path2.addPath(p, center2);
//
//     path2.addRRect(RRect.fromRectAndRadius(
//       rect,
//       const Radius.circular(95.0),
//     ));
//
//     //c.drawPath(path2, paint0);
//
//     List<int> l = List.generate(3, (index) => index++);
//
//     Map<int, Path> paths = {};
//
//     if (kDebugMode) {
//       print(l);
//     }
//
//     for (var element in l) {
//       var path2 = Path();
//       var rect = Rect.fromCenter(
//         center: Offset(Random.secure().nextInt(200).toDouble(),
//             Random.secure().nextInt(200).toDouble()),
//         width: 190.0,
//         height: 190.0,
//       );
//       path2.addRRect(
//         RRect.fromRectAndRadius(
//           rect,
//           const Radius.circular(95.0),
//         ),
//       );
//
//       if (element >= 1) {
//         var combine =
//             Path.combine(PathOperation.intersect, paths[element - 1]!, path2);
//         if (kDebugMode) {
//           print(
//             "Intersect: ${combine.getBounds().isEmpty} - ${combine.getBounds()}",
//           );
//         }
//
//         if (!combine.getBounds().isEmpty) {
//           if (kDebugMode) {
//             print(path2.getBounds());
//           }
//           path2.moveTo(combine.getBounds().width, combine.getBounds().height);
//         }
//       }
//
//       paths.putIfAbsent(element, () => path2);
//       //c.drawPath(paths[element]!, paint0);
//     }
//
//     /*for (var element in l) {
//       /// check if intersect
//       var combine = Path.combine(PathOperation.intersect, p, path2);
//       print(combine.getBounds().isEmpty);
//     }*/
//   }
//
//   @override
//   bool shouldRepaint(covariant CustomPainter oldDelegate) {
//     return false;
//   }
// }
//
// class FeedPostsGraphPage extends StatefulWidget {
//   static const String routeName = '/home/feed/graph/';
//
//   const FeedPostsGraphPage({super.key});
//
//   @override
//   State<FeedPostsGraphPage> createState() => _FeedPostsGraphPageState();
// }
//
// class FruchtermanReingoldAlgorithmA extends FruchtermanReingoldAlgorithm {
//   final Graph graph;
//
//   FruchtermanReingoldAlgorithmA({required this.graph});
//
//   /*@override
//   get focusedNode => graph.nodes.where(
//           (element) => element.key?.value as int == 1).toList().first;*/
//
//   /*@override
//   void calculateAttraction(List<Edge> edges) {
//     edges.forEach((edge) {
//       var source = edge.source;
//       var destination = edge.destination;
//       var delta = (source.position +
//               ((source.key?.value as int) == 1
//                   ? Offset(300, 300)
//                   : Offset(100, 100))) -
//           (destination.position + Offset(150, 150));
//       var deltaDistance = max(EPSILON, delta.distance);
//       var maxAttractionDistance = min(graphWidth * attractionPercentage,
//           graphHeight * attractionPercentage);
//       var attractionForce =
//           min(0, (maxAttractionDistance - deltaDistance)).abs() /
//               (maxAttractionDistance * 2);
//       var attractionVector = delta * attractionForce * attractionRate;
//
//       displacement[source] = displacement[source]! - attractionVector;
//       displacement[destination] = displacement[destination]! + attractionVector;
//     });
//   }*/
//
// /*@override
//   void init(Graph? graph) {
//     graph!.nodes.forEach((node) {
//       displacement[node] = Offset.zero;
//
//       if ((node.key?.value as int) == 1) {
//         node.position = Offset(graphWidth / 2, graphHeight / 2);
//       } else {
//         node.position = Offset(
//             rand.nextDouble() * graphWidth, rand.nextDouble() * graphHeight);
//       }
//     });
//   }*/
//
// /* @override
//   void moveNodes(Graph graph) {
//     graph.nodes.forEach((node) {
//       if ((node.key?.value as int) == 1) {
//         node.position = Offset(430 / 2, 932 / 2);
//       }
//       if ((node.key?.value as int) != 1) {
//         var newPosition = node.position += displacement[node]!;
//         double newDX = min(graphWidth - 40, max(0, newPosition.dx));
//         double newDY = min(graphHeight - 40, max(0, newPosition.dy));
//
//         // double newDX = newPosition.dx;
//         // double newDY = newPosition.dy;
//         node.position = Offset(newDX, newDY);
//       }
//     });
//   }*/
// }
//
// class AEdgeRenderer extends EdgeRenderer {
//   var linePath = Path();
//
//   @override
//   void render(Canvas canvas, Graph graph, Paint paint) {
//     for (var edge in graph.edges) {
//       linePath.reset();
//       var source = edge.source;
//       var destination = edge.destination;
//
//       var sourceOffset = source.position;
//
//       var x1 = sourceOffset.dx;
//       var y1 = sourceOffset.dy;
//
//       var destinationOffset = destination.position;
//
//       var x2 = destinationOffset.dx;
//       var y2 = destinationOffset.dy;
//       // final levelSeparationHalf = 50.0;
//       debugPrint("==== sourceOffset: $sourceOffset ==== (${source.width}, ${source.height}), destinationOffset: $destinationOffset ==== (${destination.width}, ${destination.height})");
//       // var startX = x1 + source.width / 2;
//       // var startY = y1 + source.height / 2;
//       // var stopX = x2 + destination.width / 2;
//       // var stopY = y2 + destination.height / 2;
//
//       // position at the middle-top of the child
//       linePath.moveTo((x1 + source.width / 2), y1 + source.height / 2);
//       // draws a line from the child's middle-top halfway up to its parent
//       // linePath.lineTo(x1 + source.width / 2, y1 + source.height / 2);
//       // draws a line from the previous point to the middle of the parents width
//       linePath.lineTo(x2 + destination.width / 2, y1 + source.height / 2);
//
//       // position at the middle of the level separation under the parent
//       linePath.moveTo(x2 + destination.width / 2, y1 + source.height / 2);
//       // draws a line up to the parents middle-bottom
//       linePath.lineTo(x2 + destination.width / 2, y2 + destination.height / 2);
//
//       canvas.drawPath(linePath, Paint()
//         ..strokeWidth = 1
//         ..strokeCap = StrokeCap.round
//         ..style = PaintingStyle.stroke
//         ..color = AppColors.primaryColor);
//
//       // canvas.drawLine(
//       //     Offset(startX, startY),
//       //     Offset(stopX, stopY),
//       //     Paint()
//       //       ..strokeWidth = 5
//       //       ..color = AppColors.primaryColor);
//     }
//   }
// }
//
// class _FeedPostsGraphPageState extends State<FeedPostsGraphPage> {
//   Random r = Random();
//   final Graph graph = Graph();
//
//   List<BubbleNode> childNode = [];
//
//   //BuchheimWalkerConfiguration builder = BuchheimWalkerConfiguration();
//   //SugiyamaConfiguration builder = SugiyamaConfiguration();
//   FruchtermanReingoldAlgorithmA? builder;
//   BuchheimWalkerConfiguration builder1 = BuchheimWalkerConfiguration();
//
//   @override
//   void initState() {
//     final node1 = Node.Id(1);
//     /*node1
//       ..position = const Offset(430 / 2, 932 / 2)
//       ..size = const Size(189, 189);*/
//     final node2 = Node.Id(2);
//     final node3 = Node.Id(3);
//     final node4 = Node.Id(4);
//     final node5 = Node.Id(5);
//     final node6 = Node.Id(6);
//     final node8 = Node.Id(7);
//     final node7 = Node.Id(8);
//     // final node9 = Node.Id(9);
//     // final node10 = Node.Id(10);
//     // final node11 = Node.Id(11);
//     // final node12 = Node.Id(12);
//
//     final paint = Paint()
//     ..color = Colors.green
//     ..strokeWidth = 1
//     ..strokeCap = StrokeCap.round
//     ..style = PaintingStyle.stroke;
//
//     graph.addEdge(node1, node2, paint: paint);
//     graph.addEdge(node1, node3, paint: paint);
//     graph.addEdge(node1, node4, paint: paint);
//     graph.addEdge(node2, node5, paint: paint);
//     graph.addEdge(node2, node6, paint: paint);
//     graph.addEdge(node6, node7, paint: paint);
//     graph.addEdge(node6, node8, paint: paint);
//     graph.isTree = true;
//     /*graph.addEdge(node6, node7, paint: Paint()..color = Colors.red);
//     graph.addEdge(node6, node8, paint: Paint()..color = Colors.red);
//     graph.addEdge(node4, node9);
//     graph.addEdge(node4, node10, paint: Paint()..color = Colors.black);
//     graph.addEdge(node4, node11, paint: Paint()..color = Colors.red);
//     graph.addEdge(node11, node12);*/
//
//     builder = FruchtermanReingoldAlgorithmA(graph: graph);
//
//     builder!
//           //..siblingSeparation = (10)
//           //..levelSeparation = (10)
//           //..subtreeSeparation = (10)
//           //..orientation = (SugiyamaConfiguration.DEFAULT_ORIENTATION);
//           //..renderer = TreeEdgeRenderer(BuchheimWalkerConfiguration())
//           .renderer = AEdgeRenderer()
//         /*..attractionRate = 0.9
//       ..attractionPercentage = 0.9
//       ..repulsionPercentage = 0.4
//       ..repulsionRate = 0.3*/
//         ;
//
//     builder1
//       ..siblingSeparation = (100)
//       ..levelSeparation = (150)
//       ..subtreeSeparation = (150)
//       ..orientation = (BuchheimWalkerConfiguration.ORIENTATION_TOP_BOTTOM);
//
//     _addNewNode();
//
//     super.initState();
//
//     Future.delayed(const Duration(milliseconds: 3000), () {});
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     if (kDebugMode) {
//       print(MediaQuery.of(context).size);
//     }
//     return Scaffold(
//         extendBody: true,
//         appBar: AppBar(),
//         body: Stack(
//           children: [
//             Stack(
//               children: [
//                 Positioned(
//                     top: (MediaQuery.of(context).size.height / 2) - (240 / 2),
//                     left: (MediaQuery.of(context).size.width / 2),
//                     child: SizedBox.fromSize(
//                       size: const Size(190, 240),
//                       child: RepaintBoundary(
//                         child: Builder(builder: (c) {
//                           return CustomPaint(
//                             painter: A(),
//                           );
//                         }),
//                       ),
//                     ))
//               ],
//             ),
//             Column(
//               children: [
//                 Expanded(
//                   child: InteractiveViewer(
//                       constrained: false,
//                       boundaryMargin: const EdgeInsets.all(100),
//                       minScale: 0.01,
//                       maxScale: 5.6,
//                       child: GraphView(
//                         graph: graph,
//                         // algorithm: builder!,
//                         algorithm: BuchheimWalkerAlgorithm(builder1, AEdgeRenderer()),
//                         paint: Paint()
//                           ..color = Colors.green
//                           ..strokeWidth = 1
//                           ..strokeCap = StrokeCap.round
//                           ..style = PaintingStyle.stroke,
//                         builder: (Node node) {
//                           return rectangleWidget(node);
//                         },
//                       )),
//                 ),
//               ],
//             )
//           ],
//         ));
//
//     return Scaffold(
//       backgroundColor: Colors.white,
//       body: Container(
//         child: BubbleChartLayout(
//           // padding: 10,
//           children: [
//             BubbleNode.node(
//               padding: 15,
//               children: [
//                 BubbleNode.leaf(
//                   value: 100,
//                   options: BubbleOptions(
//                     color: Colors.amber,
//                   ),
//                 ),
//                 BubbleNode.leaf(
//                   value: 2,
//                   options: BubbleOptions(
//                     color: Colors.amber,
//                   ),
//                 ),
//                 BubbleNode.node(
//                   children: [
//                     BubbleNode.leaf(
//                       value: 10,
//                       options: BubbleOptions(
//                         color: Colors.green,
//                       ),
//                     ),
//                   ],
//                   options: BubbleOptions(
//                     color: Colors.amber,
//                   ),
//                 ),
//                 BubbleNode.leaf(
//                   value: 5,
//                   options: BubbleOptions(
//                     color: Colors.amber,
//                   ),
//                 ),
//               ],
//               options: BubbleOptions(color: Colors.transparent),
//             ),
//             BubbleNode.node(
//               padding: 15,
//               children: [
//                 BubbleNode.leaf(
//                   value: 100,
//                   options: BubbleOptions(
//                     color: Colors.amber,
//                   ),
//                 ),
//               ],
//               options: BubbleOptions(color: Colors.black),
//             ),
//           ],
//           duration: const Duration(milliseconds: 500),
//         ),
//       ),
//       floatingActionButton: FloatingActionButton(
//         child: const Text("+"),
//         onPressed: () {},
//       ),
//     );
//   }
//
//   Widget rectangleWidget(Node node) {
//     var a = node.key!.value as int?;
//     return InkWell(
//       onTap: () {
//         print('clicked');
//       },
//       child: Container(
//         width: node.size.width > 0 ? node.size.width : 50,
//         height: node.size.height > 0 ? node.size.height : 50,
//         padding: const EdgeInsets.all(0),
//         decoration: BoxDecoration(
//           shape: BoxShape.circle,
//           boxShadow: [
//             BoxShadow(
//                 color: a == 1 ? Colors.blue : Colors.amber,
//                 spreadRadius: 1),
//           ],
//         ),
//         child: Center(child: Text('Node $a')),
//       ),
//     );
//   }
//
//   _addNewNode() {
//     setState(() {
//       Random random = Random();
//       BubbleNode node = BubbleNode.leaf(
//         value: max(1, random.nextInt(10)),
//         options: BubbleOptions(
//           color: Colors.red,
//         ),
//       );
//       node.options?.onTap = () {
//         setState(() {
//           node.value += 1;
//           // childNode.remove(node);
//         });
//       };
//       childNode.add(node);
//     });
//   }
// }
