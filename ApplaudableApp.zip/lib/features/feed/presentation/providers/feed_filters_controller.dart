import 'package:flutter/material.dart';

import '../../../../core/entities/item.dart';
import '../../domain/enums/posts_enum.dart';

class FeedFiltersController<T extends Item> with ChangeNotifier {
  PostsFilterByType postsFilterByType = PostsFilterByType.suggested;

  TabController? _tabController;

  bool hasSelected = false;
  final List<T> _selectedItems = [];

  bool get hasSelectedFilterItems => _selectedItems.isNotEmpty;

  set tabController(TabController? controller) {
    _tabController ??= controller;
  }

  TabController? get tabController => _tabController;

  void selectItem(T item) {
    final index = _selectedItems.indexOf(item);

    if (index != -1) {
      unselectItem(item.id);
      return;
    }

    _selectedItems.add(item);
    notifyListeners();
  }

  void unselectItem(String id) {
    final index = _selectedItems.indexWhere((element) => element.id == id);

    if (_selectedItems.isEmpty || index == -1) return;

    _selectedItems.removeWhere((element) => element.id == id);
    notifyListeners();
  }

  bool isSelected(T item) {
    return _selectedItems.contains(item);
  }

  List<T> get selectedLifeCategories => [..._selectedItems];
  List<String> get selectedIds => _selectedItems.map((e) => e.id).toList();

  void clear() {
    _selectedItems.clear();
    notifyListeners();
  }
}
