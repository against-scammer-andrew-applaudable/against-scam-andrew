import 'package:flutter/material.dart';

import '../../../../core/theme/colors.dart';
import 'search_result_shimmer_loading_item_view.dart';

class SearchPageShimmerLoadingView extends StatelessWidget {
  const SearchPageShimmerLoadingView({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      itemCount: 15,
      padding: const EdgeInsets.only(
        top: 25,
        bottom: 60,
      ),
      separatorBuilder: (_, __) => const Padding(
        padding: EdgeInsets.symmetric(
          horizontal: 35,
        ),
        child: Divider(
          color: AppColors.lightGrey,
          height: 30,
        ),
      ),
      itemBuilder: (ctx, index) {
        return const SearchResultItemShimmerLoadingView();
      },
    );
  }
}
