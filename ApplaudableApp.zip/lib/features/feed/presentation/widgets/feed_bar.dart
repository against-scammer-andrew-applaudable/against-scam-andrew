import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';

import '../../../../core/widgets/app_bar.dart';
import '../../../../core/widgets/svg_icons.dart';
import 'feed_view.dart';

class HomeFeedAppBar extends AppBarWidget {
  const HomeFeedAppBar({
    super.key,
    this.title,
    this.actions,
    this.onSettingsTab,
  }) : super();

  final Widget? title;
  final List<Widget>? actions;
  final VoidCallback? onSettingsTab;

  @override
  Widget build(BuildContext context) {
    return SliverAppBar(
      floating: true,
      leading: null,
      automaticallyImplyLeading: false,
      backgroundColor: context.scaffoldBackgroundColor,
      titleSpacing: 0,
      centerTitle: true,
      scrolledUnderElevation: 0,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(
              //visualDensity: VisualDensity.compact,
              padding: const EdgeInsets.only(left: 20),
              icon: SvgIcons.homeFeed,
              onPressed: () {
                FeedView2.update(context);
              }),
          title!,
          /* IconButton(
              visualDensity: VisualDensity.compact,
              padding: EdgeInsets.zero,
              onPressed: () {},
              icon: SvgIcons.feedNotifications)*/
          IconButton(
            visualDensity: VisualDensity.compact,
            padding: const EdgeInsets.only(right: 20),
            onPressed: onSettingsTab,
            icon: SvgIcons.feedFilters(color: context.textColor),
          ),
        ],
      ),
    );
  }
}
