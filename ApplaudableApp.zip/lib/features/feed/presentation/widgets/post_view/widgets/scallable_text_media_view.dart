import 'package:flutter/material.dart';

import '../../../../../../core/extensions/build_context_extensions.dart';
import '../../../../../../core/utils/app_utils.dart';
import '../../../../../../core/theme/colors.dart';
import '../../../../../../core/theme/styles.dart';

class ScallableTextMediaView extends StatelessWidget {
  final Function()? onTap;
  final String text;
  final double? maxWidth;
  final int maxLines;
  final TextStyle? style;
  final EdgeInsets padding;

  const ScallableTextMediaView({
    Key? key,
    required this.text,
    this.onTap,
    this.maxWidth,
    this.maxLines = 3,
    this.style,
    this.padding = const EdgeInsets.all(35),
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    TextPainter tp = AppUtils.getTextSize(
      text: text,
      maxWidth: maxWidth ?? context.screenWidth * 0.6,
      maxLines: maxLines,
      style: style ?? defaultStyle,
    );

    return GestureDetector(
      onTap: onTap,
      child: ColoredBox(
        color: AppColors.darkPeach2,
        child: Padding(
          padding: padding,
          child: FittedBox(
            child: Row(
              children: [
                SizedBox(
                  width: tp.didExceedMaxLines
                      ? context.screenWidth
                      : (maxWidth ?? context.screenWidth * 0.6),
                  child: Text(text, style: style ?? defaultStyle),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  TextStyle get defaultStyle {
    return AppStyles.text1(color: AppColors.white).copyWith(
      fontWeight: FontWeight.w700,
      height: 1.3,
      fontSize: 25,
    );
  }
}
