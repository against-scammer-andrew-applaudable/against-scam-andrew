import 'package:flutter/material.dart';

import '../../../../../../core/widgets/svg_icons.dart';

class PostApplaudRankView extends StatelessWidget {
  const PostApplaudRankView({Key? key, this.rank = 0}) : super(key: key);

  final int rank;

  Widget get first {
    if (rank == 0) {
      return SvgFeedIcons.applaudRankStroke;
    }
    return SvgFeedIcons.applaudRankFill;
  }

  Widget get second {
    if (rank < 2) {
      return SvgFeedIcons.applaudRankStroke;
    }
    return SvgFeedIcons.applaudRankFill;
  }

  Widget get third {
    if (rank < 3) {
      return SvgFeedIcons.applaudRankStroke;
    }
    return SvgFeedIcons.applaudRankFill;
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        first,
        const SizedBox(
          width: 4,
        ),
        second,
        const SizedBox(
          width: 4,
        ),
        third
      ],
    );
  }
}
