import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';

import '../../../../../../app_module.dart';
import '../../../../../../core/theme/colors.dart';
import '../../../../../../core/theme/dimensions.dart';
import '../../../../../../core/theme/styles.dart';
import '../../../../../../core/widgets/buttons/app_icon_buttom.dart';
import '../../../../../../core/widgets/svg_icons.dart';
import '../../../../../auth/presentation/callbacks.dart';
import '../../../../../auth/presentation/widgets/sheet_views/bottom_sheet_view.dart';
import '../../../../data/models/posts_response_model.dart';
import '../../../../domain/entities/post_response.dart';
import '../../../../domain/usecases/execute_post_action.dart';
import 'applauds_list_bottom_sheet.dart';
import 'post_applaud_button.dart';
import 'post_bookmark_button.dart';

class PostReactionsView extends StatelessWidget {
  final String id;
  final OnTapCallback<PostActions> onTap;
  final PostEngagement? engagement;
  final bool enableHighlights;
  final PostCounters counters;

  const PostReactionsView({
    Key? key,
    required this.id,
    required this.onTap,
    this.engagement,
    this.enableHighlights = true,
    this.counters = const PostCountersModel(),
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      decoration: BoxDecoration(
        color: context.feedCardColor,
        border: const Border(top: BorderSide(color: AppColors.darkPeach)),
      ),
      padding: const EdgeInsets.only(
        left: 8,
        right: 8,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              /*AppIconButton(
                  icon: SvgFeedIcons.comments,
                  onTap: () => onTap(PostActions.comments)),
              const SizedBox(width: 5),*/
              PostBookmarkView(
                key: Key(id),
                id: id,
                iconInput: SvgFeedIcons.bookmark(color: context.textColor),
                selectedIconInput: SvgFeedIcons.bookmarked(color: context.textColor),
                status: engagement?.bookmarked ?? false,
              ),
              const SizedBox(width: 5),
              AppIconButton.feed(
                icon: SvgFeedIcons.share(color: context.textColor),
                onTap: () => onTap(PostActions.share),
              ),
              if (enableHighlights) ...[
                AppIconButton.feed(
                  icon: SvgFeedIcons.highlights(color: context.textColor),
                  onTap: () => onTap(PostActions.highlights),
                ),
                const SizedBox(width: 5),
              ],
            ],
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: AppModule.I.enablePostApplaudsListView
                    ? () {
                        BottomSheetView.show(
                          context: context,
                          corner: const BorderRadius.only(
                            topLeft: Radius.circular(AppDimensions.radius_24),
                            topRight: Radius.circular(AppDimensions.radius_24),
                          ),
                          sheet: ApplaudsListBottomSheet(postId: id),
                        );
                      }
                    : null,
                child: Container(
                  color: AppColors.transparent,
                  padding: const EdgeInsets.symmetric(
                    vertical: 5,
                    horizontal: 8,
                  ),
                  child: Text(
                    counters.applauds.toString(),
                    style: AppStyles.text2(color: AppColors.darkGrey).copyWith(
                      fontSize: 13,
                    ),
                  ),
                ),
              ),
              PostApplaudView(
                key: Key(id),
                id: id,
                iconInput: SvgFeedIcons.applaud(color: context.textColor),
                status: engagement?.applauds ?? false,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class PostReactionsSimpleView extends StatelessWidget {
  const PostReactionsSimpleView({
    Key? key,
    required this.id,
    required this.onTap,
    this.engagement,
    this.applauds = 0,
    this.backgroundColor = AppColors.white,
    this.enableHighlights = true,
  }) : super(key: key);

  final String id;
  final OnTapCallback<PostActions> onTap;
  final PostEngagement? engagement;
  final int applauds;
  final Color backgroundColor;
  final bool enableHighlights;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
          height: 50,
          decoration: BoxDecoration(
            color: backgroundColor,
            border: const Border(top: BorderSide(color: AppColors.darkPeach)),
          ),
          padding: const EdgeInsets.only(
            left: 5,
            right: 5,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  if (enableHighlights) ...[
                    AppIconButton(
                      icon: SvgFeedIcons.highlights(color: context.textColor),
                      onTap: () => onTap(PostActions.highlights),
                    ),
                    const SizedBox(width: 5),
                  ],
                  PostBookmarkView(
                    key: Key(id),
                    id: id,
                    iconInput: SvgFeedIcons.bookmark(color: context.textColor),
                    selectedIconInput: SvgFeedIcons.bookmarked(color: context.textColor),
                    status: engagement?.bookmarked ?? false,
                  ),
                  const SizedBox(width: 5),
                  AppIconButton(
                    icon: SvgFeedIcons.share(color: context.textColor),
                    onTap: () => onTap(PostActions.share),
                  ),
                ],
              ),
              Row(
                children: [
                  Text(
                    "$applauds ${applauds == 1 ? "Applaud" : "Applauds"}",
                    style: AppStyles.text2(color: AppColors.darkGrey),
                  ),
                  const SizedBox(width: 17),
                  PostApplaudView(
                    key: Key(id),
                    id: id,
                    iconInput: SvgFeedIcons.applaud(color: context.textColor),
                    status: engagement?.applauds ?? false,
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}
