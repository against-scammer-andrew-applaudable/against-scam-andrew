import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../../../core/bloc/widgets/base_stateless_page.dart';
import '../../../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../../../core/extensions/build_context_extensions.dart';
import '../../../../../../core/theme/dimensions.dart';
import '../../../../../../core/theme/styles.dart';
import '../../../../../../core/widgets/animations/pagination_loading_view.dart';
import '../../../../../../core/widgets/app_default_error_view.dart';
import '../../../../../../core/widgets/app_listview.dart';
import '../../../../../../injection_container.dart';
import '../../../../../auth/presentation/widgets/sheet_views/bottom_sheet_view.dart';
import '../../../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../../../../../profile/presentation/pages/profile_page.dart';
import '../../../../../profile/presentation/widgets/user_tile_item.dart';
import '../../../../../profile/presentation/widgets/users_tiles_loading_view.dart';
import '../../../blocs/post_applauds_bloc/post_applauds_bloc.dart';

class ApplaudsListBottomSheet extends BottomSheetView {
  final String postId;

  const ApplaudsListBottomSheet({super.key, required this.postId});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: context.screenHeight * 0.9,
      child: Provider.value(
        value: servLocator<PostApplaudsBloc>(),
        child: PostApplaudsSheetView(postId: postId),
      ),
    );
  }
}

// ignore: must_be_immutable
class PostApplaudsSheetView
    extends BaseStatelessPage<PostApplaudsBloc, PostApplaudsState> {
  final String postId;

  PostApplaudsSheetView({super.key, required this.postId});

  @override
  void initBloc(BuildContext context, PostApplaudsBloc bloc) {
    bloc.add(GetPostApplaudsEvent(postId: postId));
  }

  @override
  Widget build(BuildContext context) {
    registerBloc(context);

    return AppSideMargins(
      margin: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            translations.applauds,
            textAlign: TextAlign.center,
            style: AppStyles.header1(color: context.textColor).copyWith(fontSize: 24),
          ),
          const Divider(height: 25),
          Flexible(
            child: DNGBlocBuilder<PostApplaudsBloc, PostApplaudsState>(
              bloc: bloc,
              buildWhen: (state) =>
                  state.postId == postId &&
                  (state is PostApplaudsLoadingState ||
                      state is PostApplaudsErrorState ||
                      state is PostApplaudsFetchedState),
              builder: (context, state) {
                if (state is PostApplaudsLoadingState) {
                  return const UsersTilesLoadingView(showFollowActions: false);
                } else if (state is PostApplaudsErrorState) {
                  return AppDefaultErrorView(message: state.message);
                } else if (state is PostApplaudsFetchedState) {
                  return AppListView.separated(
                    itemCount: state.applauds.length,
                    separatorBuilder: (_, __) =>
                        const SizedBox(height: AppDimensions.zero),
                    allowPaginationHandling: true,
                    onPaginate: () {
                      bloc.add(
                        GetPostApplaudsEvent(postId: postId, paginate: true),
                      );
                    },
                    itemBuilder: (ctx, index) {
                      final applaudUser = state.applauds[index];

                      return Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          UserTileItem(
                            user: applaudUser.asUser,
                            showFollowButton: false,
                            avatarHeight: 44,
                            avatarWidth: 44,
                            onTap: (_) => ProfilePage.push(context, applaudUser.id),
                          ),
                          DNGBlocBuilder<PostApplaudsBloc, PostApplaudsState>(
                            // buildWhen: (s) =>
                            //     s is PostApplaudsNextPageLoadingState,
                            builder: (context, curState) {
                              if (index != state.applauds.length - 1 ||
                                  (curState
                                          is! PostApplaudsNextPageLoadingState &&
                                      curState
                                          is! PostApplaudsNextPageLoadingState)) {
                                return Container();
                              }

                              return const PaginationLoadingView();
                            },
                          )
                        ],
                      );
                    },
                  );
                }

                return const SizedBox();
              },
            ),
          )
        ],
      ),
    );
  }
}
