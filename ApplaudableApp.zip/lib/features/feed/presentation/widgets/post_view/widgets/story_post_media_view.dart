import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:applaudable/features/feed/presentation/widgets/post_view/widgets/post_media_view.dart';
import 'package:flutter/material.dart';

import '../../../../../../app_module.dart';
import '../../../../../../core/constants/constant_values.dart';
import '../../../../../../core/entities/base_image.dart';
import '../../../../../../core/extensions/app_module_extensions.dart';
import '../../../../../../core/theme/colors.dart';
import '../../../../../../core/theme/styles.dart';
import '../../../../../../core/widgets/items/item_image.dart';
import '../../../../../../generated/l10n.dart';
import '../../../../../mentions/presentation/widgets/mention_render_object.dart';
import '../../../../../post/presentation/pages/post_page.dart';
import '../../../../domain/entities/post_response.dart';
import '../../../../domain/enums/posts_enum.dart';

class StoryPostMediaView extends StatelessWidget {
  final Post post;
  final int index;
  final Function()? onTap;
  final ImageOptimizationSizes? imageSize;
  final double? width;
  final double? height;
  final String? preloadMedia;
  final bool isFromPostDetails;
  final bool isGridItem;
  final int maxLines;
  final EdgeInsetsGeometry? padding;
  final Color backgroundColor;
  final Color titleColor;
  final Color textColor;
  final String? seeMoreText;
  final TextStyle? seeMoreStyle;

  const StoryPostMediaView({
    super.key,
    required this.post,
    required this.index,
    this.onTap,
    this.imageSize,
    this.width,
    this.height,
    this.preloadMedia,
    this.isFromPostDetails = false,
    this.isGridItem = false,
    this.maxLines = 26,
    this.padding,
    this.backgroundColor = AppColors.dark,
    this.titleColor = AppColors.white,
    this.textColor = AppColors.lightPeach,
    this.seeMoreText,
    this.seeMoreStyle,
  });

  PostMedia? get firstMedia => post.media.isNotEmpty ? post.media.first : null;

  double sizeWidth(BuildContext context) =>
      width ?? MediaQuery.of(context).size.width;

  double sizeHeight(BuildContext context) =>
      height ?? ConstantValues.feedPostHeight;

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    if (preloadMedia != null && preloadMedia!.isNotEmpty) {
      return ItemImage.taller(
        key: Key("$index"),
        source: preloadMedia!,
        size: sizeWidth(context),
        height: sizeHeight(context),
        onTap: onTap,
        autoAspectRatio: true,
      );
    }

    if (firstMedia != null) {
      switch (firstMedia!.type) {
        case PostMediaTypes.image:
          return ZoomingWidget(
            child: ItemImage.taller(
              key: Key("$index"),
              source: imageSize == null
                  ? firstMedia!.optimizedImage
                  : firstMedia!.getImageBySize(imageSize!),
              size: sizeWidth(context),
              height: sizeHeight(context),
              onTap: onTap,
              shouldResizeImageOnHeight: firstMedia?.shouldResizeImageOnHeight ?? false,
              disableAspectRatio: true,
            ),
          );
        case PostMediaTypes.video:
          // TODO: Handle this case.
          break;
        case PostMediaTypes.text:
          break;
      }
    }

    if (isGridItem) {
      return Text(
        firstMedia!.text,

        // text: firstMedia!.text.length < ((width ?? 0) / 7).round()
        //     ? firstMedia!.text
        //     : firstMedia!.text + '              ',
        // padding: const EdgeInsets.all(AppDimensions.defaultSidePadding),
        // maxWidth: width,
        maxLines: 1,
        style: AppStyles.text2(color: AppColors.white).copyWith(
          fontSize: firstMedia!.text.length > 6 ? 50 : 15,
        ),
        // onTap: onTap,
      );
    }

    final titleStyle = AppStyles.header1(color: context.textColor).copyWith(
      fontWeight: FontWeight.w700,
      fontSize: 20,
    );

    return GestureDetector(
      onTap: onTap,
      child: ConstrainedBox(
        constraints: BoxConstraints(
          minWidth: double.infinity,
          maxHeight: isFromPostDetails ? double.infinity : 550,
        ),
        child: ColoredBox(
          color: backgroundColor,
          child: Padding(
            padding: padding ??
                const EdgeInsets.symmetric(
                  horizontal: 30,
                  vertical: 50,
                ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (post.title.trim().isNotEmpty) ...[
                  LayoutBuilder(
                    builder: (context, size) {
                      final titlePainter = getTextSize(
                        size.maxWidth,
                        style: titleStyle,
                        maxLines: 4,
                      );

                      final textPainter =
                          getTextSize(size.maxWidth, maxLines: maxLines);

                      final titleLines =
                          (titlePainter.computeLineMetrics().length * 2.4)
                              .round();
                      final textLines = textPainter.computeLineMetrics().length;

                      return GestureDetector(
                        onTap: isFromPostDetails || titleLines + textLines < 17
                            ? null
                            : _openPostDetailsPage,
                        child: Text(
                          post.title,
                          style: titleStyle.copyWith(
                            height: 1.25,
                            color: titleColor,
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 14),
                ],
                Flexible(
                  child: LayoutBuilder(
                    builder: (ctx, size) {
                      final titlePainter = getTextSize(
                        size.maxWidth,
                        style: titleStyle,
                        maxLines: 4,
                      );
                      final titleLines =
                          (titlePainter.computeLineMetrics().length *
                                  (post.title.isEmpty ? 1 : 2.4))
                              .round();

                      final textPainter = getTextSize(
                        size.maxWidth,
                        maxLines: maxLines - titleLines <= 0
                            ? maxLines ~/ 2
                            : maxLines - titleLines,
                      );

                      final renderText = MentionRenderObject(
                        elements: post.elements,
                        mentions: post.mentions,
                      ).renderSpans(style: AppStyles.text2(color: textColor));

                      return GestureDetector(
                        onTap:
                            isFromPostDetails || !textPainter.didExceedMaxLines
                                ? null
                                : _openPostDetailsPage,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Flexible(
                              child: RichText(
                                text: TextSpan(
                                  text: '',
                                  children: renderText,
                                  style: AppStyles.text2(color: textColor),
                                ),
                                maxLines: isFromPostDetails
                                    ? null
                                    : maxLines - titleLines <= 0
                                        ? maxLines ~/ 2
                                        : maxLines - titleLines,
                                overflow: TextOverflow.fade,
                              ),
                            ),
                            // const SizedBox(height: 15),
                            if (!isFromPostDetails &&
                                textPainter.didExceedMaxLines) ...[
                              GestureDetector(
                                onTap: _openPostDetailsPage,
                                child: Container(
                                  color: Colors.transparent,
                                  child: Text(
                                    seeMoreText ?? translations.see_more_plus,
                                    style: seeMoreStyle ??
                                        AppStyles.text2(
                                          color: AppColors.darkGrey,
                                        ).copyWith(
                                          fontWeight: FontWeight.w700,
                                          height: 1,
                                        ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 20),
                            ]
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _openPostDetailsPage() {
    AppModule.I.navigateToNamed(
      PostPage.routeName,
      arguments: PostPageArgs(post: post),
    );
  }

  TextPainter getTextSize(
    double maxWidth, {
    int? maxLines,
    TextStyle? style,
  }) {
    final tp = TextPainter(
      text: TextSpan(
        text: post.media.isNotEmpty ? post.media.first.text : post.text,
        style: style ?? AppStyles.text2(color: AppColors.dark),
      ),
      maxLines: maxLines,
      textDirection: TextDirection.ltr,
    );

    tp.layout(maxWidth: maxWidth);

    return tp;
  }
}
