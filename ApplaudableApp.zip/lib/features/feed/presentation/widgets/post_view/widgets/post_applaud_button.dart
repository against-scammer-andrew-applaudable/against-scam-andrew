import 'package:flutter/material.dart';

import '../../../../../../core/widgets/buttons/animated_button/app_animated_button.dart';
import '../../../../../../core/widgets/svg_icons.dart';
import '../../../../../auth/presentation/callbacks.dart';
import '../../../../../post/presentation/blocs/post_bloc.dart';
import '../../../../domain/entities/post_response.dart';
import '../../../../domain/usecases/execute_post_action.dart';

/// ----
/// Widget views

/// [PostApplaudView] used for the Feed Post widget applaud handler
class PostApplaudView extends AppAnimatedButton {
  const PostApplaudView(
      {Key? key, required String id, required this.iconInput, OnTapCallback<bool>? onTap, bool? status})
      : super(key: key, id: id, onTap: onTap, status: status);

  final Widget iconInput;
  @override
  Widget get icon => iconInput;

  @override
  Widget get selectedIcon => SvgFeedIcons.applauded;

  @override
  bool resolveWhen(state) =>
      state is SetPostActionUpdatedState &&
      state.id == id &&
      (state.action == PostActions.applaud ||
          state.action == PostActions.removeApplaud);

  @override
  State createState() => _PostApplaudViewState();
}

class _PostApplaudViewState
    extends AppAnimatedButtonStreamState<Post, PostBloc, PostState> {
  @override
  bool get requestState => true;

  @override
  bool resolveStateFromItem(Post? item) => item?.engagement?.applauds ?? false;

  @override
  bool resolveOnState(PostState state) => state is SetPostActionUpdatedState;

  @override
  Post? item(PostState state) => (state as SetPostActionUpdatedState).model;

  @override
  setModel(String id) {
    bloc.add(SetPostActionEvent(
      id: id,
      action: PostActions.applaud,
    ));
  }

  @override
  getModel(String id) {}

  @override
  unSetModel(String id) {
    bloc.add(SetPostActionEvent(
      id: id,
      action: PostActions.removeApplaud,
    ));
  }
}
