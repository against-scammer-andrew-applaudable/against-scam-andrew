import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:zoom_pinch_overlay/zoom_pinch_overlay.dart';

import '../../../../../../core/constants/constant_values.dart';
import '../../../../../../core/controllers/scroll_gesture_controller.dart';
import '../../../../../../core/entities/base_image.dart';
import '../../../../../../core/extensions/string_extensions.dart';
import '../../../../../../core/theme/colors.dart';
import '../../../../../../core/theme/dimensions.dart';
import '../../../../../../core/theme/styles.dart';
import '../../../../../../core/utils/app_utils.dart';
import '../../../../../../core/widgets/items/item_image.dart';
import '../../../../domain/entities/post_response.dart';
import '../../../../domain/enums/posts_enum.dart';
import 'list_text_media_view.dart';
import 'scallable_text_media_view.dart';

class PostMediaView extends StatelessWidget {
  const PostMediaView({
    Key? key,
    required this.index,
    required this.item,
    this.height,
    this.width,
    this.isGridItem = false,
    this.preloadMedia,
    this.onTap,
    this.imageSize,
  }) : super(key: key);

  final int index;
  final Post item;
  final double? height;
  final double? width;
  final bool isGridItem;
  final String? preloadMedia;
  final Function()? onTap;
  final ImageOptimizationSizes? imageSize;

  PostMedia? get firstMedia => item.media.isNotEmpty ? item.media.first : null;

  double sizeWidth(BuildContext context) =>
      width ?? MediaQuery.of(context).size.width;

  double sizeHeight(BuildContext context) =>
      height ?? ConstantValues.feedPostHeight;

  @override
  Widget build(BuildContext context) {

    if (preloadMedia != null && preloadMedia!.isNotEmpty) {
      return ZoomingWidget(
        child: ItemImage.taller(
          key: Key("$index"),
          source: preloadMedia!,
          size: sizeWidth(context),
          height: sizeHeight(context),
          onTap: onTap,
          autoAspectRatio: true,
        ),
      );
    }

    if (firstMedia != null) {
      switch (firstMedia!.type) {
        case PostMediaTypes.image:
          return ZoomingWidget(
            child: ItemImage.taller(
              key: Key("$index"),
              source: imageSize == null
                  ? firstMedia!.optimizedImage
                  : firstMedia!.getImageBySize(imageSize!),
              size: sizeWidth(context),
              height: sizeHeight(context),
              onTap: onTap,
              shouldResizeImageOnHeight:
                  firstMedia?.shouldResizeImageOnHeight ?? false,
              disableAspectRatio: true,
            ),
          );
        case PostMediaTypes.video:
          return ZoomingWidget(
            child: ItemImage.taller(
              key: Key("$index"),
              source: (imageSize == null
                  ? firstMedia!.optimizedImage
                  : firstMedia!.getImageBySize(imageSize!)).thumbnailForCloudinary,
              size: sizeWidth(context),
              height: sizeHeight(context),
              onTap: onTap,
              shouldResizeImageOnHeight:
              firstMedia?.shouldResizeImageOnHeight ?? false,
              disableAspectRatio: true,
            ),
          );
        case PostMediaTypes.text:
          if (isGridItem) {
            return ScallableTextMediaView(
              text: firstMedia!.text,

              // text: firstMedia!.text.length < ((width ?? 0) / 7).round()
              //     ? firstMedia!.text
              //     : firstMedia!.text + '              ',
              padding: const EdgeInsets.all(AppDimensions.defaultSidePadding),
              maxWidth: width,
              maxLines: 1,
              style: AppStyles.text2(color: AppColors.white).copyWith(
                fontSize: firstMedia!.text.length > 6 ? 50 : 15,
              ),
              onTap: onTap,
            );
          }
          return ListTextMediaView(text: firstMedia!.text, onTap: onTap);
      }
    }

    if (item.nupp != null) {
      if (item.nupp!.hasMedia) {
        return ZoomingWidget(
          child: ItemImage.taller(
            key: Key("$index"),
            source: imageSize == null
                ? item.nupp!.firstMedia!.optimizedImage
                : item.nupp!.firstMedia!.getImageBySize(imageSize!),
            size: sizeWidth(context),
            height: sizeHeight(context),
            onTap: onTap,
            shouldResizeImageOnHeight:
            item.nupp?.firstMedia?.shouldResizeImageOnHeight ?? false,
          ),
        );
      }

      return isGridItem
          ? ScallableTextMediaView(
              text: item.nupp!.name,
              padding: const EdgeInsets.all(AppDimensions.defaultSidePadding),
              maxWidth: width,
              maxLines: 1,
              style: AppStyles.text2(color: AppColors.white).copyWith(
                fontSize: item.nupp!.name.length > 6 ? 50 : 15,
              ),
              onTap: onTap,
            )
          : ListTextMediaView(text: item.nupp!.name, onTap: onTap);
    }

    if (item.user != null) {
      return isGridItem
          ? ScallableTextMediaView(
              text: item.user!.name,
              padding: const EdgeInsets.all(AppDimensions.defaultSidePadding),
              maxWidth: width,
              maxLines: 1,
              style: AppStyles.text2(color: AppColors.white).copyWith(
                fontSize: item.user!.name.length > 6 ? 50 : 15,
              ),
              onTap: onTap,
            )
          : ListTextMediaView(text: item.user!.name, onTap: onTap);
    }

    if (item.text.isNotEmpty) {
      return isGridItem
          ? ScallableTextMediaView(
              text: item.text,
              padding: const EdgeInsets.all(AppDimensions.defaultSidePadding),
              maxWidth: width,
              maxLines: 1,
              style: AppStyles.text2(color: AppColors.white).copyWith(
                fontSize: item.text.length > 6 ? 50 : 15,
              ),
              onTap: onTap,
            )
          : ListTextMediaView(text: item.text, onTap: onTap);
    }

    return Container(
      height: 1,
      color: AppColors.darkPeach,
    );
  }
}

class ZoomingWidget extends StatefulWidget {
  const ZoomingWidget({super.key, required this.child});
  final Widget child;
  @override
  State<ZoomingWidget> createState() => _ZoomingWidgetState();
}

class _ZoomingWidgetState extends State<ZoomingWidget> {

  @override
  void initState() {
    super.initState();
    AppUtils().scrollEnabledByZooming.addListener(_listener);
  }
  @override
  void dispose() {
    AppUtils().scrollEnabledByZooming.removeListener(_listener);
    super.dispose();
  }
  void _listener() {
    try {
      final gestureController = context.read<ScrollGestureController>();
      gestureController.allowScrollGesture = AppUtils().scrollEnabledByZooming.value;
    } catch(_) {}
  }
  @override
  Widget build(BuildContext context) {
    return ZoomOverlay(
      scrollEnabled: AppUtils().scrollEnabledByZooming,
      parentContext: AppUtils().tabContext,
      child: widget.child,
    );
  }
}

class MediaTextView extends StatelessWidget {
  const MediaTextView({
    super.key,
    required this.text,
    this.isGridItem = false,
    this.onTap,
  });

  final String text;
  final bool isGridItem;
  final Function()? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Material(
        child: Container(
          width: MediaQuery.of(context).size.width,
          height: calculateTextHeight(context, text),
          padding: const EdgeInsets.symmetric(
              horizontal: ConstantValues.feedPostMediaTextHorizontalPadding,
              vertical: ConstantValues.feedPostMediaTextVerticalPadding),
          decoration: BoxDecoration(color: AppColors.darkPeach.shade30),
          child: Text(
            text,
            style: isGridItem
                ? AppStyles.mediaText(color: context.backgroundColor).copyWith(fontSize: 12)
                : AppStyles.mediaText(color: context.backgroundColor),
          ),
        ),
      ),
    );
  }

  /// Calculate the given height rendered text
  /// it used the textPainter to render with the style
  /// to calculate the exact height size
  double calculateTextHeight(BuildContext context, String text) {
    final double height = text.textHeight(
        AppStyles.mediaText(color: context.backgroundColor),
        MediaQuery.of(context).size.width -
            (ConstantValues.feedPostMediaTextVerticalPadding * 2));

    final double finalHeight =
        height + (ConstantValues.feedPostMediaTextVerticalPadding * 2);
    final bool isBiggerThanDefaultValue =
        finalHeight > ConstantValues.feedPostHeight;
    if (isBiggerThanDefaultValue) {
      return finalHeight;
    }
    return ConstantValues.feedPostHeight;
  }
}
