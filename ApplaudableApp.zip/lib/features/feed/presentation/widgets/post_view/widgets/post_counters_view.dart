import 'package:flutter/material.dart';

import '../../../../../../app_module.dart';
import '../../../../../../core/widgets/app_separator_view.dart';
import '../../../../../../core/theme/colors.dart';
import '../../../../../../core/theme/dimensions.dart';
import '../../../../../../core/theme/styles.dart';

/// TODO: Media Slider to be added in a later version
class PostCountersView extends StatelessWidget {
  final int applauds;
  final int shares;
  final int influences;
  final bool showZeroCounter;

  const PostCountersView(
      {Key? key,
      this.applauds = 0,
      this.shares = 0,
      this.influences = 0,
      this.showZeroCounter = true})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.white,
      height: 32,
      padding: const EdgeInsets.only(
          left: 19, right: 20),
      child: Row(
        children: [
          if (showZeroCounter || applauds > 0) ...[
            // Text(
            //   "$applauds ${applauds == 1 ? "Applaud" : "Applauds"}",
            //   style: AppStyles.textSmall(color: AppColors.darkGrey)
            //       .copyWith(fontSize: AppFontSizes.textSmall2),
            // ),
            if (AppModule.I.enableInfluencesMeasures)
              const Padding(
                padding: EdgeInsets.only(left: 15, right: 15),
                child: AppSeparatorView.darkGrey(),
              ),
          ],
          if (AppModule.I.enableInfluencesMeasures)
            if (showZeroCounter || shares > 0) ...[
              Text(
                "$shares ${shares == 1 ? "Share" : "Shares"}",
                style: AppStyles.textSmall(color: AppColors.darkGrey)
                    .copyWith(fontSize: AppFontSizes.textSmall2),
              ),
              const Padding(
                padding: EdgeInsets.only(left: 15, right: 15),
                child: AppSeparatorView.darkGrey(),
              ),
            ],

          if (AppModule.I.enableInfluencesMeasures)
            if (showZeroCounter || influences > 0) ...[
              Text(
                "$influences ${influences == 1 ? "influence" : "Influences"}",
                style: AppStyles.textSmall(color: AppColors.darkGrey)
                    .copyWith(fontSize: AppFontSizes.textSmall2),
              ),
            ]
          // Media Slider
        ],
      ),
    );
  }
}
