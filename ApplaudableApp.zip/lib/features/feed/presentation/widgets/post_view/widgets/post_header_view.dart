import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';

import '../../../../../../app_module.dart';
import '../../../../../../core/widgets/app_user_view.dart';
import '../../../../../../core/theme/dimensions.dart';
import '../../../../../post/domain/entities/post_entities.dart';
import '../../../../../post/presentation/blocs/post_bloc.dart';
import '../../../../../post/presentation/utils/post_bloc_utils.dart';
import '../../../../domain/usecases/execute_post_action.dart';
import '../../feed_menu_more_actions.dart';
import 'post_applaud_rank_view.dart';

class PostHeaderView extends StatelessWidget {
  const PostHeaderView({
    Key? key,
    required this.id,
    required this.owner,
    this.ranking = 0,
    this.label = "",
    this.isCurrentSessionUserThePostOwner = false,
  }) : super(key: key);

  final String id;
  final PostUser owner;
  final int ranking;
  final String label;
  final bool isCurrentSessionUserThePostOwner;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 61,
      padding: const EdgeInsets.only(
        left: AppDimensions.defaultSideMargin,
        right: AppDimensions.defaultSideMargin,
      ),
      decoration: BoxDecoration(
        color: context.feedCardColor,
        borderRadius: const BorderRadius.only(
          topRight: Radius.circular(AppDimensions.radius_20),
          topLeft: Radius.circular(AppDimensions.radius_20),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          AppUserView<PostUser>.feedPost(
            id: id,
            user: owner,
            value: label,
          ),
          Column(
            children: [
              Container(
                height: 61,
                padding: const EdgeInsets.only(top: 21, bottom: 16),
                child: Row(
                  children: [
                    if (AppModule.I.enableApplaudRankLevel)
                      PostApplaudRankView(
                        rank: ranking,
                      ),
                    FeedMenuMoreAction(
                      isCurrentSessionUserThePostOwner:
                          isCurrentSessionUserThePostOwner,
                      onTap: (action) => _onTapMoreActions(context, action),
                    ),
                  ],
                ),
              ),
            ],
          )
        ],
      ),
    );
  }

  void _onTapMoreActions(BuildContext context, action) {
    switch (action) {
      case FeedMenuMoreActions.delete:
        PostBlocUtils.getBloc(id)
            .add(SetPostActionEvent(id: id, action: PostActions.delete));
        break;
      case FeedMenuMoreActions.flag:
        PostBlocUtils.getBloc(id)
            .add(SetPostActionEvent(id: id, action: PostActions.flag));
        break;
    }
  }
}
