import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';

import '../../../../../../core/theme/colors.dart';
import '../../../../../../core/theme/styles.dart';

class ListTextMediaView extends StatelessWidget {
  final String text;
  final Function()? onTap;

  const ListTextMediaView({super.key, required this.text, this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: ConstrainedBox(
        constraints: const BoxConstraints(
          minWidth: double.infinity,
          minHeight: 376,
        ),
        child: ColoredBox(
          color: AppColors.dark,
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 40,
              vertical: 70,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  text,
                  style: AppStyles.text2(color: context.textColor)
                      .copyWith(color: AppColors.white)
                      .copyWith(
                        fontWeight: FontWeight.w700,
                        fontSize: 28,
                      ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
