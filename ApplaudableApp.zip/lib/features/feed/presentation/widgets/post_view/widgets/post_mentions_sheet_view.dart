import 'package:flutter/material.dart';

import '../../../../../../app_module.dart';
import '../../../../../../core/extensions/app_module_extensions.dart';
import '../../../../../../core/extensions/build_context_extensions.dart';
import '../../../../../../core/theme/colors.dart';
import '../../../../../../core/theme/styles.dart';
import '../../../../../../core/widgets/svg_icons.dart';
import '../../../../../../generated/l10n.dart';
import '../../../../../../ui/page/main/profile_settings/profile.dart';
import '../../../../../auth/presentation/widgets/sheet_views/bottom_sheet_view.dart';
import '../../../../../post/domain/entities/post_entities.dart';
import '../../../../../post/domain/enums/post_enums.dart';
import '../../../../../profile/presentation/pages/profile_page.dart';

class PostMentionsSheetView extends BottomSheetView {
  final List<PostMention> mentions;

  const PostMentionsSheetView({super.key, required this.mentions});

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(
          vertical: 26,
          horizontal: 28,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  translations.mentions,
                  style: AppStyles.text2(color: context.textColor).copyWith(
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                GestureDetector(
                  onTap: context.pop,
                  child: SvgIcons.close(color: AppColors.dark),
                ),
              ],
            ),
            const SizedBox(height: 15),
            ListView.builder(
              shrinkWrap: true,
              itemCount: mentions.length,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () {
                    if (mentions[index].type == PostMentionType.invite) {
                      AppModule.I.notify(
                          context, S.current.mentionTypeInviteNotJoinedYet);
                      return;
                    }
                    context.navigateToNamed(
                      AppProfilePage.routeName,
                      arguments: {
                        "userId": mentions[index].id,
                      },
                    );
                  },
                  child: Text(
                    '@${mentions[index].label}',
                    style: AppStyles.text2(color: AppColors.darkGrey).copyWith(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
