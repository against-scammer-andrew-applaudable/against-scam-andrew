import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shimmer/shimmer.dart';

import '../../../../../../core/controllers/dng_links_controller.dart';
import '../../../../../../core/theme/colors.dart';
import '../../../../../../core/theme/styles.dart';
import '../../../../../../core/widgets/loading/shimmer_placeholder_box.dart';
import '../../../../../../generated/l10n.dart';
import '../../../../../auth/presentation/widgets/sheet_views/bottom_sheet_view.dart';
import '../../../../domain/entities/post_response.dart';

class PostShareView extends BottomSheetView {
  const PostShareView({Key? key, required this.item}) : super(key: key);

  final Post item;

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size.height * 0.20;
    final translations = S.of(context);

    return FutureBuilder<Uri>(
      future: checkForLink(item.id),
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          return GestureDetector(
            onTap: () => onTap(context, snapshot.data!, item),
            child: Container(
              color: Colors.transparent,
              child: SizedBox(
                height: screenSize,
                child: SafeArea(
                  child: Column(
                    children: [
                      SheetHeader(title: translations.share),
                      Text(
                        "${snapshot.data}",
                        style: AppStyles.text1(color: context.textColor),
                      )
                    ],
                  ),
                ),
              ),
            ),
          );
        }

        return Container(
          color: Colors.transparent,
          child: SizedBox(
            height: screenSize,
            child: SafeArea(
              child: Column(
                children: [
                  SheetHeader(
                    title: translations.share,
                  ),
                  Shimmer.fromColors(
                    baseColor: AppColors.darkPeach,
                    highlightColor: AppColors.darkPeach2,
                    child: const ShimmerPlaceholderBox(
                      height: 20,
                      width: 200,
                    ),
                  )
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  /// Can be used for the Share
  Future<Uri> checkForLink(String id) async {
    var generateLink = await DngLinksController.I.generateLink({"id": id});
    debugPrint("LINK: $generateLink");
    return generateLink;
  }

  void onTap(BuildContext context, Uri link, Post item) {
    HapticFeedback.lightImpact();

    final translations = S.of(context);
    Share.share('Check out this applause $link', subject: item.name);
  }
}
