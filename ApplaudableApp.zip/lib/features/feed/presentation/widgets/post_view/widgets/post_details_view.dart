import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:applaudable/features/feed/domain/enums/posts_enum.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../../../../app_module.dart';
import '../../../../../../core/enums/category_icon_enums.dart';
import '../../../../../../core/extensions/app_module_extensions.dart';
import '../../../../../../core/mixins/mentions_mixin.dart';
import '../../../../../../core/theme/colors.dart';
import '../../../../../../core/theme/dimensions.dart';
import '../../../../../../core/theme/styles.dart';
import '../../../../../../core/utils/emoji.dart';
import '../../../../../../core/widgets/app_separator_view.dart';
import '../../../../../../core/widgets/expandable_text.dart';
import '../../../../../../core/widgets/svg_icons.dart';
import '../../../../../../ui/page/main/profile_settings/profile.dart';
import '../../../../../mentions/presentation/controllers/mentions_controller.dart';
import '../../../../../mentions/presentation/widgets/mention_render_object.dart';
import '../../../../../post/domain/entities/post_entities.dart';
import '../../../../../post_categories/domain/entities/post_category.dart';
import '../../../../../profile/presentation/pages/profile_page.dart';
import '../../../../domain/entities/post_response.dart';
import '../../../pages/nupp_page.dart';

class PostDetailsView extends StatelessWidget {
  final Post item;
  final bool enableDetailsAction;
  final String? preloadedNuppId;

  const PostDetailsView({
    Key? key,
    required this.item,
    this.preloadedNuppId,
    this.enableDetailsAction = true,
  }) : super(key: key);

  String get title {
    if (item.type == 'story') return item.title;

    return item.nupp?.name ?? item.user?.name ?? item.owner.name;
  }

  String get text => item.text;

  String? get mediaText => item.firstMedia?.text;

  PostCategory? get category => item.category;

  PostNupp? get nupp => item.nupp;

  List<PostElement>? get elements {
    return item.elements;

    // if (item.type == 'story') return item.elements;

    // return item.elements.isNotEmpty ? item.elements.first.elements : [];
  }

  List<PostMention>? get mentions => item.mentions;

  String get categoryIconSlug {
    final slug = SvgCategoryIcons.defaultIcon.slug;
    if (nupp != null) {
      return nupp!.category?.iconSlug ?? slug;
    }
    if (category != null && category!.iconSlug.isNotEmpty) {
      return category!.iconSlug;
    }
    return slug;
  }

  String get description {
    // if (item.type == 'story') return item.text;

    if (mediaText != null && mediaText == text.trim()) {
      return "";
    }
    return text;
  }

  bool get shouldShowDescriptionDetails {
    if (item.type == 'story') {
      return item.media.isNotEmpty &&
          item.media.first.type != PostMediaTypes.text;
    }

    return text.isNotEmpty &&
        getText(elements, mentions) != mediaText?.normalize;
  }

  bool get showNuppOrPostTitleView {
    if (item.type == 'story') {
      return item.media.isNotEmpty &&
          item.media.first.type != PostMediaTypes.text;
    }

    return title.isNotEmpty;
  }

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: context.feedCardColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          if (showNuppOrPostTitleView) ...[
            const SizedBox(height: AppDimensions.defaultSidePadding),
            GestureDetector(
              onTap: () => onTap(context),
              child: Padding(
                padding: const EdgeInsets.only(
                  left: 19,
                  right: 9,
                ),
                child: Row(
                  children: [
                    if (item.type != 'story') ...[
                      SizedBox(
                        width: 24,
                        height: 24,
                        child: CircleAvatar(
                          backgroundColor: context.backgroundColor,
                          child: SizedBox(
                            child: SvgCategoryIcon.load(categoryIconSlug),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                    ],
                    Expanded(
                      child: Text(
                        title,
                        maxLines: 2,
                        style: AppStyles.header2(color: context.textColor).copyWith(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          decoration: item.user != null ||
                                  (item.nupp != null && item.nupp!.isPublic)
                              ? TextDecoration.underline
                              : null,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            if (!shouldShowDescriptionDetails)
              const SizedBox(height: 15),
            const SizedBox(height: 2),
            if (item.type == 'story')
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 19,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (item.when != null)
                      Text(
                        item.formattedWhenTime,
                        style:
                            AppStyles.text2(color: AppColors.darkGrey).copyWith(
                          fontSize: 14,
                        ),
                      ),
                    if (item.type == 'story' && item.location.isNotEmpty) ...[
                      const SizedBox(height: 15),
                      Row(
                        children: [
                          SvgIcons.location(),
                          const SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              item.location,
                              style: AppStyles.text2(
                                color: AppColors.darkGrey,
                              ).copyWith(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                    const SizedBox(height: 15),
                  ],
                ),
              ),
          ],
          if (shouldShowDescriptionDetails)
            Padding(
              padding: const EdgeInsets.only(left: 21, right: 9),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const AppSeparatorView.pink(),
                  const SizedBox(height: 10),
                  ExpandablePostText(
                    text: description,
                    style: AppStyles.text2(color: context.captionTextColor),
                    elements: elements,
                    mentions: mentions,
                    enableMentionsAction: enableDetailsAction,
                    preloadedNuppId: preloadedNuppId,
                  ),
                ],
              ),
            ),
          if (shouldShowDescriptionDetails)
            const SizedBox(height: 20),
        ],
      ),
    );
  }

  void onTap(BuildContext context) {
    if (item.user != null) {
      HapticFeedback.lightImpact();

      context.navigateToNamed(
        AppProfilePage.routeName,
        arguments: {
          "userId": item.user!.id,
        },
      );
    } else if (item.nupp != null && item.nupp!.isPublic) {
      if (enableDetailsAction) {
        AppModule.I.navigateToNamed(
          NuppPage.routeName,
          arguments: NuppPageArgs(
            nuppId: item.nupp!.id,
            nuppName: item.nupp!.name,
          ),
        );
      } else {
        AppModule.I.pop();
      }
    }
  }

  String getText(elements, mentions) {
    return MentionRenderObject(elements: elements, mentions: mentions)
        .renderOnlyText(
            style: AppStyles.text2(color: AppColors.darkGrey),
            emoji: EmojiHandler())
        .normalize;
  }
}

class ExpandablePostText extends ExpandableText {
  final List<PostElement>? elements;
  final List<PostMention>? mentions;
  final bool enableMentionsAction;
  final String? preloadedNuppId;

  const ExpandablePostText({
    super.key,
    required super.text,
    super.maxLines = 2,
    super.style,
    super.enableGestureRecognizer = true,
    this.elements,
    this.mentions,
    this.enableMentionsAction = true,
    this.preloadedNuppId,
  });

  @override
  State<ExpandableText> createState() => ExpandablePostTextState();
}

class ExpandablePostTextState extends ExpandableTextState<ExpandablePostText>
    with MentionsMixin {
  @override
  buildInlineSpan(
    ExpandablePostText widget,
    String text, {
    TextStyle? style,
    EmojiHandler? emoji,
  }) {
    final String renderText = MentionRenderObject(
            elements: widget.elements, mentions: widget.mentions)
        .renderOnlyText(style: style, emoji: emoji);

    return super.buildInlineSpan(widget, renderText, style: style);
  }

  @override
  buildSpanChildren(
    ExpandablePostText widget,
    String text, {
    TextStyle? style,
    EmojiHandler? emoji,
  }) {
    final List<InlineSpan>? list = MentionRenderObject(
            elements: widget.elements, mentions: widget.mentions)
        .renderSpans(style: style, emoji: emoji);

    return TextSpan(style: style, children: list);
  }
}
