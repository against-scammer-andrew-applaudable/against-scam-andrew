import 'package:flutter/material.dart';

import '../../../../../../core/widgets/buttons/animated_button/app_animated_button.dart';
import '../../../../../auth/presentation/callbacks.dart';
import '../../../../../post/presentation/blocs/post_bloc.dart';
import '../../../../domain/entities/post_response.dart';
import '../../../../domain/usecases/execute_post_action.dart';

/// ----
/// Widget views

/// [PostBookmarkView] used for the Feed Post widget applaud handler
class PostBookmarkView extends AppAnimatedButton {
  const PostBookmarkView(
      {Key? key, required String id, required this.iconInput, required this.selectedIconInput, OnTapCallback<bool>? onTap, bool? status})
      : super(key: key, id: id, onTap: onTap, status: status);

  final Widget iconInput;
  final Widget selectedIconInput;

  @override
  Widget get icon => iconInput;

  @override
  Widget get selectedIcon => selectedIconInput;

  @override
  bool resolveWhen(state) =>
      state is SetPostActionUpdatedState &&
      state.id == id &&
      (state.action == PostActions.bookmark ||
          state.action == PostActions.removeBookmark);

  @override
  State createState() => _PostBookmarkViewState();
}

class _PostBookmarkViewState
    extends AppAnimatedButtonStreamState<Post, PostBloc, PostState> {
  @override
  bool get requestState => true;

  @override
  bool resolveStateFromItem(Post? item) =>
      item?.engagement?.bookmarked ?? false;

  @override
  bool resolveOnState(PostState state) => state is SetPostActionUpdatedState;

  @override
  Post? item(PostState state) => (state as SetPostActionUpdatedState).model;

  @override
  setModel(String id) {
    bloc.add(SetPostActionEvent(
      id: id,
      action: PostActions.bookmark,
    ));
  }

  @override
  getModel(String id) {}

  @override
  unSetModel(String id) {
    bloc.add(SetPostActionEvent(
      id: id,
      action: PostActions.removeBookmark,
    ));
  }
}
