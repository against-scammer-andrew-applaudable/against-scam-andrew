import 'dart:async';

import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';

import '../../../../../app_module.dart';
import '../../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../../core/theme/colors.dart';
import '../../../../../core/theme/dimensions.dart';
import '../../../../../core/theme/styles.dart';
import '../../../../../core/utils/datetime_ago.dart';
import '../../../../../core/widgets/svg_icons.dart';
import '../../../../../generated/l10n.dart';
import '../../../../../ui/page/main/profile_settings/profile.dart';
import '../../../../auth/presentation/callbacks.dart';
import '../../../../auth/presentation/widgets/sheet_views/bottom_sheet_view.dart';
import '../../../../post/presentation/blocs/post_bloc.dart';
import '../../../../profile/presentation/pages/profile_page.dart';
import '../../../data/models/posts_response_model.dart';
import '../../../domain/entities/post_response.dart';
import '../../../domain/usecases/execute_post_action.dart';
import '../animated_applaud_icon.dart';
import 'widgets/post_details_view.dart';
import 'widgets/post_header_view.dart';
import 'widgets/post_media_view.dart';
import 'widgets/post_mentions_sheet_view.dart';
import 'widgets/post_reactions_view.dart';
import 'widgets/story_post_media_view.dart';

class PostView extends StatelessWidget {
  final OnTapCallback<Post> onTap;
  final OnTapCallback3<PostActions, Post> onTapReaction;
  final int index;
  final OnStatusIndexedCallback<BuildContext>? onStatusCallback;
  final Post item;
  final String currentSessionUserId;
  final bool enableHighlights;
  final String? preloadMedia;
  final bool isVisible;
  final bool enableDetailsAction;
  final String? preloadedNuppId;
  final bool isFromPostDetails;

  const PostView({
    super.key,
    required this.index,
    required this.onTap,
    required this.onTapReaction,
    required this.item,
    required this.currentSessionUserId,
    this.onStatusCallback,
    this.enableHighlights = true,
    this.preloadMedia,
    this.isVisible = false,
    this.enableDetailsAction = true,
    this.preloadedNuppId,
    this.isFromPostDetails = false,
  });

  /// Validates if this Post belongs to the current session user
  bool get isCurrentSessionUserThePostOwner =>
      item.owner.id == currentSessionUserId;

  bool get enableHighlightsAction {
    if (!AppModule.I.enablePostHighlights) {
      return false;
    }
    if (isCurrentSessionUserThePostOwner) {
      return true;
    }

    if (enableHighlights && (item.hasHighlights ?? false)) {
      return true;
    }

    if (enableHighlights && item.type == "highlight") {
      return true;
    }

    return false;
  }

  @override
  Widget build(BuildContext context) {
    if (onStatusCallback != null) {
      onStatusCallback!(context, index);
    }

    final translations = S.of(context);

    return InkWell(
      onTap: () => onTap(item),
      onDoubleTap: () {
        onTapReaction(PostActions.applaud, item, index);
      },
      child: Container(
        color: /*isVisible ? Colors.green.shade50 :*/ context.scaffoldBackgroundColor,
        //height: 770,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            /// Top section of the post that contains:
            /// * User Profile,
            /// * DateTimeAgo Label,
            /// * Post Ranking,
            /// ** More actions menu
            PostHeaderView(
              id: item.id,
              owner: item.owner,
              ranking: item.ranking,
              label: getTimeAgo(item.createdAt),
              isCurrentSessionUserThePostOwner:
                  isCurrentSessionUserThePostOwner,
            ),

            /// Post Image handler
            /// TODO: handle media
            Stack(
              children: [
                Hero(
                  tag: "post_id_${item.id}",
                  child: item.type == 'story'
                      ? StoryPostMediaView(
                          post: item,
                          index: index,
                          preloadMedia: preloadMedia,
                          isFromPostDetails: isFromPostDetails,
                        )
                      : PostMediaView(
                          index: index,
                          item: item,
                          preloadMedia: preloadMedia,
                        ),
                ),
                if (item.type == 'story')
                  Positioned(
                    right: 20,
                    left: 20,
                    bottom: 20,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        (item.mentions ?? []).isNotEmpty
                            ? GestureDetector(
                                onTap: () => _openMentionsBottomSheet(context),
                                child: CircleAvatar(
                                  radius: AppDimensions.radius_15,
                                  backgroundColor: AppColors.darkGrey,
                                  child: SvgIcons.mention(),
                                ),
                              )
                            : const SizedBox(),
                        GestureDetector(
                          onTap: () => _openUeserLifeStory(context),
                          child: Container(
                            decoration: BoxDecoration(
                              color: AppColors.primaryColor,
                              borderRadius: BorderRadius.circular(
                                AppDimensions.radius_7,
                              ),
                            ),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 5,
                            ),
                            child: Text(
                              translations.life_story,
                              style: AppStyles.text2(color: AppColors.white)
                                  .copyWith(
                                fontSize: 13,
                                height: 1,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                DNGBlocBuilder<PostBloc, PostState>(
                  buildWhen: (state) =>
                      state is SetPostActionDoAnimationOnApplaudState,
                  builder: (BuildContext context, PostState state) {
                    if (state is SetPostActionDoAnimationOnApplaudState &&
                        !state.stateHandled &&
                        state.model != null &&
                        item.id == state.model!.id &&
                        state.action == PostActions.applaud) {
                      return Positioned(
                        key: UniqueKey(),
                        top: 0,
                        bottom: 0,
                        left: 0,
                        right: 0,
                        child: Center(
                          child: AnimatedApplaudIcon(
                            onAnimationCompleted: () {
                              state.stateHandled = true;
                            },
                          ),
                        ),
                      );
                    }

                    return const SizedBox();
                  },
                ),
              ],
            ),
            /*Stack(
              children: [
                Container(
                  color: Colors.amber,
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.width,
                ),
                PostViewTimer(
                    key: Key("post_id_${item.id}_$isVisible"),
                    isVisible: isVisible)
              ],
            ),*/

            /// Post Counters
            // PostCountersView(
            //   applauds: item.counters?.applauds ?? 0,
            //   shares: item.counters?.shares ?? 0,
            //   influences: item.counters?.influences ?? 0,
            // ),

            PostReactionsView(
              key: Key(item.id),
              id: item.id,
              engagement: item.engagement,
              enableHighlights: enableHighlightsAction && item.type != 'story',
              counters: item.counters ?? const PostCountersModel(),
              onTap: (action) => onTapReaction(action, item, index),
            ),

            const SizedBox(height: 1),

            /// Post Reactions - alternative UI for:
            ///
            ///  ** doing the Applaud
            ///  ** show applauds counter
            ///  ** doing bookmark
            /*PostReactionsSimpleView(
                key: Key(item.id),
                id: item.id,
                engagement: item.engagement,
                enableHighlights:
                    enableHighlights */ /*? (item.hasHighlights ?? false) : false*/ /*,
                applauds: item.counters?.applauds ?? 0,
                onTap: (action) => onTapReaction(action, item, index)),*/

            /// Post Title and Description
            PostDetailsView(
              item: item,
              enableDetailsAction: enableDetailsAction,
              preloadedNuppId: preloadedNuppId,
            ),
            const SizedBox(height: 15),
          ],
        ),
      ),
    );
  }

  void _openUeserLifeStory(BuildContext context) {
    context.navigateToNamed(
      AppProfilePage.routeName,
      arguments: {
        "userId": item.owner.id,
      },
    );
  }

  void _openMentionsBottomSheet(BuildContext context) async {
    await BottomSheetView.show<String>(
      context: context,
      corner: const BorderRadius.only(
        topLeft: Radius.circular(AppDimensions.radius_24),
        topRight: Radius.circular(AppDimensions.radius_24),
      ),
      sheet: PostMentionsSheetView(mentions: item.mentions ?? []),
    );
  }
}

class PostViewTimer extends StatefulWidget {
  final bool isVisible;

  const PostViewTimer({
    Key? key,
    this.isVisible = false,
  }) : super(key: key);

  @override
  State<PostViewTimer> createState() => _PostViewTimerState();
}

class _PostViewTimerState extends State<PostViewTimer> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();

    if (widget.isVisible) {
      _timer?.cancel();
      create(widget.isVisible);
    }
  }

  @override
  Widget build(BuildContext context) {
    create(widget.isVisible);
    return Positioned(
      bottom: 0,
      child: Container(
        color: Colors.white,
        padding: const EdgeInsets.all(8),
        child: Text("${_timer?.tick}"),
      ),
    );
  }

  create(bool isVisible) {
    if (_timer != null && _timer!.isActive) {
      if (!isVisible) {
        _timer?.cancel();
      }
      return;
    }

    if (!isVisible) {
      return;
    }

    _timer = Timer.periodic(const Duration(milliseconds: 1), onTime);
  }

  onTime(timer) {
    setState(() {});
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}
