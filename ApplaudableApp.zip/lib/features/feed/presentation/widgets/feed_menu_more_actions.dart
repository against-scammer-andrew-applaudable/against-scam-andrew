import 'dart:io';

import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../../core/theme/styles.dart';
import '../../../../core/widgets/svg_icons.dart';
import '../../../../generated/l10n.dart';
import '../../../auth/presentation/callbacks.dart';

/// This is the type used by the popup menu below.
enum FeedMenuMoreActions { delete, flag }

class FeedMenuMoreAction extends StatelessWidget {
  const FeedMenuMoreAction({
    Key? key,
    required this.onTap,
    this.isCurrentSessionUserThePostOwner = false,
  }) : super(key: key);

  final OnTapCallback<FeedMenuMoreActions> onTap;
  final bool isCurrentSessionUserThePostOwner;

  List<PopupMenuEntry<FeedMenuMoreActions>> get androidMoreOptions {
    if (isCurrentSessionUserThePostOwner) {
      return [
        PopupMenuItem<FeedMenuMoreActions>(
          value: FeedMenuMoreActions.delete,
          child: Text(S.current.delete),
        ),
        /*const PopupMenuItem<FeedMenuMoreActions>(
          value: FeedMenuMoreActions.flag,
          child: Text("flag"),
        ),*/
      ];
    }
    return [
      PopupMenuItem<FeedMenuMoreActions>(
        value: FeedMenuMoreActions.flag,
        child: Text(S.current.flag),
      ),
    ];
  }

  List<CupertinoActionSheetAction> iOSMoreOptions(BuildContext context) {
    var list = [
      CupertinoActionSheetAction(
        onPressed: () {
          Navigator.pop(context, FeedMenuMoreActions.flag);
        },
        child: Text(
          S.current.flag,
          style: AppStyles.buttons(color: context.textColor),
        ),
      ),
    ];

    if (isCurrentSessionUserThePostOwner) {
      list
        ..clear()
        ..add(CupertinoActionSheetAction(
          /// This parameter indicates the action would perform
          /// a destructive action such as delete or exit and turns
          /// the action's text color to red.
          isDestructiveAction: true,
          onPressed: () {
            Navigator.pop(context, FeedMenuMoreActions.delete);
          },
          child: Text(S.current.delete),
        ));
    }

    return list;
  }

  @override
  Widget build(BuildContext context) {
    if (Platform.isIOS) {
      return IconButton(
        padding: EdgeInsets.zero,
        onPressed: () async {
          var result = await _showActionSheet(context);
          if (result != null) onTap(result);
        },
        icon: SvgFeedIcons.moreOptions(color: context.textColor),
      );
    }

    return PopupMenuButton<FeedMenuMoreActions>(
      onSelected: onTap,
      icon: SvgFeedIcons.moreOptions(color: context.textColor),
      padding: EdgeInsets.zero,
      itemBuilder: (BuildContext context) => androidMoreOptions,
    );
  }

  Future<FeedMenuMoreActions?> _showActionSheet(BuildContext context) async {
    final translations = S.of(context);

    return showCupertinoModalPopup<FeedMenuMoreActions>(
      context: context,
      builder: (BuildContext context) => CupertinoActionSheet(
        title: Text(translations.post_actions),
        actions: iOSMoreOptions(context),
      ),
    );
  }
}
