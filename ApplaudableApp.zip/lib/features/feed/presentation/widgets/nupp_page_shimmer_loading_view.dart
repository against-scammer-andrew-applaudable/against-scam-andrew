import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

import '../../../../core/widgets/items/item_image.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/theme/styles.dart';
import '../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../../../profile/presentation/widgets/collection_posts_loading_view.dart';

class NuppPageShimmerLoadingView extends StatelessWidget {
  final String? nuppName;

  const NuppPageShimmerLoadingView({super.key, this.nuppName});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Shimmer.fromColors(
          baseColor: AppColors.darkPeach2,
          highlightColor: AppColors.darkPeach,
          child: AppSideMargins(
            marginValue: 25,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: AppDimensions.defaultSidePadding),
                const Center(child: ItemImage.profile(source: '', size: 120)),
                const SizedBox(height: AppDimensions.defaultSidePadding),
                Text(
                  nuppName != null && nuppName!.trim().isNotEmpty
                      ? nuppName!
                      : '≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈',
                  textAlign: TextAlign.center,
                  style:
                      AppStyles.text1(color: context.textColor).copyWith(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: AppDimensions.mediumSidePadding),
                Text(
                  '≈≈≈≈≈≈≈≈≈ ≈≈≈≈≈≈≈≈≈≈≈≈ ≈≈≈≈≈≈≈≈≈',
                  textAlign: TextAlign.center,
                  style: AppStyles.text1(color: AppColors.mediumGrey)
                      .copyWith(fontSize: 14),
                ),
                const SizedBox(height: AppDimensions.mediumSidePadding),
                Text(
                  '≈≈≈≈≈≈≈≈≈≈ ≈≈≈≈≈≈≈≈≈ ≈≈≈≈≈≈ ≈≈≈≈≈≈≈≈ ≈≈≈≈≈≈≈ ≈≈≈≈≈≈≈≈≈ ≈≈≈≈≈≈≈≈ ≈≈≈≈≈≈≈≈≈',
                  textAlign: TextAlign.center,
                  style: AppStyles.text2(color: context.textColor).copyWith(fontSize: 15, height: 1.3),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: AppDimensions.defaultSidePadding),
        const FeedsGridShimmerLoadingView(
          shrinkWrap: true,
          physics: NeverScrollableScrollPhysics(),
        ),
      ],
    );
  }
}
