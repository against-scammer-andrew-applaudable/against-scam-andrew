import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

import '../../../../core/theme/colors.dart';
import '../../../../core/widgets/media_avatar_placeholder.dart';

class SearchResultItemShimmerLoadingView extends StatelessWidget {
  const SearchResultItemShimmerLoadingView({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: 35,
      ),
      child: Shimmer.fromColors(
        baseColor: AppColors.darkPeach2,
        highlightColor: AppColors.peach,
        child: const Row(
          children: [
            CircleAvatar(
              backgroundColor: AppColors.transparent,
              child: MediaAvatarPlaceholder(
                iconHeight: 22,
              ),
            ),
            SizedBox(width: 12),
            Flexible(child: Text('≈≈≈≈≈≈ ≈≈≈≈≈≈≈')),
          ],
        ),
      ),
    );
  }
}
