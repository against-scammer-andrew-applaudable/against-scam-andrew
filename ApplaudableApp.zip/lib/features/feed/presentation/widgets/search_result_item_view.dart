import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';

import '../../../../core/theme/colors.dart';
import '../../../../core/theme/styles.dart';
import '../../../../core/widgets/optimized_cached_network_image.dart';
import '../../../../core/widgets/svg_icons.dart';
import '../../../../ui/page/main/profile_settings/profile.dart';
import '../../../profile/presentation/pages/profile_page.dart';
import '../../domain/entities/search_result.dart';
import '../../domain/enums/search_item_type.dart';
import '../pages/nupp_page.dart';

class SearchResultItemView extends StatelessWidget {
  final SearchResult searchItem;

  const SearchResultItemView({super.key, required this.searchItem});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        switch (searchItem.type) {
          case SearchItemType.nupp:
            context.navigateToNamed(
              NuppPage.routeName,
              arguments: NuppPageArgs(
                nuppId: searchItem.id,
                nuppName: searchItem.value,
              ),
            );
            break;
          case SearchItemType.user:
            context.navigateToNamed(
              AppProfilePage.routeName,
              arguments: {
                "userId": searchItem.id,
              },
            );
            break;
        }
      },
      child: Container(
        color: Colors.transparent,
        padding: const EdgeInsets.symmetric(
          horizontal: 35,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Flexible(
              child: Row(
                children: [
                  CircleAvatar(
                    backgroundColor: Colors.transparent,
                    radius: 20,
                    child: OptimizedCachedNetworkImage(
                      imageUrl: searchItem.photo,
                      height: 40,
                      width: 40,
                      radius: BorderRadius.circular(40),
                      fit: BoxFit.cover,
                      placeholderBackgroundColor: AppColors.peach,
                      defaultProgressIconHeight: 22,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Flexible(
                    child: Text(
                      searchItem.value,
                      style: AppStyles.text2(
                        color: searchItem.isNupp
                            ? context.textColor
                            : context.hintTextColor,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (searchItem.isNupp) SvgIcons.star(),
          ],
        ),
      ),
    );
  }
}
