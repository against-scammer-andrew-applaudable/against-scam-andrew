import 'package:flutter/material.dart';

import '../../../../core/theme/colors.dart';
import '../../../../core/widgets/svg_icons.dart';

class AnimatedApplaudIcon extends StatefulWidget {
  final bool isAnimating;
  final Duration? duration;
  final Function()? onAnimationCompleted;

  const AnimatedApplaudIcon(
      {super.key,
      this.isAnimating = true,
      this.onAnimationCompleted,
      this.duration});

  @override
  State<AnimatedApplaudIcon> createState() {
    return _AnimatedApplaudIconState();
  }
}

class _AnimatedApplaudIconState extends State<AnimatedApplaudIcon>
    with SingleTickerProviderStateMixin {
  late final Animation<double> _animation;
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: (widget.duration ?? const Duration(milliseconds: 400)) ~/ 2,
      vsync: this,
    );

    _animation = Tween(begin: 0.0, end: 1.2).animate(
      CurvedAnimation(
          parent: _controller, curve: Curves.easeInOutCubicEmphasized),
    );

    _controller.addStatusListener(_onAnimationStatusChanged);

    if (widget.isAnimating) {
      doAnimation();
    }
  }

  void _onAnimationStatusChanged(AnimationStatus status) {
    if (status == AnimationStatus.completed) {
      Future.delayed(const Duration(milliseconds: 200), () async {
        if (mounted) {
          if (widget.onAnimationCompleted != null)
            widget.onAnimationCompleted!();
          await _controller.reverse();
          _controller.reset();
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, snapshot) {
        // if (_controller.isCompleted) return Container();

        return ScaleTransition(
          scale: _animation,
          child: FadeTransition(
            opacity: _animation,
            child: SvgIcons.applaudRatingFilled(
              height: 90,
              color: AppColors.white,
            ),
          ),
        );
      },
    );
  }

  @override
  void didUpdateWidget(covariant AnimatedApplaudIcon oldWidget) {
    super.didUpdateWidget(oldWidget);
  }

  void doAnimation() async {
    if (!_controller.isAnimating) {
      await _controller.forward();
    }
  }

  @override
  void dispose() {
    _controller.removeStatusListener(_onAnimationStatusChanged);
    _controller.dispose();

    super.dispose();
  }
}
