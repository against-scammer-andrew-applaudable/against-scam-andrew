import 'package:dismissible_page/dismissible_page.dart';
import 'package:flutter/material.dart';

import '../../../../core/bloc/widgets/base_stateless_page.dart';
import '../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../core/extensions/build_context_extensions.dart';
import '../../../../core/utils/app_utils.dart';
import '../../../../core/widgets/app_scroller_view.dart';
import '../../../../core/widgets/loading/sliver_shimmer.dart';
import '../../../../model/post/feed.dart';
import '../../../../ui/page/main/feed/sub/preview.dart';
import '../../../post/presentation/pages/post_page.dart';
import '../../domain/entities/post_response.dart';
import '../../domain/enums/posts_enum.dart';
import '../blocs/feed_bloc/feed_bloc.dart';
import 'post_view/widgets/post_media_view.dart';

// ignore: must_be_immutable
class BookmarksFeedGridView
    extends BaseStatelessPage<BookmarksFeedGridBloc, FeedState> {
  final String? userId;
  final PostsFilterByType type;
  final bool shrinkWrap;
  final ScrollController? scrollController;
  final bool isFullPage;

  BookmarksFeedGridView({
    super.key,
    this.userId,
    this.type = PostsFilterByType.suggested,
    this.shrinkWrap = false,
    this.scrollController,
    this.isFullPage = false,
  });

  @override
  Widget build(BuildContext context) {
    registerBloc(context);

    return AppScrollerView(
      enableOnScrollVisibleItemsNotifier: false,
      shrinkWrap: shrinkWrap,
      scrollController: scrollController,
      paginationThreshold: 159 * 5,
      onPaginate: _onPaginate,
      slivers: [
        DNGBlocBuilder<BookmarksFeedGridBloc, FeedState>(
          buildWhen: (state) =>
              state.isBookmarks &&
              (state is GetPostsResultFetchedState ||
                  state is GetPostsLoadingState ||
                  state is GetPostsEmptyState),
          builder: (BuildContext context, FeedState state) {
            if (bloc.currentPageNo == 1 && state is GetPostsLoadingState) {
              return const SliverShimmer.grid();
            } else if (state is GetPostsEmptyState) {
              return SliverToBoxAdapter(
                child: SizedBox(
                  height: isFullPage
                      ? context.screenHeight -
                          context.paddingTop -
                          context.paddingBottom -
                          56
                      : 200,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [Text(translations.no_posts)],
                  ),
                ),
              );
            } else if (state is GetPostsResultFetchedState) {
              return SliverGridPosts(items: bloc.collection.items);
            }

            _refreshUserPosts(context);

            return const SliverToBoxAdapter(
              child: SizedBox(width: 0, height: 0),
            );
          },
        ),
        const SliverToBoxAdapter(
          child: SizedBox(height: 50),
        ),
      ],
    );
  }

  void _refreshUserPosts(BuildContext context) {
    Future(() {
      bloc
        ..resetPagination()
        ..collection.clearItems()
        ..add(GetPostsEvent(type: type));
    });
  }

  /// Handle pagination callback
  /// this will be fired on scrolling the feed
  void _onPaginate() {
    bloc.add(GetPostsEvent(type: type));
  }
}

class SliverGridPosts extends StatelessWidget {
  final List<Post> items;

  const SliverGridPosts({super.key, required this.items});

  @override
  Widget build(BuildContext context) {
    return SliverGrid(
      delegate: SliverChildBuilderDelegate(
        (BuildContext context, int index) {
          Post item = items[index];

          return Hero(
            tag: item,
            child: PostMediaView(
              index: index,
              item: item,
              height: 159,
              width: (MediaQuery.of(context).size.width / 3) - 4,
              isGridItem: true,
              onTap: () async {
                // context.navigateToNamed(PostPage.routeName,
                //     arguments: PostPageArgs(post: item));
                if (item.originalDic != null) {
                  await (AppUtils().tabContext ?? context).pushTransparentRoute(PostPreviewPage(post: FeedPostModel.dic(item.originalDic ?? {})));
                }
              },
            ),
          );
        },
        childCount: items.length, // 1000 list items
      ),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        childAspectRatio: 0.7,
        crossAxisSpacing: 2,
        mainAxisSpacing: 2,
      ),
    );
  }
}
