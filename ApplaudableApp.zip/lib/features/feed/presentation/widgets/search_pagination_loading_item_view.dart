import 'package:flutter/material.dart';

import '../../../../core/bloc/widgets/base_stateless_page.dart';
import '../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/widgets/toast/app_toast.dart';
import '../blocs/search_bloc/search_bloc.dart';
import 'search_result_shimmer_loading_item_view.dart';

// ignore: must_be_immutable
class SearchPaginationLoadingItemView
    extends BaseStatelessPage<SearchBloc, SearchState> {
  SearchPaginationLoadingItemView({super.key});

  @override
  Widget build(BuildContext context) {
    registerBloc(context);

    return DNGBlocBuilder<SearchBloc, SearchState>(
      bloc: bloc,
      builder: (context, state) {
        if (state is SearchPaginationLoadingState) {
          return const Column(
            children: [
              Padding(
                padding: EdgeInsets.symmetric(
                  horizontal: 35,
                ),
                child: Divider(
                  color: AppColors.lightGrey,
                  height: 25,
                ),
              ),
              SearchResultItemShimmerLoadingView(),
            ],
          );
        }

        return Container();
      },
    );
  }

  @override
  Stream<SearchState>? get onStateListener => bloc.stream;

  @override
  void onStateResultListener(BuildContext context, SearchState state) {
    if (state is SearchPaginationErrorState) {
      AppToast().build(context, state.message, mode: AppToastMode.error);
    }
  }
}
