import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

import '../../../../core/extensions/build_context_extensions.dart';
import '../../../../core/widgets/loading/shimmer_placeholder_box.dart';
import '../../../../core/widgets/media_avatar_placeholder.dart';
import '../../../../core/widgets/svg_icons.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../../../core/theme/styles.dart';

class PostFeedsShimmerLoadingView extends StatelessWidget {
  const PostFeedsShimmerLoadingView({super.key});

  @override
  Widget build(BuildContext context) {
    return SliverList(
      delegate: SliverChildBuilderDelegate(
        childCount: 3,
        (ctx, index) => const PostItemShimmerLoadingView(),
      ),
    );
  }
}

class PostItemShimmerLoadingView extends StatelessWidget {
  const PostItemShimmerLoadingView({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        ShimmerPlaceholderBox(
          height: 60,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(20),
            topRight: Radius.circular(20),
          ),
          color: context.backgroundColor,
          child: Shimmer.fromColors(
            baseColor: context.hintTextColor,
            highlightColor: context.backgroundColor,
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: AppDimensions.largeSidePadding,
              ),
              child: Row(
                children: [
                  const MediaAvatarPlaceholder(
                    iconHeight: 28,
                    backgroundColor: AppColors.transparent,
                  ),
                  const SizedBox(
                    width: AppDimensions.smallSidePadding,
                  ),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Text(
                          '≈≈≈≈≈≈≈ ≈≈≈≈≈≈≈≈',
                          style: AppStyles.text2(color: context.textColor).copyWith(height: 0.9),
                        ),
                        Text(
                          '≈≈≈≈≈≈≈',
                          style: AppStyles.text2(color: context.textColor).copyWith(height: 0.9),
                        ),
                      ],
                    ),
                  ),
                  SvgIcons.applaudRatingFilled(height: 20),
                  const SizedBox(width: 5),
                  SvgIcons.applaudRatingFilled(height: 20),
                  const SizedBox(width: 5),
                  SvgIcons.applaudRatingFilled(height: 20),
                ],
              ),
            ),
          ),
        ),
        SizedBox(
          height: context.screenWidth,
          child: const MediaAvatarPlaceholder(
            shape: BoxShape.rectangle,
            isLoading: true,
          ),
        ),
        ShimmerPlaceholderBox(
          height: 50,
          borderRadius: BorderRadius.zero,
          color: context.backgroundColor,
          child: Shimmer.fromColors(
            baseColor: context.hintTextColor,
            highlightColor: context.backgroundColor,
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                /*const PostBookmarkView(id: ''),
                Row(
                  children: [
                    Text(
                      "0 Applauds",
                      style: AppStyles.text2(color: AppColors.darkGrey),
                    ),
                    const SizedBox(width: 17),
                    const PostApplaudView(id: ''),
                  ],
                ),*/
              ],
            ),
          ),
        ),
        Shimmer.fromColors(
          baseColor: context.hintTextColor,
          highlightColor: context.backgroundColor,
          child: Padding(
            padding: const EdgeInsets.all(AppDimensions.defaultSidePadding),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    SvgIcons.applaudRatingFilled(height: 20),
                    const SizedBox(width: AppDimensions.smallSidePadding),
                    Text('≈≈≈≈≈≈≈≈≈≈', style: AppStyles.header1(color: context.textColor)),
                  ],
                ),
                const SizedBox(height: 20),
                const ShimmerPlaceholderBox(width: 20, height: 2.5),
              ],
            ),
          ),
        ),
        const SizedBox(height: 40),
      ],
    );
  }
}
