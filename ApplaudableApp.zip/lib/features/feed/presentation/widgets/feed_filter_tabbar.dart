import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';

import '../../../../core/theme/colors.dart';
import '../../../../core/theme/styles.dart';
import '../../../auth/presentation/callbacks.dart';
import '../../domain/enums/posts_enum.dart';

class FeedFilterTabBar extends StatefulWidget {
  const FeedFilterTabBar({Key? key, this.filterByType, this.onTap, this.onInit})
      : super(key: key);

  final PostsFilterByType? filterByType;
  final OnTapCallback<PostsFilterByType>? onTap;
  final OnTapCallback<TabController>? onInit;

  @override
  State<FeedFilterTabBar> createState() => _FeedFilterTabBarState();
}

class _FeedFilterTabBarState extends State<FeedFilterTabBar>
    with SingleTickerProviderStateMixin {
  List<PostsFilterByType> get filters =>
      [PostsFilterByType.suggested, PostsFilterByType.following];

  late final _tabController = TabController(
    initialIndex: widget.filterByType != null &&
            filters.contains(widget.filterByType)
        ? filters
            .indexWhere((element) => element.name == widget.filterByType?.name)
        : 0,
    length: filters.length,
    vsync: this,
  );

  @override
  void initState() {
    super.initState();

    if (widget.onInit != null) {
      widget.onInit!(_tabController);
    }
  }

  @override
  Widget build(BuildContext context) {
    return TabBar(
      controller: _tabController,
      indicatorColor: context.textColor,
      indicatorSize: TabBarIndicatorSize.label,
      labelPadding: const EdgeInsets.symmetric(horizontal: 24),
      labelStyle: AppStyles.header3(color: context.textColor),
      unselectedLabelStyle: AppStyles.header3(
        color: AppColors.mediumGrey.shade90,
      ),
      dividerColor: AppColors.transparent,
      indicatorWeight: 1.5,
      isScrollable: true,
      labelColor: context.textColor                          ,
      unselectedLabelColor: AppColors.mediumGrey,
      tabs: filters
          .map((e) => Tab(
                text: e.name.replaceFirst(e.name[0], e.name[0].toUpperCase()),
                iconMargin: EdgeInsets.zero,
                height: 22,
              ))
          .toList(),
      onTap: (index) {
        if (widget.onTap != null) {
          widget.onTap!(PostsFilterByType.values[index]);
        }
      },
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }
}
