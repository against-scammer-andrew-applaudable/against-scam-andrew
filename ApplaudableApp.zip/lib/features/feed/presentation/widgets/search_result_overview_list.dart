import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/widgets/app_listview.dart';
import '../blocs/search_bloc/search_bloc.dart';
import 'search_page_shimmer_loading_view.dart';
import 'search_pagination_loading_item_view.dart';
import 'search_result_item_view.dart';

class SearchResultOverviewList extends StatelessWidget {
  final TextEditingController queryController;

  const SearchResultOverviewList({super.key, required this.queryController});

  @override
  Widget build(BuildContext context) {
    return DNGBlocBuilder<SearchBloc, SearchState>(
      buildWhen: (state) =>
          state is SearchLoadingState ||
          state is SearchErrorState ||
          state is SearchResultFetchedState,
      builder: (context, state) {
        if (state is SearchLoadingState) {
          return const SearchPageShimmerLoadingView();
        } else if (state is SearchErrorState) {
          return Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 35,
            ),
            child: Center(
              child: Text(state.message),
            ),
          );
        } else if (state is SearchResultFetchedState) {
          return RefreshIndicator(
            onRefresh: () {
              final bloc = context.read<SearchBloc>();
              bloc.add(
                SearchForNuppsAndUsersEvent(query: queryController.text.trim()),
              );

              return Future.value();
            },
            child: AppListView.separated(
              padding: const EdgeInsets.only(
                top: 25,
                bottom: 60,
              ),
              separatorBuilder: (_, __) => const Padding(
                padding: EdgeInsets.symmetric(
                  horizontal: 35,
                ),
                child: Divider(
                  color: AppColors.lightGrey,
                  height: 30,
                ),
              ),
              allowPaginationHandling: true,
              onPaginate: () => _paginateSearchResult(context),
              itemCount: state.searchResults.length,
              itemBuilder: (context, index) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    SearchResultItemView(
                      searchItem: state.searchResults[index],
                    ),
                    if (index == state.searchResults.length - 1)
                      SearchPaginationLoadingItemView(),
                  ],
                );
              },
            ),
          );
        }

        return Container();
      },
    );
  }

  void _paginateSearchResult(BuildContext context) {
    final bloc = context.read<SearchBloc>();

    bloc.add(
      SearchForNuppsAndUsersEvent(
        query: queryController.text.trim(),
        paginate: true,
      ),
    );
  }
}
