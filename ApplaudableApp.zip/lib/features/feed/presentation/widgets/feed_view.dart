import 'package:applaudable/core/utils/app_utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../app_module.dart';
import '../../../../core/bloc/widgets/base_stateless_page.dart';
import '../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../core/extensions/app_module_extensions.dart';
import '../../../../core/extensions/build_context_extensions.dart';
import '../../../../core/widgets/app_default_error_view.dart';
import '../../../../core/widgets/app_scroller_view.dart';
import '../../../../core/widgets/scrolly/controllers/scrolly_controller.dart';
import '../../../../core/widgets/scrolly/widgets/scrolly_notifier_widget.dart';
import '../../../../generated/l10n.dart';
import '../../../post/presentation/blocs/post_bloc.dart';
import '../../../post/presentation/utils/post_bloc_utils.dart';
import '../../../post_categories/presentation/pages/feed_filters_page.dart';
import '../../../post_highlights/presentation/pages/post_highlights_page.dart';
import '../../domain/entities/post_response.dart';
import '../../domain/enums/posts_enum.dart';
import '../../domain/usecases/execute_post_action.dart';
import '../blocs/feed_bloc/feed_bloc.dart';
import '../providers/feed_filters_controller.dart';
import 'feed_bar.dart';
import 'feed_filter_tabbar.dart';
import 'post_feeds_shimmer_loading_view.dart';
import 'post_view/post_view.dart';

// @Deprecated("Not use, to be removed! Use [FeedView2] class instead")
// class FeedView extends BasePage {
//   const FeedView({super.key});
//
//   static update(BuildContext context) {
//     context.read<FeedBloc>().getInitialPostsPage();
//   }
//
//   @override
//   State<FeedView> createState() => _FeedViewState();
// }
//
// class _FeedViewState extends BaseStatefulState<FeedView, FeedBloc, FeedState> {
//   FeedFiltersController get filtersController =>
//       context.read<FeedFiltersController>();
//
//   @override
//   void initBloc(FeedBloc bloc) {
//     _getPosts();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     final translations = S.of(context);
//
//     return AppScrollerView(
//       enableOnScrollVisibleItemsNotifier: false,
//       onPaginate: _onPaginate,
//       /*visibleItems: () {},*/
//       slivers: [
//         HomeFeedAppBar(
//           title: FeedFilterTabBar(
//             onTap: _onFeedFilterTap,
//           ),
//           onSettingsTab: () async {
//             await context.navigatorKey?.pushNamed(FeedFiltersPage.routeName,
//                 arguments: bloc.postsFilterByType);
//             bloc.getInitialPostsPage();
//           },
//         ),
//         const SliverPadding(padding: EdgeInsets.only(top: 10)),
//         DNGBlocBuilder<FeedBloc, FeedState>(
//           buildWhen: (state) =>
//               state is GetPostsLoadingState ||
//               state is GetPostsResultFetchedState ||
//               state is GetPostsEmptyState,
//           builder: (BuildContext context, FeedState state) {
//             if (bloc.currentPageNo == 1 && state is GetPostsLoadingState) {
//               return const PostFeedsShimmerLoadingView();
//             }
//
//             if (state is GetPostsEmptyState) {
//               return SliverFillRemaining(
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     if (filtersController.postsFilterByType ==
//                         PostsFilterByType.following)
//                       SizedBox(
//                         width: 100,
//                         height: 100,
//                         child: Text(translations.no_followers),
//                       ),
//                   ],
//                 ),
//               );
//             }
//
//             if (state is GetPostsResultFetchedState) {
//               return SliverListPosts(
//                 bloc: bloc,
//                 items: state.posts,
//               );
//             }
//
//             return const SliverFillRemaining(
//               child: SizedBox(
//                 width: 0,
//                 height: 0,
//               ),
//             );
//           },
//         ),
//       ],
//     );
//   }
//
//   @override
//   void didPopNext() {
//     super.didPopNext();
//     bloc.getCachedPosts();
//   }
//
//   @override
//   Stream<FeedState>? get onStateListener => bloc.stream;
//
//   @override
//   onStateResultListener(FeedState state) {
//     if (state is GetPostsLoadingState) {
//       isRequesting = true;
//     } else if (state is GetPostsResultFetchedState) {
//       isRequesting = false;
//     }
//
//     /*if (state is SetPostActionUpdatedState &&
//         state.action == PostActions.delete) {}*/
//   }
//
//   void _onFeedFilterTap(PostsFilterByType type) {
//     if (filtersController.postsFilterByType == type) {
//       return;
//     }
//     _getPosts(type: type);
//
//     filtersController.postsFilterByType = type;
//   }
//
//   /// Handle pagination callback
//   /// this will be fired on scrolling the feed
//   void _onPaginate() {
//     if (isRequesting) {
//       return;
//     }
//
//     _getPosts();
//   }
//
//   /// Helper to request the Posts
//   /// based on the current pagination page
//   void _getPosts({PostsFilterByType type = PostsFilterByType.suggested}) {
//     if (filtersController.postsFilterByType != type) {
//       bloc.allowNewPaginationRequests = true;
//     }
//
//     if (!bloc.allowNewPaginationRequests) {
//       return;
//     }
//
//     bloc.add(
//         GetPostsEvent(type: type, categories: filtersController.selectedIds));
//   }
// }

// ignore: must_be_immutable
class FeedView2 extends BaseStatelessPage<FeedBloc, FeedState> {
  static update(BuildContext context, {bool animateToTop = true}) {
    context.read<FeedFiltersController>()
      ..clear()
      ..tabController?.animateTo(0);
    context.read<FeedBloc>().getInitialPostsPage(
        type: PostsFilterByType.suggested,
        animateToTop: animateToTop,
        categories: []);
  }

  final ScrollyController controller = const ScrollyController();

  FeedFiltersController filtersController(BuildContext context) =>
      context.read<FeedFiltersController>();

  FeedView2({super.key});

  @override
  bool get listenToInitConnectionChanges => false;

  @override
  void initBloc(BuildContext context, FeedBloc bloc) {
    bloc.add(const GetPostsEvent());
  }

  @override
  Widget build(BuildContext context) {
    registerBloc(context);
    final translations = S.of(context);

    var filters = filtersController(context);

    return AppScrollerView(
      onPaginate: () => _onPaginate(context),
      onRefresh: () => _onRefresh(context),
      slivers: [
        HomeFeedAppBar(
          title: FeedFilterTabBar(
            filterByType: filters.postsFilterByType,
            onTap: (filterType) => _onFeedFilterTap(context, filterType),
            onInit: (tabController) {
              filters.tabController = tabController;
            },
          ),
          onSettingsTab: () async {
            await context.navigatorKey?.pushNamed(FeedFiltersPage.routeName,
                arguments: bloc.postsFilterByType);
            bloc.getInitialPostsPage(categories: filters.selectedIds);
          },
        ),
        const SliverPadding(padding: EdgeInsets.only(top: 10)),
        DNGBlocBuilder<FeedBloc, FeedState>(
          buildWhen: (state) =>
              state is GetPostsLoadingState ||
              state is FeedErrorState ||
              state is GetPostsResultFetchedState ||
              state is GetPostsEmptyState,
          builder: (BuildContext context, FeedState state) {
            if (bloc.currentPageNo == 1 && state is GetPostsLoadingState) {
              return const PostFeedsShimmerLoadingView();
            }

            if (bloc.currentPageNo == 1 && state is FeedErrorState) {
              return SliverFillRemaining(
                child: AppDefaultErrorView(
                  message: state.message,
                  onRefresh: () => bloc.add(const GetPostsEvent()),
                ),
              );
            }

            if (state is GetPostsEmptyState) {
              return SliverFillRemaining(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (filtersController(context).postsFilterByType ==
                        PostsFilterByType.following)
                      SizedBox(
                        width: 100,
                        height: 100,
                        child: Text(translations.no_followers),
                      ),
                  ],
                ),
              );
            }

            if (state is GetPostsResultFetchedState) {
              if (kDebugMode) {
                print(" state.posts: ${state.posts.length}");
              }
              if (state.shouldAnimateToTop) {
                AppScrollerView.viewOf(context)?.animateToTop();
              }

              /// Set always the initial PostID to be visible
              AppScrollerView.stateOf(context)?.initialVisibleItems = [
                state.posts.first.id
              ];

              return SliverListPosts(
                bloc: bloc,
                items: state.posts,
              );
            }

            return const SliverFillRemaining(
              child: SizedBox(
                width: 0,
                height: 0,
              ),
            );
          },
        ),
      ],
    );
  }

  void _onFeedFilterTap(BuildContext context, PostsFilterByType type) {
    if (filtersController(context).postsFilterByType == type) {
      return;
    }
    _getPosts(context: context, type: type);

    filtersController(context).postsFilterByType = type;
  }

  /// Handle pagination callback
  /// this will be fired on scrolling the feed
  void _onPaginate(BuildContext context) {
    /*if (isRequesting) {
      return;
    }*/

    _getPosts(
        context: context, type: filtersController(context).postsFilterByType);
  }

  void _onRefresh(BuildContext context) {
    bloc.resetPagination();

    _getPosts(
        context: context, type: filtersController(context).postsFilterByType);
  }

  /// Helper to request the Posts
  /// based on the current pagination page
  void _getPosts(
      {required BuildContext context,
      PostsFilterByType type = PostsFilterByType.suggested}) {
    /*if (filtersController(context).postsFilterByType != type) {
      bloc.allowNewPaginationRequests = true;
    }

    if (!bloc.allowNewPaginationRequests) {
      return;
    }*/

    bloc.add(GetPostsEvent(
        pageNo: bloc.pageNo,
        type: type,
        categories: filtersController(context).selectedIds));
  }
}

class SliverListPosts extends StatelessWidget {
  const SliverListPosts({
    Key? key,
    required this.items,
    required this.bloc,
  }) : super(key: key);

  final List<Post> items;
  final FeedBloc bloc;

  @override
  Widget build(BuildContext context) {
    BuildContext mainContext = context;

    final translations = S.of(context);

    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (BuildContext context, int index) {
          Post model = items[index];

          PostBloc postBloc =
              PostBlocUtils.getOrRegisterBloc(model.id, model: model);

          /// TODO merge this to use the same PostBlocBuilderView
          return MultiProvider(
            providers: [
              ChangeNotifierProvider.value(value: postBloc),
            ],
            child: DNGBlocBuilder<PostBloc, PostState>(
              buildWhen: (state) => state is SetPostActionUpdatedState,
              builder: (BuildContext context, PostState state) {
                /// If was done any action to Post update
                ///
                /// Supported actions:
                ///  ** Applaud
                ///  ** Bookmark
                if (state is SetPostActionUpdatedState &&
                    !state.stateHandled &&
                    state.model != null &&
                    model.id == state.model!.id) {
                  model = state.model!;

                  if (state.action == PostActions.flag) {
                    AppModule.I.notify(mainContext, translations.post_flagged);
                  }
                  if (state.action == PostActions.delete) {
                    AppModule.I.notify(mainContext, translations.post_deleted);
                  }

                  /// Delete post from [FeedBloc] list
                  if (state.model != null &&
                      (state.action == PostActions.delete ||
                          state.action == PostActions.flag)) {
                    context.read<FeedBloc>().deletePost(state.model!.id);
                  }

                  if (state.action != PostActions.applaud) {
                    state.stateHandled = true;
                  }

                  final feedBloc = context.read<FeedBloc>();
                  feedBloc.updatePost(model: model, action: state.action);
                }

                return ScrollyNotifierWidget(
                  item: model,
                  child: PostView(
                    key: Key("${model.id}_${model.hashCode}"),
                    item: model,
                    enableHighlights: AppModule.I.enablePostHighlights,
                    currentSessionUserId: context.currentSessionUserId,
                    index: index,
                    onTap: (item) {},
                    onTapReaction: (action, item, index) =>
                        onTapReaction(context, action, item, index),
                  ),
                  builder:
                      (BuildContext context, bool isVisible, Widget? child) {
                    return PostView(
                      key: Key("${model.id}_${model.hashCode}"),
                      item: model,
                      currentSessionUserId: context.currentSessionUserId,
                      index: index,
                      isVisible: isVisible,
                      enableHighlights: AppModule.I.enablePostHighlights,
                      onTap: (item) {},
                      onTapReaction: (action, item, index) =>
                          onTapReaction(context, action, item, index),
                    );
                  },
                );
              },
            ),
          );
        },
        childCount: items.length,
        addAutomaticKeepAlives: false,
      ),
      //itemExtent: 675,
    );
  }

  void onTapReaction(BuildContext context, action, item, index) {
    if (action == PostActions.highlights) {
      context.navigatorKey?.pushNamed(PostHighlightsPage.routeName,
          arguments: PostHighlightsPageArgs(item));
      return;
    }

    if (action == PostActions.share) {
      openShareSheet(context, item);
      return;
    }

    PostBlocUtils.getBloc(item.id)
        .add(SetPostActionEvent(id: item.id, action: action));
  }

  void openShareSheet(BuildContext context, Post item) async {
    await AppUtils().sharePost(context, item);
    // await BottomSheetView.show<String>(
    //   context: context,
    //   corner: BorderRadius.circular(AppDimensions.radius_24),
    //   sheet: PostShareView(item: item),
    // );
  }
}
