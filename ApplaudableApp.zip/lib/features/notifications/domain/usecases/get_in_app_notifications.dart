import 'package:dartz/dartz.dart';

import '../../../../core/entities/pagination_params.dart';
import '../../../../core/entities/pagination_response.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../entities/in_app_notification.dart';
import '../repositories/notificaiton_repository.dart';

class GetInAppNotifications
    extends UseCase<PaginationResponse<InAppNotification>, PaginationParams> {
  final NotificationsRepository repository;

  GetInAppNotifications({required this.repository});

  @override
  Future<Either<Failure, PaginationResponse<InAppNotification>>> call(
    PaginationParams params,
  ) {
    return repository.getInAppNotifications(pageInfo: params);
  }
}
