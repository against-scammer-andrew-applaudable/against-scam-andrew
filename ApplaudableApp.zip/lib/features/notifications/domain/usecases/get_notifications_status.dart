import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../repositories/notificaiton_repository.dart';

class GetNotificationsStatus extends UseCase<bool, NoParams> {
  final NotificationsRepository repository;

  GetNotificationsStatus({required this.repository});

  @override
  Future<Either<Failure, bool>> call(NoParams params) {
    return repository.getNotificationsEnabledStatus();
  }
}
