import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../repositories/notificaiton_repository.dart';

class RegisterDevice extends UseCase<bool, RegisterDeviceParams> {
  final NotificationsRepository repository;

  RegisterDevice({required this.repository});

  @override
  Future<Either<Failure, bool>> call(RegisterDeviceParams params) {
    return repository.registerDevice(
      model: params,
    );
  }
}

class RegisterDeviceParams extends Equatable {
  final String name;
  final String id;
  final String token;

  final String deviceType;

  const RegisterDeviceParams({
    required this.name,
    required this.id,
    required this.token,
    required this.deviceType,
  });

  @override
  List<Object?> get props => [id, token, deviceType];
}
