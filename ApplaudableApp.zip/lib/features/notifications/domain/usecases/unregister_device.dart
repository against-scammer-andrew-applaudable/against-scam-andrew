import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../repositories/notificaiton_repository.dart';
import 'register_device.dart';

class UnregisterDevice extends UseCase<bool, RegisterDeviceParams> {
  final NotificationsRepository repository;

  UnregisterDevice({required this.repository});

  @override
  Future<Either<Failure, bool>> call(RegisterDeviceParams params) {
    return repository.unregisterDevice(model: params);
  }
}
