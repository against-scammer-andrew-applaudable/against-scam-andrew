import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../entities/in_app_notification.dart';
import '../repositories/notificaiton_repository.dart';

class MarkNotificationAsViewed extends UseCase<InAppNotification, String> {
  final NotificationsRepository repository;

  MarkNotificationAsViewed({required this.repository});

  @override
  Future<Either<Failure, InAppNotification>> call(String params) {
    return repository.markNotificationsAsViewed(id: params);
  }
}
