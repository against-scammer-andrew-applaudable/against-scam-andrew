import '../../../../core/extensions/list_extensions.dart';

enum NotificationType {
  none("none"),
  postApplaud("post_applaud"),
  userFollow("user_follow"),
  userPostMention("user_post_mention"),
  postSomeoneUser("post_someone_user"),
  addedPostVisibility("user_post_visibility"),
  disappearing("post_disappearing"),
  circleJoinRequest("circle_user_request"),
  circleInvite("circle_invite_user"),
  circleQuestion("circle_question"),
  prompt("prompt");

  final String type;
  const NotificationType(this.type);

  static NotificationType getTypeByName(String? name) =>
      values.firstWhereOrNull((e) => e.type == name?.trim()) ??
      NotificationType.none;

  String get acceptTitle {
    switch(this) {
      case NotificationType.circleJoinRequest:
        return "Approve";
      case NotificationType.circleInvite:
        return "Accept";
      default:
        return "";
    }
  }
  String get contentHint {
    switch(this) {
      case NotificationType.circleJoinRequest:
        return "wants to join";
      case NotificationType.circleInvite:
        return "invited to";
      default:
        return "";
    }
  }
}

enum NotificationObjectType {
  none,
  user,
  circle,
  post;

  static NotificationObjectType getTypeByName(String? name) =>
      NotificationObjectType.values
          .firstWhereOrNull((e) => e.name == name?.trim()) ??
      NotificationObjectType.none;
}
