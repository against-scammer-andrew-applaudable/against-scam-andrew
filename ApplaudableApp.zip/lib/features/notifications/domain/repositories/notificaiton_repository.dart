import 'package:dartz/dartz.dart';

import '../../../../core/entities/pagination_params.dart';
import '../../../../core/entities/pagination_response.dart';
import '../../../../core/errors/failures.dart';
import '../entities/in_app_notification.dart';
import '../usecases/register_device.dart';

abstract class NotificationsRepository {
  Future<Either<Failure, bool>> registerDevice({
    required RegisterDeviceParams model,
  });

  Future<Either<Failure, bool>> unregisterDevice({
    required RegisterDeviceParams model,
  });

  Future<Either<Failure, bool>> getNotificationsEnabledStatus();

  PaginatedResults<InAppNotification> getInAppNotifications({
    PaginationParams pageInfo = const PaginationParams(),
  });

  Future<Either<Failure, InAppNotification>> markNotificationsAsViewed({
    required String id,
  });

  /*Future<AppResult> getNotifications({
    required int page,
  });

  Future<AppResult> getInitialMessage();

  Stream<AppResult> get onEventNotifier;*/
}
