import 'package:equatable/equatable.dart';

import '../enums/notification_enums.dart';
import 'notification.dart';

abstract class InAppNotification extends Equatable {
  final String id;
  final NotificationType type;
  final DateTime createdAt;
  final List<Actor> actors;
  final Actor target;
  final NotificationScope? scope;
  final NotificationMetadata metadata;
  final String title;
  final String text;
  bool viewed;
  bool? removedOnOtherPage;

  InAppNotification({
    required this.id,
    required this.type,
    required this.createdAt,
    required this.actors,
    required this.target,
    required this.scope,
    required this.metadata,
    required this.title,
    required this.text,
    required this.viewed,
  });

  bool get isCircleNotification => type == NotificationType.circleInvite || type == NotificationType.circleJoinRequest;
  bool get isCircleQuestionNotification => type == NotificationType.circleQuestion;
}

abstract class Actor extends Equatable {
  final String id;
  final String type;
  final String icon;
  final String name;

  const Actor({
    required this.id,
    required this.type,
    required this.icon,
    required this.name,
  });
}

abstract class NotificationScope extends Equatable {
  final String id;
  final String type;
  final String icon;
  final String name;

  const NotificationScope({
    required this.id,
    required this.type,
    required this.icon,
    required this.name,
  });
}

// abstract class NotificationMetadata extends Equatable {
//   final String? postId;
//   final String? circleId;
//
//   const NotificationMetadata({
//     required this.postId,
//     required this.circleId,
//   });
// }
