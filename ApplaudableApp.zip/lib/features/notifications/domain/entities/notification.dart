/* Notification Payload example
{json: {
  "type": "post_applaud",
  "created_at": "2022-11-18T11:19:14.741252+0000",
  "actors": [{"id": "9PlnR5e38N6AJ", "type": "user", "icon": "", "name": "daniel"}],
  "target": {"id": "wBkaL8Dj5Z4vK", "type": "user", "icon": "", "name": "daniel jorge"},
  "scope": {"id": "M4D2d3eN7Bj1l", "type": "post", "icon": "", "name": "M4D2d3eN7Bj1l"},
  "metadata": {}}}*/

import 'package:applaudable/core/extensions/list_extensions.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/entities/item.dart';
import '../../../../core/enums/post.dart';
import '../enums/notification_enums.dart';

abstract class NotificationObject with EquatableMixin {
  final String id;
  final String name;

  final NotificationObjectType type;
  final String? icon;

  const NotificationObject({
    required this.id,
    this.name = "",
    this.type = NotificationObjectType.none,
    this.icon = "",
  });

  @override
  List<Object?> get props => [id, name, type, icon];
}

abstract class Notification with EquatableMixin implements Item<Notification> {
  @override
  final String id;

  final NotificationType type;
  final DateTime? createdAt;

  final List<NotificationObject>? actors;
  final NotificationObject? target;
  final NotificationObject? scope;

  final NotificationMetadata? metadata;

  const Notification(
      {required this.id,
      this.type = NotificationType.none,
      this.createdAt,
      this.actors,
      this.target,
      this.scope,
      this.metadata});

  @override
  copyWith() {
    throw UnimplementedError();
  }

  @override
  String get name => type.name;

  @override
  List<Object?> get props => [id, type];

  @override
  String get value {
    switch (type) {
      case NotificationType.none:
        return "";
      case NotificationType.postApplaud:
      case NotificationType.userPostMention:
      case NotificationType.postSomeoneUser:
      case NotificationType.addedPostVisibility:
      case NotificationType.disappearing:
      case NotificationType.circleInvite:
      case NotificationType.circleJoinRequest:
        return scope?.id ?? "";
      case NotificationType.circleQuestion:
        return metadata?.postId ?? "";
      case NotificationType.userFollow:
        return target?.id ?? "";
      case NotificationType.prompt:
        return metadata?.prompt ?? "";
    }
  }
}
class NotificationMetadata {
  late PromptType type;
  CreatePostType? postType;
  String? prompt;
  String? circleId;
  String? postId;
  String? question;
  String? text;
  String? title;
  String? longContent;

  String? get formattedQuestion {
    if (question == null) return null;
    if (question!.length < 60) return question;
    return "${question!.substring(0, 60)}...";
  }

  String? get displayTitleInAppNotification => longContent ?? text ?? title;

  NotificationMetadata.fromJson(Map<String, dynamic> dic) {
    type = PromptType.getTypeByName(dic["type"]);
    if (dic["post_type"] is String) {
      postType = CreatePostType.from(dic["post_type"]);
    }
    prompt = dic["prompt"];
    circleId = dic["circle_id"];
    postId = dic["post_id"] ?? dic["glimpse_id"];
    question = dic["question"];
    text = dic["text"];
    if (text?.isEmpty ?? true) {
      text = null;
    }
    title = dic["title"];
    if (title?.isEmpty ?? true) {
      title = null;
    }
    longContent = dic["long_content"];
    if (longContent?.isEmpty ?? true) {
      longContent = null;
    }
  }
}
enum PromptType {
  other("other"),
  experience("experience"),
  person("person"),
  glimpseQuestion("glimpse_question"),
  glimpse("glimpse");

  final String name;
  const PromptType(this.name);

  static PromptType getTypeByName(dynamic name) => values.firstWhereOrNull((e) => e.name == name.toString().trim()) ?? PromptType.other;
}