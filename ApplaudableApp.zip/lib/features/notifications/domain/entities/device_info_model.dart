import 'package:device_info_plus/device_info_plus.dart';

class DeviceInfoModel {
  final String name;
  final String id;
  final String token;
  final DeviceType type;

  DeviceInfoModel({
    required this.name,
    required this.id,
    required this.token,
    required this.type,
  });

  factory DeviceInfoModel.fromIOS({
    required IosDeviceInfo info,
    required String token,
  }) {
    return DeviceInfoModel(
      name: info.name,
      id: info.identifierForVendor ?? 'Unknown ID',
      token: token,
      type: DeviceType.ios,
    );
  }

  factory DeviceInfoModel.fromAndroid({
    required AndroidDeviceInfo info,
    required String token,
  }) {
    return DeviceInfoModel(
      name: info.device,
      id: info.id,
      token: token,
      type: DeviceType.android,
    );
  }
}

enum DeviceType { android, ios }

extension DeviceTypeToString on DeviceType {
  String enumToString() {
    switch (this) {
      case DeviceType.android:
        return 'android';
      case DeviceType.ios:
        return 'ios';
    }
  }
}
