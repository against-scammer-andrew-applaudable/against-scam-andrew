import 'package:equatable/equatable.dart';

import '../../../../../core/bloc/dng_base_bloc.dart';
import '../../../../../core/errors/failures.dart';
import '../../../../../core/usecase/usecase.dart';
import '../../../domain/usecases/get_notifications_status.dart';
import '../../../domain/usecases/register_device.dart';
import '../../../domain/usecases/unregister_device.dart';

part 'push_notifications_event.dart';
part 'push_notifications_state.dart';

class PushNotificationsBloc
    extends DNGBloc<PushNotificationsEvent, PushNotificationsState> {
  final RegisterDevice registerDevice;
  final UnregisterDevice unregisterDevice;
  final GetNotificationsStatus getNotificationsStatus;

  PushNotificationsBloc({
    required this.registerDevice,
    required this.unregisterDevice,
    required this.getNotificationsStatus,
  }) : super(const PushNotificationsInitialState());

  @override
  void mapEventToState(PushNotificationsEvent event) async {
    if (event is RegisterDeviceEvent) {
      final result = await registerDevice(
        RegisterDeviceParams(
          name: event.name,
          id: event.id,
          token: event.token,
          deviceType: event.deviceType,
        ),
      );

      emit(
        result.fold(
          (failure) => _mapFailureToState(failure, isEnabled: false),
          (res) => RegisterDeviceState(isEnabled: res),
        ),
      );
    } else if (event is UnregisterDeviceEvent) {
      final result = await unregisterDevice(
        RegisterDeviceParams(
          name: event.name,
          id: event.id,
          token: event.token,
          deviceType: event.deviceType,
        ),
      );

      emit(
        result.fold(
          (failure) => _mapFailureToState(failure, isEnabled: true),
          (res) => const DeviceUnregisteredState(),
        ),
      );
    } else if (event is GetPushNotificationsStatusEvent) {
      emit(const PushNotificationsLoadingState(isEnabled: false));

      final result = await getNotificationsStatus(NoParams());

      emit(
        result.fold(
          (failure) => const DeviceUnregisteredState(),
          (isEnabled) => isEnabled
              ? RegisterDeviceState(isEnabled: isEnabled)
              : const DeviceUnregisteredState(),
        ),
      );
    }
  }

  PushNotificationsState _mapFailureToState(
    Failure failure, {
    bool isEnabled = false,
  }) {
    return PushNotificationsServerErrorState(
      message: failure.message,
      isEnabled: isEnabled,
    );
  }
}
