part of 'push_notifications_bloc.dart';

abstract class PushNotificationsState extends Equatable {
  final bool isEnabled;

  const PushNotificationsState({required this.isEnabled});

  @override
  List<Object?> get props => [];
}

class PushNotificationsInitialState extends PushNotificationsState {
  const PushNotificationsInitialState({super.isEnabled = false});
}

class PushNotificationsLoadingState extends PushNotificationsState {
  const PushNotificationsLoadingState({super.isEnabled = false});
}

class RegisterDeviceState extends PushNotificationsState {
  const RegisterDeviceState({super.isEnabled = true});
}

// ignore: must_be_immutable
class PushNotificationsServerErrorState extends PushNotificationsState {
  bool isHandled;
  final String message;

  PushNotificationsServerErrorState({
    required this.message,
    required super.isEnabled,
    this.isHandled = false,
  });

  @override
  List<Object?> get props => [message, isEnabled, isHandled];
}

class DeviceUnregisteredState extends PushNotificationsState {
  const DeviceUnregisteredState({super.isEnabled = false});
}
