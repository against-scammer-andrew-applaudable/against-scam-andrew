part of 'push_notifications_bloc.dart';

abstract class PushNotificationsEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class RegisterDeviceEvent extends PushNotificationsEvent {
  final String token;
  final String id;
  final String deviceType;
  final String name;

  RegisterDeviceEvent({
    required this.token,
    required this.deviceType,
    required this.id,
    this.name = "",
  });

  @override
  List<Object?> get props => [deviceType, id, name, token];
}

class UnregisterDeviceEvent extends PushNotificationsEvent {
  final String id;
  final String deviceType;
  final String token;
  final String name;

  UnregisterDeviceEvent({
    required this.id,
    required this.deviceType,
    this.name = "",
    this.token = '',
  });

  @override
  List<Object?> get props => [deviceType, id, name, token];
}

class GetPushNotificationsStatusEvent extends PushNotificationsEvent {}
