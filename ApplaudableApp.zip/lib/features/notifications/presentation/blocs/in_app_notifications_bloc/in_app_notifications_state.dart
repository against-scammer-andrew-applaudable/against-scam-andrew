part of 'in_app_notifications_bloc.dart';

abstract class InAppNotificationsState extends Equatable {
  const InAppNotificationsState();

  @override
  List<Object?> get props => [];
}

class InAppNotificationsInitialState extends InAppNotificationsState {}

class InAppNotificationsLoadingState extends InAppNotificationsState {}

class InAppNotificationsPaginationLoadingState
    extends InAppNotificationsState {}

class InAppNotificationsErrorState extends InAppNotificationsState {
  final String message;

  const InAppNotificationsErrorState({required this.message});

  @override
  List<Object?> get props => [message];
}

class InAppNotificationsPaginationErrorState extends InAppNotificationsState {
  final String message;

  const InAppNotificationsPaginationErrorState({required this.message});

  @override
  List<Object?> get props => [message];
}

class InAppNotificationsFetchedState extends InAppNotificationsState {
  final List<InAppNotification> notifications;

  const InAppNotificationsFetchedState({required this.notifications});

  @override
  List<Object?> get props => [notifications];
}

class InAppNotificationsPaginationFetchedState extends InAppNotificationsState {
  final List<InAppNotification> notifications;

  const InAppNotificationsPaginationFetchedState({required this.notifications});

  @override
  List<Object?> get props => [notifications];
}
