part of 'in_app_notifications_bloc.dart';

abstract class InAppNotificationsEvent extends Equatable {
  const InAppNotificationsEvent();
}

class GetInAppNotificationsEvent extends InAppNotificationsEvent {
  final bool paginate;
  final int pageSize;

  const GetInAppNotificationsEvent({
    this.paginate = false,
    this.pageSize = 15,
  });

  @override
  List<Object?> get props => [paginate, pageSize];
}

class MarkNotificationAsViewedEvent extends InAppNotificationsEvent {
  final String id;

  const MarkNotificationAsViewedEvent({required this.id});

  @override
  List<Object?> get props => [id];
}
