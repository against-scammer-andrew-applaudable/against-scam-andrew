import 'package:equatable/equatable.dart';

import '../../../../../core/bloc/dng_base_bloc.dart';
import '../../../../../core/entities/pagination_params.dart';
import '../../../domain/entities/in_app_notification.dart';
import '../../../domain/usecases/get_in_app_notifications.dart';
import '../../../domain/usecases/mark_notification_as_viewed.dart';

part 'in_app_notifications_event.dart';
part 'in_app_notifications_state.dart';

class InAppNotificationsBloc
    extends DNGBloc<InAppNotificationsEvent, InAppNotificationsState> {
  final GetInAppNotifications getInAppNotifications;
  final MarkNotificationAsViewed markNotificationAsViewed;

  InAppNotificationsBloc({
    required this.getInAppNotifications,
    required this.markNotificationAsViewed,
  }) : super(InAppNotificationsInitialState());

  List<InAppNotification> _notifications = [];
  int _pageNo = 1;

  @override
  void mapEventToState(InAppNotificationsEvent event) async {
    if (event is GetInAppNotificationsEvent) {
      await _handleInAppNotificationsEvent(event);
    } else if (event is MarkNotificationAsViewedEvent) {
      await _handleMarkInAppNotificationAsViewedEvent(event);
    }
  }

  Future<void> _handleInAppNotificationsEvent(
    GetInAppNotificationsEvent event,
  ) async {
    _pageNo = event.paginate ? _pageNo : 1;

    if (_pageNo > 1) {
      emit(InAppNotificationsPaginationLoadingState());
    } else {
      _notifications.clear();
      emit(InAppNotificationsLoadingState());
    }

    final result = await getInAppNotifications(
      PaginationParams(pageNo: _pageNo, pageSize: event.pageSize),
    );

    emit(
      result.fold(
        (failure) {
          if (_pageNo > 1) {
            return InAppNotificationsPaginationErrorState(
              message: failure.message,
            );
          }
          return InAppNotificationsErrorState(message: failure.message);
        },
        (response) {
          if (response.results.length == event.pageSize) _pageNo++;

          _notifications.addAll(response.results);

          _notifications = _notifications.toSet().toList();

          return InAppNotificationsFetchedState(notifications: _notifications);
        },
      ),
    );
  }

  Future<void> _handleMarkInAppNotificationAsViewedEvent(
    MarkNotificationAsViewedEvent event,
  ) async {
    emit(InAppNotificationsInitialState());

    final result = await markNotificationAsViewed(event.id);

    emit(
      result.fold(
        (failure) =>
            InAppNotificationsPaginationErrorState(message: failure.message),
        (updatedNotification) {
          final index =
              _notifications.indexWhere((element) => element.id == event.id);

          if (index != -1) {
            _notifications.removeAt(index);
            _notifications.insert(index, updatedNotification);
            _notifications = _notifications.toSet().toList();
          }

          return InAppNotificationsFetchedState(notifications: _notifications);
        },
      ),
    );
  }
}
