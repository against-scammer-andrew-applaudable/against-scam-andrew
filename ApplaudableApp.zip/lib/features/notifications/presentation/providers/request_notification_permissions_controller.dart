import 'dart:io';

import 'package:device_info_plus/device_info_plus.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../domain/entities/device_info_model.dart';
import '../blocs/push_notifications_bloc/push_notifications_bloc.dart';

class NotificationsController extends ChangeNotifier {
  Future<bool> request({bool openSettingsIfDenied = false}) async {
    NotificationSettings notificationSettings = await _checkPermissions();
    switch (notificationSettings.authorizationStatus) {
      case AuthorizationStatus.authorized:
        return true;
      case AuthorizationStatus.denied:
        if (openSettingsIfDenied) openAppSettings();
        return false;
      case AuthorizationStatus.notDetermined:
      case AuthorizationStatus.provisional:
        _requestPermissions();
        return false;
    }
  }

  Future<String?> getToken() async {
    if (Platform.isIOS) {
      // return await FirebaseMessaging.instance.getAPNSToken();
    }
    final token = await FirebaseMessaging.instance.getToken();
    debugPrint("========= FCM token : $token");
    return token;
  }

  Future<NotificationSettings> _checkPermissions() async {
    await FirebaseMessaging.instance.getNotificationSettings();
    return await _requestPermissions();
  }

  Future<NotificationSettings> _requestPermissions() async {
    return await FirebaseMessaging.instance.requestPermission(
      announcement: true,
      carPlay: true,
      criticalAlert: true,
    );
  }

  Future<DeviceInfoModel?> _getDeviceDetails() async {
    final plugin = DeviceInfoPlugin();

    if (Platform.isIOS) {
      final info = await plugin.iosInfo;
      return DeviceInfoModel.fromIOS(info: info, token: "");
    }

    if (Platform.isAndroid) {
      final info = await plugin.androidInfo;
      return DeviceInfoModel.fromAndroid(
        info: info,
        token: "",
      );
    }

    return null;
  }

  /// handlePermissionAndPrepareForRegisterDevice - flow for checking
  /// permissions and prepare for register device
  ///
  /// Get all the device info from [_getDeviceDetails]
  /// Get the token from [getToken]
  /// ands returns a [RegisterDeviceEvent]
  Future<RegisterDeviceEvent?> handlePermissionAndPrepareForRegisterDevice({
    bool openSettingsIfDenied = false,
  }) async {
    /// Request or validate permission
    bool result = await request(openSettingsIfDenied: openSettingsIfDenied);

    if (!result) {
      return null;
    }

    return createRegisterEvent();
  }

  Future<RegisterDeviceEvent?> createRegisterEvent() async {
    /// Request Token
    String? token = await getToken();
    if (token == null) {
      return null;
    }

    /// Request Device Info Details
    DeviceInfoModel? deviceInfoModel = await _getDeviceDetails();
    if (deviceInfoModel == null) {
      return null;
    }

    return RegisterDeviceEvent(
        token: token,
        id: deviceInfoModel.id,
        name: deviceInfoModel.name,
        deviceType: deviceInfoModel.type.name);
  }

  Future<UnregisterDeviceEvent?> createUnregisterEvent() async {
    /// Request Token
    String? token = await getToken();
    if (token == null) {
      return null;
    }

    /// Request Device Info Details
    DeviceInfoModel? deviceInfoModel = await _getDeviceDetails();
    if (deviceInfoModel == null) {
      return null;
    }

    return UnregisterDeviceEvent(
      token: token,
      id: deviceInfoModel.id,
      name: deviceInfoModel.name,
      deviceType: deviceInfoModel.type.name,
    );
  }
}
