import 'dart:async';
import 'dart:developer';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import '../../../../../injection_container.dart';
import '../../blocs/push_notifications_bloc/push_notifications_bloc.dart';
import '../../providers/request_notification_permissions_controller.dart';
import '../notification_controller.dart';

mixin NotificationsCache {
  Map<String, RemoteMessage> messages = {};

  void clear() {
    log("${NotificationController.tag} CLEAR");
    messages.clear();
  }
}

mixin NotificationsStreams {
  StreamSubscription? _streamSubscription;
  StreamSubscription? _streamSubscriptionOpenedApp;

  get showNotification;

  void setupStreams(listenerOnMessageOpenedApp, listenerOnMessage) {
    /// Receive messages while the app is in Foreground
    _streamSubscription = FirebaseMessaging.onMessage.listen(listenerOnMessage);

    /// Register Listener
    _streamSubscriptionOpenedApp =
        FirebaseMessaging.onMessageOpenedApp.listen(listenerOnMessageOpenedApp);
  }

  void disposeStreams() {
    _streamSubscription?.cancel();
    _streamSubscriptionOpenedApp?.cancel();
  }
}

mixin FirebaseMethods {
  /// Get the notification if the app was opened from a terminated state
  Future<RemoteMessage?> getInitialMessage() async =>
      await FirebaseMessaging.instance.getInitialMessage();

  /// Delete current registered token to disable notifications for this device.
  Future<void> deleteFCMToken() => FirebaseMessaging.instance.deleteToken();
}

mixin FlutterLocalNotifications {
  bool isFlutterLocalNotificationsInitialized = false;

  late FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin;

  /// Create a [AndroidNotificationChannel] for heads up notifications
  late AndroidNotificationChannel channel;

  get showNotification => showFlutterNotification;

  Future<void> setupFlutterNotifications() async {
    if (isFlutterLocalNotificationsInitialized) {
      return;
    }

    flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

    await _setupForAndroid();
    await _setupForIos();

    isFlutterLocalNotificationsInitialized = true;
  }

  Future<void> _setupForAndroid() async {
    channel = const AndroidNotificationChannel(
      'applaudable_notifications', // id
      'Applaudable', // title
      description:
          'Applaudable channel for important notifications.', // description
      importance: Importance.high,
    );

    /// Create an Android Notification Channel.
    ///
    /// We use this channel in the `AndroidManifest.xml` file to override the
    /// default FCM channel to enable heads up notifications.
    await flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);
  }

  Future<void> _setupForIos() async {
    /// Update the iOS foreground notification presentation options to allow
    /// heads up notifications.
    await FirebaseMessaging.instance
        .setForegroundNotificationPresentationOptions(
      alert: false,
      badge: true,
      sound: true,
    );
  }

  void showFlutterNotification(RemoteMessage message) async {
    RemoteNotification? notification = message.notification;
    // AndroidNotification? android = message.notification?.android;

    log(message.data.toString());

    if (notification != null && !kIsWeb) {
      flutterLocalNotificationsPlugin.show(
        notification.hashCode,
        notification.title,
        notification.body,
        const NotificationDetails(
            iOS: DarwinNotificationDetails(
                presentAlert: true, presentBadge: true, presentSound: true)
            /*android: AndroidNotificationDetails(
            channel.id,
            channel.name,
            channelDescription: channel.description,
            icon: 'launch_background',
          ),*/
            ),
      );
    }
  }
}

mixin RemoteNotifications {
  void registerDeviceToken({bool requestPermissions = false}) async {
    /// Request using NotificationsBloc
    final PushNotificationsBloc bloc = servLocator<PushNotificationsBloc>();
    bloc.emit(const PushNotificationsLoadingState());

    /// Get Provider info
    final NotificationsController notificationsController =
        servLocator<NotificationsController>();

    /// Create Event for Request
    RegisterDeviceEvent? registerDeviceEvent;

    if (requestPermissions) {
      registerDeviceEvent = await notificationsController
          .handlePermissionAndPrepareForRegisterDevice(
        openSettingsIfDenied: true,
      );
    } else {
      registerDeviceEvent = await notificationsController.createRegisterEvent();
    }

    if (registerDeviceEvent == null) {
      bloc.emit(const DeviceUnregisteredState());
      return;
    }

    bloc.add(registerDeviceEvent);

    //! Review this!!!
    /// Bloc is being used now to toggle notifications status so it couldn't be disposed
    // bloc.stream.listen((event) {
    //   if (event is RegisterDeviceState) {
    //     bloc.dispose();
    //   }
    // });
  }

  void unregisterDeviceToken() async {
    /// Request using NotificationsBloc
    final PushNotificationsBloc bloc = servLocator<PushNotificationsBloc>();
    bloc.emit(const PushNotificationsLoadingState(isEnabled: true));

    /// Get Provider info
    final NotificationsController notificationsController =
        servLocator<NotificationsController>();

    /// Create Event for Request
    final unregisterDeviceEvent =
        await notificationsController.createUnregisterEvent();

    if (unregisterDeviceEvent == null) {
      return;
    }

    bloc.add(unregisterDeviceEvent);
  }
}
