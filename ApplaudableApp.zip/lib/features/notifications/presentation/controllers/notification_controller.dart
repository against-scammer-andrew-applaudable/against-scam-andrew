import 'dart:developer';

import 'package:applaudable/core/api/api/api.dart';
import 'package:applaudable/core/extensions/app_module_extensions.dart';
import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:applaudable/model/post/feed.dart';
import 'package:applaudable/ui/page/circle/feed/circle.dart';
import 'package:applaudable/ui/page/circle/feed/question.dart';
import 'package:applaudable/ui/page/highlight_glimpse/glimpse/create.dart';
import 'package:dismissible_page/dismissible_page.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

import '../../../../app_module.dart';
import '../../../../core/utils/app_utils.dart';
import '../../../../ui/page/main/feed/sub/preview.dart';
import '../../../../ui/page/main/profile_settings/profile.dart';
import '../../../../ui/page/new_post/select_experience.dart';
import '../../../post/presentation/pages/post_page.dart';
import '../../../profile/presentation/pages/profile_page.dart';
import '../../data/models/notification_response_models.dart';
import '../../domain/entities/notification.dart';
import '../../domain/enums/notification_enums.dart';
import 'mixins/notification_mixins.dart';

class NotificationController
    with
        FirebaseMethods,
        FlutterLocalNotifications,
        NotificationsStreams,
        RemoteNotifications,
        NotificationsCache {
  static const String tag = '.NotificationController';
  static final NotificationController _controller = NotificationController._();

  static NotificationController get I => _controller;

  NotificationController._();

  bool _initialized = false;

  void init() {
    log("$tag INIT $_initialized");
    if (_initialized) {
      return;
    }

    /// Setup local notifications
    /// thus handling notifications while the app is in Foreground
    setupFlutterNotifications();

    /// Setup streams to listen for notifications
    ///
    /// Currently capture notifications from:
    ///  ** App in Foreground
    ///  ** App in Background (Not Terminated)
    setupStreams(onMessageOpenedAppListener, onMessageListener);

    _initialized = true;
  }

  onMessageListener(RemoteMessage event) {
    log("[** ${NotificationController.tag} **] onMessage: $event ${event.data["json"]}");
    //_stream?.sink.add(_parseResult(event));

    //showNotification(event);
    _mapEventToNotification(event: event);
  }

  onMessageOpenedAppListener(RemoteMessage event) {
    log("[** $tag **] onMessageOpenedApp MESSAGE: $event");

    messages.putIfAbsent(event.messageId ?? "0", () => event);

    _mapEventToNotification(event: event);
  }

  Notification? _mapEventToNotification({RemoteMessage? event}) {
    if (event == null) {
      return null;
    }
    if (!event.data.containsKey("json")) {
      return null;
    }

    Notification notification = NotificationModel.fromMessage(event.data);
    log(notification.toString());

    return notification;
  }

  void checkPendingNotificationAndPushPage() async {
    if (!_initialized) {
      init();
    }

    RemoteMessage? initialMessage = await getInitialMessage();
    if (initialMessage == null && messages.values.isEmpty) {
      return;
    }

    initialMessage ??= messages.values.last;
    messages.removeWhere((key, value) => value == initialMessage);

    log("----------------messages: ${initialMessage.data} $messages");

    Notification? notification = _mapEventToNotification(event: initialMessage);
    if (notification == null) {
      return;
    }

    log("NNN: $notification ${notification.value} ${notification.type}");

    switch (notification.type) {
      case NotificationType.none:
        break;
      case NotificationType.postApplaud:
      case NotificationType.addedPostVisibility:
      case NotificationType.disappearing:
      if ((AppUtils().tabContext) != null) {
        await (AppUtils().tabContext!).pushTransparentRoute(PostPreviewPage(postId: notification.value,));
      }
        // PostPage.pushAndResetRouteToFeed(notification.value);
        break;
      case NotificationType.userFollow:
        AppModule.I.navigateToNamed(
          AppProfilePage.routeName,
          arguments: {
            "userId": notification.value,
          },
        );
        break;
      case NotificationType.userPostMention:
      case NotificationType.postSomeoneUser:
      if (AppUtils().tabContext != null) {
        await (AppUtils().tabContext!).pushTransparentRoute(PostPreviewPage(postId: notification.value,));
      }

      // PostPage.pushAndResetRouteToFeed(notification.value);
        break;
      case NotificationType.prompt:
        if (AppUtils().tabContext != null) {
          if (notification.metadata?.prompt != null) {
            if ((notification.metadata?.type == PromptType.experience || notification.metadata?.type == PromptType.person)) {
              await AppUtils().tabContext!.navigateToNamed(
                SelectExperiencePage.routeName,
                arguments: {
                  "promptType": notification.metadata?.type,
                  "promptId": notification.metadata?.prompt,
                },
              );
            } else if (notification.metadata?.type == PromptType.glimpse || notification.metadata?.type == PromptType.glimpseQuestion) {
              FeedPostModel? post;
              if (notification.metadata?.postId != null) {
                final res = await APIs().getPostDetail(postId: notification.metadata?.postId ?? "");
                if (res is FeedPostModel) {
                  post = res;
                }
              }
              await AppUtils().tabContext!.navigateToNamed(
                CreateGlimpsePage.routeName,
                arguments: {
                  "promptType": notification.metadata?.type,
                  "circleQuestion": post,
                  "promptId": notification.metadata?.prompt,
                },
              );
            }

          }
        }

        break;
      case NotificationType.circleJoinRequest:
      case NotificationType.circleInvite:
      await AppModule.I.navigateToNamed(
        CirclePostsFeedPage.routeName,
        arguments: {
          "circleId": notification.value,
          "notification": notification,
        },
      );
      case NotificationType.circleQuestion:
      await AppModule.I.navigateToNamed(
        CircleQuestionFeedPage.routeName,
        arguments: {
          "postId": notification.value,
        },
      );
    }
  }

  void dispose() {
    log("$tag DISPOSE");
    _initialized = false;

    disposeStreams();
    clear();
  }
}
