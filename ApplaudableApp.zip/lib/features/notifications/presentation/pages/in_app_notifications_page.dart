import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';

import '../../../../core/bloc/widgets/base_stateless_page.dart';
import '../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/styles.dart';
import '../../../../core/widgets/app_bar.dart';
import '../../../../core/widgets/app_default_error_view.dart';
import '../../../../core/widgets/app_scaffold.dart';
import '../blocs/in_app_notifications_bloc/in_app_notifications_bloc.dart';
import '../widgets/in_app_notifications_overview_list.dart';
import '../widgets/in_app_notifications_page_shimmer_loading_view.dart';

// ignore: must_be_immutable
class InAppNotificationsPage
    extends BaseStatelessPage<InAppNotificationsBloc, InAppNotificationsState> {
  static const String routeName = '/in-app-notifications-page';

  InAppNotificationsPage({super.key});

  @override
  void initBloc(BuildContext context, InAppNotificationsBloc bloc) {
    bloc.add(const GetInAppNotificationsEvent());
  }

  @override
  Widget build(BuildContext context) {
    registerBloc(context);

    return AppScaffold(
      appBar: NavigationPageBar(
        title: translations.notifications,
        centerTitle: false,
        style: AppStyles.header1(color: context.textColor),
        leading: Container(),
        leadingWidth: 8,
      ),
      body: DNGBlocBuilder<InAppNotificationsBloc, InAppNotificationsState>(
        bloc: bloc,
        buildWhen: (state) =>
            state is InAppNotificationsLoadingState ||
            state is InAppNotificationsErrorState ||
            state is InAppNotificationsFetchedState,
        builder: (context, state) {
          if (state is InAppNotificationsLoadingState) {
            return const InAppNotificationsPageShimmerLoadingView();
          } else if (state is InAppNotificationsErrorState) {
            return AppDefaultErrorView(
              message: state.message,
              onRefresh: () => bloc.add(const GetInAppNotificationsEvent()),
            );
          } else if (state is InAppNotificationsFetchedState) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                  ),
                  child: RichText(
                    text: TextSpan(
                      text: translations.you_have,
                      children: [
                        TextSpan(
                          text:
                              '${state.notifications.where((e) => !e.viewed).length} ${translations.new_}',
                          style: AppStyles.text2(color: AppColors.primaryColor),
                        ),
                        TextSpan(text: translations.c_notifications),
                      ],
                      style: AppStyles.text2(color: AppColors.mediumGrey),
                    ),
                  ),
                ),
                const SizedBox(height: 25),
                // Text(
                //   'Today',
                //   style: AppStyles.text2(color: context.textColor).copyWith(
                //     fontWeight: FontWeight.w700,
                //   ),
                // ),
                // const SizedBox(height: 18),
                Expanded(
                  child: InAppNotificationsOverviewList(
                    notifications: state.notifications,
                  ),
                ),
              ],
            );
          }

          return const SizedBox();
        },
      ),
    );
  }
}
