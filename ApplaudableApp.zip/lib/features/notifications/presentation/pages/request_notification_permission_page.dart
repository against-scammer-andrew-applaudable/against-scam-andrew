import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../app_module.dart';
import '../../../../core/bloc/widgets/base_stateless_page.dart';
import '../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../core/widgets/animations/wiggle.dart';
import '../../../../core/widgets/svg_icons.dart';
import '../../../../generated/l10n.dart';
import '../../../auth/presentation/presenters/base_view_page.dart';
import '../../../../core/theme/colors.dart';
import '../../../../core/theme/styles.dart';
import '../../../auth/presentation/widgets/buttons/action_button.dart';
import '../../../auth/presentation/widgets/sizing/side_margins.dart';
import '../../../onboarding/presentation/pages/select_interests_page.dart';
import '../blocs/push_notifications_bloc/push_notifications_bloc.dart';
import '../providers/request_notification_permissions_controller.dart';

// ignore: must_be_immutable
class NotificationPermissionPage
    extends BaseStatelessPage<PushNotificationsBloc, PushNotificationsState> {
  static const String routeName = '/notifications-permission/';

  NotificationPermissionPage({super.key});

  void _submitForm() {}

  @override
  Widget build(BuildContext context) {
    registerBloc(context);
    S translations = S.of(context);

    return BaseStatelessViewPage(
      centerContentOnPage: true,
      child: AppSideMargins(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Wiggle(
              shouldAutoAnimate: true,
              child: SvgIcons.notificationsBig,
            ),
            const SizedBox(height: 34),
            Text(
              translations.enableNotifications,
              style: AppStyles.header1(color: context.textColor),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 13),
            Text(
              translations.enableNotificationsDescription,
              style: AppStyles.text2(color: AppColors.mediumGrey),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 25),
            DNGBlocBuilder<PushNotificationsBloc, PushNotificationsState>(
              bloc: bloc,
              buildWhen: (state) =>
                  state is PushNotificationsLoadingState ||
                  state is PushNotificationsServerErrorState ||
                  state is RegisterDeviceState,
              builder: (context, state) {
                return SizedBox(
                  width: 168,
                  child: AppActionButton.submit(
                    text: translations.buttonContinueLabel,
                    showLoading: state is PushNotificationsLoadingState,
                    onPressed: () => onHandlePermission(
                        context.read<NotificationsController>()),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  void onHandlePermission(NotificationsController data) async {
    bloc.emit(const PushNotificationsLoadingState());
    final RegisterDeviceEvent? registerDeviceEvent =
        await data.handlePermissionAndPrepareForRegisterDevice();
    if (registerDeviceEvent == null) {
      return;
    }

    bloc.add(registerDeviceEvent);
  }

  @override
  Stream<PushNotificationsState>? get onStateListener => bloc.stream;

  @override
  onStateResultListener(BuildContext context, PushNotificationsState state) {
    if (state is RegisterDeviceState) {
      final currentRoute = ModalRoute.of(context)?.settings.name;

      if (currentRoute == routeName) {
        AppModule.instance.navigatorKey.currentState
            ?.pushNamed(SelectInterestsPage.routeName);
      }
    }
  }
}
