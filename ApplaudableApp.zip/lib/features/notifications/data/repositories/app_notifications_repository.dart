import 'package:dartz/dartz.dart';

import '../../../../core/entities/pagination_params.dart';
import '../../../../core/entities/pagination_response.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/errors/repository_call_handler.dart';
import '../../domain/entities/in_app_notification.dart';
import '../../domain/repositories/notificaiton_repository.dart';
import '../../domain/usecases/register_device.dart';
import '../datasources/notifications_local_data_source.dart';
import '../datasources/remote_notification_data_source.dart';
import '../mappers/notification_mapper.dart';

class AppNotificationsRepository implements NotificationsRepository {
  final RepositoryCallHandler callHandler;
  final NotificationRemoteDataSource remoteDataSource;
  final NotificationsLocalDataSource localDataSource;
  // final AppLocalDataSource localDataSource;

  AppNotificationsRepository({
    required this.callHandler,
    required this.remoteDataSource,
    required this.localDataSource,
    // required this.localDataSource,
  });

  @override
  Future<Either<Failure, bool>> registerDevice({
    required RegisterDeviceParams model,
  }) {
    return callHandler.handleCall<bool>(
      () async {
        final isEnabled = await remoteDataSource.registerDevice(
          model: model.toRequestModel(),
        );

        await localDataSource.cacheNotificationsStatus(isEnabled: isEnabled);

        return isEnabled;
      },
    );
  }

  @override
  Future<Either<Failure, bool>> unregisterDevice({
    required RegisterDeviceParams model,
  }) {
    return callHandler.handleCall<bool>(
      () async {
        final isEnabled = await remoteDataSource.unregisterDevice(
          model: model.toRequestModel(),
        );

        await localDataSource.cacheNotificationsStatus(isEnabled: isEnabled);

        return isEnabled;
      },
    );
  }

  @override
  Future<Either<Failure, bool>> getNotificationsEnabledStatus() {
    return callHandler.handleCall<bool>(
      () => localDataSource.getNotificationsStatus(),
    );
  }

  @override
  PaginatedResults<InAppNotification> getInAppNotifications({
    PaginationParams pageInfo = const PaginationParams(),
  }) {
    return callHandler.handleCall<PaginationResponse<InAppNotification>>(
      () => remoteDataSource.getInAppNotifications(pageInfo: pageInfo),
    );
  }

  @override
  Future<Either<Failure, InAppNotification>> markNotificationsAsViewed({
    required String id,
  }) {
    return callHandler.handleCall<InAppNotification>(
      () => remoteDataSource.markNotificationAsViewed(id: id),
    );
  }

/*@override
  Future<AppResult> getNotifications({required int page}) async {
    final Session? _session = await localDataSource.getSession();

    if (_session == null) {
      return AppResult.failure();
    }

    final AppResult _result = await remoteDataSource.getNotifications(
      headers: await localDataSource.getHeaders(),
      page: page,
    );

    logger.i("Result: $_result && State : ${_result.status}");

    return _result;
  }

  @override
  Future<AppResult> getInitialMessage() async {
    return remoteDataSource.getInitialMessage();
  }

  @override
  Stream<AppResult> get onEventNotifier => remoteDataSource.onEventNotifier;*/
}
