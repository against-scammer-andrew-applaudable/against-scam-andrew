import '../../domain/usecases/register_device.dart';
import '../models/register_device_request_model.dart';

extension RegisterDeviceRequestMapper on RegisterDeviceParams {
  RegisterDeviceRequestModel toRequestModel() => RegisterDeviceRequestModel(
      name: name, deviceId: id, registrationId: token, type: deviceType);
}
