import '../../../../core/api/api_config.dart';
import '../../../../core/api/remote_api_service.dart';
import '../../../../core/entities/pagination_params.dart';
import '../../presentation/controllers/mixins/notification_mixins.dart';
import '../models/in_app_notification_model.dart';
import '../models/register_device_request_model.dart';

abstract class NotificationRemoteDataSource {
  /// Will not need to parse the response,
  /// if is success device should be activated
  Future<bool> registerDevice({
    required RegisterDeviceRequestModel model,
  });

  Future<bool> unregisterDevice({
    required RegisterDeviceRequestModel model,
  });

  Future<InAppNotificationsResponse> getInAppNotifications({
    PaginationParams pageInfo = const PaginationParams(),
  });

  Future<InAppNotificationModel> markNotificationAsViewed({
    required String id,
  });

  /*Future<AppResult> getNotifications({
    required Map<String, String> headers,
    required int page,
  });

  Future<AppResult> getInitialMessage();

  Stream<AppResult> get onEventNotifier;*/

  dispose();
}

class AppNotificationRemoteDataSource
    with FirebaseMethods
    implements NotificationRemoteDataSource {
  final RemoteApiService _httpClient = RemoteApiService.api;

  /*@override
  Stream<AppResult> get onEventNotifier => service.onEventNotifier.map((event) {
        print("EVENT: $event");
        return AppResult.success(
            (event as NotificationPayloadResponseModel).toEntity());
      });*/

  @override
  Future<bool> registerDevice({required model}) async {
    await _httpClient.post(url: ApiResource.registerDevice, body: model.toMap);

    return true;
  }

  @override
  Future<bool> unregisterDevice({
    required RegisterDeviceRequestModel model,
  }) async {
    await deleteFCMToken();

    /// returns false to represent disable status
    return false;
  }

  @override
  Future<InAppNotificationsResponse> getInAppNotifications({
    PaginationParams pageInfo = const PaginationParams(),
  }) async {
    final parsedJson = await _httpClient.get(
      url: ApiResource.inAppNotificationsEndpoint(pageInfo),
    );

    return InAppNotificationsResponse.fromJson(parsedJson);
  }

  @override
  Future<InAppNotificationModel> markNotificationAsViewed({
    required String id,
  }) async {
    final parsedJson = await _httpClient.patch(
      url: ApiResource.markNotificationAsViewedEndpoint(id),
    );

    return InAppNotificationModel.fromJson(parsedJson);
  }

  /*@override
  Future<AppResult> getNotifications(
          {required Map<String, String> headers, required int page}) async =>
      service.getNotifications(headers: headers, page: page).then((result) {
        var notificationsResponseModel =
            NotificationsResponseModel.fromJson(result as Map<String, Object?>);

        return AppResult.success(notificationsResponseModel.toList(),
            notificationsResponseModel.count);
      }).onError((error, stackTrace) => processErrorResponse(error));

  @override
  Future<AppResult> getInitialMessage() async {
    var object = await service.getInitialMessage();
    if (object != null) {
      return AppResult.success(
          (object as NotificationPayloadResponseModel).toEntity());
    }
    return AppResult.failure();
  }*/

  @override
  dispose() {}
}
