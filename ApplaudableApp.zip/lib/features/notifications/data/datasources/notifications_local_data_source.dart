import 'package:shared_preferences/shared_preferences.dart';

import '../../../../core/constants/constant_values.dart';

abstract class NotificationsLocalDataSource {
  /// Caches the new status of the notifications toggle(whether notifications is enabled or not)
  Future<void> cacheNotificationsStatus({required bool isEnabled});

  Future<bool> getNotificationsStatus();
}

class AppNotificationsLocalDataSource extends NotificationsLocalDataSource {
  final SharedPreferences preferences;

  AppNotificationsLocalDataSource({required this.preferences});

  @override
  Future<void> cacheNotificationsStatus({required bool isEnabled}) async {
    await preferences.setBool(
      ConstantValues.isNotificationsEnabledKey,
      isEnabled,
    );
  }

  @override
  Future<bool> getNotificationsStatus() async {
    return preferences.getBool(ConstantValues.isNotificationsEnabledKey) ??
        false;
  }
}
