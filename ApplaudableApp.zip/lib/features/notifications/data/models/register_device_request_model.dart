import 'package:json_annotation/json_annotation.dart';

part 'register_device_request_model.g.dart';

@JsonSerializable(
  fieldRename: FieldRename.snake,
  includeIfNull: false,
)
class RegisterDeviceRequestModel {
  final String name;
  final String deviceId;
  final String registrationId;
  final String type;

  RegisterDeviceRequestModel({
    required this.name,
    required this.deviceId,
    required this.registrationId,
    required this.type,
  });

  factory RegisterDeviceRequestModel.fromJson(Map<String, Object?> json) =>
      _$RegisterDeviceRequestModelFromJson(json);

  Map<String, Object?> toJson() => _$RegisterDeviceRequestModelToJson(this);

  Map<String, Object> get toMap {
    Map<String, Object?> m = toJson();
    Map<String, Object> request = {};

    m.forEach((key, value) => request.putIfAbsent(key, () => value!));
    return request;
  }
}
