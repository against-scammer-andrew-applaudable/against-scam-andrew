import 'dart:convert';

import '../../../../core/utils/json.dart';
import '../../../../core/serializers/date_serializer.dart';
import '../../domain/entities/notification.dart';
import '../../domain/enums/notification_enums.dart';

class NotificationModel extends Notification {
  const NotificationModel({
    required super.id,
    super.type,
    super.createdAt,
    super.actors,
    super.target,
    super.scope,
    super.metadata,
  });

  factory NotificationModel.fromMessage(data) {
    Map<String, Object?> json =
        jsonDecode(data["json"]) as Map<String, Object?>;

    return NotificationModel.fromJson(json);
  }

  factory NotificationModel.fromJson(Map<String, dynamic> parsedJson) {
    final DateTime createdAt = jsonConverterFromJson<String, DateTime>(
            parsedJson['created_at'],
            const OptionalDateSerializer().fromJson) ??
        DateTime.now();

    return NotificationModel(
      id: "id${createdAt.millisecondsSinceEpoch}",
      createdAt: createdAt,
      type: NotificationType.getTypeByName(parsedJson['type']),
      actors: ((parsedJson['actors'] ?? []) as List<dynamic>)
          .map((e) => NotificationObjectModel.fromJson(e))
          .toList(),
      target: NotificationObjectModel.fromJson(parsedJson['target']),
      scope: parsedJson.containsKey("scope") && parsedJson['scope'] != null
          ? NotificationObjectModel.fromJson(parsedJson['scope'])
          : null,
      metadata: parsedJson['metadata'] is Map<String, dynamic> ? NotificationMetadata.fromJson(parsedJson['metadata']) : null,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
    };
  }
}

class NotificationObjectModel extends NotificationObject {
  NotificationObjectModel(
      {
        required super.id,
        super.type,
        super.name,
        super.icon,
      });

  factory NotificationObjectModel.fromJson(Map<String, dynamic> parsedJson) {
    return NotificationObjectModel(
      id: parsedJson['id'],
      type: NotificationObjectType.getTypeByName(parsedJson['type']),
      name: parsedJson['name'],
      icon: parsedJson['icon'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
    };
  }
}
