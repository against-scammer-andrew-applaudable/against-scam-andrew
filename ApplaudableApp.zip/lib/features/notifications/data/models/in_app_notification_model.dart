import 'package:applaudable/core/utils/app_utils.dart';
import 'package:applaudable/features/notifications/domain/enums/notification_enums.dart';

import '../../../../core/entities/pagination_response.dart';
import '../../domain/entities/in_app_notification.dart';
import '../../domain/entities/notification.dart';

class InAppNotificationsResponse
    extends PaginationResponse<InAppNotificationModel> {
  const InAppNotificationsResponse({
    required super.count,
    required super.next,
    required super.previous,
    required super.results,
  });

  factory InAppNotificationsResponse.fromJson(Map<String, dynamic> parsedJson) {
    return InAppNotificationsResponse(
      count: parsedJson['count'],
      next: parsedJson['next'],
      previous: parsedJson['previous'],
      results: ((parsedJson['results'] ?? []) as List<dynamic>)
          .map((e) => InAppNotificationModel.fromJson(e))
          .toList(),
    );
  }
}

class InAppNotificationModel extends InAppNotification {
  InAppNotificationModel({
    required super.id,
    required super.type,
    required super.createdAt,
    required super.actors,
    required super.target,
    required super.scope,
    required super.metadata,
    required super.title,
    required super.text,
    required super.viewed,
  });

  factory InAppNotificationModel.fromJson(Map<String, dynamic> parsedJson) {
    return InAppNotificationModel(
      id: parsedJson['id'],
      type: NotificationType.getTypeByName(parsedJson['type']),
      actors: ((parsedJson['actors'] ?? []) as List<dynamic>)
          .map((e) => ActorModel.fromJson(e))
          .toList(),
      target: ActorModel.fromJson(parsedJson['target']),
      scope: parsedJson['scope'] != null
          ? NotificationScopeModel.fromJson(parsedJson['scope'])
          : null,
      metadata: NotificationMetadata.fromJson(parsedJson['metadata'] ?? {}),
      title: getNullableString(parsedJson['title']) ?? "",
      text: getNullableString(parsedJson['text']) ?? "",
      viewed: parsedJson['viewed'],
      createdAt: parsedJson['created_at'] != null
          ? DateTime.parse(parsedJson['created_at'])
          : DateTime.now(),
    );
  }
  InAppNotificationModel copyWith(bool viewed) {
    return InAppNotificationModel(
      id: id,
      type: type,
      createdAt: createdAt,
      actors: actors,
      target: target,
      scope: scope,
      metadata: metadata,
      title: title,
      text: text,
      viewed: viewed,
    );
  }
  @override
  List<Object?> get props => [
        id,
        type,
        createdAt,
        actors,
        target,
        scope,
        metadata,
        title,
        text,
        viewed
      ];
}

class ActorModel extends Actor {
  const ActorModel({
    required super.id,
    required super.type,
    required super.icon,
    required super.name,
  });

  factory ActorModel.fromJson(Map<String, dynamic> parsedJson) {
    return ActorModel(
      id: parsedJson['id'],
      type: parsedJson['type'],
      icon: parsedJson['icon'],
      name: parsedJson['name'],
    );
  }

  Map<String, dynamic> toJson() {
    return {'id': id, 'type': type, 'icon': icon, 'name': name};
  }

  @override
  List<Object?> get props => [id, type, icon, name];
}

class NotificationScopeModel extends NotificationScope {
  const NotificationScopeModel({
    required super.id,
    required super.type,
    required super.icon,
    required super.name,
  });

  factory NotificationScopeModel.fromJson(Map<String, dynamic> parsedJson) {
    return NotificationScopeModel(
      id: parsedJson['id'],
      type: parsedJson['type'],
      icon: parsedJson['icon'],
      name: parsedJson['name'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'type': type,
      'icon': icon,
      'name': name,
    };
  }

  @override
  List<Object?> get props => [id, type, icon, name];
}

// class NotificationMetadataModel extends NotificationMetadata {
//   const NotificationMetadataModel({
//     required super.circleId,
//     required super.postId,
//   });
//
//   factory NotificationMetadataModel.fromJson(Map<String, dynamic> parsedJson) {
//     return NotificationMetadataModel(
//       circleId: parsedJson['circle_id'],
//       postId: parsedJson['post_id'],
//     );
//   }
//
//   @override
//   List<Object?> get props => [circleId, postId];
// }
