/// Callback to handle on tap
///
/// this will receive the current [value]
typedef OnTapCallback<T> = void Function(T value);

/// Callback to handle on tap an item with index value
///
/// this will receive the current [value] and [index]
typedef OnTapItemIndexCallback<T> = void Function(T value, int index);

/// Callback to handle on tap with status
///
/// this will receive the current [value]
typedef OnTapCallbackStatus<T> = void Function(T value, bool status);

/// Callback to handle status changes
///
/// this will receive the current [value]
typedef OnStatusCallback<T> = void Function(T value);

/// Callback to handle status changes
///
/// this will receive the current [value]
typedef OnChangedCallback<T> = void Function(T value);

/// Callback to handle status changes
///
/// this will receive the current [value]
typedef OnStatusIndexedCallback<T> = void Function(T value, int index);

/// Callback to handle status changes
///
/// this will receive the current [value]
typedef OnTapCallback3<T, I> = void Function(T value, I item, int index);
