import 'package:flutter/material.dart';

import '../../../../generated/l10n.dart';

enum SnackbarType { success, error, info }

apdSnackBar({
  required BuildContext context,
  required String message,
  required SnackbarType type,
}) {
  final translations = S.of(context);

  return ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(message),
      backgroundColor: type == SnackbarType.error
          ? Colors.red[800]
          : type == SnackbarType.success
              ? Colors.green[800]
              : Colors.blue[800],
      duration: const Duration(seconds: 3),
      action: SnackBarAction(
        label: translations.ok,
        textColor: Colors.white,
        onPressed: () {},
      ),
    ),
  );
}
