import 'package:flutter/material.dart';

import '../../../../../core/theme/dimensions.dart';

class AppSideMargins extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? margin;
  final double? marginValue;

  const AppSideMargins({
    Key? key,
    required this.child,
    this.margin,
    this.marginValue,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin ??
          EdgeInsets.symmetric(
            horizontal: marginValue ?? AppDimensions.defaultSideMargin,
          ),
      child: child,
    );
  }
}
