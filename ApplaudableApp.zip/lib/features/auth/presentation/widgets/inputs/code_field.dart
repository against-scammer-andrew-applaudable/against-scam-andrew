import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../validator/validator_service.dart';
import '../../../../../core/theme/colors.dart';
import '../../../../../core/theme/styles.dart';

class AppCodeField extends StatefulWidget {
  final FocusNode focusNode;
  final Function(String) onChanged;
  final Function(String?) onSaved;
  final int index;
  final int size;
  final String code;
  final Function(String)? onPaste;

  const AppCodeField({
    Key? key,
    required this.focusNode,
    required this.onChanged,
    required this.onSaved,
    this.index = 0,
    this.size = 1,
    this.code = "",
    this.onPaste,
  }) : super(key: key);

  @override
  State<AppCodeField> createState() => _AppCodeFieldState();
}

class _AppCodeFieldState extends State<AppCodeField> {
  int _currentLength = 0;
  final _controller = TextEditingController();

  @override
  void initState() {
    _controller.addListener(_onTyping);

    _controller.text = widget.code;

    super.initState();
  }

  @override
  void dispose() {
    _controller.removeListener(_onTyping);
    _controller.dispose();

    super.dispose();
  }

  void _onTyping() {
    if (_controller.text.length - _currentLength > 1) {
      if (widget.onPaste != null) {
        final cursorPos = _controller.selection.baseOffset;

        widget.onPaste!(
          _controller.text.length == cursorPos
              ? _controller.text
                  .substring(_currentLength, _controller.text.length)
              : _controller.text.substring(0, _controller.text.length),
        );
      }
    }

    _currentLength = _controller.text.length;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 44,
      height: 56,
      margin: EdgeInsets.only(
          right: widget.size - 1 == widget.index ? 0.0 : 5.0, left: 0.0),
      child: TextFormField(
        key: Key("code-${widget.code}"),
        controller: _controller,
        focusNode: widget.focusNode,
        onChanged: (value) {
          if (value.length == 2) {
            final cursorPos = _controller.selection.baseOffset;
            _controller.text = cursorPos == 1 ? value[0] : value[1];
            _controller.selection =
                TextSelection.fromPosition(const TextPosition(offset: 1));
            widget.onChanged(_controller.text);
          }

          if (value.length <= 1) {
            widget.onChanged(_controller.text);
          }
        },
        inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'\d+'))],
        keyboardType: TextInputType.number,
        style: AppStyles.text1(color: context.textColor),
        textAlign: TextAlign.center,
        decoration: InputDecoration(
          isDense: true,
          filled: true,
          fillColor: AppColors.white,
          border: AppStyles.inputCodeBorder,
          enabledBorder: AppStyles.inputCodeBorder,
          focusedBorder: AppStyles.inputCodeBorder,
          disabledBorder: AppStyles.underlineInputBorder,
          errorBorder: AppStyles.underlineInputErrorBorder,
          focusedErrorBorder: AppStyles.underlineFocusedInputErrorBorder,
          contentPadding: const EdgeInsets.all(16),
          counterStyle: AppStyles.noText,
          errorStyle: AppStyles.noText,
        ),
        validator: (String? value) =>
            ValidatorService.hasText(value) ? null : '',
        onSaved: widget.onSaved,
      ),
    );
  }
}
