abstract class ItemEntity<T> {
  final T id;
  final String name;

  ItemEntity({required this.id, required this.name});

  String get value;
}
