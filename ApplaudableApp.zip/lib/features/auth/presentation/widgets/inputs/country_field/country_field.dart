import 'package:country_codes/country_codes.dart';
import 'package:flutter/material.dart';

import '../../../../../../core/extensions/build_context_extensions.dart';
import '../../../../../../generated/l10n.dart';
import '../../../validator/validator_service.dart';
import '../../sheet_views/bottom_sheet_view.dart';
import '../text_field.dart';
import 'country_sheet.dart';
import 'models/country_model.dart';
import 'providers/country_provider.dart';

class AppCountryField extends StatefulWidget {
  const AppCountryField({super.key, this.onSaved});

  final void Function(String?)? onSaved;

  @override
  State<AppCountryField> createState() => _AppCountryFieldState();
}

class _AppCountryFieldState extends State<AppCountryField> {
  late final S translations = S.of(context);
  late final CountryDetails details;

  final TextEditingController _countryController = TextEditingController();

  List<Country> countries = [];
  Country? selectedCountry;

  String getSelectedCountryText(Country result) {
    return "(${result.dialCode}) ${result.name}";
  }

  @override
  void initState() {
    loadCountries();

    details = CountryCodes.detailsForLocale();
    selectedCountry = Country(
      name: details.name ?? "",
      alpha2Code: details.alpha2Code,
      alpha3Code: details.alpha3Code,
      dialCode: details.dialCode,
      flagUri: "",
    );

    _countryController.text = getSelectedCountryText(selectedCountry!);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return AppTextField.country(
      labelText: translations.country,
      controller: _countryController,
      validator: (String? value) => ValidatorService.hasText(value) ? null : '',
      onTap: onCountryFieldTap,
      onSaved: (value) {
        if (widget.onSaved == null) {
          return;
        }
        widget.onSaved!(selectedCountry?.dialCode);
      },
    );
  }

  void onCountryFieldTap() async {
    final result = await BottomSheetView.show<Country>(
      context: context,
      sheet: CountrySheet(items: countries),
    );

    if (result == null) {
      if (mounted) context.unfocus();
      return;
    }

    selectedCountry = result;
    _countryController.text = getSelectedCountryText(result);
  }

  /// loads countries from [Countries.countryList] and selected Country
  void loadCountries({Country? previouslySelectedCountry}) {
    if (mounted) {
      List<Country> countries =
          CountryProvider.getCountriesData(countries: null);

      /*Country country = previouslySelectedCountry ??
          Utils.getInitialSelectedCountry(
            countries,
            widget.initialValue?.isoCode ?? '',
          );*/

      // Remove potential duplicates
      countries = countries.toSet().toList();

      /*final CountryComparator? countryComparator =
          widget.selectorConfig.countryComparator;
      if (countryComparator != null) {
        countries.sort(countryComparator);
      }*/

      setState(() {
        this.countries = countries;
        //this.country = country;
      });
    }
  }
}
