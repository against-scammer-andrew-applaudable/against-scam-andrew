import 'package:flutter/material.dart';

import '../../../../../../core/extensions/build_context_extensions.dart';
import '../../../../../../core/theme/colors.dart';
import '../../../../../../core/theme/styles.dart';
import '../../../../../../generated/l10n.dart';
import '../../../callbacks.dart';
import '../../sheet_views/bottom_sheet_view.dart';
import 'item.dart';

class SearchField extends StatelessWidget {
  const SearchField({
    Key? key,
    this.controller,
    this.focusNode,
    this.onChanged,
    this.onFieldSubmitted,
    this.onClear,
  }) : super(key: key);

  final TextEditingController? controller;
  final FocusNode? focusNode;
  final ValueChanged<String>? onChanged;
  final ValueChanged<String>? onFieldSubmitted;
  final VoidCallback? onClear;

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return TextFormField(
      cursorColor: AppColors.dark.withOpacity(0.8),
      controller: controller,
      focusNode: focusNode,
      keyboardType: TextInputType.number,
      onChanged: onChanged,
      onFieldSubmitted: onFieldSubmitted,
      decoration: InputDecoration(
        contentPadding: const EdgeInsets.only(bottom: -10.0),
        isDense: true,
        label: Text(translations.search),
        labelStyle: TextStyle(
          color: AppColors.dark.withOpacity(0.8),
        ),
        errorStyle: TextStyle(
          color: AppColors.dark.withOpacity(0.8),
          fontSize: 14,
        ),
        border: AppStyles.underlineInputBorder,
        focusedBorder: AppStyles.underlineInputBorder,
        suffixIconConstraints: const BoxConstraints(maxHeight: 10),
        suffix: IconButton(
          alignment: Alignment.centerRight,
          padding: const EdgeInsets.only(left: 8),
          iconSize: 16,
          icon: Icon(
            Icons.clear,
            size: 16,
            color: AppColors.dark.withOpacity(0.8),
          ),
          onPressed: () {
            controller?.clear();
            focusNode?.requestFocus();

            if (onClear != null) {
              onClear!();
            }
          },
        ),
      ),
    );
  }
}

class CountrySheet<T extends ItemEntity> extends BottomSheetView {
  const CountrySheet({Key? key, required this.items}) : super(key: key);

  final List<T> items;

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size.height * 0.90;

    final translations = S.of(context);

    return Container(
      color: AppColors.lightPeach,
      child: SizedBox(
        height: screenSize,
        child: SafeArea(
          child: Column(
            children: [
              SheetHeader(title: translations.country),
              Expanded(
                child: CountryListView(
                  items: items,
                  onChange: (value) => onChange(context, value),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void onChange(BuildContext context, Map<int, bool> selected) {}
}

class CountryListView<T extends ItemEntity> extends StatefulWidget {
  const CountryListView({
    Key? key,
    required this.items,
    required this.onChange,
    this.selectedItem,
  }) : super(key: key);

  final List<T> items;
  final T? selectedItem;
  final OnStatusCallback<Map<int, bool>> onChange;

  @override
  State<CountryListView<T>> createState() => _CountryListViewState<T>();
}

class _CountryListViewState<T extends ItemEntity>
    extends State<CountryListView<T>> {
  final TextEditingController editingController = TextEditingController();

  List<T> get items => widget.items;
  List<T> allItems = [];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        /// TODO: review Country Search UI
        /*Padding(
          padding: const EdgeInsets.only(right: 12, left: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: SearchField(
                  controller: editingController,
                  onChanged: (value) {
                    filterSearchResults(value);
                  },
                  onClear: () {
                    setState(() {
                      allItems
                        ..clear()
                        ..addAll(items);
                    });
                    context.unfocus();
                  },
                ),
              ),
            ],
          ),
        ),*/
        Expanded(
          child: ListView.separated(
            itemCount: items.length,
            itemBuilder: (context, index) {
              return ListTile(
                title: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 29),
                  child: Text(
                    items[index].name,
                    style: AppStyles.text2(color: AppColors.mediumGrey)
                        .copyWith(fontWeight: FontWeight.w400),
                  ),
                ),
                //subtitle: Text(items[index].value, style: AppStyles.text2(color: context.textColor)),
                onTap: () {
                  context.navigatorKey?.pop(items[index]);
                },
              );
            },
            separatorBuilder: (context, index) {
              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 30),
                width: MediaQuery.of(context).size.width - 60,
                height: 1,
                color: AppColors.darkPeach,
              );
            },
          ),
        ),
      ],
    );
  }

  void filterSearchResults(String query) {
    /*List<T> searchList = [];

    if (query.isNotEmpty) {
      for (var item in items) {
        if (item.name.contains(query)) {
          searchList.add(item);
        }
      }
    }

    setState(() {
      allItems
        ..clear()
        ..addAll(searchList.isNotEmpty ? searchList : items);
    });
    return;*/
  }
}
