import 'dart:developer';
import 'dart:math' as math;

import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../../../app_module.dart';
import '../../../../../core/controllers/text_controllers/post_description_text_controller.dart';
import '../../../../../core/extensions/app_module_extensions.dart';
import '../../../../../core/theme/colors.dart';
import '../../../../../core/theme/styles.dart';
import '../../../../../core/utils/app_regex.dart';
import '../../../../../core/utils/debouncer.dart';
import '../../../../../core/widgets/svg_icons.dart';
import '../../../../mentions/presentation/pages/add_mention_page.dart';
import '../../../domain/entities/user.dart';

enum AppTextFieldType {
  generic,
  email,
  password,
  country,
  birthdate,
  instagram
}

class AppTextField extends StatefulWidget {
  final AppTextFieldType textFieldType;

  final String initialValue;
  final String? labelText;
  final TextCapitalization textCapitalization;
  final TextInputType textInputType;
  final TextAlign? textAlign;
  final TextInputAction? textInputAction;
  final bool obscureText;
  final bool autoCorrect;
  final bool enableSuggestions;
  final bool isPassword;
  final bool readOnly;
  final TextEditingController? controller;
  final FocusNode? focusNode;
  final Widget? prefix;
  final Widget? suffix;
  final String? Function(String?)? validator;
  final void Function(String)? onChanged;
  final void Function(String?)? onSaved;
  final void Function()? onTap;
  final Color? fillColor;
  final Color? labelColor;
  final int? maxLines;
  final int? minLines;
  final bool alignLabelWithHint;
  final Color? textColor;
  final String? hintText;
  final Color? hintColor;
  final TextStyle? hintTextStyle;
  final int? maxLength;
  final BorderRadiusGeometry? borderRadius;

  final bool useDebouncer;
  final bool useDefaultHeight;

  final String prefixText;
  final TextStyle? prefixTextStyle;
  final bool enableMentions;
  final Function(int, String, String?)? onMentionAdded;
  final Function(int)? onMentionRemoved;
  final List<TextInputFormatter> inputFormatters;
  final InputBorder? border;
  final TextStyle? style;
  final EdgeInsetsGeometry? padding;

  const AppTextField({
    super.key,
    this.textFieldType = AppTextFieldType.generic,
    this.controller,
    this.initialValue = '',
    this.labelText,
    this.textCapitalization = TextCapitalization.sentences,
    this.textInputType = TextInputType.text,
    this.textInputAction = TextInputAction.next,
    this.obscureText = false,
    this.autoCorrect = true,
    this.enableSuggestions = true,
    this.prefix,
    this.suffix,
    this.focusNode,
    this.isPassword = false,
    this.readOnly = false,
    this.validator,
    this.onChanged,
    this.onSaved,
    this.onTap,
    this.fillColor,
    this.labelColor,
    this.maxLines = 1,
    this.minLines,
    this.alignLabelWithHint = false,
    this.textColor,
    this.hintText,
    this.hintColor,
    this.maxLength,
    this.useDebouncer = false,
    this.useDefaultHeight = true,
    this.prefixText = "",
    this.prefixTextStyle,
    this.enableMentions = false,
    this.onMentionAdded,
    this.onMentionRemoved,
    this.inputFormatters = const [],
    this.border,
    this.style,
    this.padding,
    this.textAlign,
    this.hintTextStyle,
    this.borderRadius,
  });

  const AppTextField.email({
    super.key,
    this.textFieldType = AppTextFieldType.email,
    this.controller,
    this.initialValue = '',
    this.labelText,
    this.textInputAction = TextInputAction.next,
    this.obscureText = false,
    this.enableSuggestions = true,
    this.readOnly = false,
    this.prefix,
    this.suffix,
    this.focusNode,
    this.isPassword = false,
    this.validator,
    this.onChanged,
    this.onSaved,
    this.onTap,
    this.fillColor,
    this.labelColor,
    this.maxLines = 1,
    this.minLines,
    this.alignLabelWithHint = false,
    this.textColor,
    this.hintText,
    this.hintColor,
    this.maxLength,
    this.useDebouncer = false,
    this.enableMentions = false,
    this.onMentionAdded,
    this.onMentionRemoved,
    this.inputFormatters = const [],
    this.border,
    this.style,
    this.padding,
    this.textAlign,
    this.hintTextStyle,
    this.borderRadius,
  })  : autoCorrect = false,
        useDefaultHeight = true,
        textCapitalization = TextCapitalization.none,
        textInputType = TextInputType.emailAddress,
        prefixText = "",
        prefixTextStyle = null;

  const AppTextField.password({
    super.key,
    this.textFieldType = AppTextFieldType.password,
    this.controller,
    this.initialValue = '',
    this.labelText,
    this.textInputType = TextInputType.text,
    this.textInputAction = TextInputAction.next,
    this.prefix,
    this.suffix,
    this.focusNode,
    this.isPassword = true,
    this.readOnly = false,
    this.validator,
    this.onChanged,
    this.onSaved,
    this.onTap,
    this.fillColor,
    this.labelColor,
    this.alignLabelWithHint = false,
    this.textColor,
    this.hintText,
    this.hintColor,
    this.maxLength,
    this.useDebouncer = false,
    this.enableMentions = false,
    this.onMentionAdded,
    this.onMentionRemoved,
    this.inputFormatters = const [],
    this.border,
    this.style,
    this.padding,
    this.textAlign,
    this.hintTextStyle,
    this.borderRadius,
  })  : obscureText = true,
        maxLines = 1,
        minLines = 1,
        autoCorrect = false,
        enableSuggestions = false,
        useDefaultHeight = true,
        textCapitalization = TextCapitalization.none,
        prefixText = "",
        prefixTextStyle = null;

  const AppTextField.country({
    super.key,
    this.textFieldType = AppTextFieldType.country,
    this.controller,
    this.initialValue = '',
    this.labelText,
    this.validator,
    this.onChanged,
    this.onSaved,
    this.onTap,
    this.fillColor,
    this.labelColor,
    this.maxLines = 1,
    this.minLines,
    this.alignLabelWithHint = false,
    this.textColor,
    this.hintText,
    this.hintColor,
    this.maxLength,
    this.useDebouncer = false,
    this.enableMentions = false,
    this.onMentionAdded,
    this.onMentionRemoved,
    this.inputFormatters = const [],
    this.border,
    this.style,
    this.padding,
    this.textAlign,
    this.hintTextStyle,
    this.borderRadius,
  })  : obscureText = false,
        autoCorrect = false,
        enableSuggestions = false,
        useDefaultHeight = true,
        textInputType = TextInputType.text,
        textInputAction = TextInputAction.next,
        textCapitalization = TextCapitalization.none,
        isPassword = false,
        readOnly = true,
        prefix = null,
        focusNode = null,
        suffix = null,
        prefixText = "",
        prefixTextStyle = null;

  const AppTextField.birthdate({
    super.key,
    this.textFieldType = AppTextFieldType.birthdate,
    this.controller,
    this.initialValue = '',
    this.labelText,
    this.validator,
    this.onChanged,
    this.onSaved,
    this.onTap,
    this.fillColor,
    this.labelColor,
    this.maxLines = 1,
    this.minLines,
    this.alignLabelWithHint = false,
    this.textColor,
    this.hintText,
    this.hintColor,
    this.maxLength,
    this.useDebouncer = false,
    this.enableMentions = false,
    this.onMentionAdded,
    this.onMentionRemoved,
    this.inputFormatters = const [],
    this.border,
    this.style,
    this.padding,
    this.textAlign,
    this.hintTextStyle,
    this.borderRadius,
  })  : obscureText = false,
        autoCorrect = false,
        enableSuggestions = false,
        useDefaultHeight = true,
        textInputType = TextInputType.text,
        textInputAction = TextInputAction.next,
        textCapitalization = TextCapitalization.none,
        isPassword = false,
        readOnly = true,
        prefix = null,
        focusNode = null,
        suffix = null,
        prefixText = "",
        prefixTextStyle = null;

  const AppTextField.instagram({
    super.key,
    this.controller,
    this.initialValue = '',
    this.labelText,
    this.validator,
    this.onChanged,
    this.onSaved,
    this.onTap,
    this.useDebouncer = false,
    this.enableMentions = false,
    this.onMentionAdded,
    this.onMentionRemoved,
    this.inputFormatters = const [],
    this.border,
    this.style,
    this.padding,
    this.textAlign,
    this.hintTextStyle,
    this.borderRadius,
  })  : textFieldType = AppTextFieldType.instagram,
        fillColor = null,
        labelColor = null,
        textColor = null,
        hintText = "",
        hintColor = null,
        maxLength = null,
        obscureText = false,
        autoCorrect = false,
        enableSuggestions = false,
        useDefaultHeight = true,
        alignLabelWithHint = false,
        textInputType = TextInputType.text,
        textInputAction = TextInputAction.next,
        textCapitalization = TextCapitalization.none,
        isPassword = false,
        readOnly = false,
        prefix = null,
        focusNode = null,
        suffix = null,
        maxLines = 1,
        minLines = 1,
        prefixText = "@",
        prefixTextStyle = null;

  const AppTextField.withMentions({
    super.key,
    this.controller,
    this.textFieldType = AppTextFieldType.generic,
    this.initialValue = '',
    this.labelText,
    this.textCapitalization = TextCapitalization.sentences,
    this.textInputType = TextInputType.text,
    this.textInputAction = TextInputAction.next,
    this.obscureText = false,
    this.autoCorrect = true,
    this.enableSuggestions = true,
    this.prefix,
    this.suffix,
    this.focusNode,
    this.isPassword = false,
    this.readOnly = false,
    this.validator,
    this.onChanged,
    this.onSaved,
    this.onTap,
    this.fillColor,
    this.labelColor,
    this.maxLines = 1,
    this.minLines,
    this.alignLabelWithHint = false,
    this.textColor,
    this.hintText,
    this.hintColor,
    this.maxLength,
    this.useDebouncer = false,
    this.useDefaultHeight = true,
    this.prefixText = "",
    this.prefixTextStyle,
    this.onMentionAdded,
    this.onMentionRemoved,
    this.inputFormatters = const [],
    this.border,
    this.style,
    this.padding,
    this.textAlign,
    this.hintTextStyle,
    this.borderRadius,
  })  : enableMentions = true,
        assert(controller is PostDescriptionTextController?);

  @override
  State<AppTextField> createState() => _AppTextFieldState();
}

class _AppTextFieldState extends State<AppTextField> {
  final Debouncer _debouncer = Debouncer(milliseconds: 450);
  late bool _obscureText = widget.obscureText;

  late final TextEditingController _controller;
  String _previousDesc = '';
  int _cursorPos = 0;

  void _toggleObscureText() {
    setState(() {
      _obscureText = !_obscureText;
    });
  }

  Widget? get suffix {
    switch (widget.textFieldType) {
      case AppTextFieldType.generic:
      case AppTextFieldType.email:
      case AppTextFieldType.password:
      case AppTextFieldType.birthdate:
      case AppTextFieldType.instagram:
        return widget.suffix;
      case AppTextFieldType.country:
        return IconButton(
          icon: SvgIcons.dropdownArrow,
          onPressed: widget.onTap,
        );
    }
  }

  @override
  void initState() {
    _controller = widget.controller ??
        (widget.enableMentions
            ? PostDescriptionTextController()
            : TextEditingController());

    if (widget.initialValue.isNotEmpty) {
      _controller.text = widget.initialValue;
    }

    _previousDesc = _controller.text;

    if (widget.enableMentions) {
      _controller.addListener(_onListeningToTextChanges);
    }

    super.initState();
  }

  void _onListeningToTextChanges() {
    try {
      _validateMentions(_controller.text);
    } catch (err) {
      log(err.toString());
      _isValidating = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    /*
    todo: wip
    if (Platform.isIOS) {
      return ConstrainedBox(
        constraints: const BoxConstraints(minHeight: 56),
        child: CupertinoTextFormFieldRow(
          key: widget.key,
          padding: EdgeInsets.zero,
          controller: _controller,
          keyboardType: widget.textInputType,
          textInputAction: widget.textInputAction,
          obscureText: _obscureText,
          autocorrect: widget.autoCorrect,
          enableSuggestions: widget.enableSuggestions,
          readOnly: widget.readOnly,
          validator: widget.validator,
          inputFormatters: widget.inputFormatters,
          onChanged: (value) {
            if (widget.useDebouncer) {
              _debouncer.run(() {
                if (widget.onChanged != null) widget.onChanged!(value);
              });
              return;
            }

            if (widget.onChanged != null) widget.onChanged!(value);
          },
          onSaved: widget.onSaved,
          selectionControls: CupertinoTextSelectionControls(),
          focusNode: widget.focusNode,
          onTap: () {
            if (widget.onTap != null) widget.onTap!();

            _cursorPos = _controller.selection.baseOffset;
          },
          style: widget.style ?? AppStyles.text2(color: widget.textColor),
          maxLines: widget.maxLines,
          minLines: widget.minLines,
          maxLength: widget.maxLength,
          decoration: BoxDecoration(
            color: widget.fillColor ?? AppColors.white,
          ),
        ),
      );
    }*/

    return ClipRRect(
      borderRadius: widget.borderRadius ?? BorderRadius.zero,
      child: ConstrainedBox(
        constraints: const BoxConstraints(minHeight: 56),
        child: TextFormField(
          key: widget.key,
          controller: _controller,
          textAlign: widget.textAlign ?? TextAlign.start,
          spellCheckConfiguration:
          CupertinoTextField.inferIOSSpellCheckConfiguration(
              const SpellCheckConfiguration()),
          autovalidateMode: AutovalidateMode.disabled,
          keyboardType: widget.textInputType,
          textInputAction: widget.textInputAction,
          obscureText: _obscureText,
          autocorrect: widget.autoCorrect,
          enableSuggestions: widget.enableSuggestions,
          readOnly: widget.readOnly,
          validator: widget.validator,
          inputFormatters: widget.inputFormatters,
          onChanged: (value) {
            if (widget.useDebouncer) {
              _debouncer.run(() {
                if (widget.onChanged != null) widget.onChanged!(value);
              });
              return;
            }

            if (widget.onChanged != null) widget.onChanged!(value);
          },
          onSaved: widget.onSaved,
          selectionControls: CupertinoTextSelectionControls(),
          focusNode: widget.focusNode,
          onTap: () {
            if (widget.onTap != null) widget.onTap!();

            _cursorPos = _controller.selection.baseOffset;
          },
          style: widget.style ?? AppStyles.text2(color: widget.textColor ?? context.textColor),
          maxLines: widget.maxLines,
          minLines: widget.minLines,
          maxLength: widget.maxLength,
          decoration: InputDecoration(
            //isDense: false,
            alignLabelWithHint: widget.alignLabelWithHint,
            filled: true,
            fillColor: widget.fillColor ?? context.backgroundColor,
            //isCollapsed: true,
            //floatingLabelBehavior: FloatingLabelBehavior.never,
            labelText: widget.labelText,
            labelStyle:
            AppStyles.text1(color: widget.labelColor ?? context.textColor)
                .copyWith(
              fontSize: 18,
            ),
            hintStyle: widget.hintTextStyle ?? AppStyles.text1(color: widget.hintColor ?? context.textColor)
                .copyWith(
              fontSize: 18,
            ),
            hintText: widget.hintText,
            floatingLabelStyle: AppStyles.textSmall(color: context.hintTextColor),
            border: widget.border ?? AppStyles.underlineInputBorder,
            enabledBorder: widget.border,
            focusedBorder: widget.border ?? AppStyles.underlineInputBorder,
            disabledBorder: widget.border,
            errorBorder: widget.border ?? AppStyles.underlineInputBorder,
            errorMaxLines: 100,
            focusedErrorBorder: widget.border ?? AppStyles.underlineInputBorder,
            // errorStyle: AppStyles.noText,
            contentPadding: widget.padding ??
                const EdgeInsets.symmetric(
                  vertical: 10.0,
                  horizontal: 16.0,
                ),
            prefixIcon: widget.prefix,
            suffixIcon: widget.isPassword
                ? IconButton(
              onPressed: _toggleObscureText,
              icon: Icon(
                _obscureText
                    ? Icons.visibility_outlined
                    : Icons.visibility_off_outlined,
                size: 22.5,
                color: AppColors.lightGrey,
              ),
            )
                : suffix,
            prefixText: widget.prefixText,
            prefixStyle: widget.prefixTextStyle ?? AppStyles.text2(color: context.textColor),
          ),
        ),
      ),
    );
  }

  bool _isValidating = false;

  Future<void> _validateMentions(value) async {
    // \u200b

    if (value.isEmpty || _isValidating) return;

    _isValidating = true;

    _cursorPos = _controller.selection.base.offset;
    if (_cursorPos == -1) {
      _isValidating = false;
      return;
    }

    if (_previousDesc.length == value.length + 1) {
      final allMatches = AppRegex.mentionRegex.allMatches(_previousDesc);
      for (int i = 0; i < allMatches.length; i++) {
        final match = allMatches.elementAt(i);

        if (_cursorPos >= match.start && _cursorPos <= match.end) {
          if (widget.onMentionRemoved != null) widget.onMentionRemoved!(i);

          _previousDesc =
              _previousDesc.replaceRange(match.start, match.end, '');
          _controller.text = _previousDesc;

          _controller.selection = TextSelection.fromPosition(
            TextPosition(
              offset: math.min(
                match.start,
                _controller.text.length,
              ),
            ),
          );
          break;
        }
      }
    }

    if (value == _previousDesc) {
      _isValidating = false;
      return;
    }

    _previousDesc = value;

    final lastLetter = value[_cursorPos == 0 ? _cursorPos : _cursorPos - 1];

    if (lastLetter == '@' || lastLetter == '#') {
      final user = await AppModule.I.navigateToNamed(AddMentionPage.routeName);
      if (user != null && user is HiveUser) {
        final leadingText = _controller.text.substring(0, _cursorPos - 1);
        final leadingMatches = AppRegex.mentionRegex.allMatches(leadingText);

        if (widget.onMentionAdded != null) {
          widget.onMentionAdded!(
              leadingMatches.length, user.id, user.mentionSource);
        }

        _previousDesc =
            value.replaceRange(_cursorPos - 1, _cursorPos, '${user.name} ');
        _controller.text = _previousDesc;

        _controller.selection = TextSelection.fromPosition(
          TextPosition(offset: _cursorPos - 1 + '${user.name} '.length),
        );
      } else {
        _previousDesc = value.replaceRange(_cursorPos - 1, _cursorPos, '');
        _controller.text = _previousDesc;
        _controller.selection = TextSelection.fromPosition(
          TextPosition(offset: _cursorPos - 1),
        );
      }
    }

    Future(() {
      _isValidating = false;
    });
  }

  @override
  void dispose() {
    if (widget.useDebouncer) {
      _debouncer.dispose();
    }

    if (widget.enableMentions) {
      _controller.removeListener(_onListeningToTextChanges);
    }

    super.dispose();
  }
}
