import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../../../core/extensions/build_context_extensions.dart';
import '../../../../../generated/l10n.dart';
import '../../validator/validator_service.dart';
import 'text_field.dart';

class AppBirthdateField extends StatefulWidget {
  const AppBirthdateField({
    super.key,
    required this.onSaved,
    this.initial,
    this.validator,
  });

  final void Function(DateTime) onSaved;
  final DateTime? initial;
  final String? Function(String?)? validator;

  @override
  State<AppBirthdateField> createState() => _AppBirthdateFieldState();
}

class _AppBirthdateFieldState extends State<AppBirthdateField> {
  late final S translations = S.of(context);

  final TextEditingController _textController = TextEditingController();

  DateTime? _birthDate;

  @override
  void initState() {
    super.initState();

    if (widget.initial != null) {
      _birthDate = widget.initial;
      _textController.text = DateFormat.yMd().format(_birthDate!);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppTextField.birthdate(
      labelText: translations.birthdate,
      controller: _textController,
      validator: widget.validator ??
          (String? value) => ValidatorService.hasText(value)
              ? null
              : translations.invalid_birthdate_msg,
      onTap: onTap,
      onSaved: (_) {
        if (_birthDate != null) {
          widget.onSaved(_birthDate!);
        }
      },
    );
  }

  void onTap() {
    _onDateOfBirthFocus();
  }

  void _onDateOfBirthFocus() {
    // max age= 100 years
    final DateTime firstDate =
        DateTime.now().subtract(const Duration(days: 365 * 100));
    // min age = 18 years
    final DateTime lastDate =
        DateTime.now().subtract(const Duration(days: 365 * 18));
    context
        .showAppDatePicker(
      initialDate: _birthDate ?? lastDate,
      firstDate: firstDate,
      lastDate: lastDate,
    )
        .then((DateTime? selectedDate) {
      if (selectedDate != null) {
        _birthDate = selectedDate;
        _textController.text = DateFormat.yMd().format(selectedDate);
      }
    });
  }
}
