import 'package:flutter/material.dart';

import '../../../../core/theme/colors.dart';
import '../../../../core/theme/styles.dart';

enum AppSnackBarMode {
  info,
  error,
  success,
}

class AppSnackBar {
  final ScaffoldMessengerState _scaffoldMessengerState;

  AppSnackBar(this._scaffoldMessengerState);

  Color _getBackgroundColor(AppSnackBarMode mode) {
    Color color = AppColors.white;
    switch (mode) {
      case AppSnackBarMode.info:
        color = AppColors.white;
        break;
      case AppSnackBarMode.success:
        color = AppColors.white;
        break;
      case AppSnackBarMode.error:
        color = AppColors.pink;
        break;
    }
    return color;
  }

  Color _getFontColor(AppSnackBarMode mode) {
    Color color = AppColors.dark;
    switch (mode) {
      case AppSnackBarMode.info:
        color = AppColors.dark;
        break;
      case AppSnackBarMode.success:
        color = AppColors.dark;
        break;
      case AppSnackBarMode.error:
        color = AppColors.white;
        break;
    }
    return color;
  }

  void show({
    required String message,
    AppSnackBarMode mode = AppSnackBarMode.info,
    bool neverExpire = false,
  }) {
    _scaffoldMessengerState.removeCurrentSnackBar();
    _scaffoldMessengerState.showSnackBar(
      SnackBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        duration:
            neverExpire ? const Duration(days: 1) : const Duration(seconds: 4),
        behavior: SnackBarBehavior.fixed,
        content: Container(
          decoration: BoxDecoration(
              color: _getBackgroundColor(mode),
              borderRadius: BorderRadius.circular(8.0),
              boxShadow: mode == AppSnackBarMode.info
                  ? [
                      const BoxShadow(
                        color: Color(0x33000000),
                        spreadRadius: -1,
                        blurRadius: 4,
                        offset: Offset(0, 2),
                      ),
                      const BoxShadow(
                        color: Color(0x1e000000),
                        offset: Offset(0, 1),
                        blurRadius: 10,
                        spreadRadius: 0,
                      ),
                      const BoxShadow(
                        color: Color(0x23000000),
                        offset: Offset(0, 4),
                        blurRadius: 5,
                        spreadRadius: 0,
                      ),
                    ]
                  : null),
          margin: const EdgeInsets.only(
            top: 0,
            bottom: 8.0,
          ),
          padding: const EdgeInsets.symmetric(
            vertical: 16.0,
            horizontal: 18.0,
          ),
          child: Text(
            message,
            style: AppStyles.text1(
              color: _getFontColor(mode),
            ),
          ),
        ),
      ),
    );
  }
}
