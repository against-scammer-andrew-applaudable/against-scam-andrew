import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:applaudable/core/utils/app_utils.dart';
import 'package:flutter/material.dart';

import '../../../../../core/theme/colors.dart';
import '../../../../../core/theme/styles.dart';

class SheetHeader extends StatelessWidget {
  const SheetHeader({Key? key, this.title = ""}) : super(key: key);

  final String title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 29, top: 28, bottom: 26, right: 30),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: AppStyles.header2(color: context.textColor).copyWith(fontSize: 20)),
          InkWell(
            onTap: () => Navigator.of(context).pop(),
            child: const Icon(
              Icons.close,
              color: Colors.black,
            ),
          ),
        ],
      ),
    );
  }
}

abstract class BottomSheetView extends StatelessWidget {
  const BottomSheetView({Key? key}) : super(key: key);

  double getViewHeight(BuildContext context) {
    return MediaQuery.of(context).size.height / 2;
  }

  static Future<T?> show<T>({
    required BuildContext context,
    required BottomSheetView sheet,
    bool dismissible = true,
    BorderRadius? corner,
  }) async {
    corner ??= BorderRadius.circular(8.0);

    return await showModalBottomSheet(
      context: AppUtils().tabContext ?? context,
      backgroundColor: AppColors.peach,
      isScrollControlled: true,
      enableDrag: dismissible,
      shape: RoundedRectangleBorder(borderRadius: corner),
      isDismissible: dismissible,
      builder: (_) {
        return Padding(
          padding: MediaQuery.of(context).viewInsets,
          child: sheet,
        );
      },
    );
  }
}
