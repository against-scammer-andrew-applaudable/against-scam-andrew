import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../../generated/l10n.dart';

enum Type { phone, password, date, email }

// @Deprecated("")
// ignore: must_be_immutable
class APDTextField extends StatefulWidget {
  String? hint;
  bool? borders;
  String? dialCode;
  TextEditingController? controller;
  String Function(String?)? onValidate;
  Type? keyboardType;
  bool readOnly = false;
  bool dateTime = false;
  bool password = false;
  VoidCallback? onTap;
  Function(String?)? onSave;

  APDTextField({
    super.key,
    this.hint,
    this.onSave,
    this.keyboardType,
    this.borders,
    this.onTap,
    this.dialCode,
    this.onValidate,
    required this.dateTime,
    this.controller,
    required this.password,
    required this.readOnly,
  });

  APDTextField.password({
    Key? key,
    this.borders,
    this.dialCode,
    this.controller,
    this.onValidate,
    this.hint,
    this.readOnly = true,
  }) : super(key: key);

  @override
  State<APDTextField> createState() => _APDTextFieldState();
}

class _APDTextFieldState extends State<APDTextField> {
  late bool _password = widget.password;

  void _toggleObscureText() {
    setState(() {
      _password = !_password;
    });
  }

  TextInputType get getKeyboardType {
    TextInputType type;
    switch (widget.keyboardType) {
      case Type.date:
        return type = TextInputType.datetime;
      case Type.phone:
        return type = TextInputType.phone;
      case Type.email:
        return type = TextInputType.emailAddress;
      case Type.password:
        return type = TextInputType.visiblePassword;

      default:
        type = TextInputType.text;
    }
    return type;
  }

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Container(
        decoration: BoxDecoration(
            border: widget.borders! ? Border.all(color: Colors.black38) : null,
            color: Colors.white,
            borderRadius: BorderRadius.circular(5)),
        padding: const EdgeInsets.all(8.0),
        child: TextFormField(
          onSaved: widget.onSave,
          validator: widget.onValidate,
          keyboardType: getKeyboardType,
          controller: widget.controller,
          inputFormatters: [
            if (widget.keyboardType == Type.phone)
              FilteringTextInputFormatter.digitsOnly
          ],
          readOnly: widget.readOnly,
          obscureText: _password,
          decoration: InputDecoration(
            filled: true,
            fillColor: Colors.white,
            suffixIcon: widget.dateTime
                ? IconButton(
                    onPressed: widget.onTap,
                    icon: const Icon(Icons.calendar_today))
                : widget.password
                    ? IconButton(
                        onPressed: _toggleObscureText,
                        icon: Icon(
                          _password ? Icons.visibility_off : Icons.visibility,
                        ),
                      )
                    : null,
            prefixIcon: widget.dialCode != null
                ? Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          translations.country,
                          style: const TextStyle(
                            color: Colors.black45,
                            fontSize: 12,
                            fontWeight: FontWeight.w300,
                          ),
                        ),
                        Text(
                          "(${widget.dialCode})",
                          style: const TextStyle(
                            color: Colors.black45,
                            fontSize: 12,
                            fontWeight: FontWeight.w300,
                          ),
                        ),
                      ],
                    ),
                  )
                : null,
            hintText: widget.hint,
            focusedBorder: InputBorder.none,
            border: InputBorder.none,
          ),
        ),
      ),
    );
  }
}
