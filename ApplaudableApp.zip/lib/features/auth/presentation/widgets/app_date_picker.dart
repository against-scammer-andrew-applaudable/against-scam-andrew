import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class AppDatePicker extends StatefulWidget {
  const AppDatePicker({super.key});

  @override
  State<AppDatePicker> createState() => _AppDatePickerState();
}

class _AppDatePickerState extends State<AppDatePicker> {
  @override
  Widget build(BuildContext context) {
    if (Platform.isIOS) {
      return CupertinoDatePicker(
        mode: CupertinoDatePickerMode.date,
        onDateTimeChanged: (DateTime value) {
        },
      );
    } else {
      return DatePickerDialog(
        firstDate: DateTime.now().subtract(const Duration(days: 365 * 100)),
        initialDate: DateTime.now(),
        lastDate: DateTime.now().add(const Duration(days: 365)),
      );
    }
  }
}
