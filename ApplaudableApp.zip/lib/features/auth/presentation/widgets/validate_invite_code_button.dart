import 'package:flutter/material.dart';

import '../../../../app_module.dart';
import '../../../../core/bloc/widgets/base_stateless_page.dart';
import '../../../../core/bloc/widgets/dng_bloc_builder.dart';
import '../../../../core/extensions/app_module_extensions.dart';
import '../../../../core/theme/styles.dart';
import '../../../../core/widgets/toast/app_toast.dart';
import '../../../../generated/l10n.dart';
import '../../../../routes.dart';
import '../blocs/invite_code_bloc/invite_code_bloc.dart';
import '../ui/auth/signin/signin_page.dart';
import 'buttons/action_button.dart';

// ignore: must_be_immutable
class ValidateInviteCodeButton
    extends BaseStatelessPage<InviteCodeBloc, InviteCodeState> {
  final GlobalKey<FormState>? formKey;
  final TextEditingController inviteCodeController;

  ValidateInviteCodeButton({
    super.key,
    required this.inviteCodeController,
    this.formKey,
  });

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    registerBloc(context);

    return DNGBlocBuilder<InviteCodeBloc, InviteCodeState>(
      bloc: bloc,
      builder: (context, state) {
        return AppActionButton.submit(
          text: translations.confirmLabel,
          withArrowIcon: true,
          boxShadow: [
            AppShadows.submitButtonDefaultShadow,
          ],
          showLoading: state is InviteCodeLoadingState,
          onPressed: _performInviteCodeValidationEvent,
        );
      },
    );
  }

  void _performInviteCodeValidationEvent() {
    final isValid = formKey?.currentState?.validate() ?? false;

    if (isValid) {
      bloc.add(
        ValidateInviteCodeEvent(
          inviteCode: inviteCodeController.text.trim(),
        ),
      );
    }
  }

  @override
  Stream<InviteCodeState>? get onStateListener => bloc.stream;

  @override
  void onStateResultListener(BuildContext context, InviteCodeState state) {
    if (state is InviteCodeErrorState) {
      AppToast().build(context, state.message, mode: AppToastMode.error);
    } else if (state is InviteCodeValidatedState) {
      if (state.isValid) {
        AppModule.I.navigateToNamed(
          Routes.signIn,
          arguments: SignInPageArgs(
            inviteCode: inviteCodeController.text.trim(),
          ),
        );
      } else {
        AppToast().build(
          context,
          translations.invalid_invite_code_msg,
          mode: AppToastMode.error,
        );
      }
    }
  }
}
