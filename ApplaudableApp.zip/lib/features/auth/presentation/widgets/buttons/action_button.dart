import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:gradient_like_css/gradient_like_css.dart';

import '../../../../../core/theme/colors.dart';
import '../../../../../core/theme/dimensions.dart';
import '../../../../../core/theme/styles.dart';

class AppActionButton extends StatefulWidget {
  final String text;
  final Color backgroundColor;
  final bool showLoading;
  final bool withBorder;
  final bool withArrowIcon;
  final TextStyle? textStyle;
  final BorderRadius? borderRadius;
  final VoidCallback? onPressed;
  final bool enableGradient;
  final bool fitsFullWidth;
  final Widget? leadingIcon;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;
  final Color? actionTextColor;
  final TextDecoration? actionTextDecoration;
  final FontWeight actionTextWeight;
  final double? width;
  final double? height;
  final List<BoxShadow>? boxShadow;
  final Color? borderColor;
  final Color? splashColor;
  final double? actionTextSize;
  final Color loaderColor;
  final bool dependOnFieldController;
  final TextEditingController? fieldController;
  final bool Function()? enableWhen;

  const AppActionButton({
    Key? key,
    required this.text,
    this.backgroundColor = AppColors.white,
    this.showLoading = false,
    this.withBorder = false,
    this.textStyle,
    this.borderRadius,
    this.onPressed,
    this.enableGradient = true,
    this.fitsFullWidth = true,
    this.leadingIcon,
    this.padding,
    this.margin,
    this.actionTextColor,
    this.actionTextDecoration,
    this.actionTextWeight = FontWeight.w600,
    this.width,
    this.height,
    this.boxShadow,
    this.borderColor,
    this.splashColor,
    this.actionTextSize,
    this.loaderColor = AppColors.white,
    this.dependOnFieldController = false,
    this.fieldController,
    this.enableWhen,
    this.withArrowIcon = false,
  }) : super(key: key);

  AppActionButton.submit({
    super.key,
    required this.text,
    this.showLoading = false,
    this.backgroundColor = AppColors.pink,
    this.onPressed,
    this.enableGradient = true,
    this.borderRadius,
    this.fitsFullWidth = true,
    this.leadingIcon,
    this.padding,
    this.margin,
    this.actionTextColor,
    this.actionTextDecoration,
    this.actionTextWeight = FontWeight.w600,
    this.width,
    this.height,
    this.boxShadow,
    this.borderColor,
    this.splashColor,
    this.actionTextSize,
    this.loaderColor = AppColors.white,
    this.dependOnFieldController = false,
    this.fieldController,
    this.enableWhen,
    this.withArrowIcon = false,
  })  : textStyle = AppStyles.buttons(
          color: actionTextColor ?? AppColors.white,
        ).copyWith(
          decoration: actionTextDecoration,
          fontWeight: actionTextWeight,
          fontSize: actionTextSize,
        ),
        withBorder = false;

  AppActionButton.submitWithBorder({
    super.key,
    required this.text,
    this.showLoading = false,
    this.onPressed,
    this.borderRadius,
    this.fitsFullWidth = true,
    this.leadingIcon,
    this.padding,
    this.margin,
    this.actionTextColor,
    this.actionTextDecoration,
    this.actionTextWeight = FontWeight.w600,
    this.width,
    this.height,
    this.boxShadow,
    this.backgroundColor = AppColors.white,
    this.borderColor,
    this.splashColor,
    this.actionTextSize,
    this.loaderColor = AppColors.white,
    this.dependOnFieldController = false,
    this.fieldController,
    this.enableWhen,
    this.withArrowIcon = false,
  })  : withBorder = true,
        enableGradient = false,
        textStyle = AppStyles.buttons2(color: AppColors.dark).copyWith(
          decoration: actionTextDecoration,
          fontWeight: actionTextWeight,
          color: actionTextColor,
          fontSize: actionTextSize,
          height: 1,
        );

  @override
  State<AppActionButton> createState() => _AppActionButtonState();
}

class _AppActionButtonState extends State<AppActionButton> {
  bool _isEnabled = true;

  @override
  void initState() {
    if (widget.dependOnFieldController) {
      _isEnabled = _getCurrentEnableStatus();

      widget.fieldController?.addListener(_onFieldTextChanged);
    }

    super.initState();
  }

  @override
  void dispose() {
    if (widget.dependOnFieldController) {
      widget.fieldController?.removeListener(_onFieldTextChanged);
    }

    super.dispose();
  }

  void _onFieldTextChanged() {
    final status = _getCurrentEnableStatus();

    if (status != _isEnabled) {
      setState(() {
        _isEnabled = status;
      });
    }
  }

  bool _getCurrentEnableStatus() {
    if (widget.enableWhen != null) {
      log(widget.enableWhen!().toString());
      return widget.enableWhen!();
    } else if (widget.fieldController != null) {
      return widget.fieldController!.text.trim().isNotEmpty;
    }

    return true;
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(
        milliseconds: 450,
      ),
      width: widget.fitsFullWidth ? double.maxFinite : widget.width,
      height: widget.fitsFullWidth ? null : widget.height,
      margin: widget.margin,
      decoration: BoxDecoration(
        color: !_isEnabled || widget.onPressed == null
            ? widget.backgroundColor == AppColors.transparent
                ? widget.backgroundColor
                : widget.backgroundColor.withOpacity(0.5)
            : widget.backgroundColor,
        gradient: widget.enableGradient
            ? linearGradient(137.2, ['#E73D5F 35.06%', '#FE5B7C 92.93%'])
            : null,
        borderRadius: widget.borderRadius ??
            BorderRadius.circular(50),
        border: widget.withBorder
            ? Border.all(
                color: widget.borderColor ??
                    (!_isEnabled || widget.onPressed == null
                        ? AppColors.white.withOpacity(0.5)
                        : AppColors.lightGrey),
                width: 1.0,
              )
            : null,
        boxShadow: widget.boxShadow,
      ),
      child: TextButton(
        onPressed: !_isEnabled || widget.showLoading ? null : widget.onPressed,
        style: TextButton.styleFrom(
          padding: widget.padding ??
              const EdgeInsets.all(AppDimensions.defaultSidePadding),
          fixedSize: _calculateButtonSize(),
          shape: RoundedRectangleBorder(
            borderRadius: widget.borderRadius ??
                BorderRadius.circular(50),
          ),
          textStyle: widget.textStyle,
          foregroundColor: widget.actionTextColor ?? Colors.white,
        ),
        child: Center(
          child: widget.showLoading
              ? SizedBox(
                  width: 20.0,
                  height: 22.0,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.0,
                    valueColor:
                        AlwaysStoppedAnimation<Color>(widget.loaderColor),
                  ),
                )
              : Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (widget.leadingIcon != null)
                      Flexible(child: widget.leadingIcon!),
                    if (widget.leadingIcon != null &&
                        widget.text.trim().isNotEmpty)
                      const SizedBox(
                          width: AppDimensions.defaultIconButtonSidePadding),
                    Text(widget.text, style: widget.textStyle),
                    if (widget.withArrowIcon)
                      ...[
                        const SizedBox(width: 8,),
                        Icon(
                          Icons.arrow_forward_rounded,
                          color: widget.textStyle?.color,
                        )
                      ]
                  ],
                ),
        ),
      ),
    );
  }

  Size? _calculateButtonSize() {
    if (widget.fitsFullWidth) return const Size.fromWidth(double.maxFinite);

    if (widget.width != null && widget.height == null) {
      return Size.fromWidth(widget.width!);
    }

    if (widget.width == null && widget.height != null) {
      return Size.fromHeight(widget.height!);
    }

    if (widget.width != null && widget.height != null) {
      return Size(widget.width!, widget.height!);
    }

    return null;
  }
}
