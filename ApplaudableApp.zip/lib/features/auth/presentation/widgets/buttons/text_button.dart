import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';

import '../../../../../core/theme/colors.dart';
import '../../../../../core/theme/styles.dart';

class AppTextButton extends StatelessWidget {
  final String label;
  final String text;
  final TextStyle textStyle;
  final TextStyle? labelTextStyle;
  final VoidCallback onPressed;
  final bool hasLeftPadding;

  const AppTextButton({
    Key? key,
    required this.text,
    required this.textStyle,
    required this.onPressed,
    this.label = "",
    this.labelTextStyle,
    this.hasLeftPadding = true,
  }) : super(key: key);

  AppTextButton.normal({
    Key? key,
    required this.text,
    required this.onPressed,
    this.label = "",
    this.labelTextStyle,
    required BuildContext context,
  })  : textStyle = AppStyles.text2(color: context.textColor),
        hasLeftPadding = true,
        super(key: key);

  AppTextButton.underline({
    Key? key,
    required this.text,
    required this.onPressed,
    this.label = "",
  })  : textStyle = AppStyles.text2(
          color: AppColors.dark,
          isUnderlined: true,
        ),
        labelTextStyle = AppStyles.text2(
          color: AppColors.mediumGrey,
        ),
        hasLeftPadding = true,
        super(key: key);

  AppTextButton.appBar({
    Key? key,
    required BuildContext context,
    required this.text,
    required this.onPressed,
  })  : label = "",
        labelTextStyle = null,
        textStyle = AppStyles.text1(color: context.textColor),
        hasLeftPadding = true,
        super(key: key);

  AppTextButton.agreementText({
    Key? key,
    required this.text,
    required this.onPressed,
  })  : label = "",
        labelTextStyle = null,
        textStyle = AppStyles.textSmall(
          color: AppColors.dark,
          isUnderlined: true,
        ),
        hasLeftPadding = false,
        super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (label.isNotEmpty) Text(label, style: labelTextStyle),
        if (hasLeftPadding) const SizedBox(width: 3),
        Material(
          color: AppColors.transparent,
          child: InkWell(
            splashColor: AppColors.peach,
            onTap: onPressed,
            child: Text(text, style: textStyle),
          ),
        ),
      ],
    );
  }
}
