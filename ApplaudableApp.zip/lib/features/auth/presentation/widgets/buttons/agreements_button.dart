import 'package:applaudable/core/extensions/app_module_extensions.dart';
import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import '../../../../../app_module.dart';
import '../../../../../generated/l10n.dart';
import '../../../../../core/theme/styles.dart';
import '../../../../app_content/domain/enums/app_content_type.dart';
import '../../../../app_content/presentation/pages/app_content_page.dart';

class AppAgreementsButton extends StatelessWidget {
  const AppAgreementsButton({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final S translations = S.of(context);

    return RichText(
      textAlign: TextAlign.center,
      text: TextSpan(
        children: [
          TextSpan(
            text: '${translations.bySelecting} ',
            style: AppStyles.textSmall(color: context.hintTextColor),
          ),
          TextSpan(
            text: translations.termsOfService,
            style: AppStyles.textSmall(color: context.textColor, isUnderlined: true,),
            recognizer: TapGestureRecognizer()..onTap = () => _openAppContentPageOfType(AppContentType.about_us),
          ),
          TextSpan(
            text: ', ',
            style: AppStyles.textSmall(color: context.hintTextColor),
          ),
          TextSpan(
            text: translations.paymentsTermsOfService,
            style: AppStyles.textSmall(color: context.textColor, isUnderlined: true,),
            recognizer: TapGestureRecognizer()..onTap = () => _openAppContentPageOfType(AppContentType.terms_and_conditions),
          ),
          TextSpan(
            text: ', ',
            style: AppStyles.textSmall(color: context.hintTextColor),
          ),
          TextSpan(
            text: translations.privacyPolicy,
            style: AppStyles.textSmall(color: context.textColor, isUnderlined: true,),
            recognizer: TapGestureRecognizer()..onTap = () => _openAppContentPageOfType(AppContentType.faqs),
          ),
          TextSpan(
            text: ' ${translations.and} ',
            style: AppStyles.textSmall(color: context.hintTextColor),
          ),
          TextSpan(
            text: translations.nonDiscriminationPolicy,
            style: AppStyles.textSmall(color: context.textColor, isUnderlined: true,),
            recognizer: TapGestureRecognizer()..onTap = () => _openAppContentPageOfType(AppContentType.privacy),
          ),
          /*WidgetSpan(
            child: Text(
              '. ${translations.plus18Confirm}',
              style: AppStyles.textSmall(
                color: AppColors.white,
              ),
            ),
          ),*/
        ],
      ),
    );
  }
  void _openAppContentPageOfType(AppContentType type) {
    AppModule.I.navigateToNamed(
      AppContentPage.routeName,
      arguments: AppContentPageArgs(type: type),
    );
  }

}
