import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../../app_module.dart';
import '../../controllers/controller.dart';
import '../../presenters/base_statefull_stream.dart';

@Deprecated("")
abstract class BaseAppPage<A extends BasePage, B extends BaseCore>
    extends BaseState<A, B> {
  bool get showAppbar => true;

  String get appBarTitle => '';

  List<Widget> get appBarActions => [];

  bool get implyLeading => true;

  Widget? get appBarLeading => null;

  double? get appBarLeadingWidth => null;

  bool get extendBodyBehindAppBar => true;

  bool get extendBody => true;

  bool get centerContentOnPage => false;

  bool get hasPager => false;

  bool get isFullScrollPage => false;

  Widget get body;

  Widget get bottomNavigationBar => const SizedBox.shrink();

  Future<bool> onWillPop() => Future<bool>.value(true);

  late final ScrollController scrollController = ScrollController();
  // late final S translations = S.of(context);
  late final NavigatorState navigator =
      AppModule.instance.navigatorKey.currentState!;

  //TODO: When Available create App Snackbar to show error and success messages
  // late final AppSnackBar snackBar =
  //     AppSnackBar(scaffoldMessengerKey.currentState!);

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: onWillPop,
      child: Scaffold(
        backgroundColor: Colors.transparent,
        extendBodyBehindAppBar: extendBodyBehindAppBar,
        extendBody: extendBody,
        appBar: showAppbar
            ? PreferredSize(
                preferredSize: AppBar().preferredSize,
                child: Consumer<B>(
                  builder: (_, value, __) {
                    return AppBar(
                      automaticallyImplyLeading: implyLeading,
                      leading: appBarLeading,
                      leadingWidth: appBarLeadingWidth,
                      scrolledUnderElevation: 0,
                      title: appBarTitle.isEmpty
                          ? null
                          : Text(appBarTitle,
                              style: const TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold)),
                      actions: appBarActions,
                    );
                  },
                  child: AppBar(
                    automaticallyImplyLeading: implyLeading,
                    leading: appBarLeading,
                    leadingWidth: appBarLeadingWidth,
                    scrolledUnderElevation: 0,
                    title: appBarTitle.isEmpty
                        ? null
                        : Text(
                            appBarTitle,
                            style: const TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold),
                          ),
                    actions: appBarActions,
                  ),
                ),
              )
            : null,
        body: GestureDetector(
          onTap: () => context.owner!.focusManager.primaryFocus!.unfocus(),
          child: hasPager
              ? SafeArea(
                  top: !centerContentOnPage,
                  bottom: false,
                  child: Container(
                    alignment: centerContentOnPage
                        ? Alignment.center
                        : Alignment.topLeft,
                    child: body,
                  ),
                )
              : LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                  if (isFullScrollPage) {
                    return SafeArea(
                      bottom: false,
                      child: SizedBox(
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height,
                        child: body,
                      ),
                    );
                  }

                  return SingleChildScrollView(
                    controller: scrollController,
                    child: ConstrainedBox(
                      constraints: BoxConstraints(
                        minHeight: constraints.maxHeight,
                      ),
                      child: SafeArea(
                        top: !centerContentOnPage,
                        bottom: false,
                        child: Container(
                          alignment: centerContentOnPage
                              ? Alignment.center
                              : Alignment.topLeft,
                          child: body,
                        ),
                      ),
                    ),
                  );
                }),
        ),
        bottomNavigationBar: bottomNavigationBar,
      ),
    );
  }
}
