import 'package:flutter/material.dart';

import '../../../../core/widgets/svg_icons.dart';

class AppBackground extends StatelessWidget {
  final Widget child;
  final Widget? topLogo;
  final Widget? bottomLogo;
  final Widget? centerLogo;
  final bool fitTopWidth;
  final bool fitBottomWidth;
  final bool showTopLogo;
  final bool showBottomLogo;
  final bool showCenterLogo;

  const AppBackground({
    Key? key,
    required this.child,
    this.topLogo,
    this.bottomLogo,
    this.centerLogo,
    this.fitTopWidth = false,
    this.fitBottomWidth = false,
    this.showTopLogo = true,
    this.showBottomLogo = true,
    this.showCenterLogo = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        if (showTopLogo)
          Positioned(
            top: 0,
            right: 0,
            left: fitTopWidth ? 0 : null,
            child: topLogo ?? SvgIcons.topLogo,
          ),
        if (showCenterLogo)
          Positioned(
            top: 0,
            bottom: 0,
            left: 0,
            right: 0,
            child: centerLogo ?? SvgIcons.centerBGLogo(),
          ),
        if (showBottomLogo)
          Positioned(
            bottom: 0,
            left: 0,
            right: fitBottomWidth ? 0 : null,
            child: bottomLogo ?? SvgIcons.bottomLogo,
          ),
        Positioned.fill(child: child),
      ],
    );
  }
}
