part of 'invite_code_bloc.dart';

abstract class InviteCodeEvent extends Equatable {
  const InviteCodeEvent();
}

class ValidateInviteCodeEvent extends InviteCodeEvent {
  final String inviteCode;

  const ValidateInviteCodeEvent({required this.inviteCode});

  @override
  List<Object?> get props => [inviteCode];
}
