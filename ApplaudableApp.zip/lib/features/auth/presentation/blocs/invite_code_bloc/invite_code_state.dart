part of 'invite_code_bloc.dart';

abstract class InviteCodeState extends Equatable {
  const InviteCodeState();

  @override
  List<Object?> get props => [];
}

class InviteCodeInitialState extends InviteCodeState {}

class InviteCodeLoadingState extends InviteCodeState {}

class InviteCodeErrorState extends InviteCodeState {
  final String message;

  const InviteCodeErrorState({required this.message});

  @override
  List<Object?> get props => [message];
}

class InviteCodeValidatedState extends InviteCodeState {
  final bool isValid;

  const InviteCodeValidatedState({required this.isValid});

  @override
  List<Object?> get props => [isValid];
}

class InviteCodeDoNothingState extends InviteCodeState {}
