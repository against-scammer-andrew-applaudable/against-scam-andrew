import 'package:equatable/equatable.dart';

import '../../../../../core/bloc/dng_base_bloc.dart';
import '../../../domain/usecases/validate_invite_code.dart';

part 'invite_code_event.dart';
part 'invite_code_state.dart';

class InviteCodeBloc extends DNGBloc<InviteCodeEvent, InviteCodeState> {
  final ValidateInviteCode validateInviteCode;

  InviteCodeBloc({
    required this.validateInviteCode,
  }) : super(InviteCodeInitialState());

  @override
  void mapEventToState(InviteCodeEvent event) async {
    if (event is ValidateInviteCodeEvent) {
      await _handleValidateInviteCodeEvent(event);
    }
  }

  Future<void> _handleValidateInviteCodeEvent(
    ValidateInviteCodeEvent event,
  ) async {
    emit(InviteCodeLoadingState());

    final result = await validateInviteCode(event.inviteCode);

    emit(
      result.fold(
        (failure) => InviteCodeErrorState(message: failure.message),
        (isValid) => InviteCodeValidatedState(isValid: isValid),
      ),
    );

    emit(InviteCodeDoNothingState());
  }
}
