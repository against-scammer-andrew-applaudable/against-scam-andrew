import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../app_module.dart';
import '../../../../core/extensions/app_module_extensions.dart';
import '../../../../core/extensions/build_context_extensions.dart';
import '../../../../core/widgets/app_scaffold.dart';
import '../../../../core/widgets/svg_icons.dart';
import '../../../../generated/l10n.dart';
import '../../../../core/theme/styles.dart';
import '../widgets/snack_bar.dart';
import '../controllers/controller.dart';
import 'base_statefull_stream.dart';

abstract class BaseViewPage<A extends BasePage, B extends BaseCore>
    extends BaseState<A, B> {
  late final S translations = S.of(context);
  late final NavigatorState navigator =
      AppModule.instance.navigatorKey.currentState!;
  late final AppSnackBar snackBar =
      AppSnackBar(AppModule.instance.scaffoldMessengerKey.currentState!);

  get arguments => ModalRoute.of(context)!.settings.arguments;

  bool get showAppbar => true;

  String get appBarTitle => '';

  List<Widget> get appBarActions => [];

  bool get implyLeading => true;

  Widget? get appBarLeading => IconButton(
        icon: SvgIcons.backArrow(),
        onPressed: () {
          AppModule.I.pop();
        },
      );

  double? get appBarLeadingWidth => null;

  bool get extendBodyBehindAppBar => true;

  bool get extendBody => true;

  bool get centerContentOnPage => false;

  bool get hasPager => false;

  bool get isFullScrollPage => false;

  Widget get body;

  Widget get bottomNavigationBar => const SizedBox.shrink();


  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: true,
      child: Scaffold(
        extendBodyBehindAppBar: extendBodyBehindAppBar,
        extendBody: extendBody,
        appBar: showAppbar
            ? PreferredSize(
                preferredSize: AppBar().preferredSize,
                child: Consumer<B>(
                  builder: (_, value, __) {
                    return AppBar(
                      automaticallyImplyLeading: implyLeading,
                      leading: appBarLeading,
                      leadingWidth: appBarLeadingWidth,
                      scrolledUnderElevation: 0,
                      title: appBarTitle.isEmpty
                          ? null
                          : Text(
                              appBarTitle,
                              style: AppStyles.header2(color: context.textColor),
                            ),
                      actions: appBarActions,
                    );
                  },
                  child: AppBar(
                    automaticallyImplyLeading: implyLeading,
                    leading: appBarLeading,
                    leadingWidth: appBarLeadingWidth,
                    scrolledUnderElevation: 0,
                    title: appBarTitle.isEmpty
                        ? null
                        : Text(
                            appBarTitle,
                            style: AppStyles.header2(color: context.textColor),
                          ),
                    actions: appBarActions,
                  ),
                ),
              )
            : null,
        body: GestureDetector(
          onTap: () => context.unfocus(),
          child: centerContentOnPage
              ? SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                          height: MediaQuery.of(context).size.height,
                          width: MediaQuery.of(context).size.width,
                          child: body)
                    ],
                  ),
                )
              : body,
        ),
        bottomNavigationBar: bottomNavigationBar,
      ),
    );
  }
}

class BaseStatelessViewPage extends StatelessWidget {
  //late final S translations = S.of(context);
  late final NavigatorState navigator =
      AppModule.instance.navigatorKey.currentState!;
  late final AppSnackBar snackBar =
      AppSnackBar(AppModule.instance.scaffoldMessengerKey.currentState!);

  final Widget child;
  final bool centerContentOnPage;

  BaseStatelessViewPage(
      {super.key, required this.child, this.centerContentOnPage = true});

  //get arguments => ModalRoute.of(context)!.settings.arguments;

  bool get showAppbar => true;

  String get appBarTitle => '';

  List<Widget> get appBarActions => [];

  bool get implyLeading => true;

  Widget? get appBarLeading => IconButton(
        icon: SvgIcons.backArrow(),
        onPressed: () {
          AppModule.I.pop();
        },
      );

  double? get appBarLeadingWidth => null;

  bool get extendBodyBehindAppBar => true;

  bool get extendBody => true;

  bool get hasPager => false;

  bool get isFullScrollPage => false;

  Widget get bottomNavigationBar => const SizedBox.shrink();

  Future<bool> onWillPop() => Future<bool>.value(true);

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: onWillPop,
      child: AppScaffold(
        extendBodyBehindAppBar: extendBodyBehindAppBar,
        extendBody: extendBody,
        appBar: showAppbar
            ? PreferredSize(
                preferredSize: AppBar().preferredSize,
                child: AppBar(
                  automaticallyImplyLeading: implyLeading,
                  leading: appBarLeading,
                  leadingWidth: appBarLeadingWidth,
                  scrolledUnderElevation: 0,
                  title: appBarTitle.isEmpty
                      ? null
                      : Text(
                          appBarTitle,
                          style: AppStyles.header2(color: context.textColor),
                        ),
                  actions: appBarActions,
                ),
              )
            : null,
        body: GestureDetector(
          onTap: () => context.unfocus(),
          child: centerContentOnPage
              ? SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                          height: MediaQuery.of(context).size.height,
                          width: MediaQuery.of(context).size.width,
                          child: child)
                    ],
                  ),
                )
              : child,
        ),
        bottomNavigationBar: bottomNavigationBar,
      ),
    );
  }
}
