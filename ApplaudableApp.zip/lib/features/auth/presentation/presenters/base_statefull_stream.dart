import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../app_module.dart';
import '../controllers/controller.dart';
import '../results/base_result_stream.dart';

/// Base abstract class that extends [StatefulWidget]
///
abstract class BasePage extends StatefulWidget {
  const BasePage({Key? key}) : super(key: key);
}

/// BaseStreamService receives an [Bloc] instance
///
/// this will create a listener for every stream events pushed
/// into the [StreamSubscription]
///
/// then it will call [onStateListener] with the result stream
/// of the type [ResultStream]
///
/// on dispose from parent class will cancel the [StreamSubscription]
///
mixin BaseStreamService<Bloc extends BaseCore> {
  Bloc? _bloc;

  Bloc get bloc {
    //reset();
    return _bloc!;
  }

  Stream<BaseStream>? get onStateListener;

  StreamSubscription? _streamSubscription;
  StreamSubscription? _connectivitySubscription;

  StreamSubscription? get streamSubscription => _streamSubscription;

  void reset() {
    _bloc = bloc;
    initBloc(_bloc!);
    _listen(_bloc!);
  }

  void _listen(Bloc bloc) async {
    if (onStateListener == null) {
      return;
    }
    _streamSubscription?.cancel();
    _streamSubscription = onStateListener!.listen(onStateResultListener);

    if (_bloc!.onConnectivityListener != null) {
      _connectivitySubscription = _bloc!.onConnectivityListener!
          .listen(onConnectivityStateResultListener);
    }
  }

  onStateResultListener(BaseStream stream);

  // ignore: avoid_positional_boolean_parameters
  onConnectivityStateResultListener(bool hasConnection) {}

  void initBloc(Bloc bloc);

  void _dispose() {
    _streamSubscription?.cancel();
    _connectivitySubscription?.cancel();
  }
}

/// [BaseState] abstract class that receives two types:
/// [Page] extends a [BasePage]
/// and [Bloc] extends a [BaseService]
///
/// that will extends the State, The logic and internal
/// state for a [StatefulWidget].
///
/// * The [didChangeDependencies] method will be called again if the
///   inherited widgets subsequently change or if the widget moves in the tree.
///
///   Get the instance Provider Bloc and call [_listen] to listen to
///   the Stream changes
///
///   if the Provider Bloc if different from the [_bloc]
///   updates to use the new instance of the Provider
///
abstract class BaseState<Page extends BasePage, Bloc extends BaseCore>
    extends State<Page>
    with BaseStreamService<Bloc>, WidgetsBindingObserver, RouteAware {
  bool get notify => false;

  bool get disposeBloc => true;

  bool get isChildState => false;
  bool isRequesting = false;
  bool initialized = false;

  @override
  void initState() {
    super.initState();

    initialized = true;

    WidgetsBinding.instance
      ..addPostFrameCallback((timeStamp) {
        if (ModalRoute.of(context) != null) {
          AppModule.instance.routeObserver
              .subscribe(this, ModalRoute.of(context)!);
        }
      })
      ..addObserver(this);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final Bloc bloc = Provider.of<Bloc>(context, listen: notify);

    if (isChildState) {
      _bloc = bloc;
      initBloc(_bloc!);
      _listen(_bloc!);
      return;
    }

    if (bloc != _bloc) {
      if (_bloc != null) {
        _dispose();
      }

      _bloc = bloc;
      initBloc(_bloc!);
      _listen(_bloc!);
      return;
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {}

  void resume() {
    _dispose();

    _bloc = bloc;

    initBloc(_bloc!);
    _listen(_bloc!);
  }

  void resetListener() {
    _listen(bloc);
  }

  /// On dispose if the state is a child state
  /// dont dispose the bloc
  ///
  /// delegate all the dispose to the parent state
  @override
  void dispose() {
    if (!isChildState) {
      if (disposeBloc) {
        bloc.disposeBloc();
      }

      _dispose();
    }

    AppModule.instance.routeObserver.unsubscribe(this);
    WidgetsBinding.instance.removeObserver(this);

    super.dispose();
  }
}

/// Base child abstract class that extends [StatefulWidget]
abstract class BaseChildState<Page extends BasePage, Bloc extends BaseCore>
    extends BaseState<Page, Bloc> with RouteAware {
  @override
  bool get isChildState => true;

  @override
  Stream<BaseStream>? get onStateListener => _bloc!.onListener;
}
