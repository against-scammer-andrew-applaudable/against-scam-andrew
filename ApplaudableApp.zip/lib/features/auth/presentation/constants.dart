class Constants {
  /// To [noThrottle] means no throttling
  static int get noThrottle => 0;

  /// To [throttle05] means will throttle 500 milliseconds
  static int get throttle05 => 500;

  /// To [throttle1] means will throttle 1000 milliseconds
  static int get throttle1 => 1000;

  /// To [throttle2] means will throttle 3000 milliseconds
  static int get throttle2 => 2000;

  /// To [throttle3] means will throttle 3000 milliseconds
  static int get throttle3 => 3000;
}
