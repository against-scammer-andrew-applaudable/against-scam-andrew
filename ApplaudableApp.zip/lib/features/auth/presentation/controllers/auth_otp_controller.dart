import 'dart:async';

import 'package:flutter/material.dart';
import 'package:rxdart/rxdart.dart';

import '../api/auth_api.dart';
import '../results/base_result_stream.dart';
import 'controller.dart';

abstract class BaseAuthOTPController
    with BaseCore, BaseAuthApi, ChangeNotifier {}

class AuthOTPController extends BaseAuthOTPController with Core, AuthApi {
  @override
  Stream<BaseStream> get onListener => Rx.merge([onAuthListener]);

  @override
  disposeBloc() {
    disposeAuthApi();
  }
}
