import 'package:flutter/material.dart';
import 'package:rxdart/rxdart.dart';

import '../../domain/entities/user.dart';
import '../api/auth_api.dart';
import '../results/base_result_stream.dart';

abstract mixin class BaseCore {
  bool get isLoading;

  Stream<BaseStream> get onListener;

  Stream<bool>? get onConnectivityListener => null;

  getInitialData() {}

  void setIsLoading({
    required bool isLoading,
  });

  disposeBloc();
}

mixin Core on ChangeNotifier implements BaseCore {
  bool _isLoading = false;

  @override
  bool get isLoading => _isLoading;

  @override
  void setIsLoading({required bool isLoading}) {
    _isLoading = isLoading;
    notifyListeners();
  }
}

/// TODO:
///  ** [ ] implement BaseNotificationApi
///
abstract class BaseController with BaseCore, BaseAuthApi, ChangeNotifier {
  HiveUser? get currentUser;

  void updateCurrentUser({required HiveUser user});
  void updateAvatar({required String avatar});
  void updateUsername({required String username});
  void updateInvitationCode({required String invitationCode});

  void clear() {}
}

class Controller extends BaseController with Core, AuthApi {
  HiveUser? _user;

  @override
  HiveUser? get currentUser => _user;

  @override
  void updateCurrentUser({required HiveUser user}) {
    if (_user == null) {
      _user = user;
    } else {
      _user = _user!.copyWithUser(user);
    }
    notifyListeners();
  }

  @override
  void updateAvatar({required String avatar}) {
    _user?.avatar = avatar;
    notifyListeners();
  }

  @override
  void updateUsername({required String username}) {
    _user?.username = username;
    notifyListeners();
  }

  @override
  void  updateInvitationCode({required String invitationCode}) {
    _user?.invitationCode = invitationCode;
    notifyListeners();
  }

  @override
  Stream<BaseStream> get onListener =>
      // onNotificationListener
      Rx.merge([onAuthListener]);

  @override
  Stream<bool>? get onConnectivityListener => null;

  @override
  void clear() {
    _user = null;
  }

  @override
  void disposeBloc() {
    clear();
    disposeAuthApi();
  }
}
