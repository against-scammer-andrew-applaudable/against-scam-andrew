import 'dart:async';

import 'package:flutter/material.dart';
import 'package:rxdart/rxdart.dart';

import '../api/auth_api.dart';
import '../results/base_result_stream.dart';
import 'controller.dart';

abstract class BaseSignupController
    with BaseCore, BaseAuthApi, ChangeNotifier {}

class SignupController extends BaseSignupController with AuthApi, Core {
  @override
  Stream<BaseStream> get onListener => Rx.merge([onAuthListener]);

  @override
  disposeBloc() {
    disposeAuthApi();
  }
}
