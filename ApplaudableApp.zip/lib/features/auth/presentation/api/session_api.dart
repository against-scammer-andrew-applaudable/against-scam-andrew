import 'dart:async';

import '../../../../core/errors/repository_call_handler.dart';
import '../../data/repositories/auth_repository.dart';
import '../../../../core/api/services/remote_auth_service.dart';
import '../../data/datasources/local_source.dart';
import '../../data/datasources/remote_auth_data_source.dart';
import '../../domain/repositories/auth_repository.dart';
import '../../domain/entities/session.dart';
import '../../domain/usecases/get_session_use_case.dart';
import '../../../../injection_container.dart';
import '../results/auth/session_data_stream.dart';
import '../results/base_result_stream.dart';

abstract class BaseSessionApi {
  Stream<BaseStream> getSession();

  void disposeSessionApi();
}

mixin SessionApi implements BaseSessionApi {
  final AuthRepository _repository = AppAuthRepository(
    remoteDataSource: AppRemoteAuthDataSource(
      service: AppRemoteAuthService(),
    ),
    localDataSource: AppLocalDataSource.instance,
    callHandler: servLocator<RepositoryCallHandler>(),
  );

  /// Use Cases
  late final GetSessionUseCase _getSessionUseCase = GetSession(
    repository: _repository,
  );

  /// Actions
  @override
  Stream<BaseStream> getSession() async* {
    final Session? session = await _getSessionUseCase();
    yield SessionDataStream(
      state: session != null ? BaseStateEnum.success : BaseStateEnum.fail,
      data: session,
    );
  }

  /// Dispose
  @override
  void disposeSessionApi() {}
}
