import 'dart:async';

import 'package:rxdart/subjects.dart';

import '../../../../core/controllers/dng_links_controller.dart';
import '../../../../core/errors/repository_call_handler.dart';
import '../../data/repositories/auth_repository.dart';
import '../../../../core/api/services/remote_auth_service.dart';
import '../../data/datasources/local_source.dart';
import '../../data/datasources/remote_auth_data_source.dart';
import '../../domain/repositories/auth_repository.dart';
import '../../domain/entities/activate_account_request.dart';
import '../../domain/entities/login_request.dart';
import '../../domain/entities/recover_password_request.dart';
import '../../domain/entities/reset_password_request.dart';
import '../../domain/entities/session.dart';
import '../../domain/entities/signup_request.dart';
import '../../domain/usecases/activate_account_use_case.dart';
import '../../domain/usecases/get_session_use_case.dart';
import '../../domain/usecases/login_confirm_code_use_case.dart';
import '../../domain/usecases/login_use_case.dart';
import '../../domain/usecases/login_with_phone_number_use_case.dart';
import '../../domain/usecases/logout_use_case.dart';
import '../../domain/usecases/recover_password_use_case.dart';
import '../../domain/usecases/refresh_token_use_case.dart';
import '../../domain/usecases/reset_password_use_case.dart';
import '../../domain/usecases/singup_use_case.dart';
import '../../domain/usecases/verify_token_use_case.dart';
import '../../../../injection_container.dart';
import '../results/app_result.dart';
import '../results/auth/activate_account_data_stream.dart';
import '../results/auth/logout_data_stream.dart';
import '../results/auth/recover_password_data_stream.dart';
import '../results/auth/session_data_stream.dart';
import '../results/base_result_stream.dart';

abstract mixin class BaseAuthApi {
  Stream<BaseStream> get onAuthListener;

  Future<void> signUp({required SignUpRequest model});

  Future<void> signIn({required LoginRequest model});

  Future<void> signInWithPhoneNumber({
    required LoginWithPhoneNumberRequest model,
  });

  Future<void> signInConfirmCode({
    required SignInConfirmCodeRequest model,
  });

  Future<void> logout();

  Future<void> recoverPassword({required RecoverPasswordRequest model});

  Future<void> verifyToken();

  Future<void> activateAccount({
    required String uuid,
    required ActivateAccountRequest model,
  });

  Future<void> resetPassword({required ResetPasswordRequest model});

  Future<void> getSession();

  void disposeAuthApi();
}

mixin AuthApi implements BaseAuthApi {
  final AuthRepository _repository = AppAuthRepository(
    remoteDataSource: AppRemoteAuthDataSource(
      service: AppRemoteAuthService(),
    ),
    localDataSource: AppLocalDataSource.instance,
    callHandler: servLocator<RepositoryCallHandler>(),
  );

  /// Use Cases
  late final SignUpUseCase _signUpUseCase = SignUp(
    repository: _repository,
  );
  late final SignInUseCase _loginUseCase = SignIn(
    repository: _repository,
  );
  late final SignInWithPhoneNumberUseCase _loginWithPhoneNumberUseCase =
      SignInWithPhoneNumber(
    repository: _repository,
  );
  late final SignInConfirmCodeUseCase _signInConfirmCodeUseCase =
      SignInConfirmCode(
    repository: _repository,
  );

  late final LogoutUseCase _logoutUseCase = Logout(
    repository: _repository,
  );
  late final RecoverPasswordUseCase _recoverPasswordUseCase = RecoverPassword(
    repository: _repository,
  );
  late final VerifyTokenUseCase _verifyTokenUseCase = VerifyToken(
    repository: _repository,
  );
  late final RefreshTokenUseCase _refreshTokenUseCase = RefreshToken(
    repository: _repository,
  );
  late final GetSessionUseCase _getSessionUseCase = GetSession(
    repository: _repository,
  );
  late final ActivateAccountUseCase _activateAccountUseCase = ActivateAccount(
    repository: _repository,
  );
  late final ResetPasswordUseCase _resetPasswordUseCase = ResetPassword(
    repository: _repository,
  );

  /// Streams
  StreamController<BaseStream> _authStream = BehaviorSubject<BaseStream>();

  StreamSink get _authSink {
    if (_authStream.isClosed) {
      return (_authStream = BehaviorSubject<BaseStream>()).sink;
    }
    return _authStream.sink;
  }

  @override
  Stream<BaseStream> get onAuthListener => _authStream.stream;

  /// Actions
  @override
  Future<void> signIn({
    required LoginRequest model,
  }) async {
    _authSink.add(SessionDataStream(
      state: BaseStateEnum.request,
    ));

    final AppResult result = await _loginUseCase(
      model: model,
    );

    _authSink.add(
      SessionDataStream(
        state: result.isSuccess ? BaseStateEnum.success : BaseStateEnum.fail,
        data: result.isSuccess ? result.data : null,
        errorResponse: result.isSuccess ? null : result.data,
      ),
    );
  }

  @override
  Future<void> signInWithPhoneNumber({
    required LoginWithPhoneNumberRequest model,
  }) async {
    _authSink.add(SessionDataStream(
      state: BaseStateEnum.request,
    ));

    final AppResult result = await _loginWithPhoneNumberUseCase(
      model: model,
    );

    _authSink.add(
      SessionDataStream(
        state: result.isSuccess ? BaseStateEnum.success : BaseStateEnum.fail,
        data: result.isSuccess ? result.data : null,
        errorResponse: result.isSuccess ? null : result.data,
      ),
    );
  }

  @override
  Future<void> signInConfirmCode(
      {required SignInConfirmCodeRequest model}) async {
    _authSink.add(SessionDataStream(
      state: BaseStateEnum.request,
    ));

    final AppResult result = await _signInConfirmCodeUseCase(
      model: model,
    );

    _authSink.add(
      SessionDataStream(
        state: result.isSuccess ? BaseStateEnum.success : BaseStateEnum.fail,
        data: result.isSuccess ? result.data : null,
        errorResponse: result.isSuccess ? null : result.data,
      ),
    );
  }

  @override
  Future<void> logout() async {
    _authSink.add(LogoutDataStream(
      state: BaseStateEnum.request,
    ));

    final AppResult result = await _logoutUseCase();

    _authSink.add(
      LogoutDataStream(
        state: result.isSuccess ? BaseStateEnum.success : BaseStateEnum.fail,
      ),
    );
  }

  @override
  Future<void> signUp({
    required SignUpRequest model,
  }) async {
    _authSink.add(SessionDataStream(
      state: BaseStateEnum.request,
    ));

    final String inviteCode = await DngLinksController.I.checkInviteCode();
    if (inviteCode.isNotEmpty) {
      model.inviteCode = inviteCode;
    }

    final AppResult result = await _signUpUseCase(
      model: model,
    );

    if (result.isSuccess) {
      DngLinksController.I.remove(type: DngLinkType.invite);
    }

    _authSink.add(
      SessionDataStream(
        state: result.isSuccess ? BaseStateEnum.success : BaseStateEnum.fail,
        data: result.isSuccess ? result.data : null,
        errorResponse: result.isSuccess ? null : result.data,
      ),
    );
  }

  @override
  Future<void> recoverPassword({
    required RecoverPasswordRequest model,
  }) async {
    _authSink.add(RecoverPasswordDataStream(
      state: BaseStateEnum.request,
    ));

    final AppResult result = await _recoverPasswordUseCase(
      model: model,
    );

    _authSink.add(
      RecoverPasswordDataStream(
        state: result.isSuccess ? BaseStateEnum.success : BaseStateEnum.fail,
        errorResponse: result.isSuccess ? null : result.data,
      ),
    );
  }

  @override
  Future<void> verifyToken() async {
    _authSink.add(SessionDataStream(
      state: BaseStateEnum.request,
    ));

    Session? session = await _getSessionUseCase();
    if (session != null) {
      final AppResult verifyTokenResult = await _verifyTokenUseCase();

      if (verifyTokenResult.isSuccess) {
        _authSink.add(SessionDataStream(
          state: BaseStateEnum.success,
          data: session,
        ));
      } else {
        final AppResult refreshTokenResult = await _refreshTokenUseCase();
        if (refreshTokenResult.status == Status.error) {
          _repository.clear();
        }
        _authSink.add(
          SessionDataStream(
            state: refreshTokenResult.isSuccess
                ? BaseStateEnum.success
                : BaseStateEnum.fail,
            data: refreshTokenResult.isSuccess ? session : null,
            errorResponse:
                refreshTokenResult.isSuccess ? null : refreshTokenResult.data,
          ),
        );
      }
    } else {
      _repository.clear();
      _authSink.add(SessionDataStream(
        state: BaseStateEnum.fail,
      ));
    }
  }

  @override
  Future<void> activateAccount({
    required String uuid,
    required ActivateAccountRequest model,
  }) async {
    _authSink.add(ActivateAccountDataStream(
      state: BaseStateEnum.request,
    ));

    final AppResult result = await _activateAccountUseCase(
      uuid: uuid,
      model: model,
    );

    _authSink.add(
      ActivateAccountDataStream(
        state: result.isSuccess ? BaseStateEnum.success : BaseStateEnum.fail,
        data: result.isSuccess ? result.data : null,
        errorResponse: result.isSuccess ? null : result.data,
      ),
    );
  }

  @override
  Future<void> resetPassword({
    required ResetPasswordRequest model,
  }) async {
    _authSink.add(RecoverPasswordDataStream(
      state: BaseStateEnum.request,
    ));

    final AppResult result = await _resetPasswordUseCase(
      model: model,
    );

    _authSink.add(
      RecoverPasswordDataStream(
        state: result.isSuccess ? BaseStateEnum.success : BaseStateEnum.fail,
        errorResponse: result.isSuccess ? null : result.data,
      ),
    );
  }

  @override
  Future<void> getSession() async {
    _authSink.add(SessionDataStream(
      state: BaseStateEnum.request,
    ));

    final Session? session = await _getSessionUseCase();

    _authSink.add(
      SessionDataStream(
        state: session != null ? BaseStateEnum.success : BaseStateEnum.fail,
        data: session,
      ),
    );
  }

  /// Dispose
  @override
  void disposeAuthApi() {
    _authSink.close();
    _authStream.close();
  }
}
