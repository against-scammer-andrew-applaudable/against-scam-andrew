enum Status { success, error }

class AppResult<T> {
  final Status status;
  final T? data;
  final String? message;
  final int? count;

  AppResult.success([this.data, this.count])
      : status = Status.success,
        message = "";

  AppResult.failure([this.data, this.message])
      : status = Status.error,
        count = 0;

  bool get isSuccess => status == Status.success;

  @override
  String toString() {
    return 'AppResult{status: $status, data: $data, message: $message}';
  }
}
