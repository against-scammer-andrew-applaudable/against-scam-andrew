import '../../../../core/entities/error/error_response.dart';

enum BaseStateEnum {
  request,
  success,
  fail,
}

abstract class BaseStream<S, T> {
  /// [state] of the result
  final S state;

  /// [data] data that should receive, can be any type
  final T? data;

  /// [count] for how many items exists
  final int? count;

  /// Error message and code
  final ErrorResponse? errorResponse;

  BaseStream({
    required this.state,
    this.data,
    this.errorResponse,
    this.count = 0,
  });

  String? get errorResponseMessage => errorResponse?.message;

  String? get errorResponseCode => errorResponse?.code;
}
