import '../../../../../core/entities/error/error_response.dart';
import '../base_result_stream.dart';

class LogoutDataStream extends BaseStream<BaseStateEnum, void> {
  LogoutDataStream({
    required BaseStateEnum state,
    ErrorResponse? errorResponse,
  }) : super(
          state: state,
          data: null,
          errorResponse: errorResponse,
        );

  @override
  String toString() {
    return 'SessionDataStream {state: $state, error: $errorResponse}';
  }
}
