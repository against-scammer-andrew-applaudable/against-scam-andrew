import '../../../../../core/entities/error/error_response.dart';
import '../../../domain/entities/session.dart';
import '../base_result_stream.dart';

class SessionDataStream extends BaseStream<BaseStateEnum, Session> {
  SessionDataStream({
    required BaseStateEnum state,
    Session? data,
    ErrorResponse? errorResponse,
  }) : super(
          state: state,
          data: data,
          errorResponse: errorResponse,
        );

  @override
  String toString() {
    return 'SessionDataStream {data: $data, state: $state, error: $errorResponse}';
  }
}
