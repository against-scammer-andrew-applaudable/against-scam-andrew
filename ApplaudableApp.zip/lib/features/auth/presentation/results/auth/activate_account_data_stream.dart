import '../../../../../core/entities/error/error_response.dart';
import '../../../domain/entities/session.dart';
import '../base_result_stream.dart';

class ActivateAccountDataStream extends BaseStream<BaseStateEnum, Session> {
  ActivateAccountDataStream({
    required BaseStateEnum state,
    Session? data,
    ErrorResponse? errorResponse,
  }) : super(
          state: state,
          data: data,
          errorResponse: errorResponse,
        );

  @override
  String toString() {
    return 'SessionDataStream {state: $state, error: $errorResponse}';
  }
}
