import '../../../../../core/entities/error/error_response.dart';
import '../base_result_stream.dart';

class LoginWithPhoneResult extends BaseStream<BaseStateEnum, Object> {
  LoginWithPhoneResult({
    required BaseStateEnum state,
    Object? data,
    ErrorResponse? errorResponse,
  }) : super(
          state: state,
          data: data,
          errorResponse: errorResponse,
        );

  @override
  String toString() {
    return 'LoginWithPhoneResult {state: $state, error: $errorResponse}';
  }
}
