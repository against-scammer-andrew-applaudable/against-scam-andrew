import 'package:flutter/material.dart';

import '../../../../../domain/entities/signup_request.dart';
import '../../../../../../../generated/l10n.dart';
import '../../../../validator/validator_service.dart';
import '../../../../widgets/inputs/country_field/country_field.dart';
import '../../../../widgets/inputs/text_field.dart';
import '../signup_page.dart';

/// TODO:
///  ** [ ] expose callback for checking the email
///
class SignupStep2View extends StatefulWidget {
  final GlobalKey<FormState> formKey;
  final SignUpRequest request;
  final SignUpPageFlow flow;

  const SignupStep2View({
    super.key,
    required this.formKey,
    required this.request,
    this.flow = SignUpPageFlow.sms,
  });

  @override
  State<SignupStep2View> createState() => _SignupStep2ViewState();
}

class _SignupStep2ViewState extends State<SignupStep2View> {
  late final S translations = S.of(context);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        AppTextField(
          labelText: translations.username,
          autoCorrect: false,
          textCapitalization: TextCapitalization.none,
          validator: (String? value) => ValidatorService.hasText(value)
              ? null
              : translations.invalid_username_msg,
          onSaved: (String? value) {
            widget.request.username = value?.toLowerCase().trim();
            return;
          },
        ),
        const SizedBox(height: 17.0),
        if (widget.flow == SignUpPageFlow.sms) ...[
          AppTextField.email(
            labelText: translations.email,
            initialValue: widget.request.email ?? "",
            validator: (String? value) => ValidatorService.hasText(value)
                ? null
                : translations.invalid_email_msg,
            onSaved: (String? value) {
              widget.request.email = value?.toLowerCase().trim();
              return;
            },
          ),
        ],
        if (widget.flow == SignUpPageFlow.email) ...[
          AppCountryField(
            onSaved: (String? value) {
              widget.request.country = value;
              return;
            },
          ),
          const SizedBox(height: 17.0),
          AppTextField(
            labelText: translations.phoneNumber,
            autoCorrect: false,
            textCapitalization: TextCapitalization.none,
            textInputType: TextInputType.phone,
            validator: (String? value) => ValidatorService.hasText(value)
                ? null
                : translations.invalid_phone_msg,
            onSaved: (String? value) {
              widget.request.phoneNumber =
                  "${widget.request.country}${value?.toLowerCase().trim()}";
              return;
            },
          ),
        ],
        const SizedBox(height: 17.0),
        AppTextField.password(
          labelText: translations.password,
          initialValue: widget.request.password ?? "",
          validator: (String? value) => ValidatorService.hasText(value)
              ? null
              : translations.invalid_password_msg,
          onSaved: (String? value) {
            widget.request.password = value;
            return;
          },
        ),
      ],
    );
  }
}
