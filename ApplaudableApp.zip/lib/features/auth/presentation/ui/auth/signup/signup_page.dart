import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../../../app_module.dart';
import '../../../../../../core/extensions/app_module_extensions.dart';
import '../../../../../../core/extensions/build_context_extensions.dart';
import '../../../../../../core/widgets/toast/app_toast.dart';
import '../../../../domain/entities/session.dart';
import '../../../../domain/entities/signup_request.dart';
import '../../../../../onboarding/presentation/pages/add_profile_avatar_page.dart';
import '../../../controllers/signup_controller.dart';
import '../../../presenters/base_statefull_stream.dart';
import '../../../presenters/base_view_page.dart';
import '../../../results/auth/session_data_stream.dart';
import '../../../results/base_result_stream.dart';
import '../../../../../../routes.dart';
import '../../../../../../core/theme/colors.dart';
import '../../../../../../core/theme/styles.dart';
import '../../../widgets/buttons/action_button.dart';
import '../../../widgets/buttons/agreements_button.dart';
import '../../../widgets/sizing/side_margins.dart';
import 'steps/step1_view.dart';
import 'steps/step2_view.dart';

enum SignUpPageStep { page1, page2 }

enum SignUpPageFlow { sms, email }

class SignUpPageArgs {
  final SignUpPageStep step;
  final SignUpPageFlow flow;

  final SignUpRequest request;

  SignUpPageArgs({
    this.step = SignUpPageStep.page1,
    this.flow = SignUpPageFlow.sms,
    required this.request,
  });
}

class SignUpPage extends BasePage {
  const SignUpPage({
    Key? key,
  }) : super(key: key);

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends BaseViewPage<SignUpPage, BaseSignupController> {
  late final SignUpPageArgs args = arguments as SignUpPageArgs;

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  SignUpRequest get signUpRequest => args.request;
  SignUpPageStep get step => args.step;

  @override
  bool get centerContentOnPage => true;

  String get buttonLabel {
    switch (step) {
      case SignUpPageStep.page1:
        return translations.buttonNextLabel;
      case SignUpPageStep.page2:
        return translations.buttonAgreeAndComplete;
    }
  }

  void _submitForm() {
    if (!_formKey.currentState!.validate()) {
      AppModule.I.notify(
        context,
        translations.formValidationError,
        mode: AppToastMode.error,
      );
    } else {
      _formKey.currentState!.save();

      switch (step) {
        case SignUpPageStep.page1:
          Navigator.of(context).pushNamed(
            Routes.completeSignup,
            arguments: SignUpPageArgs(
              step: SignUpPageStep.page2,
              flow: args.flow,
              request: signUpRequest,
            ),
          );
          break;
        case SignUpPageStep.page2:
          bloc.signUp(model: signUpRequest);
          break;
      }
    }
  }

  @override
  Widget get body => AppSideMargins(
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                translations.signUp,
                style: AppStyles.header1(color: context.textColor),
              ),
              const SizedBox(
                height: 8.0,
              ),
              Text(
                translations.signupNoAccountWithPhoneNumberLabel,
                style: AppStyles.text2(color: AppColors.mediumGrey),
              ),
              const SizedBox(
                height: 30.0,
              ),
              if (step == SignUpPageStep.page1)
                SignupStep1View(formKey: _formKey, request: signUpRequest),
              if (step == SignUpPageStep.page2)
                SignupStep2View(
                    formKey: _formKey, request: signUpRequest, flow: args.flow),
              const SizedBox(
                height: 47.0,
              ),
              Consumer<BaseSignupController>(
                builder: (_, data, __) => AppActionButton.submit(
                  text: buttonLabel,
                  showLoading: data.isLoading,
                  onPressed: _submitForm,
                ),
              ),
              if (args.step == SignUpPageStep.page2) ...[
                const SizedBox(
                  height: 18.0,
                ),
                const AppAgreementsButton(),
              ]
            ],
          ),
        ),
      );

  @override
  void initBloc(BaseSignupController bloc) {}

  @override
  Stream<BaseStream>? get onStateListener => bloc.onListener;

  @override
  onStateResultListener(BaseStream stream) {
    if (stream is SessionDataStream) {
      switch (stream.state) {
        case BaseStateEnum.request:
          bloc.setIsLoading(
            isLoading: true,
          );
          break;
        case BaseStateEnum.success:
          bloc.setIsLoading(
            isLoading: false,
          );

          if (stream.data is Session) {
            context.baseController.updateCurrentUser(
              user: stream.data!.user,
            );
          }
          Navigator.of(context).pushNamedAndRemoveUntil(
            AddProfileAvatarPage.routeName,
            (Route route) => false,
          );

          break;
        case BaseStateEnum.fail:
          bloc.setIsLoading(
            isLoading: false,
          );
          AppModule.I.notify(
            context,
            stream.errorResponseMessage ?? translations.generalError,
            mode: AppToastMode.error,
          );
          break;
      }
    }
  }

  // void _openAppContentPageOfType(AppContentType type) {
  //   AppModule.I.navigateToNamed(
  //     AppContentPage.routeName,
  //     arguments: AppContentPageArgs(type: type),
  //   );
  // }
}
