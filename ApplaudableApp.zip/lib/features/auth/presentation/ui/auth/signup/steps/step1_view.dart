import 'package:flutter/material.dart';

import '../../../../../domain/entities/signup_request.dart';
import '../../../../../../../generated/l10n.dart';
import '../../../../validator/validator_service.dart';
import '../../../../widgets/inputs/birthdate_field.dart';
import '../../../../widgets/inputs/text_field.dart';

/// TODO:
///  ** [ ] expose callback for checking the username
///
class SignupStep1View extends StatefulWidget {
  final GlobalKey<FormState> formKey;
  final SignUpRequest request;

  const SignupStep1View({
    super.key,
    required this.formKey,
    required this.request,
  });

  @override
  State<SignupStep1View> createState() => _SignupStep1ViewState();
}

class _SignupStep1ViewState extends State<SignupStep1View> {
  late final S translations = S.of(context);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        AppTextField(
          labelText: translations.name,
          autoCorrect: false,
          textCapitalization: TextCapitalization.none,
          validator: (String? value) => ValidatorService.hasText(value)
              ? null
              : translations.invalid_name_msg,
          onSaved: (String? value) {
            widget.request.name = value;
            return;
          },
        ),
        const SizedBox(height: 17.0),
        AppTextField.instagram(
          labelText: translations.instagramHandlerLabel,
          onSaved: (String? value) {
            widget.request.instagramHandler = value?.toLowerCase().trim();
            return;
          },
        ),
        const SizedBox(height: 17.0),
        AppBirthdateField(
          onSaved: (DateTime? value) {
            widget.request.birthDate = value;
            return;
          },
        ),
      ],
    );
  }
}
