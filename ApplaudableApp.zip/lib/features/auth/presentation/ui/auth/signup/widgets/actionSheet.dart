import 'package:flutter/cupertino.dart';

import '../../../../../../../generated/l10n.dart';

apdActionSheet({
  required BuildContext context,
  VoidCallback? takePhoto,
  VoidCallback? pickFromGallery,
}) {
  final translations = S.of(context);

  showCupertinoModalPopup(
    context: context,
    builder: (context) => CupertinoActionSheet(
      title: Text(translations.choose_a_photo),
      actions: [
        CupertinoActionSheetAction(
          onPressed: takePhoto!,
          child: Text(translations.take_a_photo),
        ),
        CupertinoActionSheetAction(
          onPressed: pickFromGallery!,
          child: Text(translations.choose_from_gallery),
        ),
      ],
      cancelButton: CupertinoActionSheetAction(
        child: Text(translations.cancel),
        onPressed: () {
          Navigator.pop(context);
        },
      ),
    ),
  );
}
