import 'package:flutter/material.dart';

import '../../../../../domain/entities/login_request.dart';
import '../../../../../../../generated/l10n.dart';
import '../../../../validator/validator_service.dart';
import '../../../../widgets/inputs/text_field.dart';

/// TODO:
///  ** [ ] expose callback for checking the email
///
class SignInStep1View extends StatefulWidget {
  final GlobalKey<FormState> formKey;
  final LoginRequest request;

  const SignInStep1View({
    super.key,
    required this.formKey,
    required this.request,
  });

  @override
  State<SignInStep1View> createState() => _SignInStep1ViewState();
}

class _SignInStep1ViewState extends State<SignInStep1View> {
  late final S translations = S.of(context);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        AppTextField.email(
          labelText: translations.email,
          validator: (String? value) =>
              ValidatorService.isEmailValid(value) ? null : '',
          onSaved: (String? value) {
            widget.request.email = value?.toLowerCase().trim();
            return;
          },
        ),
      ],
    );
  }
}
