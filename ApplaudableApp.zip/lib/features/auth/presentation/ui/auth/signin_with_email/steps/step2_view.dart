import 'package:flutter/material.dart';

import '../../../../../domain/entities/login_request.dart';
import '../../../../../../../generated/l10n.dart';
import '../../../../validator/validator_service.dart';
import '../../../../widgets/inputs/text_field.dart';

/// TODO:
///  ** [ ] expose callback for checking the email
///
class SignInStep2View extends StatefulWidget {
  final GlobalKey<FormState> formKey;
  final LoginRequest request;

  const SignInStep2View({
    super.key,
    required this.formKey,
    required this.request,
  });

  @override
  State<SignInStep2View> createState() => _SignInStep2ViewState();
}

class _SignInStep2ViewState extends State<SignInStep2View> {
  late final S translations = S.of(context);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        AppTextField.password(
          labelText: translations.password,
          validator: (String? value) =>
              ValidatorService.hasText(value) ? null : '',
          onSaved: (String? value) {
            widget.request.password = value;
            return;
          },
        ),
      ],
    );
  }
}
