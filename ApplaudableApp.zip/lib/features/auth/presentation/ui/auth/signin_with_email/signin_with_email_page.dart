import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../../../app_module.dart';
import '../../../../../../core/entities/error/error_response.dart';
import '../../../../../../core/extensions/app_module_extensions.dart';
import '../../../../../../core/extensions/build_context_extensions.dart';
import '../../../../../../core/theme/styles.dart';
import '../../../../../../core/widgets/toast/app_toast.dart';
import '../../../../../../routes.dart';
import '../../../../../notifications/presentation/controllers/notification_controller.dart';
import '../../../../../onboarding/presentation/pages/add_profile_avatar_page.dart';
import '../../../../domain/entities/login_request.dart';
import '../../../../domain/entities/recover_password_request.dart';
import '../../../../domain/entities/session.dart';
import '../../../../domain/entities/signup_request.dart';
import '../../../controllers/login_controller.dart';
import '../../../presenters/base_statefull_stream.dart';
import '../../../presenters/base_view_page.dart';
import '../../../results/auth/recover_password_data_stream.dart';
import '../../../results/auth/session_data_stream.dart';
import '../../../results/base_result_stream.dart';
import '../../../widgets/background.dart';
import '../../../widgets/buttons/action_button.dart';
import '../../../widgets/buttons/text_button.dart';
import '../../../widgets/sizing/side_margins.dart';
import '../signup/signup_page.dart';
import 'steps/step1_view.dart';
import 'steps/step2_view.dart';

enum SignInWithEmailPageStep { emailPage, passwordPage }

/// TODO:
///  ** [ ] add top and bottom SVGs
///  ** [ ] review UI
///  ** [ ] Validate email
///  ** [ ] Validate Navigation flow
class SignInWithEmailPage extends BasePage {
  const SignInWithEmailPage({
    Key? key,
    this.step = SignInWithEmailPageStep.emailPage,
  }) : super(key: key);

  final SignInWithEmailPageStep step;

  @override
  State createState() => _SignInWithEmailPage();
}

class _SignInWithEmailPage
    extends BaseViewPage<SignInWithEmailPage, BaseSignInController> {
  late final LoginRequest _request =
      arguments != null ? arguments as LoginRequest : LoginRequest();

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  SignInWithEmailPageStep get step => widget.step;

  String get titlePage {
    switch (step) {
      case SignInWithEmailPageStep.emailPage:
        return translations.signInWithEmailTitle;
      case SignInWithEmailPageStep.passwordPage:
        return translations.signIn;
    }
  }

  @override
  bool get centerContentOnPage => true;

  void _submitForm() {
    if (!_formKey.currentState!.validate()) {
      AppModule.I.notify(
        context,
        translations.formValidationError,
        mode: AppToastMode.error,
      );
    } else {
      _formKey.currentState!.save();

      switch (step) {
        case SignInWithEmailPageStep.emailPage:
          Navigator.of(context)
              .pushNamed(Routes.completeSignInWithEmail, arguments: _request);
          break;
        case SignInWithEmailPageStep.passwordPage:
          bloc.signIn(
            model: _request,
          );
          break;
      }
    }
  }

  @override
  void initBloc(bloc) {}

  @override
  Widget get body => AppBackground(
        child: AppSideMargins(
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  titlePage,
                  style: AppStyles.header1(color: context.textColor),
                ),
                const SizedBox(height: 29.0),
                if (step == SignInWithEmailPageStep.emailPage)
                  SignInStep1View(formKey: _formKey, request: _request),
                if (step == SignInWithEmailPageStep.passwordPage)
                  SignInStep2View(formKey: _formKey, request: _request),
                const SizedBox(height: 29.0),
                Consumer<BaseSignInController>(
                  builder: (_, data, __) => AppActionButton.submit(
                    text: translations.buttonContinueLabel,
                    showLoading: data.isLoading,
                    onPressed: _submitForm,
                  ),
                ),
                if (step == SignInWithEmailPageStep.passwordPage) ...[
                  const SizedBox(height: 14.0),
                  Center(
                    child: AppTextButton.underline(
                      text: translations.forgotPassword,
                      onPressed: () {
                        bloc.recoverPassword(
                          model: RecoverPasswordRequest(email: _request.email),
                        );
                      },
                    ),
                  ),
                ]
              ],
            ),
          ),
        ),
      );

  @override
  Stream<BaseStream>? get onStateListener => bloc.onListener;

  @override
  onStateResultListener(BaseStream stream) {
    if (stream is SessionDataStream) {
      switch (stream.state) {
        case BaseStateEnum.request:
          bloc.setIsLoading(
            isLoading: true,
          );
          break;
        case BaseStateEnum.success:
          bloc.setIsLoading(
            isLoading: false,
          );

          /// Case its a valida session redirect to Home
          if (stream.data is Session) {
            context.baseController.updateCurrentUser(
              user: stream.data!.user,
            );

            /// Register Device Token
            NotificationController.I.registerDeviceToken();

            /// [hasProfile] is True if user has done the onboarding flow
            /// then navigate to Home Page
            /// if [hasProfile] is false then navigate and continue
            /// to the onboarding flow
            bool hasProfile = stream.data!.user.hasProfile ?? false;
            if (hasProfile) {
              Navigator.of(context).pushNamedAndRemoveUntil(
                Routes.home,
                (Route route) => false,
              );
              return;
            }

            Navigator.of(context).pushNamedAndRemoveUntil(
              AddProfileAvatarPage.routeName,
              (Route route) => false,
            );
          }

          break;
        case BaseStateEnum.fail:
          bloc.setIsLoading(
            isLoading: false,
          );

          /// In case this is a incomplete profile,
          /// then create [CompleteProfileRequest] with all the data
          /// and navigate to [Routes.signup]
          if (stream.errorResponse is SignInInCompleteErrorResponse) {
            context.navigatorKey?.pushNamed(
              Routes.signup,
              arguments: SignUpPageArgs(
                flow: SignUpPageFlow.email,
                request: SignUpRequest(
                  phoneNumber: "",
                  email: _request.email,
                  password: _request.password,
                  country: "",
                  code: "",
                  fields: stream.errorResponse?.fields,
                  missingFields: stream.errorResponse?.missingFields
                      ?.map((e) => e ?? "")
                      .toList(),
                  inviteCode: _request.inviteCode,
                ),
              ),
            );

            return;
          }

          AppModule.I.notify(
            context,
            stream.errorResponseMessage ?? translations.generalError,
            mode: AppToastMode.error,
          );
          break;
      }
    }

    if (stream is RecoverPasswordDataStream) {
      switch (stream.state) {
        case BaseStateEnum.request:
          // TODO: Handle this case.
          break;
        case BaseStateEnum.success:
          /*snackBar.show(
            mode: AppSnackBarMode.success,
            message: translations.recoverPasswordSentMessage(_request.email ??
                translations.recoverPasswordSentMessageEmailFallback),
          );*/
          AppModule.I.notify(
              context,
              translations.recoverPasswordSentMessage(_request.email ??
                  translations.recoverPasswordSentMessageEmailFallback));

          break;
        case BaseStateEnum.fail:
          AppModule.I.notify(
            context,
            stream.errorResponseMessage ?? translations.generalError,
            mode: AppToastMode.error,
          );
          break;
      }
    }
  }
}
