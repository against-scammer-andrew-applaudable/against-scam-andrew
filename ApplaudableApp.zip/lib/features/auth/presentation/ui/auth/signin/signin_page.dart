import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:applaudable/features/auth/presentation/widgets/buttons/agreements_button.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../../../app_module.dart';
import '../../../../../../core/extensions/app_module_extensions.dart';
import '../../../../../../core/theme/styles.dart';
import '../../../../../../core/widgets/or_text_divider.dart';
import '../../../../../../core/widgets/svg_icons.dart';
import '../../../../../../core/widgets/toast/app_toast.dart';
import '../../../../../../routes.dart';
import '../../../../domain/entities/login_request.dart';
import '../../../controllers/login_controller.dart';
import '../../../presenters/base_statefull_stream.dart';
import '../../../presenters/base_view_page.dart';
import '../../../results/auth/session_data_stream.dart';
import '../../../results/base_result_stream.dart';
import '../../../validator/validator_service.dart';
import '../../../widgets/background.dart';
import '../../../widgets/buttons/action_button.dart';
import '../../../widgets/inputs/country_field/country_field.dart';
import '../../../widgets/inputs/text_field.dart';
import '../../../widgets/sizing/side_margins.dart';
import '../code_input/code_input_page.dart';

/// TODO:
///  ** [ ] add bottom sheet to choose country
///  ** [ ] add top and bottom SVGs
///  ** [ ] review UI
///  ** [ ] Validate phone number
///  ** [ ] Validate Navigation flow

class SignInPageArgs extends Equatable {
  final String? inviteCode;

  const SignInPageArgs({this.inviteCode});

  @override
  List<Object?> get props => [inviteCode];
}

class SignInPage extends BasePage {
  final SignInPageArgs args;

  const SignInPage({Key? key, this.args = const SignInPageArgs()})
      : super(key: key);

  @override
  State createState() => _SignInPage();
}

class _SignInPage extends BaseViewPage<SignInPage, BaseSignInController> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final LoginWithPhoneNumberRequest _loginRequest =
      LoginWithPhoneNumberRequest();

  @override
  bool get showAppbar => false;

  @override
  bool get centerContentOnPage => true;

  void _submitForm() {
    if (!_formKey.currentState!.validate()) {
      AppModule.I.notify(
        context,
        translations.formValidationError,
        mode: AppToastMode.error,
      );
    } else {
      _formKey.currentState!.save();
      bloc.signInWithPhoneNumber(
        model: _loginRequest,
      );
    }
  }

  @override
  void initBloc(bloc) {}

  @override
  Widget get body => AppBackground(
        child: AppSideMargins(
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  translations.signInOrSignUpTitle,
                  style: AppStyles.header1(color: context.textColor),
                ),
                const SizedBox(height: 34.0),
                AppCountryField(
                  onSaved: (String? value) {
                    _loginRequest.country = value;
                    return;
                  },
                ),
                const SizedBox(height: 17.0),
                AppTextField(
                  labelText: translations.phoneNumber,
                  autoCorrect: false,
                  textCapitalization: TextCapitalization.none,
                  textInputType: TextInputType.phone,
                  validator: (String? value) => ValidatorService.hasText(value)
                      ? null
                      : translations.invalid_phone_msg,
                  onSaved: (String? value) {
                    _loginRequest.phoneNumber = value?.toLowerCase().trim();
                    return;
                  },
                ),
                const SizedBox(height: 29.0),
                Consumer<BaseSignInController>(
                  builder: (_, data, __) => AppActionButton.submit(
                    text: translations.buttonContinueLabel,
                    showLoading: data.isLoading,
                    onPressed: _submitForm,
                    boxShadow: [
                      AppShadows.submitButtonDefaultShadow,
                    ],
                  ),
                ),
                const SizedBox(height: 22.0),
                const OrTextDivider(),
                const SizedBox(height: 18.0),
                AppActionButton.submitWithBorder(
                  leadingIcon: SvgIcons.email,
                  text: translations.buttonContinueWithEmailLabel,
                  onPressed: () {
                    Navigator.of(context).pushNamed(
                      Routes.signInWithEmail,
                      arguments: LoginRequest(
                        inviteCode: widget.args.inviteCode,
                      ),
                    );
                  },
                ),
                const SizedBox(height: 20),
                const AppAgreementsButton(),
              ],
            ),
          ),
        ),
      );

  // void _openAppContentPageOfType(AppContentType type) {
  //   AppModule.I.navigateToNamed(
  //     AppContentPage.routeName,
  //     arguments: AppContentPageArgs(type: type),
  //   );
  // }

  @override
  Stream<BaseStream>? get onStateListener => bloc.onListener;

  @override
  onStateResultListener(BaseStream stream) {
    if (stream is SessionDataStream) {
      switch (stream.state) {
        case BaseStateEnum.request:
          bloc.setIsLoading(
            isLoading: true,
          );
          break;
        case BaseStateEnum.success:
          bloc.setIsLoading(
            isLoading: false,
          );
          CodeInputPage.navigate(
            value: _loginRequest.phoneNumber ?? "",
            code: _loginRequest.country ?? "",
            invitationCode: widget.args.inviteCode,
          );
          break;
        case BaseStateEnum.fail:
          bloc.setIsLoading(
            isLoading: false,
          );
          //stream.errorResponseMessage ??
          AppModule.I.notify(
            context,
            translations.generalError,
            mode: AppToastMode.error,
          );
          break;
      }
    }
  }
}
