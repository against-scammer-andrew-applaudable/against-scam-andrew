import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../../../app_module.dart';
import '../../../../../../core/extensions/app_module_extensions.dart';
import '../../../../../../core/theme/colors.dart';
import '../../../../../../core/theme/styles.dart';
import '../../../../../../core/widgets/toast/app_toast.dart';
import '../../../../../../routes.dart';
import '../../../../domain/entities/reset_password_request.dart';
import '../../../controllers/reset_pass_controller.dart';
import '../../../presenters/base_statefull_stream.dart';
import '../../../presenters/base_view_page.dart';
import '../../../results/auth/recover_password_data_stream.dart';
import '../../../results/base_result_stream.dart';
import '../../../validator/validator_service.dart';
import '../../../widgets/background.dart';
import '../../../widgets/buttons/action_button.dart';
import '../../../widgets/inputs/text_field.dart';
import '../../../widgets/sizing/side_margins.dart';

class ResetPasswordPage extends BasePage {
  static const String routeName = '/signin/email/reset';
  static push(String code, String email) {
    AppModule.I.navigateToNamed(
      ResetPasswordPage.routeName,
      arguments: ResetPasswordRequest(code: code, email: email),
    );
  }

  const ResetPasswordPage({Key? key}) : super(key: key);

  @override
  State createState() => _RecoverPassPage();
}

class _RecoverPassPage
    extends BaseViewPage<ResetPasswordPage, ResetPassController> {
  late final ResetPasswordRequest _request = arguments != null
      ? arguments as ResetPasswordRequest
      : ResetPasswordRequest();

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  void _submitForm() {
    if (!_formKey.currentState!.validate()) {
      AppModule.I.notify(
        context,
        translations.formValidationError,
        mode: AppToastMode.error,
      );
    } else {
      _formKey.currentState!.save();

      bloc.resetPassword(model: _request);
    }
  }

  @override
  void initBloc(bloc) {}

  @override
  Widget get body => AppBackground(
        showTopLogo: false,
        showBottomLogo: false,
        child: AppSideMargins(
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  translations.resetPassword,
                  style: AppStyles.header1(color: context.textColor),
                ),
                const SizedBox(height: 4),
                Text(
                  translations.password_validation_msg,
                  style: AppStyles.text2(color: AppColors.mediumGrey),
                ),
                const SizedBox(height: 29),
                AppTextField.password(
                  labelText: translations.password,
                  validator: (String? value) =>
                      ValidatorService.hasText(value) ? null : '',
                  onSaved: (String? value) {
                    _request.password = value;
                    return;
                  },
                ),
                const SizedBox(height: 29),
                Consumer<ResetPassController>(
                  builder: (_, data, __) => AppActionButton.submit(
                    text: translations.buttonContinueLabel,
                    showLoading: data.isLoading,
                    onPressed: _submitForm,
                  ),
                ),
                const SizedBox(
                  height: 14,
                ),
              ],
            ),
          ),
        ),
      );

  @override
  Stream<BaseStream>? get onStateListener => bloc.onListener;

  @override
  onStateResultListener(BaseStream stream) {
    if (stream is RecoverPasswordDataStream) {
      switch (stream.state) {
        case BaseStateEnum.request:
          // TODO: Handle this case.
          break;
        case BaseStateEnum.success:
          AppModule.I.notify(context, translations.your_password_changed_msg);

          AppModule.I.navigatorKey.currentState!.pushNamedAndRemoveUntil(
            Routes.signIn,
            (route) => false,
          );
          break;
        case BaseStateEnum.fail:
          // TODO: Handle this case.
          break;
      }
    }
  }
}
