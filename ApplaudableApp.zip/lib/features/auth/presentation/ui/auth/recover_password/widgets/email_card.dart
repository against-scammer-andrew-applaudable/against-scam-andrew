import 'package:flutter/material.dart';

import '../../../../../../../generated/l10n.dart';
import '../../../../widgets/text_field.dart';

class EmailCard extends StatelessWidget {
  final VoidCallback callBack;
  const EmailCard({super.key, required this.callBack});

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8.0),
          child: Text(
            translations.reset_password,
            style: const TextStyle(
              color: Colors.black,
              fontSize: 24,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8.0),
          child: Text(
            translations.reset_password_desc_msg,
            style: const TextStyle(
              color: Colors.black,
              fontSize: 16,
              fontWeight: FontWeight.w200,
            ),
          ),
        ),
        APDTextField(
          dateTime: false,
          password: false,
          readOnly: false,
          hint: translations.email,
          keyboardType: Type.email,
          borders: false,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 10.0),
          child: Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: () {
                    callBack();
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Text(
                      translations.send_reset_link,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
