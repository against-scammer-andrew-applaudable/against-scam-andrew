import 'package:flutter/material.dart';

import '../../../../../../../generated/l10n.dart';
import '../../../../widgets/text_field.dart';

class NewPassCard extends StatelessWidget {
  final VoidCallback callBack;
  const NewPassCard({Key? key, required this.callBack}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8.0),
          child: Text(
            translations.reset_password,
            style: const TextStyle(
              color: Colors.black,
              fontSize: 24,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8.0),
          child: Text(
            translations.password_validation_msg,
            style: const TextStyle(
              color: Colors.black,
              fontSize: 16,
              fontWeight: FontWeight.w200,
            ),
          ),
        ),
        APDTextField(
          dateTime: false,
          password: false,
          readOnly: false,
          borders: false,
          hint: translations.new_password,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 10.0),
          child: Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: callBack,
                  child: Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Text(
                      translations.submit,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
