import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../../widgets/inputs/code_field.dart';

class AppCodeInput extends StatefulWidget {
  final int length;
  final Function(String) onSaved;

  const AppCodeInput({Key? key, required this.length, required this.onSaved})
      : super(key: key);

  @override
  State<AppCodeInput> createState() => _AppCodeInputState();
}

class _AppCodeInputState extends State<AppCodeInput>
    with WidgetsBindingObserver {
  String _currentCode = '      ';

  late final List<FocusNode> _focusNodes = List.generate(
    widget.length,
    (index) => FocusNode(),
  );
  late final List<String> _code = List.generate(
    widget.length,
    (index) => '',
  );

  bool _isLastInput(int index) => index + 1 == _focusNodes.length;

  String getCodeDigitByIndex(int index) {
    if (_currentCode.isEmpty || _currentCode.length < index) {
      return "";
    }

    if (index >= _currentCode.length) return '';

    return _currentCode[index].trim();
  }

  bool _needRebuild = false;

  @override
  void initState() {
    WidgetsBinding.instance.addObserver(this);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 56,
      width: double.maxFinite,
      child: FractionallySizedBox(
        alignment: FractionalOffset.center,
        widthFactor: 0.85,
        child: FittedBox(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              _focusNodes.length,
              (int index) {
                final code = getCodeDigitByIndex(index);

                return Builder(
                    key: _needRebuild ? UniqueKey() : null,
                    builder: (context) {
                      _needRebuild = false;

                      return AppCodeField(
                        focusNode: _focusNodes[index],
                        code: code,
                        onPaste: (copiedText) {
                          _currentCode = copiedText;
                          _needRebuild = true;
                          setState(() {});
                        },
                        onChanged: (String value) {
                          _currentCode = _currentCode.replaceRange(
                              index, index + 1, value.isEmpty ? ' ' : value);

                          if (value.trim().isNotEmpty) {
                            _focusNodes[index].unfocus();
                            if (!_isLastInput(index)) {
                              _focusNodes[index + 1].requestFocus();
                            }
                          }
                        },
                        onSaved: (String? value) {
                          value = value?.trim();
                          if (value != null) {
                            _code[index] = value;
                          }
                          final String newCode = _code.join().trim();
                          if (newCode.length == _focusNodes.length) {
                            // clear code to prevent saving multiple times
                            for (int i = 0; i < _code.length; i++) {
                              _code[i] = '';
                            }
                            // save code
                            widget.onSaved(newCode);
                          }
                        },
                        index: index,
                        size: _focusNodes.length,
                      );
                    });
              },
            ),
          ),
        ),
      ),
    );
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) async {
    switch (state) {
      case AppLifecycleState.resumed:
        final copiedText = await Clipboard.getData(Clipboard.kTextPlain);

        if (copiedText?.text != null) {
          final digitsRegex = RegExp(r'\d{6}$');

          if (_currentCode != copiedText!.text &&
              digitsRegex.hasMatch(copiedText.text!)) {
            setState(() {
              _currentCode = copiedText.text!;
              _needRebuild = true;
            });
          }
        }
        break;
      default:
    }

    super.didChangeAppLifecycleState(state);
  }

  @override
  void dispose() {
    for (FocusNode focusNode in _focusNodes) {
      focusNode.dispose();
    }

    WidgetsBinding.instance.removeObserver(this);

    super.dispose();
  }
}
