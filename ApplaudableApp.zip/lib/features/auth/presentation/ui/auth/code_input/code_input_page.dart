import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../../../app_module.dart';
import '../../../../../../core/extensions/app_module_extensions.dart';
import '../../../../../../core/extensions/build_context_extensions.dart';
import '../../../../../../core/widgets/toast/app_toast.dart';
import '../../../../../../core/entities/error/error_response.dart';
import '../../../../domain/entities/activate_account_request.dart';
import '../../../../domain/entities/login_request.dart';
import '../../../../domain/entities/session.dart';
import '../../../../domain/entities/signup_request.dart';
import '../../../../../notifications/presentation/controllers/notification_controller.dart';
import '../../../../../onboarding/presentation/pages/add_profile_avatar_page.dart';
import '../../../controllers/auth_otp_controller.dart';
import '../../../presenters/base_statefull_stream.dart';
import '../../../presenters/base_view_page.dart';
import '../../../results/auth/session_data_stream.dart';
import '../../../results/base_result_stream.dart';
import '../../../../../../routes.dart';
import '../../../../../../core/theme/colors.dart';
import '../../../../../../core/theme/styles.dart';
import '../../../widgets/buttons/action_button.dart';
import '../../../widgets/buttons/text_button.dart';
import '../../../widgets/sizing/side_margins.dart';
import '../signup/signup_page.dart';
import 'components/code_input.dart';

enum CodeInputType {
  authOtp,
  recoverPassword,
  changePassword,
}

class CodeInputArgs {
  final CodeInputType type;
  final String value;
  final String code;
  final String? invitationCode;

  CodeInputArgs({
    required this.type,
    required this.value,
    required this.code,
    this.invitationCode,
  });
}

class CodeInputPage extends BasePage {
  const CodeInputPage({Key? key}) : super(key: key);

  static navigate({
    required String value,
    required String code,
    CodeInputType codeInputType = CodeInputType.authOtp,
    String? invitationCode,
  }) {
    AppModule.instance.navigatorKey.currentState?.pushNamed(
      Routes.codeInput,
      arguments: CodeInputArgs(
        type: codeInputType,
        value: value,
        code: code,
        invitationCode: invitationCode,
      ),
    );
  }

  @override
  State createState() => _CodeInputPageState();
}

class _CodeInputPageState
    extends BaseViewPage<CodeInputPage, BaseAuthOTPController> {
  late final CodeInputArgs args = arguments as CodeInputArgs;

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final SignInConfirmCodeRequest _signInConfirmCodeRequest =
      SignInConfirmCodeRequest();

  bool checking = false;

  @override
  bool get centerContentOnPage => true;

  String get phoneNumber => "${args.code}${args.value}";
  String get _maskedPhoneNumber => phoneNumber.replaceRange(
      1, args.value.length - 2, 'x' * (args.value.length - 2));

  void _submitForm() {
    if (!_formKey.currentState!.validate()) {
      AppModule.I.notify(
        context,
        translations.formValidationError,
        mode: AppToastMode.error,
      );
    } else {
      _formKey.currentState!.save();

      switch (args.type) {
        case CodeInputType.authOtp:
          bloc.signInConfirmCode(
            model: _signInConfirmCodeRequest,
          );
          break;
        case CodeInputType.recoverPassword:
          break;
        case CodeInputType.changePassword:
          break;
      }
    }
  }

  @override
  void initBloc(BaseAuthOTPController bloc) {}

  @override
  Widget get body => AppSideMargins(
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                translations.authentication,
                style: AppStyles.header1(color: context.textColor),
              ),
              const SizedBox(height: 4.0),
              Text(
                "${translations.enter_pin_code_msg} $_maskedPhoneNumber",
                style: AppStyles.text2(color: AppColors.mediumGrey),
              ),
              const SizedBox(height: 34.0),
              AppCodeInput(
                length: 6,
                onSaved: (String code) {
                  _signInConfirmCodeRequest.code = code;
                  _signInConfirmCodeRequest.phoneNumber = phoneNumber;
                },
              ),
              const SizedBox(height: 25.0),
              Consumer<BaseAuthOTPController>(
                builder: (_, data, __) => AppActionButton.submit(
                  text: translations.buttonContinueLabel,
                  showLoading: data.isLoading,
                  onPressed: _submitForm,
                ),
              ),
              const SizedBox(height: 33.0),
              Center(
                child: AppTextButton.underline(
                  text: translations.resendCodeAgainText,
                  label: translations.notReceivedCodeText,
                  onPressed: () {
                    bloc.signInWithPhoneNumber(
                      model: LoginWithPhoneNumberRequest(
                        country: args.code,
                        phoneNumber: args.value,
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      );

  @override
  Stream<BaseStream>? get onStateListener => bloc.onListener;

  @override
  onStateResultListener(BaseStream stream) {
    /// TODO: Separate Streams into:
    ///  ** validate request
    ///  ** resend code request
    if (stream is SessionDataStream) {
      switch (stream.state) {
        case BaseStateEnum.request:
          bloc.setIsLoading(
            isLoading: true,
          );
          break;
        case BaseStateEnum.success:
          bloc.setIsLoading(
            isLoading: false,
          );

          if (stream.data is Session) {
            context.baseController.updateCurrentUser(
              user: stream.data!.user,
            );

            /// [hasProfile] is True if user has done the onboarding flow
            /// then navigate to Home Page
            /// if [hasProfile] is false then navigate and continue
            /// to the onboarding flow
            bool hasProfile = stream.data!.user.hasProfile ?? false;
            if (hasProfile) {
              Navigator.of(context).pushNamedAndRemoveUntil(
                Routes.home,
                (Route route) => false,
              );
              return;
            }

            /// Register Device Token
            NotificationController.I.registerDeviceToken();

            Navigator.of(context).pushNamedAndRemoveUntil(
              AddProfileAvatarPage.routeName,
              (Route route) => false,
            );
          }
          break;
        case BaseStateEnum.fail:
          bloc.setIsLoading(isLoading: false);

          /// In case this is a incomplete profile,
          /// then create [CompleteProfileRequest] with all the data
          /// and navigate to [Routes.signup]
          if (stream.errorResponse is SignInInCompleteErrorResponse) {
            context.navigatorKey?.pushNamed(
              Routes.signup,
              arguments: SignUpPageArgs(
                request: SignUpRequest(
                  phoneNumber: _signInConfirmCodeRequest.phoneNumber,
                  country: args.code,
                  code: stream.errorResponse?.code,
                  fields: stream.errorResponse?.fields,
                  missingFields: stream.errorResponse?.missingFields
                      ?.map((e) => e ?? "")
                      .toList(),
                  inviteCode: args.invitationCode,
                ),
              ),
            );

            return;
          }

          AppModule.I.notify(
            context,
            stream.errorResponseMessage ?? translations.generalError,
            mode: AppToastMode.error,
          );
          break;
      }
    }
  }
}
