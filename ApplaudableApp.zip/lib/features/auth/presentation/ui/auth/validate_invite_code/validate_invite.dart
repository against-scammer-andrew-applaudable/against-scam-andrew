import 'package:applaudable/core/utils/app_utils.dart';
import 'package:applaudable/ui/page/auth/base_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import '../../../../../../core/theme/colors.dart';
import '../../../../../../core/theme/styles.dart';
import '../../../../../../core/widgets/svg_icons.dart';
import '../../../../../../generated/l10n.dart';
import '../../../widgets/background.dart';
import '../../../widgets/inputs/text_field.dart';
import '../../../widgets/sizing/side_margins.dart';
import '../../../widgets/validate_invite_code_button.dart';

class ValidateInviteCodePage extends StatelessWidget {
  static const String routeName = '/register/validate_invite';

  ValidateInviteCodePage({super.key});

  final _inviteCodeController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return BaseAuthenticationPage(
      child: AppBackground(
        child: SingleChildScrollView(
          padding: MediaQuery.of(context).padding.copyWith(top: 35 + AppUtils().safePaddingTop(context)),
          child: AppSideMargins(
            marginValue: 30,
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SvgIcons.applaudRatingFilled(
                      height: 42, color: AppColors.primaryColor),
                  const SizedBox(height: 5),
                  Text(
                    translations.app_name,
                    style: AppStyles.header1(
                      color: AppColors.primaryColor,
                    ).copyWith(fontSize: 16),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 130),
                  Text(
                    translations.enter_code_just_texted_you,
                    textAlign: TextAlign.center,
                    style: AppStyles.header1(
                      color: AppColors.dark,
                    ).copyWith(fontSize: 20, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 20),
                  AppTextField(
                    controller: _inviteCodeController,
                    hintText: "•••••••",
                    // hintText: translations.invite_code_hint,
                    textAlign: TextAlign.center,
                    style: AppStyles.text1(
                      color: AppColors.dark,
                    ).copyWith(fontSize: 28, fontWeight: FontWeight.w600, letterSpacing: 2),
                    hintTextStyle: AppStyles.text1(
                      color: AppColors.imagePreviewOverlayColor,
                    ).copyWith(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: 8),
                    autoCorrect: false,
                    textCapitalization: TextCapitalization.characters,
                    borderRadius: BorderRadius.circular(100),
                    padding: const EdgeInsets.symmetric(
                      vertical: 12,
                      horizontal: 18,
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return translations.invalid_invite_code_msg;
                      }

                      return null;
                    },
                  ),
                  const SizedBox(height: 20),
                  RichText(
                    textAlign: TextAlign.center,
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: "${translations.didnot_receive_it}  ",
                          style: AppStyles.text2(
                            color: AppColors.dark,
                          ).copyWith(fontWeight: FontWeight.w600),
                        ),
                        TextSpan(
                          text: translations.tap_to_resend,
                          style: AppStyles.text2(
                            color: AppColors.primaryColor,
                          ).copyWith(fontWeight: FontWeight.w700),
                          recognizer: TapGestureRecognizer()
                            ..onTap = () async {
                            },
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 110),
                  ValidateInviteCodeButton(
                    inviteCodeController: _inviteCodeController,
                    formKey: _formKey,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
