// import 'package:flutter/material.dart';
//
// import '../../../../../routes.dart';
//
// @Deprecated("TODO: refactor this to use native splash")
// class SplashPage extends StatefulWidget {
//   const SplashPage({Key? key}) : super(key: key);
//
//   @override
//   State<SplashPage> createState() => _SplashPageState();
// }
//
// class _SplashPageState extends State<SplashPage> {
//   @override
//   void initState() {
//     Future.delayed(
//       const Duration(seconds: 5),
//       () => Navigator.of(context).pushNamed(Routes.signup),
//     );
//     super.initState();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Center(
//         child: Image.asset(
//           "assets/applaudable.png",
//           color: Colors.brown,
//           width: 250,
//           height: 250,
//         ),
//       ),
//     );
//   }
// }
