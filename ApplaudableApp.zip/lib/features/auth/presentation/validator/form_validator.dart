import 'package:flutter/material.dart';

class FormValidator {
  static submitForm(GlobalKey<FormState> key) async {
    if (key.currentState!.validate()) {
      key.currentState!.save();
    }
  }

  static bool isPhoneNumberValid(String? value) {
    if (value == null) return false;
    final RegExp expression =
        RegExp(r'^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4}$');
    return expression.hasMatch(value);
  }

  static bool isPasswordValid(String? value) {
    if (value == null) return false;
    final RegExp expression =
        RegExp(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$');
    return expression.hasMatch(value);
  }

  static bool isEmailValid(String? value) {
    if (value == null) return false;
    final RegExp expression = RegExp(
        r'^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$');
    return expression.hasMatch(value);
  }
}
