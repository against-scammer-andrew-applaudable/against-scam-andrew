import '../../../../core/constants/constant_values.dart';

class ValidatorService {
  static bool hasText(String? value) =>
      value != null && value.trim().isNotEmpty;

  static bool hasLimitedText(String? value) =>
      value != null && value.trim().length < ConstantValues.maxTextSize;

  static bool isEmailValid(String? value) {
    if (value == null) return false;
    final RegExp _expression = RegExp(
        r'^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$');
    return _expression.hasMatch(value);
  }

  static bool isNotNull<T>(T? value) => value != null;

  static bool isPhoneNumberValid(String? value) {
    if (value == null) return false;
    final RegExp _expression =
        RegExp(r'^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$');
    return _expression.hasMatch(value);
  }
}
