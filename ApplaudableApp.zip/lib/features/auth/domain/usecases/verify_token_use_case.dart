import '../repositories/auth_repository.dart';
import '../../presentation/results/app_result.dart';

abstract class VerifyTokenUseCase {
  Future<AppResult> call();
}

class VerifyToken extends VerifyTokenUseCase {
  final AuthRepository repository;

  VerifyToken({required this.repository});

  @override
  Future<AppResult> call() => repository.verifyToken();
}
