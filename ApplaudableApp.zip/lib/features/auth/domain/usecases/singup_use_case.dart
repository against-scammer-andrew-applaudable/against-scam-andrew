import '../repositories/auth_repository.dart';
import '../../presentation/results/app_result.dart';
import '../entities/signup_request.dart';

abstract class SignUpUseCase {
  Future<AppResult> call({required SignUpRequest model});
}

class SignUp implements SignUpUseCase {
  final AuthRepository repository;

  SignUp({required this.repository});

  @override
  Future<AppResult> call({required SignUpRequest model}) {
    return repository.signUp(model: model);
  }
}
