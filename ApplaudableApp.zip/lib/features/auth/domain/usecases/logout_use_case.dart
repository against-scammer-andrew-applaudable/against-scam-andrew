import '../repositories/auth_repository.dart';
import '../../presentation/results/app_result.dart';

abstract class LogoutUseCase {
  Future<AppResult> call();
}

class Logout implements LogoutUseCase {
  final AuthRepository repository;

  Logout({required this.repository});

  @override
  Future<AppResult> call() => repository.logout();
}
