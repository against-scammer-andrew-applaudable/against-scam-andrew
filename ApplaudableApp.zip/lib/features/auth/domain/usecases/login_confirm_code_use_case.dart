import '../repositories/auth_repository.dart';
import '../../presentation/results/app_result.dart';
import '../entities/activate_account_request.dart';

abstract class SignInConfirmCodeUseCase {
  Future<AppResult> call({
    required SignInConfirmCodeRequest model,
  });
}

class SignInConfirmCode implements SignInConfirmCodeUseCase {
  final AuthRepository repository;

  SignInConfirmCode({required this.repository});

  @override
  Future<AppResult> call({
    required SignInConfirmCodeRequest model,
  }) {
    return repository.signInConfirmCode(model: model);
  }
}
