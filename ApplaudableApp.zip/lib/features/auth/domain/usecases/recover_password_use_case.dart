import '../repositories/auth_repository.dart';
import '../../presentation/results/app_result.dart';
import '../entities/recover_password_request.dart';

abstract class RecoverPasswordUseCase {
  Future<AppResult> call({
    required RecoverPasswordRequest model,
  });
}

class RecoverPassword implements RecoverPasswordUseCase {
  final AuthRepository repository;

  RecoverPassword({required this.repository});

  @override
  Future<AppResult> call({required RecoverPasswordRequest model}) {
    return repository.recoverPassword(model: model);
  }
}
