import '../repositories/auth_repository.dart';
import '../../presentation/results/app_result.dart';
import '../entities/reset_password_request.dart';

abstract class ResetPasswordUseCase {
  Future<AppResult> call({required ResetPasswordRequest model});
}

class ResetPassword implements ResetPasswordUseCase {
  final AuthRepository repository;

  ResetPassword({required this.repository});

  @override
  Future<AppResult> call({required ResetPasswordRequest model}) {
    return repository.resetPassword(model: model);
  }
}
