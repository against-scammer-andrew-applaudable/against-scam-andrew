import '../repositories/auth_repository.dart';
import '../../presentation/results/app_result.dart';
import '../entities/activate_account_request.dart';

abstract class ActivateAccountUseCase {
  Future<AppResult> call({
    required String uuid,
    required ActivateAccountRequest model,
  });
}

class ActivateAccount implements ActivateAccountUseCase {
  final AuthRepository repository;

  ActivateAccount({required this.repository});

  @override
  Future<AppResult> call({
    required String uuid,
    required ActivateAccountRequest model,
  }) {
    return repository.activateAccount(uuid: uuid, model: model);
  }
}
