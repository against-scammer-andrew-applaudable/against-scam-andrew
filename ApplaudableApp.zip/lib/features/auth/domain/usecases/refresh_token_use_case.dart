import '../repositories/auth_repository.dart';
import '../../presentation/results/app_result.dart';

abstract class RefreshTokenUseCase {
  Future<AppResult> call();
}

class RefreshToken implements RefreshTokenUseCase {
  final AuthRepository repository;

  RefreshToken({required this.repository});

  @override
  Future<AppResult> call() => repository.refreshToken();
}
