import '../repositories/auth_repository.dart';
import '../../presentation/results/app_result.dart';
import '../entities/login_request.dart';

abstract class SignInUseCase {
  Future<AppResult> call({required LoginRequest model});
}

class SignIn implements SignInUseCase {
  final AuthRepository repository;

  SignIn({required this.repository});

  @override
  Future<AppResult> call({required LoginRequest model}) {
    return repository.signIn(model: model);
  }
}
