import '../repositories/auth_repository.dart';
import '../entities/session.dart';

abstract class GetSessionUseCase {
  Future<Session?> call();
}

class GetSession extends GetSessionUseCase {
  final AuthRepository repository;

  GetSession({required this.repository});

  @override
  Future<Session?> call() => repository.getSession();
}
