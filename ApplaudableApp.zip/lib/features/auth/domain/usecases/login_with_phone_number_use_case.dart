import '../repositories/auth_repository.dart';
import '../../presentation/results/app_result.dart';
import '../entities/login_request.dart';

abstract class SignInWithPhoneNumberUseCase {
  Future<AppResult> call({
    required LoginWithPhoneNumberRequest model,
  });
}

class SignInWithPhoneNumber implements SignInWithPhoneNumberUseCase {
  final AuthRepository repository;

  SignInWithPhoneNumber({required this.repository});

  @override
  Future<AppResult> call({required LoginWithPhoneNumberRequest model}) {
    return repository.signInWithPhoneNumber(model: model);
  }
}
