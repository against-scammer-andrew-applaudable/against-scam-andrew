import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../repositories/auth_repository.dart';

class ValidateInviteCode extends UseCase<bool, String> {
  final AuthRepository repository;

  ValidateInviteCode({required this.repository});

  @override
  Future<Either<Failure, bool>> call(String params) {
    return repository.validateInviteCode(inviteCode: params);
  }
}
