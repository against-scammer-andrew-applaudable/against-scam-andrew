import 'package:equatable/equatable.dart';
import 'package:hive/hive.dart';

import '../../../../core/entities/base_hive_types.dart';
import 'token.dart';
import 'user.dart';

part 'session.g.dart';

@HiveType(typeId: BaseHiveTypeIds.sessionModel)
class Session extends HiveObject with EquatableMixin {
  @HiveField(0)
  Token token;

  @HiveField(1)
  HiveUser user;

  Session({required this.token, required this.user});

  @override
  List<Object?> get props => [token, user];
}
