class RecoverPasswordRequest {
  String? email;

  RecoverPasswordRequest({
    this.email,
  });
}
