class ActivateAccountRequest {
  String? phoneNumber;
  String? code;

  ActivateAccountRequest({
    this.phoneNumber,
    this.code,
  });
}

class SignInConfirmCodeRequest {
  String? phoneNumber;
  String? code;

  SignInConfirmCodeRequest({
    this.phoneNumber,
    this.code,
  });
}
