class LoginRequest {
  String? email;
  String? password;
  String? inviteCode;

  LoginRequest({
    this.email,
    this.password,
    this.inviteCode,
  });
}

class LoginWithPhoneNumberRequest {
  String? country;
  String? phoneNumber;

  LoginWithPhoneNumberRequest({
    this.country,
    this.phoneNumber,
  });
}
