import 'dart:ui';

import 'package:equatable/equatable.dart';
import 'package:hive/hive.dart';

import '../../../../core/entities/base_image.dart';
import '../../../../core/entities/base_hive_types.dart';
import '../../../../core/entities/base_user.dart';
import '../../../post_collections/domain/entities/post_collection.dart';
import '../../../profile/data/models/profile_response_models.dart';
import '../../../profile/domain/entities/profile_response.dart';

part 'user.g.dart';

@HiveType(typeId: BaseHiveTypeIds.userModel)
class HiveUser with HiveObjectMixin, EquatableMixin, BaseImage implements BaseUser {
  @override
  @HiveField(0)
  final String id;

  @override
  @HiveField(1)
  String name;

  @override
  @HiveField(2)
  String username;

  @HiveField(3)
  final String? email;

  @HiveField(4)
  final bool? isActive;

  @override
  @HiveField(6)
  String? avatar;

  @HiveField(7)
  final String? phoneNumber;

  @HiveField(8)
  final DateTime? birthDate;

  @HiveField(9)
  final String? location;

  @HiveField(10)
  final String? instagramHandler;

  @HiveField(11)
  final String? bio;

  @HiveField(12)
  final bool? hasProfile;

  @HiveField(13)
  final bool? yearOnly;

  @HiveField(14)
  int? invitationsCount;

  @HiveField(15)
  String? invitationCode;

  final ProfileCounters? counters;
  final UserEngagement? engagement;
  final List<PostCollection> collections;
  final String? mentionSource;
  final bool isFollowing;

  bool fetchAndGenerate = false;
  bool hasDownloadedImage = false;
  Image? image;

  HiveUser({
    required this.id,
    required this.name,
    required this.username,
    this.email,
    this.isActive,
    this.avatar,
    this.phoneNumber,
    this.birthDate,
    this.location,
    this.instagramHandler,
    this.bio,
    this.hasProfile,
    this.yearOnly,
    this.counters,
    this.engagement,
    this.collections = const [],
    this.mentionSource,
    this.isFollowing = false,
    this.invitationsCount = 0,
    this.invitationCode = '',
  });

  @override
  List<Object?> get props => [id, username];

  int get age {
    if (birthDate == null) return 0;

    final DateTime now = DateTime.now();
    int age = now.year - birthDate!.year;

    final int monthDifference = now.month - birthDate!.month;
    final int dayDifference = now.day - birthDate!.day;

    if (monthDifference < 0) {
      age -= 1;
    } else if (monthDifference == 0 && dayDifference < 0) {
      age -= 1;
    }

    return age;
  }

  String get initials {
    String name = this.name;
    if (name.isEmpty) {
      name = username;
    }
    List<String> names = name.split(" ");
    if (names.length == 1) {
      return names[0].substring(0, 2).toUpperCase();
    }
    if (names.length > 1) {
      return "${names[0].substring(0, 1)}${names[names.length - 1].substring(0, 1)}"
          .toUpperCase();
    }
    return "";
  }

  String get firstName {
    String name = this.name;
    if (name.isEmpty) {
      name = username;
    }
    List<String> names = name.split(" ");
    if (names.length == 1) {
      return name;
    }
    if (names.length > 1) {
      return "${names[0]} ${names[names.length - 1].substring(0, 1)}.";
    }
    return "";
  }

  @override
  String get formattedName {
    if (name.length <= 25) {
      return name;
    }

    var split = name.split(" ");
    if (split.length == 1 && split[0].length <= 25) {
      return split[0];
    }

    if (split.length == 1 && split[0].length > 25) {
      return username;
    }

    if (split.length > 1) {
      return "${split[0].substring(0, split[0].length)}_${split[split.length - 1][0]}";
    }

    return username;
  }

  @override
  ImageOptimizationSizes get defaultSize => ImageOptimizationSizes.profile;

  @override
  String get defaultImage =>
      (avatar != null && avatar!.isNotEmpty) ? avatar! : "";

  HiveUser copyWith({
    String? id,
    String? name,
    String? username,
    String? email,
    bool? isActive,
    String? avatar,
    String? phoneNumber,
    DateTime? birthDate,
    String? location,
    String? instagramHandler,
    String? bio,
    bool? hasProfile,
    bool? yearOnly,
    ProfileCountersModel? counters,
    UserEngagementModel? engagement,
    List<PostCollection>? collections,
    String? mentionSource,
    bool? isFollowing,
    int? invitationsCount,
    String? invitationCode,
  }) {
    return HiveUser(
      id: id ?? this.id,
      name: name ?? this.name,
      username: username ?? this.username,
      email: email ?? this.email,
      isActive: isActive ?? this.isActive,
      avatar: avatar ?? this.avatar,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      birthDate: birthDate ?? this.birthDate,
      location: location ?? this.location,
      instagramHandler: instagramHandler ?? this.instagramHandler,
      bio: bio ?? this.bio,
      hasProfile: hasProfile ?? this.hasProfile,
      yearOnly: yearOnly ?? this.yearOnly,
      counters: counters ?? this.counters,
      engagement: engagement ?? this.engagement,
      collections: collections ?? this.collections,
      mentionSource: mentionSource ?? this.mentionSource,
      isFollowing: isFollowing ?? this.isFollowing,
      invitationsCount: invitationsCount ?? this.invitationsCount,
      invitationCode: invitationCode ?? this.invitationCode,
    );
  }

  HiveUser copyWithUser(HiveUser user) {
    return HiveUser(
      id: user.id.isNotEmpty ? user.id : id,
      name: user.name.isNotEmpty ? user.name : name,
      username: user.username.isNotEmpty ? user.username : username,
      email: user.email ?? email,
      isActive: user.isActive ?? isActive,
      avatar: user.avatar ?? avatar,
      phoneNumber: user.phoneNumber ?? phoneNumber,
      birthDate: user.birthDate ?? birthDate,
      location: user.location ?? location,
      instagramHandler: user.instagramHandler ?? instagramHandler,
      bio: user.bio ?? bio,
      hasProfile: user.hasProfile ?? hasProfile,
      yearOnly: user.yearOnly ?? yearOnly,
      counters: user.counters ?? counters,
      engagement: user.engagement ?? engagement,
      collections: user.collections.isNotEmpty ? user.collections : collections,
      mentionSource: user.mentionSource ?? mentionSource,
      isFollowing: user.isFollowing,
      invitationsCount: (user.invitationsCount ?? 0) > (invitationsCount ?? 0) ? user.invitationsCount : invitationsCount,
      invitationCode: (user.invitationCode?.isNotEmpty ?? false) ? user.invitationCode : invitationCode,
    );
  }
}
