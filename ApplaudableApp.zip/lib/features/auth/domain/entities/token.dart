// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';
import 'package:hive/hive.dart';

import '../../../../core/entities/base_hive_types.dart';

part 'token.g.dart';

@HiveType(typeId: BaseHiveTypeIds.tokenModel)
class Token extends Equatable {
  @HiveField(0)
  String access;

  @HiveField(1)
  final String refresh;

  Token({required this.access, required this.refresh});

  @override
  List<Object?> get props => [access, refresh];
}
