class ResetPasswordRequest {
  String? email;
  String? code;
  String? password;

  ResetPasswordRequest({this.email, this.code, this.password});
}
