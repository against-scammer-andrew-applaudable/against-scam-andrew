class SignUpRequest {
  String? name;
  String? username;
  String? email;
  String? password;

  String? instagramHandler;

  String? country;
  String? phoneNumber;

  DateTime? birthDate;

  String? code;
  Object? fields;
  List<String>? missingFields;

  String? inviteCode;

  SignUpRequest(
      {this.name,
      this.username,
      this.email,
      this.password,
      this.instagramHandler,
      this.country,
      this.phoneNumber,
      this.birthDate,
      this.code,
      this.fields,
      this.missingFields,
      this.inviteCode});
}
