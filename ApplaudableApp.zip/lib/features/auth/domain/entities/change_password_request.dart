class ChangePasswordRequest {
  String? email;
  String? code;
  String? password;

  ChangePasswordRequest({
    this.email,
    this.code,
    this.password,
  });
}
