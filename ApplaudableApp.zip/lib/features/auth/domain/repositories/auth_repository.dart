import 'package:dartz/dartz.dart';
import 'package:flutter/material.dart';

import '../../../../core/errors/failures.dart';
import '../../data/models/requests/activate_account_request_model.dart';
import '../../data/models/requests/login_request_model.dart';
import '../../data/models/requests/recover_password_request_model.dart';
import '../../data/models/requests/reset_password_request_model.dart';
import '../../data/models/requests/signup_request_model.dart';
import '../../data/models/requests/token_refresh_request_model.dart';
import '../../data/models/requests/token_verify_request_model.dart';
import '../../presentation/results/app_result.dart';
import '../entities/activate_account_request.dart';
import '../entities/login_request.dart';
import '../entities/recover_password_request.dart';
import '../entities/reset_password_request.dart';
import '../entities/session.dart';
import '../entities/signup_request.dart';

abstract class AuthRepository {
  Future<AppResult> signIn({
    required LoginRequest model,
    @visibleForTesting LoginRequestModel? requestModel,
  });

  Future<AppResult> signInWithPhoneNumber({
    required LoginWithPhoneNumberRequest model,
  });

  Future<AppResult> signInConfirmCode({
    required SignInConfirmCodeRequest model,
  });

  Future<AppResult> signUp({
    required SignUpRequest model,
    @visibleForTesting SignUpRequestModel? requestModel,
  });

  Future<AppResult> logout();

  Future<AppResult> recoverPassword({
    required RecoverPasswordRequest model,
    @visibleForTesting RecoverPasswordRequestModel? requestModel,
  });

  Future<Session?> getSession();

  Future<AppResult> verifyToken({
    @visibleForTesting TokenVerifyRequestModel? requestModel,
  });

  Future<AppResult> refreshToken({
    @visibleForTesting TokenRefreshRequestModel? requestModel,
  });

  Future<AppResult> activateAccount({
    required String uuid,
    required ActivateAccountRequest model,
    @visibleForTesting ActivateAccountRequestModel? requestModel,
  });

  Future<AppResult> resetPassword({
    required ResetPasswordRequest model,
    @visibleForTesting ResetPasswordRequestModel? requestModel,
  });

  Future<Either<Failure, bool>> validateInviteCode({
    required String inviteCode,
  });

  void clear();
}
