import 'dart:async';

import '../../../core/errors/repository_call_handler.dart';
import '../../../features/auth/data/repositories/auth_repository.dart';
import '../../../core/api/services/remote_auth_service.dart';
import '../../../features/auth/data/datasources/local_source.dart';
import '../../../features/auth/data/datasources/remote_auth_data_source.dart';
import '../../../features/auth/domain/repositories/auth_repository.dart';
import '../../../features/auth/domain/entities/session.dart';
import '../../../features/auth/domain/usecases/get_session_use_case.dart';
import '../../../injection_container.dart';
import '../presentation/results/auth/session_data_stream.dart';
import '../presentation/results/base_result_stream.dart';

abstract class BaseSessionApi {
  Stream<BaseStream> getSession();

  void disposeSessionApi();
}

mixin SessionApi implements BaseSessionApi {
  final AuthRepository _repository = AppAuthRepository(
    remoteDataSource: AppRemoteAuthDataSource(
      service: AppRemoteAuthService(),
    ),
    localDataSource: AppLocalDataSource.instance,
    callHandler: servLocator<RepositoryCallHandler>(),
  );

  /// Use Cases
  late final GetSessionUseCase _getSessionUseCase = GetSession(
    repository: _repository,
  );

  /// Actions
  @override
  Stream<BaseStream> getSession() async* {
    final Session? session = await _getSessionUseCase();
    yield SessionDataStream(
      state: session != null ? BaseStateEnum.success : BaseStateEnum.fail,
      data: session,
    );
  }

  /// Dispose
  @override
  void disposeSessionApi() {}
}
