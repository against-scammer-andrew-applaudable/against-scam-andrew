import 'dart:async';

import 'package:dartz/dartz.dart';
import 'package:flutter/material.dart';

import '../../../../app_module.dart';
import '../../../../core/api/remote_api_service.dart';
import '../../../../core/entities/error/error_response.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/errors/repository_call_handler.dart';
import '../../../../core/mappers/auth_mappers.dart';
import '../../domain/entities/activate_account_request.dart';
import '../../domain/entities/login_request.dart';
import '../../domain/entities/recover_password_request.dart';
import '../../domain/entities/reset_password_request.dart';
import '../../domain/entities/session.dart';
import '../../domain/entities/signup_request.dart';
import '../../domain/repositories/auth_repository.dart';
import '../../presentation/results/app_result.dart';
import '../datasources/local_source.dart';
import '../datasources/remote_auth_data_source.dart';
import '../models/requests/activate_account_request_model.dart';
import '../models/requests/login_request_model.dart';
import '../models/requests/login_with_phone_number_request_model.dart';
import '../models/requests/recover_password_request_model.dart';
import '../models/requests/reset_password_request_model.dart';
import '../models/requests/signin_confirm_code_request_model.dart';
import '../models/requests/signup_request_model.dart';
import '../models/requests/token_refresh_request_model.dart';
import '../models/requests/token_verify_request_model.dart';

class AppAuthRepository implements AuthRepository {
  final RemoteAuthDataSource remoteDataSource;
  final AppLocalDataSource localDataSource;
  final RepositoryCallHandler callHandler;

  AppAuthRepository({
    required this.remoteDataSource,
    required this.localDataSource,
    required this.callHandler,
  });

  get logger => AppModule.instance.logger;

  @override
  Future<Session?> getSession() => localDataSource.getSession();

  @override
  Future<AppResult> signIn({
    required LoginRequest model,
    @visibleForTesting LoginRequestModel? requestModel,
  }) async {
    final resultEither = await callHandler.handleCall<AppResult>(
      () async {
        final result = await remoteDataSource.signIn(
          model: requestModel ?? model.toRequestModel(),
        );

        logger.i("Result: $result && State : ${result.status}");

        if (result.isSuccess) {
          await _handleSessionToken(result.data);
        }

        return result;
      },
    );

    return _handleResultEither(resultEither);
  }

  @override
  Future<AppResult> signInWithPhoneNumber({
    required LoginWithPhoneNumberRequest model,
    @visibleForTesting LoginWithPhoneNumberRequestModel? requestModel,
  }) async {
    final resultEither = await callHandler.handleCall<AppResult>(
      () async {
        final result = await remoteDataSource.signInWithPhoneNumber(
          model: requestModel ?? model.toRequestModel(),
        );

        logger.i("Result: $result && State : ${result.status}");

        return result;
      },
    );

    return _handleResultEither(resultEither);
  }

  @override
  Future<AppResult> signInConfirmCode({
    required SignInConfirmCodeRequest model,
    @visibleForTesting SignInConfirmCodeRequestModel? requestModel,
  }) async {
    final resultEither = await callHandler.handleCall<AppResult>(
      () async {
        final result = await remoteDataSource.signInConfirmCode(
          model: requestModel ?? model.toRequestModel(),
        );

        logger.i("Result: $result && State : ${result.status}");

        if (result.isSuccess) {
          await _handleSessionToken(result.data);
        }

        return result;
      },
    );

    return _handleResultEither(resultEither);
  }

  @override
  Future<AppResult> logout() async {
    final resultEither = await callHandler.handleCall<AppResult>(
      () async {
        await localDataSource.clear();
        return AppResult.success();
      },
    );

    return _handleResultEither(resultEither);
  }

  @override
  Future<AppResult> recoverPassword({
    required RecoverPasswordRequest model,
    @visibleForTesting RecoverPasswordRequestModel? requestModel,
  }) async {
    final resultEither = await callHandler.handleCall<AppResult>(
      () async {
        final result = await remoteDataSource.recoverPassword(
          model: requestModel ?? model.toRequestModel(),
        );

        logger.i("Result: $result && State : ${result.status}");

        return result;
      },
    );

    return _handleResultEither(resultEither);
  }

  @override
  Future<AppResult> refreshToken({
    @visibleForTesting TokenRefreshRequestModel? requestModel,
  }) async {
    final resultEither = await callHandler.handleCall<AppResult>(
      () async {
        final session = await localDataSource.getSession();

        if (session != null) {
          final AppResult result = await remoteDataSource.tokenRefresh(
            model: requestModel ??
                TokenRefreshRequestModel(refresh: session.token.refresh),
          );

          logger.i("Result: $result && State : ${result.status}");

          if (!result.isSuccess) {
            _clearSession();
            return AppResult.failure();
          }

          _handleUpdateToken(result.data);
          return result;
        }

        _clearSession();
        return AppResult.failure();
      },
    );

    return _handleResultEither(resultEither);
  }

  @override
  Future<AppResult> signUp({
    required SignUpRequest model,
    @visibleForTesting SignUpRequestModel? requestModel,
  }) async {
    final resultEither = await callHandler.handleCall<AppResult>(
      () async {
        final AppResult result = await remoteDataSource.signUp(
          model: requestModel ?? model.toRequestModel(),
        );

        logger.i("Result: $result && State : ${result.status}");

        if (result.isSuccess) {
          await _handleSessionToken(result.data);
        }

        return result;
      },
    );

    return _handleResultEither(resultEither);
  }

  @override
  Future<AppResult> verifyToken({
    @visibleForTesting TokenVerifyRequestModel? requestModel,
  }) async {
    final resultEither = await callHandler.handleCall<AppResult>(
      () async {
        final session = await localDataSource.getSession();

        if (session != null) {
          final AppResult result = await remoteDataSource.tokenVerify(
            model: requestModel ??
                TokenVerifyRequestModel(token: session.token.access),
          );

          logger.i("Result: $result && State : ${result.status}");

          return result;
        }

        _clearSession();
        return AppResult.failure();
      },
    );

    return _handleResultEither(resultEither);
  }

  @override
  Future<AppResult> activateAccount({
    required String uuid,
    required ActivateAccountRequest model,
    @visibleForTesting ActivateAccountRequestModel? requestModel,
  }) async {
    final resultEither = await callHandler.handleCall<AppResult>(
      () async {
        final result = await remoteDataSource.activateAccount(
          uuid: uuid,
          model: requestModel ?? model.toRequestModel(),
        );

        logger.i("Result: $result && State : ${result.status}");

        if (result.isSuccess) {
          await localDataSource.saveSession(result.data);
        }

        return result;
      },
    );

    return _handleResultEither(resultEither);
  }

  @override
  Future<AppResult> resetPassword({
    required ResetPasswordRequest model,
    @visibleForTesting ResetPasswordRequestModel? requestModel,
  }) async {
    final resultEither = await callHandler.handleCall<AppResult>(
      () async {
        final AppResult result = await remoteDataSource.resetPassword(
          model: requestModel ?? model.toRequestModel(),
        );

        logger.i("Result: $result && State : ${result.status}");

        return result;
      },
    );

    return _handleResultEither(resultEither);
  }

  @override
  void clear() {
    _clearSession();
  }

  AppResult _handleResultEither(
    Either<Failure, AppResult<dynamic>> resultEither,
  ) {
    return resultEither.fold(
      (failure) {
        if (failure is SignInIncompleteFailure) {
          return AppResult.failure(failure.error);
        }

        if (failure is UnauthorizedUserFailure) {
          _clearSession();

          return AppResult.failure(ErrorResponse(message: failure.message));
        }

        return AppResult.failure(ErrorResponse(message: failure.message));
      },
      (respResult) => respResult,
    );
  }

  Future<void> _handleSessionToken(Session session) async {
    /// Save Session into cache
    await localDataSource.saveSession(session);

    /// Update API Service to use latest token
    RemoteApiService.api.token = session.token.access;
  }

  Future<void> _handleUpdateToken(String token) async {
    /// Updates with new token
    await localDataSource.updateSessionToken(token);

    /// Update API Service to use latest token
    RemoteApiService.api.token = token;
  }

  void _clearSession() {
    localDataSource.clear();
    RemoteApiService.api.clearSession();
  }

  @override
  Future<Either<Failure, bool>> validateInviteCode({
    required String inviteCode,
  }) {
    return callHandler.handleCall(
      () => remoteDataSource.validateInviteCode(inviteCode: inviteCode),
    );
  }
}
