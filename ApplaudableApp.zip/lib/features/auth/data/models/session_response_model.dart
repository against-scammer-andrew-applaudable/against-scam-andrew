import 'package:json_annotation/json_annotation.dart';

import 'token_response_model.dart';
import 'user_response_model.dart';

part 'session_response_model.g.dart';

@JsonSerializable(
  fieldRename: FieldRename.snake,
  includeIfNull: false,
)
class SessionResponseModel {
  final TokenResponseModel token;
  final UserResponseModel user;

  SessionResponseModel({
    required this.token,
    required this.user,
  });

  factory SessionResponseModel.fromJson(Map<String, Object?> json) =>
      _$SessionResponseModelFromJson(json);

  Map<String, Object?> toJson() => _$SessionResponseModelToJson(this);
}
