import 'package:json_annotation/json_annotation.dart';

part 'token_response_model.g.dart';

@JsonSerializable(
  fieldRename: FieldRename.snake,
  includeIfNull: false,
)
class TokenResponseModel {
  final String refresh;
  final String access;

  TokenResponseModel({
    required this.refresh,
    required this.access,
  });

  factory TokenResponseModel.fromJson(Map<String, Object?> json) =>
      _$TokenResponseModelFromJson(json);

  Map<String, Object?> toJson() => _$TokenResponseModelToJson(this);
}
