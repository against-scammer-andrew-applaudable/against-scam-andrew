import 'package:json_annotation/json_annotation.dart';

part 'signup_error_response_model.g.dart';

@JsonSerializable(
  fieldRename: FieldRename.snake,
  includeIfNull: false,
)
class SignUpErrorResponseModel {
  final List<String>? email;
  final List<String>? username;
  final List<String>? phoneNumber;

  SignUpErrorResponseModel({
    this.email,
    this.username,
    this.phoneNumber,
  });

  factory SignUpErrorResponseModel.fromJson(Map<String, Object?> json) =>
      _$SignUpErrorResponseModelFromJson(json);

  Map<String, Object?> toJson() => _$SignUpErrorResponseModelToJson(this);
}
