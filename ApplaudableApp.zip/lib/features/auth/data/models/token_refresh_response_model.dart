import 'package:json_annotation/json_annotation.dart';

part 'token_refresh_response_model.g.dart';

@JsonSerializable(
  fieldRename: FieldRename.snake,
  includeIfNull: false,
)
class TokenRefreshResponseModel {
  final String access;

  TokenRefreshResponseModel({
    required this.access,
  });

  factory TokenRefreshResponseModel.fromJson(Map<String, Object?> json) =>
      _$TokenRefreshResponseModelFromJson(json);

  Map<String, Object?> toJson() => _$TokenRefreshResponseModelToJson(this);
}
