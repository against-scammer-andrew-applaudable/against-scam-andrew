import 'package:json_annotation/json_annotation.dart';

part 'activate_account_error_response_model.g.dart';

@JsonSerializable(
  fieldRename: FieldRename.snake,
  includeIfNull: false,
)
class ActivateAccountErrorResponseModel {
  final List<String>? code;
  final List<String>? phoneNumber;

  ActivateAccountErrorResponseModel({
    this.code,
    this.phoneNumber,
  });

  factory ActivateAccountErrorResponseModel.fromJson(
          Map<String, Object?> json) =>
      _$ActivateAccountErrorResponseModelFromJson(json);

  Map<String, Object?> toJson() =>
      _$ActivateAccountErrorResponseModelToJson(this);
}
