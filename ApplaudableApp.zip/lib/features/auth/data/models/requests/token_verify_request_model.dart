import 'package:json_annotation/json_annotation.dart';

part 'token_verify_request_model.g.dart';

@JsonSerializable(
  fieldRename: FieldRename.snake,
  includeIfNull: false,
)
class TokenVerifyRequestModel {
  final String token;

  TokenVerifyRequestModel({
    required this.token,
  });

  factory TokenVerifyRequestModel.fromJson(Map<String, Object?> json) =>
      _$TokenVerifyRequestModelFromJson(json);

  Map<String, Object?> toJson() => _$TokenVerifyRequestModelToJson(this);
}
