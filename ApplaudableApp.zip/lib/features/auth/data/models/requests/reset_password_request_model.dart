import 'package:json_annotation/json_annotation.dart';

part 'reset_password_request_model.g.dart';

@JsonSerializable(
  fieldRename: FieldRename.snake,
  includeIfNull: false,
)
class ResetPasswordRequestModel {
  final String email;
  final String code;
  final String password;
  final String confirmPassword;

  ResetPasswordRequestModel({
    required this.email,
    required this.code,
    required this.password,
    required this.confirmPassword,
  });

  factory ResetPasswordRequestModel.fromJson(Map<String, Object?> json) =>
      _$ResetPasswordRequestModelFromJson(json);

  Map<String, Object?> toJson() => _$ResetPasswordRequestModelToJson(this);
}
