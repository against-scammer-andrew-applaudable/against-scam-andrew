import 'package:json_annotation/json_annotation.dart';

part 'token_refresh_request_model.g.dart';

@JsonSerializable(
  fieldRename: FieldRename.snake,
  includeIfNull: false,
)
class TokenRefreshRequestModel {
  final String refresh;

  TokenRefreshRequestModel({
    required this.refresh,
  });

  factory TokenRefreshRequestModel.fromJson(Map<String, Object?> json) =>
      _$TokenRefreshRequestModelFromJson(json);

  Map<String, Object?> toJson() => _$TokenRefreshRequestModelToJson(this);
}
