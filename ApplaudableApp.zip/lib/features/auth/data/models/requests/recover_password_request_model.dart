import 'package:json_annotation/json_annotation.dart';

part 'recover_password_request_model.g.dart';

@JsonSerializable(
  fieldRename: FieldRename.snake,
  includeIfNull: false,
)
class RecoverPasswordRequestModel {
  final String email;

  RecoverPasswordRequestModel({
    required this.email,
  });

  factory RecoverPasswordRequestModel.fromJson(Map<String, Object?> json) =>
      _$RecoverPasswordRequestModelFromJson(json);

  Map<String, Object?> toJson() => _$RecoverPasswordRequestModelToJson(this);
}
