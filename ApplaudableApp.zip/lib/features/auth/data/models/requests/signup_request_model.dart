import 'package:json_annotation/json_annotation.dart';

import '../../../../../core/serializers/date_serializer.dart';

part 'signup_request_model.g.dart';

@JsonSerializable(
  fieldRename: FieldRename.snake,
  includeIfNull: false,
)
@MandatoryDateSerializer()
class SignUpRequestModel {
  final String name;
  final String username;
  final String password;
  final String email;
  final String phoneNumber;

  final DateTime birthDate;

  final String location;

  final String bio;
  final String code;
  final String instagramHandler;

  final String inviteCode;

  SignUpRequestModel(
      {required this.name,
      required this.username,
      required this.password,
      required this.email,
      required this.phoneNumber,
      required this.birthDate,
      required this.location,
      required this.bio,
      required this.code,
      required this.instagramHandler,
      required this.inviteCode});

  factory SignUpRequestModel.fromJson(Map<String, Object?> json) =>
      _$SignUpRequestModelFromJson(json);

  Map<String, Object?> toJson() => _$SignUpRequestModelToJson(this);
}
