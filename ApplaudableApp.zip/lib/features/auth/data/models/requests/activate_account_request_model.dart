import 'package:json_annotation/json_annotation.dart';

part 'activate_account_request_model.g.dart';

@JsonSerializable(
  fieldRename: FieldRename.snake,
  includeIfNull: false,
)
class ActivateAccountRequestModel {
  final String phoneNumber;
  final String pinCode;

  ActivateAccountRequestModel({
    required this.phoneNumber,
    required this.pinCode,
  });

  factory ActivateAccountRequestModel.fromJson(Map<String, Object?> json) =>
      _$ActivateAccountRequestModelFromJson(json);

  Map<String, Object?> toJson() => _$ActivateAccountRequestModelToJson(this);
}
