import 'package:json_annotation/json_annotation.dart';

part 'login_with_phone_number_request_model.g.dart';

@JsonSerializable(fieldRename: FieldRename.snake, includeIfNull: false)
class LoginWithPhoneNumberRequestModel {
  final String phoneNumber;

  LoginWithPhoneNumberRequestModel({
    required this.phoneNumber,
  });

  factory LoginWithPhoneNumberRequestModel.fromJson(
          Map<String, dynamic> json) =>
      _$LoginWithPhoneNumberRequestModelFromJson(json);

  Map<String, dynamic> toJson() =>
      _$LoginWithPhoneNumberRequestModelToJson(this);
}
