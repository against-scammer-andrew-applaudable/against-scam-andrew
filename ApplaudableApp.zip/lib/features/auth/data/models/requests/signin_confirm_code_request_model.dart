import 'package:json_annotation/json_annotation.dart';

part 'signin_confirm_code_request_model.g.dart';

@JsonSerializable(fieldRename: FieldRename.snake, includeIfNull: false)
class SignInConfirmCodeRequestModel {
  final String phoneNumber;
  final String pinCode;

  SignInConfirmCodeRequestModel(
      {required this.phoneNumber, required this.pinCode});

  factory SignInConfirmCodeRequestModel.fromJson(Map<String, dynamic> json) =>
      _$SignInConfirmCodeRequestModelFromJson(json);

  Map<String, dynamic> toJson() => _$SignInConfirmCodeRequestModelToJson(this);
}
