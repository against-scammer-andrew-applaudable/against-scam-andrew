abstract class BaseParamsRequestModel {
  final int? offset;
  final int? limit;

  BaseParamsRequestModel({
    this.offset,
    this.limit,
  });

  Map<String, Object?> toMap();
}
