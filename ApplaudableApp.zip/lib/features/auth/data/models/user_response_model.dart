import 'package:json_annotation/json_annotation.dart';

import '../../../../core/serializers/date_serializer.dart';

import '../../../post_collections/data/model/post_collections_response_model.dart';
import '../../../post_collections/domain/entities/post_collection.dart';
import '../../../profile/data/models/profile_response_models.dart';
import '../../../profile/domain/entities/profile_response.dart';

part 'user_response_model.g.dart';

@JsonSerializable(
  fieldRename: FieldRename.snake,
  includeIfNull: false,
)
@MandatoryDateSerializer()
class UserResponseModel {
  final String id;
  final String name;

  final String? username;
  final String? email;
  final String? avatar;
  final String? phoneNumber;
  final DateTime? birthDate;
  final bool yearOnly;

  final String? location;
  final String? instagramHandler;
  final String? bio;

  final bool? isActive;
  final bool? isSuspend;
  final bool? hasProfile;

  @JsonKey(includeToJson: false, includeFromJson: false)
  final ProfileCounters? counters;

  @JsonKey(includeToJson: false, includeFromJson: false)
  final UserEngagement? engagement;

  @JsonKey(includeToJson: false, includeFromJson: false)
  final List<PostCollection>? collections;

  @JsonKey(includeToJson: false, includeFromJson: false)
  final bool isFollowing;

  final int invitationsCount;
  final String invitationCode;

  UserResponseModel({
    required this.id,
    required this.name,
    this.username,
    this.email,
    this.phoneNumber,
    this.avatar,
    this.birthDate,
    this.yearOnly = true,
    this.location,
    this.instagramHandler,
    this.bio,
    this.isActive = true,
    this.isSuspend = false,
    this.hasProfile = false,
    this.counters,
    this.engagement,
    this.collections = const [],
    this.isFollowing = false,
    required this.invitationsCount,
    required this.invitationCode,
  });

  factory UserResponseModel.fromJson(Map<String, Object?> json) =>
      _$UserResponseModelFromJson(json);

  factory UserResponseModel.fromProfileJson(Map<String, dynamic> profileJson) {
    return UserResponseModel(
      id: profileJson.containsKey('id') ? profileJson['id'] : "",
      name: profileJson['name'],
      username: profileJson['username'] ?? '',
      email: profileJson['email'] ?? '',
      phoneNumber: profileJson['phone_number'],
      birthDate: _$JsonConverterFromJson<String, DateTime>(
          profileJson['birth_date'], const MandatoryDateSerializer().fromJson),
      yearOnly: profileJson["year_only"] ?? false,
      avatar: profileJson['avatar'],
      location: profileJson['location'],
      instagramHandler: profileJson['instagram_handler'],
      bio: profileJson['bio'],
      isActive: profileJson['is_active'],
      isSuspend: profileJson['is_suspend'],
      hasProfile: profileJson['has_profile'],
      counters: profileJson.containsKey("counters")
          ? ProfileCountersModel.fromJson(profileJson['counters'])
          : ProfileCountersModel.fromJson(const {}),
      engagement: profileJson.containsKey("engagement")
          ? UserEngagementModel.fromJson(profileJson['engagement'])
          : UserEngagementModel(),
      collections: ((profileJson['collections'] ?? []) as List<dynamic>)
          .map((e) => PostCollectionModel.fromJson(e))
          .toList(),
      isFollowing: profileJson['is_following'] ?? false,
      invitationsCount: profileJson['invitations_count'] ?? 0,
      invitationCode: profileJson['invitation_code'] ?? '',
    );
  }

  factory UserResponseModel.fromFollowJson(Map<String, dynamic> profileJson) {
    return UserResponseModel(
      id: profileJson['id'],
      name: profileJson['name'],
      username: profileJson['username'],
      avatar: profileJson['avatar'],
      isFollowing: profileJson['is_following'] ?? false,
      invitationsCount: profileJson['invitations_count'] ?? 0,
      invitationCode: profileJson['invitation_code'] ?? '',
      counters: ProfileCountersModel.fromJson(const {}),
      engagement: UserEngagementModel(),
    );
  }

  factory UserResponseModel.fromFriendInviteJson(
    Map<String, dynamic> profileJson,
  ) {
    return UserResponseModel(
      id: profileJson['id'],
      name: profileJson['name'],
      username: profileJson['username'],
      avatar: profileJson['avatar'],
      invitationsCount: profileJson['invitations_count'] ?? 0,
      invitationCode: profileJson['invitation_code'] ?? '',
      counters: ProfileCountersModel.fromJson(const {}),
      engagement: UserEngagementModel(),
    );
  }

  Map<String, Object?> toJson() => _$UserResponseModelToJson(this);
}
