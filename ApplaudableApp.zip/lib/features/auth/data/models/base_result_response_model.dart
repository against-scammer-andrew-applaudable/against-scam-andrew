abstract class BaseResultResponseModel<T> {
  int? lastPage;

  int? count;

  int? countItemsOnPage;

  int? current;

  String? next;

  String? previous;

  List<T>? results;

  BaseResultResponseModel({
    this.lastPage,
    this.count,
    this.countItemsOnPage,
    this.current,
    this.next,
    this.previous,
    this.results,
  });
}
