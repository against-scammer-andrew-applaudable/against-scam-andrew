import 'package:json_annotation/json_annotation.dart';

import 'default_error_response_model.dart';

part 'signin_incomplete_error_response_model.g.dart';

@JsonSerializable(
  fieldRename: FieldRename.snake,
  includeIfNull: false,
)
class SignInIncompleteErrorResponseModel extends DefaultErrorResponseModel {
  SignInIncompleteErrorResponseModel(
      {String? code, Object? fields, List<String>? missingFields})
      : super(code: code, fields: fields, missingFields: missingFields);

  factory SignInIncompleteErrorResponseModel.fromJson(
          Map<String, Object?> json) =>
      _$SignInIncompleteErrorResponseModelFromJson(json);

  @override
  Map<String, Object?> toJson() =>
      _$SignInIncompleteErrorResponseModelToJson(this);
}
