@Deprecated("")
class LoginWithPhoneResponseModel {
  String? message;
  LoginWithPhoneResponseModel({this.message});
}
