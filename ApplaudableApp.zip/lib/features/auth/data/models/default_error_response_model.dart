import 'package:json_annotation/json_annotation.dart';

part 'default_error_response_model.g.dart';

@JsonSerializable(
  fieldRename: FieldRename.snake,
  includeIfNull: false,
)
class DefaultErrorResponseModel {
  final String? code;
  final String? detail;

  final Object? fields;
  final List<String?>? missingFields;

  DefaultErrorResponseModel(
      {this.code, this.detail, this.fields, this.missingFields});

  factory DefaultErrorResponseModel.fromJson(Map<String, Object?> json) =>
      _$DefaultErrorResponseModelFromJson(json);

  Map<String, Object?> toJson() => _$DefaultErrorResponseModelToJson(this);
}
