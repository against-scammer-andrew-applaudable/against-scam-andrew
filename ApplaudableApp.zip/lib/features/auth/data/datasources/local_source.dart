import 'dart:async';

import 'package:hive/hive.dart';

import '../../domain/entities/session.dart';
import '../../domain/entities/token.dart';
import '../../domain/entities/user.dart';
import '../../../influence/domain/entities/influence_impression.dart';

class CacheKeys {
  static const session = 'Session';
}

class AppLocalDataSource {
  static final AppLocalDataSource _instance = AppLocalDataSource._();

  static AppLocalDataSource get instance => _instance;

  AppLocalDataSource._() {
    /// Register models
    this
      ..register<Token>(TokenAdapter())
      ..register<HiveUser>(HiveUserAdapter())
      ..register<Session>(SessionAdapter())
      ..register<PostSeenImpression>(PostSeenImpressionAdapter());
  }

  final Map<int, TypeAdapter> adapters = <int, TypeAdapter>{};

  register<T>(TypeAdapter<T> adapter) {
    var typeId = adapter.typeId;
    if (adapters.containsKey(typeId)) {
      return;
    }

    Hive.registerAdapter<T>(adapter);
    adapters.putIfAbsent(typeId, () => adapter);
  }

  Future<Box<T>?> open<T>(String name) async {
    Box<T>? box;
    try {
      box = await Hive.openBox<T>(name);
    } on Error catch (_) {
      /// fallback in case any error on opening the box.
      bool success = false;
      int attempt = 0;
      while (!success) {
        name = name + attempt.toString();
        Error? err;
        try {
          box = await Hive.openBox<T>(name);
        } on Error catch (e) {
          err = e;
        }

        if (err == null) {
          success = true;
        } else if (attempt > 10) {
          /// Crashlytics
          /// TODO: uncomment
          //FirebaseCrashlytics.instance.recordError(_err, _err.stackTrace!);
          throw ("Hive box could not be opened.");
        }
        attempt++;
      }
      return box;
    }
    return box;
  }

  Future<void> saveValues<T>(String key, List<T> values) async {
    final Box<T> box = (await (open<T>(key)))!;
    await box.clear();
    await box.addAll(values);
  }

  Future<T> saveValue<T>(String key, T value) async {
    final Box<T> box = (await (open<T>(key)))!;
    final int savedKey = await box.add(value);
    return box.get(savedKey)!;
  }

  Future<void> updateValue<T>(String key, int valueKey, T value) async {
    final Box<T> box = (await (open<T>(key)))!;
    await box.put(valueKey, value);
  }

  Future<List<T>> getValues<T>(String key, {int? limit}) async {
    final Box<T> box = (await (open<T>(key)))!;

    if (limit != null) {
      return box.values.take(limit).toList();
    }

    return box.values.toList();
  }

  Future<T?> getListValue<T>(String key, bool Function(T e) lookup) async {
    final Box<T> box = (await (open<T>(key)))!;
    try {
      return box.values.toList().firstWhere(lookup);
    } on StateError {
      return null;
    }
  }

  Future<T?> getValue<T>(String key) async {
    final Box<T>? box = (await (open<T>(key)));
    try {
      if (box != null && box.isNotEmpty) {
        return box.values.toList().first;
      } else {
        return null;
      }
    } on Exception {
      return null;
    }
  }

  Future<void> removeValue<T>(String key, int valueKey) async {
    final Box<T> box = (await (open<T>(key)))!;
    await box.delete(valueKey);
  }

  Future<void> removeAll<T>(String key, List<int>? keys) async {
    final Box<T> box = (await (open<T>(key)))!;

    if (keys != null) {
      await box.deleteAll(keys);
      return;
    }

    await box.clear();
  }

  Future<void> updateSessionToken(String token) async {
    final Session? session = await getSession();
    if (session != null) {
      session.token.access = token;
      await session.save();
    }
  }

  Future<void> updateSessionUser(HiveUser user) async {
    final Session? session = await getSession();
    if (session != null) {
      session.user = session.user.copyWithUser(user);
      await session.save();
    }
  }

  Future<void> updateUserAvatarUrl(String avatarUrl) async {
    final Session? session = await getSession();

    if (session != null) {
      session.user.avatar = avatarUrl;
      await session.save();
    }
  }
  Future<void> updateUsername(String username) async {
    final Session? session = await getSession();

    if (session != null) {
      session.user.username = username;
      await session.save();
    }
  }

  Future<void> updateInvitationCode(String invitationCode) async {
    final Session? session = await getSession();

    if (session != null) {
      session.user.invitationCode = invitationCode;
      await session.save();
    }
  }

  Future<bool> hasValidSession() async {
    final Session? session = await getValue<Session>(CacheKeys.session);
    if (session == null) {
      return false;
    }
    return true;
  }

  Future<Session?> getSession() async {
    return getValue<Session>(CacheKeys.session);
  }

  Future<Map<String, String>> getHeaders() async {
    final Session? session = await getSession();
    return <String, String>{'Authorization': 'Bearer ${session?.token.access}'};
  }

  Future<void> saveSession(Session session) async {
    final box = (await (open<Session>(CacheKeys.session)))!;
    await box.clear();
    await box.add(session);
  }

  Future<void> listen(String key, void Function(BoxEvent event)? onData) async {
    await open(key)
        .then((box) => box?.watch(key: key))
        .then((stream) => stream?.listen(onData));
  }

  Future<void> clear() async {
    // clear session box
    Box box = (await (open<Session>(CacheKeys.session)))!;
    await box.clear();

    //clear User Box
    // box = (await (open<List<User>>(CacheKeys.friends)))!;
    // await box.clear();
  }
}
