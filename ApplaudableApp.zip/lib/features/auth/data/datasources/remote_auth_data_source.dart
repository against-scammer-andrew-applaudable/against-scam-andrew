import '../../../../app_module.dart';
import '../../../../core/api/services/remote_auth_service.dart';
import '../../../../core/mappers/auth_mappers.dart';
import '../../presentation/results/app_result.dart';
import '../models/requests/activate_account_request_model.dart';
import '../models/requests/login_request_model.dart';
import '../models/requests/login_with_phone_number_request_model.dart';
import '../models/requests/recover_password_request_model.dart';
import '../models/requests/reset_password_request_model.dart';
import '../models/requests/signin_confirm_code_request_model.dart';
import '../models/requests/signup_request_model.dart';
import '../models/requests/token_refresh_request_model.dart';
import '../models/requests/token_verify_request_model.dart';
import '../models/session_response_model.dart';
import '../models/token_refresh_response_model.dart';

abstract class RemoteAuthDataSource {
  Future<AppResult> signUp({
    required SignUpRequestModel model,
  });

  Future<AppResult> signIn({
    required LoginRequestModel model,
  });

  Future<AppResult> signInWithPhoneNumber({
    required LoginWithPhoneNumberRequestModel model,
  });

  Future<AppResult> signInConfirmCode({
    required SignInConfirmCodeRequestModel model,
  });

  Future<AppResult> recoverPassword({
    required RecoverPasswordRequestModel model,
  });

  Future<AppResult> tokenVerify({
    required TokenVerifyRequestModel model,
  });

  Future<AppResult> tokenRefresh({
    required TokenRefreshRequestModel model,
  });

  Future<AppResult> activateAccount({
    required String uuid,
    required ActivateAccountRequestModel model,
  });

  Future<AppResult> resetPassword({
    required ResetPasswordRequestModel model,
  });

  Future<bool> validateInviteCode({
    required String inviteCode,
  });
}

class AppRemoteAuthDataSource implements RemoteAuthDataSource {
  final RemoteAuthService service;

  get logger => AppModule.instance.logger;

  AppRemoteAuthDataSource({required this.service});

  @override
  Future<AppResult> signIn({
    required LoginRequestModel model,
  }) async {
    final response = await service.signIn(model: model);

    final sessionResponseModel = SessionResponseModel.fromJson(response);

    return AppResult.success(sessionResponseModel.toEntity());
  }

  @override
  Future<AppResult> signInWithPhoneNumber({
    required LoginWithPhoneNumberRequestModel model,
  }) async {
    await service.signInWithPhoneNumber(model: model);

    return AppResult.success();
  }

  @override
  Future<AppResult> signInConfirmCode({
    required SignInConfirmCodeRequestModel model,
  }) async {
    final response = await service.signInConfirmCode(model: model);

    final sessionResponseModel = SessionResponseModel.fromJson(response);

    return AppResult.success(sessionResponseModel.toEntity());
  }

  @override
  Future<AppResult> recoverPassword({
    required RecoverPasswordRequestModel model,
  }) async {
    await service.recoverPassword(model: model);

    return AppResult.success();
  }

  @override
  Future<AppResult> signUp({required SignUpRequestModel model}) async {
    final response = await service.signUp(model: model);

    final responseModel = SessionResponseModel.fromJson(response);

    return AppResult.success(responseModel.toEntity());
  }

  @override
  Future<AppResult> tokenRefresh({
    required TokenRefreshRequestModel model,
  }) async {
    final response = await service.tokenRefresh(model: model);

    final responseModel = TokenRefreshResponseModel.fromJson(response);

    return AppResult.success(responseModel.access);
  }

  @override
  Future<AppResult> tokenVerify({
    required TokenVerifyRequestModel model,
  }) async {
    await service.tokenVerify(model: model);

    return AppResult.success();
  }

  @override
  Future<AppResult> activateAccount({
    required String uuid,
    required ActivateAccountRequestModel model,
  }) async {
    final json = await service.activateAccount(uuid: uuid, model: model);

    final response = SessionResponseModel.fromJson(json);

    return AppResult.success(response.toEntity());
  }

  @override
  Future<AppResult> resetPassword({
    required ResetPasswordRequestModel model,
  }) async {
    await service.resetPassword(model: model);

    return AppResult.success();
  }

  @override
  Future<bool> validateInviteCode({required String inviteCode}) async {
    final parsedJson = await service.validateInviteCode(inviteCode: inviteCode);

    return parsedJson['success'];
  }
}
