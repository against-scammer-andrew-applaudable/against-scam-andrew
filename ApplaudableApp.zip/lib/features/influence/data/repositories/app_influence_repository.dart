import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/errors/repository_call_handler.dart';
import '../../../auth/data/datasources/local_source.dart';
import '../../domain/repositories/influence_repository.dart';
import '../../domain/usecases/send_post_analytics.dart';
import '../datasources/influence_remote_data_source.dart';

class AppInfluenceRepository extends InfluenceRepository {
  final RepositoryCallHandler callHandler;
  final InfluenceRemoteDataSource remoteDataSource;
  final AppLocalDataSource localDataSource;

  AppInfluenceRepository({
    required this.callHandler,
    required this.remoteDataSource,
    required this.localDataSource,
  });

  @override
  Future<Either<Failure, List<int>>> sendInfluencesPosts({
    required PostAnalyticsParams params,
  }) {
    return callHandler.handleCall<List<int>>(
      () async => remoteDataSource.sendInfluencesPosts(params: params),
    );
  }
}
