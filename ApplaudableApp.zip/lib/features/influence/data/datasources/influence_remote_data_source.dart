import 'package:flutter/foundation.dart';

import '../../../../core/api/api_config.dart';
import '../../../../core/api/api_service.dart';
import '../../../../core/api/remote_api_service.dart';
import '../../domain/usecases/send_post_analytics.dart';

abstract class InfluenceRemoteDataSource {
  /// Send analytics
  Future<List<int>> sendInfluencesPosts({required PostAnalyticsParams params});
}

class AppInfluenceRemoteDataSource extends InfluenceRemoteDataSource {
  ApiService _httpClient = RemoteApiService.api;

  @visibleForTesting
  set setMockApiClient(ApiService apiService) => _httpClient = apiService;

  @override
  Future<List<int>> sendInfluencesPosts({
    required PostAnalyticsParams params,
  }) async {
    await _httpClient.postRaw(
        url: ApiResource.influencesPosts, body: params.toListMap());

    return params.impressions.map((e) => e.key as int).toList();
  }
}
