import 'dart:async';
import 'dart:developer';

import 'package:flutter/material.dart';

import '../../../../core/entities/item.dart';
import '../../../auth/data/datasources/local_source.dart';
import '../../../../injection_container.dart';
import '../../domain/entities/influence_impression.dart';
import '../blocs/influence_bloc.dart';

mixin InfluenceAnalytics<T extends InfluenceItemImpression> {
  final local = AppLocalDataSource.instance;

  String get modelKey;

  Future<T?> _get(String id) async {
    return await local.getListValue<T>(modelKey, (e) => e.id == id);
  }

  Future<void> _add(T impression) async =>
      await local.saveValue<T>(modelKey, impression);

  Future<void> _update(String id, int valueKey, T impression) async {
    T? value = await _get(id);
    if (value == null) {
      await local.saveValue<T>(modelKey, impression);
      return;
    }
    await local.updateValue<T>(modelKey, valueKey, impression);
  }

  Future<void> _removeAll(List<int> keys) async =>
      await local.removeAll<T>(modelKey, keys);

  Future<void> _remove(int valueKey) async =>
      await local.removeValue<T>(modelKey, valueKey);

  Future<void> clear() async => await local.removeAll<T>(modelKey, null);
}

/// Influences Controller:
///  ** [X] Create timer
///  ** [X] On time pick all the influences
///  ** [X] Send and on success delete the sent ones
///  ** [X] Handle case the user goes to background or state changed
///  ** [X] Ignore if not greater than [minimumInfluenceTime]
///  ** [X] Do not update impressions that are currently being sent to server
class InfluencesPosts with InfluenceAnalytics<PostSeenImpression> {
  /// Minimum allow time to register an influence, in milliseconds
  static const int minimumInfluenceTime = 1000;

  /// Timer to run each [periodicTime] seconds
  static const int periodicTime = 15;

  static const String tag = '.InfluencesPosts';
  static final InfluencesPosts _controller = InfluencesPosts._();

  static InfluencesPosts get I => _controller;

  /// Request using InfluenceBloc
  StreamSubscription<InfluenceState>? _stream;
  final InfluenceBloc bloc = servLocator<InfluenceBloc>();

  InfluencesPosts._() {
    init();
  }

  @override
  String get modelKey => "influences_posts";

  Timer? _timer;

  List<int> processingBatchItemKeys = [];

  bool _initialized = false;
  bool isRequesting = false;

  void init() {
    if (_initialized) {
      return;
    }
    _initialized = true;

    _stream = bloc.stream.listen(listener);

    run();
    clear();
  }

  void update<T extends Item>(T item,
      {int time = 0, Object? metadata, VoidCallback? onDone}) async {
    if (time == 0) {
      return;
    }

    if (time < minimumInfluenceTime) {
      log("Time [$time] less than [$minimumInfluenceTime], ignoring");
      return;
    }

    /// check if already exists
    PostSeenImpression? impression = await _get(item.id);
    if (impression == null) {
      PostSeenImpression impression = PostSeenImpression(
          id: item.id,
          time: time,
          metadata: PostSeenImpression.initialMetadata(time));

      /// Cache impression to be sent later
      await _add(impression);

      /// on ready call [onDone]
      onDone?.call();
      return;
    }

    /// If the current item keys are being sent to server then
    /// do not update the existing created objects,
    /// because this ones will be removed upon on successfully sent.
    ///
    /// Instead create new entries to send in the next batch request
    if (processingBatchItemKeys.contains(impression.key)) {
      PostSeenImpression impressionCopy = impression.copy(
          time: time, metadata: PostSeenImpression.initialMetadata(time));

      /// Cache impression to be sent later
      await _add(impressionCopy);

      /// on ready call [onDone]
      onDone?.call();
      return;
    }

    /// Copy [impression] instance
    ///
    /// Then update the time to have the total time so far
    /// Then update metadata to add a new entry
    PostSeenImpression impressionCopy = impression.copy(
        time: (impression.time ?? 0) + time,
        metadata: impression.updateMetadata(time));

    /// Cache updated impression to be sent later
    await _update(item.id, impression.key, impressionCopy);

    /// on ready call [onDone]
    onDone?.call();
  }

  void run() {
    if (null != _timer) {
      _timer!.cancel();
    }
    _timer = Timer.periodic(const Duration(seconds: periodicTime), onTime);
  }

  void onTime(Timer t) {
    if (isRequesting) {
      return;
    }

    isRequesting = true;
    processBatch();
  }

  void processBatch() async {
    var list = await local.getValues<PostSeenImpression>("influences_posts",
        limit: 100);
    if (list.isEmpty) {
      isRequesting = false;
      return;
    }
    bloc.emit(InfluenceLoadingState());

    /// Save the keys that are being send at the moment
    /// this will be used to know
    /// what are the post impressions that should not be used
    /// to update
    /// and instead to create new entries
    processingBatchItemKeys = [...list.map((e) => e.key).toList()];

    /// Create Event for Request
    SendPostInfluencesEvent event = SendPostInfluencesEvent(impressions: list);

    /// Add event to request and send the post impressions
    bloc.add(event);
  }

  void stateChange(AppLifecycleState state) {
    switch (state) {
      case AppLifecycleState.resumed:
        init();
        break;
      case AppLifecycleState.inactive:
        // TODO: Handle this case.
        break;
      case AppLifecycleState.paused:
        dispose();
        break;
      case AppLifecycleState.detached:
        // TODO: Handle this case.
        break;
      case AppLifecycleState.hidden:
        // TODO: Handle this case.
        break;
    }
  }

  listener(event) {
    if (event is InfluenceResultFetchedState) {
      isRequesting = false;
      _removeAll(event.ids);
      processingBatchItemKeys.clear();
    }
  }

  dispose() {
    _initialized = false;
    _stream?.cancel();
    _timer?.cancel();
  }
}
