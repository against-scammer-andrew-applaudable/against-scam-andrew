part of 'influence_bloc.dart';

abstract class InfluenceEvent extends Equatable {
  const InfluenceEvent();

  @override
  List<Object?> get props => [];
}

class SendPostInfluencesEvent extends InfluenceEvent {
  final List<PostSeenImpression> impressions;

  const SendPostInfluencesEvent({
    required this.impressions,
  });

  @override
  List<Object?> get props => [impressions];
}
