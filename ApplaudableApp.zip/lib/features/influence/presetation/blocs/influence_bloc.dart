import 'package:equatable/equatable.dart';

import '../../../../core/bloc/dng_base_bloc.dart';
import '../../../../core/errors/failures.dart';
import '../../../feed/domain/entities/post_response.dart';
import '../../domain/entities/influence_impression.dart';
import '../../domain/usecases/send_post_analytics.dart';

part 'influence_event.dart';
part 'influence_state.dart';

class InfluenceBloc extends DNGBloc<InfluenceEvent, InfluenceState> {
  final SendPostsAnalytics sendPostsAnalytics;

  InfluenceBloc({required this.sendPostsAnalytics})
      : super(InfluenceInitialState());

  Post? item;

  @override
  void mapEventToState(InfluenceEvent event) async {
    if (event is SendPostInfluencesEvent) {
      await _handleSendPostsAnalyticsEvent(event);
    }
  }

  Future<void> _handleSendPostsAnalyticsEvent(
      SendPostInfluencesEvent event) async {
    final result = await sendPostsAnalytics(
      PostAnalyticsParams(
        impressions: event.impressions,
      ),
    );

    emit(
      result.fold(
        (failure) => _mapFailureToState(failure),
        (response) {
          return InfluenceResultFetchedState(ids: response);
        },
      ),
    );

    emit(InfluenceDoNothingState());
  }

  InfluenceState _mapFailureToState(Failure failure) {
    if (failure is ServerFailure) {
      return InfluenceErrorState(message: failure.message);
    } else if (failure is NetworkFailure) {
      return InfluenceErrorState(message: failure.message);
    } else {
      return InfluenceErrorState(message: failure.message);
    }
  }
}
