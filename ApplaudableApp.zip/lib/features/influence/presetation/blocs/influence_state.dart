part of 'influence_bloc.dart';

abstract class InfluenceState extends Equatable {
  const InfluenceState();

  @override
  List<Object?> get props => [];
}

/// Send Posts Influences
class InfluenceInitialState extends InfluenceState {}

class InfluenceLoadingState extends InfluenceState {}

class InfluenceEmptyState extends InfluenceState {}

class InfluenceResultFetchedState extends InfluenceState {
  final List<int> ids;

  const InfluenceResultFetchedState({
    required this.ids,
  });

  @override
  List<Object?> get props => [ids];
}

/// Default error state
class InfluenceErrorState extends InfluenceState {
  final String message;

  const InfluenceErrorState({required this.message});

  @override
  List<Object?> get props => [message];
}

class InfluenceDoNothingState extends InfluenceState {}
