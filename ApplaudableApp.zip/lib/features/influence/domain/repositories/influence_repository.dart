import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../usecases/send_post_analytics.dart';

abstract class InfluenceRepository {
  // Feed Request a Post Action
  Future<Either<Failure, List<int>>> sendInfluencesPosts({
    required PostAnalyticsParams params,
  });
}
