import 'package:equatable/equatable.dart';
import 'package:hive/hive.dart';

import '../../../../core/entities/base_hive_types.dart';

part 'influence_impression.g.dart';

abstract class InfluenceItemImpression with EquatableMixin {
  final String id;
  final int? time;
  final Object? metadata;

  const InfluenceItemImpression({required this.id, this.time, this.metadata});

  @override
  List<Object?> get props => [id, time, metadata];
}

@HiveType(typeId: BaseHiveTypeIds.influencePostImpressionModel)
class PostSeenImpression
    with HiveObjectMixin, EquatableMixin
    implements InfluenceItemImpression {
  static initialMetadata(time) => <String, Object>{
        "impressions": [
          <String, Object>{"time": time, "impression": 1}
        ]
      };

  @override
  @HiveField(0)
  final String id;

  @override
  @HiveField(1)
  final int? time;

  @override
  @HiveField(2)
  final Object? metadata;

  PostSeenImpression({required this.id, this.time, this.metadata});

  @override
  List<Object?> get props => [id, time, metadata];

  PostSeenImpression copy({String? id, int? time, Object? metadata}) {
    return PostSeenImpression(
        id: id ?? this.id,
        time: time ?? this.time,
        metadata: metadata ?? this.metadata);
  }

  Map<String, Object> updateMetadata(int time) {
    Map<String, Object> metadataMap =
        (metadata ?? <String, Object>{}) as Map<String, Object>;
    if (!metadataMap.containsKey("impressions")) {
      metadataMap.putIfAbsent(
          "impressions",
          () => <Map<String, Object>>[
                <String, Object>{"time": time, "impression": 1}
              ]);
      return metadataMap;
    }
    if (metadataMap.containsKey("impressions")) {
      List<Map<String, Object>> imps =
          metadataMap["impressions"] as List<Map<String, Object>>;
      imps.add({"time": time, "impression": imps.length + 1});
    }

    return metadataMap;
  }
}
