import 'dart:convert';

import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../entities/influence_impression.dart';
import '../repositories/influence_repository.dart';

class SendPostsAnalytics extends UseCase<List<int>, PostAnalyticsParams> {
  final InfluenceRepository repository;

  SendPostsAnalytics({required this.repository});

  @override
  Future<Either<Failure, List<int>>> call(PostAnalyticsParams params) {
    return repository.sendInfluencesPosts(params: params);
  }
}

class PostAnalyticsParams extends Equatable {
  final List<PostSeenImpression> impressions;

  const PostAnalyticsParams({
    required this.impressions,
  });

  @override
  List<Object?> get props => [
        impressions,
      ];

  List<Map<String, Object?>> toListMap() {
    return impressions
        .map((e) => {
              "post": e.id,
              "view_time": e.time,
              "metadata": jsonEncode(e.metadata)
            })
        .toList();
  }
}
