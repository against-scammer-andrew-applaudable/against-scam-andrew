import 'package:country_codes/country_codes.dart';
import 'package:country_picker/country_picker.dart';
import 'package:flutter_contacts/contact.dart';
import 'package:flutter_contacts/properties/phone.dart';
import 'package:flutter_sim_country_code/flutter_sim_country_code.dart';

extension ContactExteensions on Contact {
  String get fullname {
    String fname = name.prefix.trim();

    if (name.first.trim().isNotEmpty) fname += ' ${name.first.trim()}';
    if (name.nickname.trim().isNotEmpty) fname += ' ${name.nickname.trim()}';
    if (name.middle.trim().isNotEmpty) fname += ' ${name.middle.trim()}';
    if (name.last.trim().isNotEmpty) fname += ' ${name.last.trim()}';
    if (name.suffix.trim().isNotEmpty) fname += ' ${name.suffix.trim()}';

    return fname;
  }
}

extension PhoneExtensions on Phone {
  /// returns the abstract phone number without any formatting.
  String get abstractNumber {
    final phone = number.replaceAll(RegExp(r'[\s ()-]'), '');

    if (!phone.trim().startsWith('+') && !phone.trim().startsWith('00')) {
      _getSIMCountryCode();

      if (_countryCode != null) {
        final phoneCode = Country.tryParse(_countryCode!)?.phoneCode ?? '';

        return '+$phoneCode$phone';
      }
    }

    return phone;
  }

  static String? _countryCode;

  _getSIMCountryCode() async {
    if (_countryCode != null) return _countryCode;

    final String? simCountryCode = await FlutterSimCountryCode.simCountryCode;

    /// If [simCountryCode] is null or empty then try get from locale
    if (simCountryCode == null ||
        simCountryCode.isEmpty ||
        simCountryCode == "--") {
      final CountryDetails details = CountryCodes.detailsForLocale();
      _countryCode = details.alpha2Code;
      return;
    }

    _countryCode = simCountryCode;
  }
}
