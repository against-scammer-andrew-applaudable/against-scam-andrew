import 'dart:io';

import 'package:applaudable/core/extensions/color_scheme.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app_module.dart';
import '../../features/auth/presentation/controllers/controller.dart';
import '../../routes.dart';
import '../theme/dimensions.dart';
import '../theme/styles.dart';
import '../theme/themes.dart';
import '../../features/auth/presentation/widgets/buttons/action_button.dart';
import '../../features/auth/presentation/widgets/sizing/side_margins.dart';

/// TODO: Should be merged into the other extension
/// BuildContext extenstions
extension BuildContextExtensions on BuildContext {
  // Theme related extensions
  ThemeData get theme => Theme.of(this);

  // Colors
  // Color get primaryColor => Theme.of(this).primaryColor;

  Color get canvasColor => Theme.of(this).scaffoldBackgroundColor;

  bool get isLight => MediaQuery.of(this).platformBrightness == Brightness.light;
  Color get scaffoldBackgroundColor => Theme.of(this).scaffoldBackgroundColor;
  Color get primaryColor => Theme.of(this).colorScheme.primaryColor;
  Color get disabledPrimaryColor => Theme.of(this).colorScheme.disabledPrimaryColor;
  Color get logoColor => Theme.of(this).colorScheme.logoColor;
  Color get textColor => Theme.of(this).colorScheme.textColor;
  Color get hintTextColor => Theme.of(this).colorScheme.hintTextColor;
  Color get borderColor => Theme.of(this).colorScheme.borderColor;
  Color get circleBorderColor => Theme.of(this).colorScheme.circleBorderColor;
  Color get textInputColor => Theme.of(this).colorScheme.textInputColor;
  Color get backgroundColor => Theme.of(this).colorScheme.backgroundColor;
  Color get mainContentColor => Theme.of(this).colorScheme.mainContentColor;
  Color get mainContentBorderColor => Theme.of(this).colorScheme.mainContentBorderColor;
  Color get captionTextColor => Theme.of(this).colorScheme.captionTextColor;
  Color get feedCardColor => Theme.of(this).colorScheme.feedCardColor;
  Color get quoteCardColor => Theme.of(this).colorScheme.quoteCardColor;
  Color get percent5Color => Theme.of(this).colorScheme.percent5Color;

  // Test Styles
  TextTheme get textTheme => Theme.of(this).textTheme;

  TextStyle? get title => textTheme.titleLarge;

  TextStyle? get buttonTextTheme => textTheme.labelLarge;

  TextStyle? get body1TextTheme => textTheme.bodyLarge;

  TextStyle? get body2TextTheme => textTheme.bodyMedium;

  TextStyle? get subtitle1TextTheme => textTheme.titleMedium;

  TextStyle? get subtitle2TextTheme => textTheme.titleSmall;

  // Dimentions
  MediaQueryData get queryData => MediaQuery.of(this);

  double get screenWidth => queryData.size.width;

  double get screenHeight => queryData.size.height;

  EdgeInsets get padding => queryData.padding;

  double get paddingTop => queryData.padding.top;

  double get paddingBottom => queryData.padding.bottom;

  double get deviceVerticalPadding => paddingTop + paddingBottom;

  // Navigator related extensions
  get arguments => ModalRoute.of(this)?.settings.arguments;

  void Function<T extends Object?>([T? result]) get pop =>
      Navigator.of(this).pop;

  void Function(RoutePredicate predicate) get popUntil =>
      Navigator.of(this).popUntil;

  Future<T?> Function<T extends Object?>(String routeName, {Object? arguments})
      get navigateToNamed => Navigator.of(this).pushNamed;

  void popUntilFromRoute(String predicate) =>
      popUntil((Route route) => route.settings.name == predicate);

  String? get currentRouteName => ModalRoute.of(this)?.settings.name;

  Future<T?> Function<T extends Object?, TO extends Object?>(
    String routeName, {
    TO? result,
    Object? arguments,
  }) get navigateToNamedReplacement => Navigator.of(this).pushReplacementNamed;

  void unfocus() => FocusScope.of(this).unfocus();

  Locale currentLocale() => Localizations.localeOf(this);

  BaseController get baseController =>
      Provider.of<BaseController>(this, listen: false);

  String get currentSessionUserId => baseController.currentUser!.id;

  void navigateToHome() =>
      AppModule.instance.navigatorKey.currentState?.popUntil(
        (Route route) => route.settings.name == Routes.home,
      );

  NavigatorState? get navigatorKey =>
      AppModule.instance.navigatorKey.currentState;

  Future<DateTime?> showAppDatePicker({
    required DateTime initialDate,
    required DateTime firstDate,
    required DateTime lastDate,
  }) async {
    if (Platform.isIOS) {
      DateTime datetime = initialDate;
      return showCupertinoModalPopup<DateTime?>(
        context: this,
        builder: (BuildContext context) => Container(
          color: context.scaffoldBackgroundColor,
          child: SafeArea(
            top: false,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  height: 250.0,
                  child: CupertinoDatePicker(
                    mode: CupertinoDatePickerMode.date,
                    initialDateTime: initialDate,
                    minimumDate: firstDate,
                    maximumDate: lastDate,
                    onDateTimeChanged: (DateTime selectedDateTime) {
                      datetime = selectedDateTime;
                    },
                  ),
                ),
                const SizedBox(
                  height: 15.0,
                ),
                AppSideMargins(
                  child: AppActionButton.submit(
                    text: 'OK',
                    onPressed: () => navigatorKey?.pop(datetime),
                  ),
                ),
                const SizedBox(
                  height: AppDimensions.defaultSideMargin,
                ),
              ],
            ),
          ),
        ),
      );
    } else {
      return showDatePicker(
        context: this,
        initialEntryMode: DatePickerEntryMode.calendarOnly,
        initialDate: initialDate,
        firstDate: firstDate,
        lastDate: lastDate,
        builder: (BuildContext context, Widget? child) => Theme(
          data: AppThemes.defaultTheme,
          child: child!,
        ),
      );
    }
  }

  Future showAlertDialog(
      {String? title = "Info", String? description = ""}) async {
    return showCupertinoModalPopup<void>(
      context: this,
      builder: (BuildContext context) => CupertinoAlertDialog(
        title: Text(title ?? ""),
        content: Text(description ?? ""),
        actions: <CupertinoDialogAction>[
          CupertinoDialogAction(
            isDefaultAction: true,
            onPressed: () {
              Navigator.pop(context, false);
            },
            child: Text(
              'No',
              style: AppStyles.header2(color: context.textColor),
            ),
          ),
          CupertinoDialogAction(
            isDestructiveAction: true,
            onPressed: () {
              Navigator.pop(context, true);
            },
            child: const Text('Yes'),
          ),
        ],
      ),
    );
  }
}
