import 'package:flutter/material.dart';

extension AppColorScheme on ColorScheme {
  Color get primaryColor => primary;
  Color get disabledPrimaryColor => onPrimary;
  Color get logoColor => background;
  Color get textColor => secondary;
  Color get hintTextColor => onSecondary;
  Color get borderColor => onBackground;
  Color get circleBorderColor => onSurface;
  Color get textInputColor => surface;
  Color get backgroundColor => error;
  Color get mainContentColor => primaryContainer;
  Color get mainContentBorderColor => onPrimaryContainer;
  Color get captionTextColor => secondaryContainer;
  Color get feedCardColor => onError;
  Color get quoteCardColor => onErrorContainer;
  Color get percent5Color => errorContainer;

  static ColorScheme defineScheme({
    required Brightness brightness,
    required Color primaryColor,
    required Color disabledPrimaryColor,
    required Color logoColor,
    required Color textColor,
    required Color hintTextColor,
    required Color borderColor,
    required Color circleBorderColor,
    required Color textInputColor,
    required Color backgroundColor,
    required Color mainContentColor,
    required Color mainContentBorderColor,
    required Color captionTextColor,
    required Color feedCardColor,
    required Color quoteCardColor,
    required Color percent5Color,
  }) {
    return ColorScheme(
      brightness: Brightness.dark,
      primary: primaryColor,
      onPrimary: disabledPrimaryColor,
      background: logoColor,
      secondary: textColor,
      onSecondary: hintTextColor,
      onBackground: borderColor,
      onSurface: circleBorderColor,
      surface: textInputColor,
      error: backgroundColor,
      primaryContainer: mainContentColor,
      onPrimaryContainer: mainContentBorderColor,
      secondaryContainer: captionTextColor,
      onError: feedCardColor,
      onErrorContainer: quoteCardColor,
      errorContainer: percent5Color,
    );
  }
}