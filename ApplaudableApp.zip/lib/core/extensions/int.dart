import 'package:sprintf/sprintf.dart';

extension IntEx on int {
  String get formattedCounter {
    if (this < 1000) {
      return toString();
    } else if (this < 1000000) {
      var value = toDouble() / 1000.0;
      return sprintf("%.1fK", [value]);
    }
    var value = toDouble() / 1000000.0;
    return sprintf("%.1fM", [value]);
  }
}