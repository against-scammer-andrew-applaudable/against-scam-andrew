import 'package:flutter/material.dart';

import '../../app_module.dart';
import '../widgets/toast/app_toast.dart';

extension AppModuleExtensions on AppModule {
  void Function<T extends Object?>([T? result]) get pop => AppModule.I.navigatorKey.currentState!.pop;

  // void Function<T extends Object?>(BuildContext context, [T? result]) get popWithContext => Navigator.pop;

  bool get canPop => AppModule.I.navigatorKey.currentState!.canPop();

  void Function(bool Function(Route<dynamic>)) get popUntil => AppModule.I.navigatorKey.currentState!.popUntil;

  Future<T?> Function<T extends Object?>(String routeName, {Object? arguments}) get navigateToNamed => AppModule.I.navigatorKey.currentState!.pushNamed;

  // Future<T?> Function<T extends Object?>(BuildContext context, String routeName, {Object? arguments}) get navigateToNamedWithContext => Navigator.pushNamed;

  Future<T?> Function<T extends Object?, TO extends Object?>(
    String routeName, {
    TO? result,
    Object? arguments,
  }) get navigateToNamedReplacement => AppModule.I.navigatorKey.currentState!.pushReplacementNamed;

  // Future<T?> Function<T extends Object?, TO extends Object?>(BuildContext context, String routeName, {
  //   TO? result,
  //   Object? arguments,
  // }) get navigateToNamedReplacementWithContext => Navigator.pushReplacementNamed;

  Future<T?> Function<T extends Object?>(
          String routeName, RoutePredicate predicate, {Object? arguments})
      get navigateToNamedAndRemoveUntil => AppModule.I.navigatorKey.currentState!.pushNamedAndRemoveUntil;

  // Future<T?> Function<T extends Object?>(BuildContext context, String routeName, RoutePredicate predicate, {Object? arguments}) get navigateToNamedAndRemoveUntilWithContext => Navigator.pushNamedAndRemoveUntil;

  bool get hasSession => controller.currentUser != null;
}

extension AppModuleNofifyExtensions on AppModule {
  notify(
    BuildContext context,
    String message, {
    bool neverExpire = false,
    AppToastMode mode = AppToastMode.success,
  }) {
    AppToast().build(context, message, mode: mode, neverExpire: neverExpire);
  }
}
