import 'package:sprintf/sprintf.dart';

extension DurationEx on Duration {
  String get durationString => "${inSeconds > 3600 ? "${sprintf("%d", [inSeconds ~/ 60])}:" : ""}${sprintf("%d", [inSeconds ~/ 60])}:${sprintf("%02d", [inSeconds % 60])}";
  String get durationFullString => "${sprintf("%02d", [inSeconds ~/ 3600])}:${sprintf("%02d", [inSeconds ~/ 60])}:${sprintf("%02d", [inSeconds % 60])}";
  double get durationDouble => inMilliseconds.toDouble() / 1000.0;
}