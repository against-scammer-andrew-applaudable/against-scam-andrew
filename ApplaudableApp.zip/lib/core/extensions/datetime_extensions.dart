import 'dart:math';

import 'package:intl/intl.dart';

import '../constants/constants_datetime.dart';

extension DateTimxtensions on DateTime? {
  String? toServerFormat({
    String format = ConstantsDateTime.serverDateRequestFormat,
  }) {
    if (this == null) return null;

    final DateFormat f = DateFormat(format);
    return f.format(f.parse(this!.toIso8601String()));
  }

  String? get shortDate {
    if (this == null) return null;

    return DateFormat(ConstantsDateTime.shortDateFormat)
        .format(DateTime.parse(this!.toIso8601String()));
  }
}
extension DateTimeEx on DateTime {
  bool isSameDate(DateTime other) {
    return year == other.year && month == other.month && day == other.day;
  }

  String get timeString {
    return DateFormat("M/d/yy, h:mm a").format(toLocal());
  }
  String get dobString {
    return DateFormat("M/d/yy").format(toLocal());
  }
  String get birthdayString {
    return DateFormat("MM/d").format(toLocal());
  }
  String get timeStringForAPI {
    return DateFormat("yyyyMMddhhmm").format(toUtc());
  }
  String get dateString {
    return DateFormat("MMMM dd, yyyy").format(toLocal());
  }
  String get hourString {
    return DateFormat("hh a").format(toLocal());
  }
  String get monthString {
    return DateFormat("MMM").format(toLocal());
  }
  int get age {
    DateTime currentDate = DateTime.now();
    int age = currentDate.year - year;
    int month1 = currentDate.month;
    int month2 = month;
    if (month2 > month1) {
      age--;
    } else if (month1 == month2) {
      int day1 = currentDate.day;
      int day2 = day;
      if (day2 > day1) {
        age--;
      }
    }
    return max(age, 0);
  }
}
