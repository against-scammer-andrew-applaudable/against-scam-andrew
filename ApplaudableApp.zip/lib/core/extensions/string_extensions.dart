import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;

extension StringExtension on String? {
  double textHeight(TextStyle style, double textWidth) {
    final TextPainter textPainter = TextPainter(
      text: TextSpan(text: this, style: style),
      textDirection: TextDirection.ltr,
    )..layout(minWidth: 0, maxWidth: textWidth);

    final countLines = (textPainter.size.width / textWidth).ceil();
    final height = countLines * textPainter.size.height;
    return height;
  }

  DateTime? get toDate {
    if (this == null) return null;

    return DateTime.parse(this!);
  }

  String capitalize() {
    if (this == null) return '';
    if (this!.isEmpty) return '';

    return "${this![0].toUpperCase()}${this!.substring(1)}";
  }
}
extension StringEx on String {
  String get characterBreak {
    return characters.map((e) => "\u200B$e").join();
  }
  String get displayUsername {
    return "@$this";
  }
  String get removedSpecialCharactersForPhone => replaceAll("(", "").replaceAll(")", "").replaceAll(" ", "").replaceAll("-", "");
  NameModel get parseName {
    var firstName = "";
    var lastName = "";
    var array = split(" ");
    if (array.isNotEmpty) {
      firstName = array.first;
      if (array.length > 1) {
        lastName = substring(firstName.length + 1);
      }
    } else {
      firstName = this;
    }
    return NameModel(firstName, lastName);
  }
  String get capitalizeName {
    final model = parseName;
    return "${model.firstName.isNotEmpty ? model.firstName[0].toUpperCase() : ""}${model.lastName.isNotEmpty ? model.lastName[0].toUpperCase() : ""}";
  }
  String get suggestedUserNamePrefix {
    final model = toLowerCase().parseName;
    var suggested = model.firstName;
    if (model.lastName.isNotEmpty) {
      suggested = "${model.lastName[0]}$suggested";
    }
    return suggested;
  }
  String get shortNameForBusinessName {
    final array = split(", ");
    if (array.isNotEmpty) {
      return array.last;
    }
    return this;
  }
  String resizeCloudinaryImage(double width) => replaceAll("image/upload/", "image/upload/w_${width.toInt()}/");
  String get thumbnailForCloudinary {
    final extension = p.extension(this);
    return replaceAll(extension, ".jpg");
  }
}

class NameModel {
  String firstName;
  String lastName;

  NameModel(this.firstName, this.lastName);
}