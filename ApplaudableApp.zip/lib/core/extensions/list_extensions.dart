extension ListExtensions<T> on List<T> {
  T? firstWhereOrNull(
    bool Function(T) test, {
    T Function()? orElse,
  }) {
    try {
      return firstWhere(test, orElse: orElse);
    } catch (_) {
      return null;
    }
  }
}
