import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'colors.dart';
import 'styles.dart';

class AppThemes {
  static ThemeData defaultTheme = ThemeData(
      brightness: Brightness.light,
      scaffoldBackgroundColor: AppColors.scaffoldBackgroundColorLight,
      primaryColor: AppColors.primaryColor,
      hintColor: AppColors.peach,
      cardColor: AppColors.pink,
      splashColor: AppColors.peach.withOpacity(0.3),
      highlightColor: AppColors.dark.withOpacity(0.2),
      colorScheme: const ColorScheme.dark(
        primary: AppColors.primaryColor,
        secondary: AppColors.white,
        onPrimary: AppColors.white,
        onSecondary: AppColors.white,
        onSurface: AppColors.dark,
        brightness: Brightness.light,
      ),
      fontFamily: "SourceSansPro",
      //GoogleFonts.getFont("SourceSansPro").fontFamily,
      textTheme: TextTheme(
        headlineLarge: AppStyles.header1(color: AppColors.dark),
        headlineMedium: AppStyles.header2(color: AppColors.dark),
        bodyLarge: AppStyles.text1(color: AppColors.dark),
        bodyMedium: AppStyles.text2(color: AppColors.dark),
      ),
      progressIndicatorTheme: const ProgressIndicatorThemeData(
        color: AppColors.primaryColor,
      ),
      appBarTheme: const AppBarTheme(
        systemOverlayStyle: SystemUiOverlayStyle.dark,
        // 2
        elevation: 0,
        backgroundColor: AppColors.transparent,
        shadowColor: AppColors.transparent,
        centerTitle: true,
        iconTheme: IconThemeData(
          color: AppColors.pink,
        ),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      cupertinoOverrideTheme: CupertinoThemeData(
        textTheme: CupertinoTextThemeData(
          dateTimePickerTextStyle: AppStyles.text1(color: AppColors.dark),
        ),
      ));
}
