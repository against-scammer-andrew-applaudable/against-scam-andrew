import 'package:applaudable/core/extensions/color_scheme.dart';
import 'package:flutter/material.dart';

/// MainColor class similar to MaterialColor
///
/// So this have the purpose to set the custom
/// shape colors, that goes from 10 to 100 in 10 step increment
class MainColor extends ColorSwatch<int> {
  const MainColor(int primary, Map<int, Color> swatch) : super(primary, swatch);

  /// The lightest shade.
  Color get shade10 => this[10]!;

  /// The second lightest shade.
  Color get shade20 => this[20]!;

  /// The third lightest shade.
  Color get shade30 => this[30]!;

  /// The fourth lightest shade.
  Color get shade40 => this[40]!;

  /// The fifth lightest shade.
  Color get shade50 => this[50]!;

  /// The default shade.
  Color get shade60 => this[60]!;

  /// The fourth darkest shade.
  Color get shade70 => this[70]!;

  /// The third darkest shade.
  Color get shade80 => this[80]!;

  /// The second darkest shade.
  Color get shade90 => this[90]!;

  /// The darkest shade.
  Color get shade100 => this[100]!;
}

class AppColors {
  static const Color transparent = Colors.transparent;

  static const int _dark = 0xFF212121;
  static const MainColor dark = MainColor(
    _dark,
    <int, Color>{
      100: Color(_dark),
    },
  );

  static const int _darkGrey = 0xFF666666;
  static const MainColor darkGrey = MainColor(
    _darkGrey,
    <int, Color>{
      100: Color(_darkGrey),
    },
  );

  static const int _mediumGrey = 0xFF999999;
  static const MainColor mediumGrey = MainColor(
    _mediumGrey,
    <int, Color>{
      100: Color(_mediumGrey),
      90: Color(0xFFAFAFAF),
    },
  );

  static const int _lightGrey = 0xFFCCCCCC;
  static const MainColor lightGrey = MainColor(
    _lightGrey,
    <int, Color>{
      100: Color(_lightGrey),
    },
  );

  static const int _white = 0xFFFFFFFF;
  static const MainColor white = MainColor(
    _white,
    <int, Color>{
      100: Color(_white),
    },
  );

  static const int _pink = 0xFFE73D5F;
  static const MainColor pink = MainColor(
    _pink,
    <int, Color>{
      100: Color(_pink),
    },
  );

  static const int _peach = 0xFFFFF5ED;
  static const MainColor peach = MainColor(
    _peach,
    <int, Color>{
      10: Color(0xFFFFFAF7),
      100: Color(_peach),
    },
  );

  static const Color darkPeach2 = Color(0xFFD4BFAF);

  static const int _darkPeach = 0xFFFAEEE5;
  static const MainColor darkPeach = MainColor(
    _darkPeach,
    <int, Color>{
      10: Color(_darkPeach),
      20: Color(0xFFD4BFAF),
      30: Color(0xFFD5BFAF),
      100: Color(0xFFE4CFBE),
    },
  );

  static const Color warning = Color(0xFFFCB022);
  static const Color lightPeach = Color(0xFFFFFAF7);

  static const Color scaffoldBackgroundColorLight = Color(0xFFFEFAF6);
  static const Color scaffoldBackgroundColorDark = Colors.black;
  // static const Color scaffoldBackgroundColorDark = Color(0xFF152E2C);

  static const Color buttonBGColor = Color(0xFF333333);
  static const Color black = Colors.black;

  static const int _red = 0xFFDC2A63;
  static const MainColor red = MainColor(
    _red,
    <int, Color>{
      60: Color(0xFFDC2A63),
      100: Color(_red),
    },
  );

  static const int _green = 0xFF23ECCF;
  static const MainColor green = MainColor(
    _green,
    <int, Color>{
      60: Color(0xFF27ECCE),
      100: Color(_green),
    },
  );

  static const Color primaryColor = Color(0xFFF72D55);

  static const Color greenColor = Color(0xFF00E141);
  static const Color yellowColor = Color(0xFFFFD50B);

  static const Color imagePreviewOverlayColor = Color(0xFFD9D9D9);

  static const Color searchFieldBorderColor = Color(0xFF939598);

  static const Color searchFieldHintColor = Color(0xFF939598);

  static const Color chipBorderColor = Color(0xFFE5E5E5);

  static const Color shadow = Color(0xFFE4CFBE);

  static const Color gray = Color(0xFF8D8D8D);

  static const Color placeholderGreyColor = Color(0xFFD9D9D9);

  static ColorScheme lightScheme = AppColorScheme.defineScheme(
    brightness: Brightness.light,
    primaryColor: primaryColor,
    disabledPrimaryColor: const Color(0xFFF18B9F),
    logoColor: primaryColor,
    textColor: black,
    hintTextColor: black.withOpacity(0.5),
    borderColor: const Color(0xFFEFEAE7),
    circleBorderColor: const Color(0xFFEFEAE7),
    textInputColor: transparent,
    backgroundColor: white,
    mainContentColor: transparent,
    mainContentBorderColor: const Color(0xFFEFEAE7),
    captionTextColor: black.withOpacity(0.8),
    feedCardColor: white,
    quoteCardColor: const Color(0xFFEFEAE7),
    percent5Color: black.withOpacity(0.05),
  );
  static ColorScheme darkScheme = AppColorScheme.defineScheme(
    brightness: Brightness.dark,
    primaryColor: primaryColor,
    disabledPrimaryColor: const Color(0xFFF18B9F),
    logoColor: white,
    textColor: white,
    hintTextColor: white.withOpacity(0.5),
    borderColor: const Color(0xFF213937),
    circleBorderColor: white.withOpacity(0.2),
    textInputColor: const Color(0xFF213937),
    backgroundColor: dark,
    mainContentColor: const Color(0xFF213937),
    mainContentBorderColor: transparent,
    captionTextColor: white.withOpacity(0.8),
    feedCardColor: const Color(0xFF1F3230),
    quoteCardColor: const Color(0xFF283939),
    percent5Color: white.withOpacity(0.05),
  );
}
