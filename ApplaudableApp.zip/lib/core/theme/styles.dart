import 'package:applaudable/core/extensions/color_scheme.dart';
import 'package:applaudable/core/utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';

import '../../app_module.dart';
import 'colors.dart';
import 'dimensions.dart';

class AppStyles {
  /// Text

  static TextStyle mediaText({
    required Color color,
  }) =>
      TextStyle(
        fontFamily: AppUtils.fontFamily,
        fontWeight: FontWeight.w700,
        fontSize: AppFontSizes.header1,
        height: 34 / AppFontSizes.header1,
        color: color,
      );

  static TextStyle header1({
    required Color color,
  }) =>
      TextStyle(
        fontFamily: AppUtils.fontFamily,
        fontWeight: FontWeight.bold,
        fontSize: AppFontSizes.header1,
        height: 30 / AppFontSizes.header1,
        color: color,
      );

  static TextStyle header2({
    required Color color,
  }) =>
      TextStyle(
        fontFamily: AppUtils.fontFamily,
        fontWeight: FontWeight.bold,
        fontSize: AppFontSizes.header2,
        height: 22 / AppFontSizes.header2,
        color: color,
      );

  static TextStyle header3({
    required Color color,
  }) =>
      TextStyle(
        fontFamily: AppUtils.fontFamily,
        fontWeight: FontWeight.w700,
        fontSize: AppFontSizes.header3,
        height: 22 / AppFontSizes.header3,
        color: color,
      );

  static TextStyle text1({
    required Color color,
  }) =>
      TextStyle(
        fontFamily: AppUtils.fontFamily,
        fontWeight: FontWeight.normal,
        fontSize: AppFontSizes.text1,
        height: 1,
        color: color,
      );

  static TextStyle text2({
    required Color color,
    bool isUnderlined = false,
  }) =>
      TextStyle(
        fontFamily: AppUtils.fontFamily,
        fontWeight: FontWeight.normal,
        fontSize: AppFontSizes.text2,
        height: 22 / AppFontSizes.text2,
        color: color,
        decoration:
            isUnderlined ? TextDecoration.underline : TextDecoration.none,
      );

  static TextStyle mention({
    required Color color,
    bool isUnderlined = false,
  }) =>
      TextStyle(
        fontFamily: AppUtils.fontFamily,
        fontWeight: FontWeight.w600,
        fontSize: AppFontSizes.text2,
        height: 22 / AppFontSizes.text2,
        color: color,
        decoration:
            isUnderlined ? TextDecoration.underline : TextDecoration.none,
      );

  static TextStyle textSmall({
    required Color color,
    bool isUnderlined = false,
  }) =>
      TextStyle(
        fontFamily: AppUtils.fontFamily,
        fontWeight: FontWeight.normal,
        fontSize: AppFontSizes.textSmall,
        height: 16 / AppFontSizes.textSmall,
        color: color,
        decoration:
            isUnderlined ? TextDecoration.underline : TextDecoration.none,
      );

  static TextStyle buttons({
    required Color color,
  }) =>
      TextStyle(
        fontFamily: AppUtils.fontFamily,
        fontWeight: FontWeight.w500,
        fontSize: AppFontSizes.buttons,
        height: 22 / AppFontSizes.buttons,
        color: color,
      );

  static TextStyle buttons2({
    required Color color,
  }) =>
      TextStyle(
        fontFamily: AppUtils.fontFamily,
        fontWeight: FontWeight.w600,
        fontSize: AppFontSizes.buttons2,
        height: 22 / AppFontSizes.buttons2,
        color: color,
      );

  static const TextStyle noText = TextStyle(
    fontSize: 0,
    height: 0,
  );

  /// Inputs

  static OutlineInputBorder inputBorder = OutlineInputBorder(
    borderSide: BorderSide(
      color: AppColors.white.withOpacity(0.1),
      width: 1.0,
    ),
    borderRadius: const BorderRadius.all(Radius.circular(5.0)),
  );

  static OutlineInputBorder inputFocusedBorder = const OutlineInputBorder(
    borderSide: BorderSide(
      color: AppColors.white,
      width: 1.0,
    ),
    borderRadius: BorderRadius.all(Radius.circular(5.0)),
  );

  static OutlineInputBorder inputErrorBorder = OutlineInputBorder(
    borderSide: BorderSide(
      color: AppColors.pink.withOpacity(0.5),
      width: 1.0,
    ),
    borderRadius: const BorderRadius.all(Radius.circular(5.0)),
  );

  static OutlineInputBorder inputFocusedErrorBorder = const OutlineInputBorder(
    borderSide: BorderSide(
      color: AppColors.pink,
      width: 1.0,
    ),
    borderRadius: BorderRadius.all(Radius.circular(5.0)),
  );

  static UnderlineInputBorder underlineInputBorder = UnderlineInputBorder(
    borderRadius: BorderRadius.circular(3.0),
    borderSide: BorderSide.none,
  );

  static UnderlineInputBorder underlineFocusedInputBorder =
      const UnderlineInputBorder(
    borderSide: BorderSide(
      color: AppColors.white,
      width: 2.0,
    ),
  );

  static UnderlineInputBorder underlineInputErrorBorder = UnderlineInputBorder(
    borderSide: BorderSide(
      color: AppColors.pink.withOpacity(0.5),
      width: 2.0,
    ),
  );

  static UnderlineInputBorder underlineFocusedInputErrorBorder =
      const UnderlineInputBorder(
    borderSide: BorderSide(
      color: AppColors.pink,
      width: 2.0,
    ),
  );

  static UnderlineInputBorder inputCodeBorder = const UnderlineInputBorder(
    borderSide: BorderSide(
      color: AppColors.lightGrey,
      width: 1.0,
    ),
    borderRadius: BorderRadius.zero,
  );

  static OutlineInputBorder outlinedFocusedBorder = const OutlineInputBorder(
    borderSide: BorderSide(
      color: AppColors.mediumGrey,
      width: 1.0,
    ),
    borderRadius: BorderRadius.all(Radius.circular(5.0)),
  );
}

class AppShadows {
  static BoxShadow createPostSegmentShadow = BoxShadow(
    offset: const Offset(0, 10),
    color: AppColors.darkPeach.shade100.withOpacity(0.3),
    blurRadius: 15,
    spreadRadius: 0,
  );
  static BoxShadow profileCountersViewShadow = BoxShadow(
    color: Theme.of(AppModule.I.navigatorKey.currentContext ?? GetIt.instance.get<BuildContext>()).colorScheme.backgroundColor.withOpacity(0.3),
    offset: const Offset(0, 10),
    blurRadius: 15,
    spreadRadius: 0,
  );

  static BoxShadow submitButtonDefaultShadow = BoxShadow(
    offset: const Offset(0, 10),
    color: AppColors.primaryColor.withOpacity(0.1),
    blurRadius: 15,
  );

  static BoxShadow collectionGraphPostShadow = BoxShadow(
    color: AppColors.shadow.withOpacity(0.5),
    blurRadius: 20,
  );
  static Shadow textShadow = Shadow(
    blurRadius: 8.0,  // shadow blur
    color: Colors.black.withOpacity(0.1), // shadow color
    offset: const Offset(1.0, 1.0), // how much shadow will be shown
  );
  static Shadow textBigShadow = Shadow(
    blurRadius: 10.0,  // shadow blur
    color: Colors.black.withOpacity(0.3), // shadow color
    offset: const Offset(1.0, 1.0), // how much shadow will be shown
  );
  static Shadow textShadowWithColor(Color color, {double blurRadius = 8.0}) => Shadow(
    blurRadius: blurRadius,  // shadow blur
    color: color, // shadow color
    offset: const Offset(1.0, 1.0), // how much shadow will be shown
  );
  static Shadow iconShadow = Shadow(
    blurRadius: 8.0,  // shadow blur
    color: Colors.black.withOpacity(0.5), // shadow color
    offset: const Offset(1.0, 1.0), // how much shadow will be shown
  );
}
