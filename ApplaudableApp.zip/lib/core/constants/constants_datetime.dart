class ConstantsDateTime {
  static const String serverDateRequestFormat = "yyyy-MM-dd";
  static const String shortDateFormat = "MMM dd";
}
