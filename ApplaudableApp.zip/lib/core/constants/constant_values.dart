import '../enums/environment.dart';

class ConstantValues {
  static AppEnvironment environment = AppEnvironment.staging;

  static const String GOOGLE_PLACES_API = "AIzaSyBNj9oofG8PtbvcWm063yeElr7DKq7mod0";
  static const String GOOGLE_PLACES_MAP_GEOCODE_API = "AIzaSyAZboRy3Lk9n_RFe8PN2YFPl2ZR_LNPbas";

  static const String noInternetConnectionMsg = 'No Internet Connection. please check your connection and try again.';
  static const String instaBugKey = 'e5142b72626f4fc16e608c931c3dce1c';

  static const int maxVideoLengthInSec = 60;
  static const int maxQuoteLengthInCharacter = 240;

  static const double defaultMediaRatio = 1.0;
  static const double maxMediaRatioOnFeed = 1.2;
  static const double pagePadding = 16;
  static const double maxMedias = 10;

  static const int bufferingVideosOnFeed = 1;

  static const Duration minThresholdRefreshFeedInSeconds = Duration(seconds: 60);

  static const int maxTextSize = 288;
  static const double feedPostHeight = 376;
  static const double feedPostMediaTextVerticalPadding = 70;
  static const double feedPostMediaTextHorizontalPadding = 45;

  static const String defaultCategoryIcon = "ic_category_default";

  /// Special non-printable characters
  static const String mentionDivider = '#';
  static const String mentionSeparator = '\u200b';

  /// Notifications Enabled Status Key
  static const String isNotificationsEnabledKey = 'isNotificationsEnabledKey';

  /// Login with Email Key
  static const String keyLoginWithEmail = 'keyLoginWithEmail';
}
