import 'package:flutter/foundation.dart';

class ConstantKeys {
  /// Add Profile Avatar page keys
  static const Key addPhotoBtnKey = Key('add_a_photo_btn');
  static const Key skipBtnKey = Key('skip_btn');

  /// Alerts Mixin Keys
  static const Key avatarImageSourceKey = Key('avatar_picker_source_view');
  static const Key chooseFromLibraryKey = Key('choose_from_library_action');
  static const Key takePhotoKey = Key('take_photo_action');
  static const Key cancelKey = Key('cancel_action');

  /// Choose Post Type Page Keys
  static const Key createRegularPostBtnKey = Key('create_regular_post_btn');
  static const Key createLifeStoryPostBtnKey = Key('create_life_story_btn');
  static const Key closeChoosePostTypePageBtnKey =
      Key('close_choose_post_type_page_btn');

  /// Select Story Question Page Keys
  static const Key selectStoryQuestionCloseBtnKey =
      Key('select_story_question_close_btn');
  static const Key selectStoryQuestionBackBtnKey =
      Key('select_story_question_back_btn');
  static const Key storyQuestionsListViewKey =
      Key('story_questions_list_view_key');
  static const Key selectAQuestionTextKey = Key('select_a_question_text_key');
  static const Key refreshQuestionsBtnViewKey =
      Key('refresh_questions_btn_view_key');

  /// Create Story Details Page Keys
  static const Key createStoryDetailsBackBtnKey =
      Key('create_story_details_back_btn_key');
  static const Key createStoryQuestionTextKey =
      Key('create_story_question_text_key');
  static const Key createStoryAnswerExampleTextKey =
      Key('create_story_answer_example_text_key');
  static const Key createStoryAnswerFieldKey =
      Key('create_story_answer_field_key');
  static const Key createStoryContinueBtnKey =
      Key('create_story_continue_btn_key');

  /// Create Story Confirmation Page Keys
  static const Key storyConfirmationEditQuesBtnKey =
      Key('story_confirmation_edit_ques_btn_key');
  static const Key improveWithAIBtnKey = Key('improve_with_ai_btn_key');
  static const Key storyWhenItHappenedOptionKey =
      Key('story_when_it_happened_option_key');
  static const Key storyCategoryOptionKey = Key('story_category_option_key');
  static const Key storyMentionOptionKey = Key('story_mention_option_key');
  static const Key storyLocationOptionKey = Key('story_location_option_key');
  static const Key storyAddMediaViewKey = Key('story_add_media_view_key');
  static const Key storyDiscardBtnKey = Key('sotry_discard_btn_key');
  static const Key storyConfirmationSubmitBtnKey =
      Key('story_confirmation_btn_key');

  /// DNGDatePicker View
  static const Key dngDatePickerViewKey = Key('dng_date_picker_view_ke');

  /// App Confirmation Dialog Keys
  static const Key appConfirmationConfirmBtnKey =
      Key('app_confirmation_confirm_btn_key');
  static const Key appConfirmationCancelBtnKey =
      Key('app_confirmation_cancel_btn_key');
}
