part of 'dng_base_bloc.dart';

abstract class DNGBloc<Event, State> extends DNGBaseBloc<State> {
  final StreamController<Event> _eventsController = BehaviorSubject();

  late final State _intialState;

  DNGBloc(State initial, {bool shouldEmitInitial = true}) {
    _intialState = initial;

    log('$runtimeType has been created.', name: 'DNGBloc');
    if (shouldEmitInitial) emit(initial);

    _eventsController.stream.listen((event) {
      log('${event.runtimeType} is fired.', name: 'DNGBloc');

      mapEventToState(event);
    });
  }

  // Getters
  Function(Event) get add => _eventsController.sink.add;

  @override
  State get initial => _intialState;

  @override
  Stream<State> get stream => _statesController.stream.distinct();

  @override
  Future<State> get state => _statesController.stream.last;

  // Mapper
  void mapEventToState(Event event);

  void disposeStreams() {
    _eventsController.close();
    _statesController.close();
  }

  @override
  void dispose() {
    disposeStreams();
    super.dispose();
  }
}
