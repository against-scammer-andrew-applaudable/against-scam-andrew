import 'dart:async';
import 'dart:developer';

import 'package:flutter/foundation.dart';
import 'package:rxdart/rxdart.dart';

part 'dng_bloc.dart';
part 'dng_cubit.dart';

abstract class DNGBaseBloc<State> with ChangeNotifier {
  final StreamController<State> _statesController = BehaviorSubject();

  bool register = false;

  // Getters
  State get initial;
  Stream<State> get stream;
  Future<State> get state;

  // Actions
  void emit(State state) {
    _statesController.sink.add(state);

    log('${state.runtimeType} emmited.', name: 'DNGBloc');
  }

  @override
  void dispose() {
    _statesController.close();
    super.dispose();
  }
}
