import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../dng_base_bloc.dart';

// ignore: must_be_immutable
class DNGBlocBuilder<B extends DNGBaseBloc<S>, S> extends StatelessWidget {
  final bool Function(S state)? buildWhen;
  B? bloc;
  final Widget Function(BuildContext context, S state) builder;

  DNGBlocBuilder({
    Key? key,
    this.buildWhen,
    this.bloc,
    required this.builder,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    bloc ??= context.read<B>();

    return StreamBuilder<S>(
      key: key,
      initialData: bloc?.initial,
      stream: buildWhen == null ? bloc?.stream : bloc?.stream.where(buildWhen!),
      builder: (ctx, snapshot) {
        return builder(context, snapshot.data as S);
      },
    );
  }
}
