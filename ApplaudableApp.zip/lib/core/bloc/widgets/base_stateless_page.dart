import 'dart:async';
import 'dart:developer';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../app_module.dart';
import '../../../generated/l10n.dart';
import '../../../injection_container.dart';
import '../../../features/auth/presentation/widgets/snack_bar.dart';
import '../../network/network_info.dart';
import '../dng_base_bloc.dart';

// ignore: must_be_immutable
abstract class BaseStatelessPage<Bloc extends DNGBaseBloc, State>
    extends StatelessWidget
    with BaseStreamService<Bloc, State>, WidgetsBindingObserver, RouteAware {
  BaseStatelessPage({super.key});

  late final AppSnackBar snackBar =
      AppSnackBar(AppModule.instance.scaffoldMessengerKey.currentState!);

  late final S translations;

  bool get notify => false;

  bool get listenToConnectionChanges => false;

  bool get disposeBloc => true;

  bool get listenToInitConnectionChanges => true;

  void registerBloc(context) {
    final Bloc bloc = Provider.of<Bloc>(context, listen: notify);
    if (_bloc.hashCode == bloc.hashCode) {
      return;
    }

    translations = S.of(context);
    _bloc = bloc;
    String blocKey = "${_bloc.hashCode}:$hashCode";
    if (!listenToInitConnectionChanges) {
      blocKey = "${_bloc.hashCode}";
    }

    bool isRegistered = AppModule.I.isRegistered(blocKey);
    if (!isRegistered) {
      initBloc(context, _bloc!);
      _listen(context, _bloc!);

      AppModule.I.registerBloc<Bloc>(blocKey, _bloc!);
      AppModule.I.routeObserver.subscribe(this, ModalRoute.of(context)!);
    }

    if (listenToConnectionChanges) {
      _listenToConnectionChanges();
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {}

  void resetListener(BuildContext context) => _listen(context, bloc);

  @override
  void didPush() {}

  void dispose() {}

  @override
  void didPop() {
    _cancelStreams();
    dispose();

    AppModule.I

      /// unsubscribe route observer
      ..routeObserver.unsubscribe(this)

      /// unregister bloc
      ..unregisterBloc("${_bloc.hashCode}");
  }
}

mixin BaseStreamService<Bloc extends DNGBaseBloc, State> {
  Bloc? _bloc;

  Bloc get bloc {
    //reset();
    if (_bloc == null) {
      FlutterError.presentError(
        const FlutterErrorDetails(
          exception:
              'Must call registerBloc(context) in initState() or build() for the bloc to get initialized',
        ),
      );
    }

    return _bloc!;
  }

  Stream<State>? get onStateListener => null;

  void initBloc(BuildContext context, Bloc bloc) {}
  void onStateResultListener(BuildContext context, State state) {}

  void onConnectivityStateResultListener(
    bool hasConnection,
    ConnectionType connectionType,
  ) {}

  final _connectivity = Connectivity();
  StreamSubscription? _streamSubscription;
  StreamSubscription? _connectivitySubscription;

  StreamSubscription? get streamSubscription => _streamSubscription;

  void reset(BuildContext context) {
    _bloc = bloc;
    initBloc(context, _bloc!);
    _listen(context, _bloc!);
  }

  void _listen(BuildContext context, Bloc bloc) async {
    if (onStateListener == null) {
      return;
    }
    _streamSubscription?.cancel();
    _streamSubscription = onStateListener!
        .listen((state) => onStateResultListener(context, state));
  }

  void _listenToConnectionChanges() {
    log('Listening to connection changes in $runtimeType', name: 'BStlessPage');

    _connectivitySubscription = _connectivity.onConnectivityChanged.listen(
      (result) async {
        final isConnected = await servLocator<NetworkInfo>().isConnected;
        if (result.isNotEmpty) {
          onConnectivityStateResultListener(isConnected, result.last.type);
        }
      },
    );
  }

  void _cancelStreams() {
    log('Closing $runtimeType', name: 'BStlessPage');

    _streamSubscription?.cancel();
    _connectivitySubscription?.cancel();
  }
}

extension ConnectivityResultExtensions on ConnectivityResult {
  ConnectionType get type {
    switch (this) {
      case ConnectivityResult.bluetooth:
        return ConnectionType.bluetooth;
      case ConnectivityResult.wifi:
        return ConnectionType.wifi;
      case ConnectivityResult.ethernet:
        return ConnectionType.ethernet;
      case ConnectivityResult.mobile:
        return ConnectionType.cellular;
      case ConnectivityResult.vpn:
        return ConnectionType.vpn;
      case ConnectivityResult.none:
        return ConnectionType.none;
      case ConnectivityResult.other:
        return ConnectionType.none;
    }

    // ignore: dead_code
    return ConnectionType.none;
  }
}

enum ConnectionType { wifi, cellular, ethernet, bluetooth, vpn, none }
