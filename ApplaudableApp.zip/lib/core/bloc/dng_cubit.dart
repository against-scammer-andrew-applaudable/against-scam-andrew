part of 'dng_base_bloc.dart';

abstract class DNGCubit<State> extends DNGBaseBloc<State> {
  late final State _initialState;

  DNGCubit(State initial, {bool shouldEmitInitial = true}) {
    _initialState = initial;

    log('$runtimeType has been created.', name: 'DNGCubit');
    if (shouldEmitInitial) emit(initial);
  }

  // Getters
  @override
  State get initial => _initialState;

  @override
  Stream<State> get stream => _statesController.stream.distinct();

  @override
  Future<State> get state => _statesController.stream.last;

  @override
  void dispose() {
    _statesController.close();
    super.dispose();
  }
}
