import 'package:another_flushbar/flushbar.dart';
import 'package:flutter/material.dart';

import '../../theme/colors.dart';
import '../../theme/styles.dart';

enum AppToastMode { info, success, error }

class AppToast {
  build(
    BuildContext context,
    String message, {
    AppToastMode mode = AppToastMode.success,
    bool neverExpire = false,
  }) {
    final flushbar = Flushbar(
      // icon: Icon(
      //   _getAppropriateModelIcon(mode),
      //   color: AppColors.white,
      // ),
      isDismissible: true,
      // padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      padding: EdgeInsets.zero,
      borderRadius: BorderRadius.circular(12),
      flushbarPosition: FlushbarPosition.TOP,
      margin: const EdgeInsets.fromLTRB(20, 20, 20, 0),
      // margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      duration: neverExpire ? null : const Duration(seconds: 3),
      boxShadows: [
        BoxShadow(
          offset: const Offset(0, 10),
          color: AppColors.primaryColor.withOpacity(0.1),
          blurRadius: 15,
          spreadRadius: -10,
        )
      ],
      messageText: Container(
        padding: const EdgeInsets.fromLTRB(8, 10, 8, 10),
        child: Center(
          child: Text(
            message,
            textAlign: TextAlign.center,
            style: AppStyles.text2(color: AppColors.white),
          ),
        ),
      ),
      backgroundColor: AppColors.dark,
      // mainButton: TextButton(
      //   onPressed: () => flushbar.dismiss(),
      //   child: Text(
      //     translations.close,
      //     style: AppStyles.text2(color: AppColors.lightGrey)
      //         .copyWith(decoration: TextDecoration.underline),
      //   ),
      // ),
    );

    Future(() {
      flushbar.show(context);
    });
  }

  // IconData _getAppropriateModelIcon(AppToastMode mode) {
  //   switch (mode) {
  //     case AppToastMode.info:
  //       return Icons.info_outline_rounded;
  //     case AppToastMode.success:
  //       return Icons.check_circle_outline;
  //     case AppToastMode.error:
  //       return Icons.error_outline;
  //     default:
  //       return Icons.check_circle_outline;
  //   }
  // }
}
