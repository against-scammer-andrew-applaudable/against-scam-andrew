import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../features/auth/presentation/widgets/buttons/action_button.dart';
import '../../constants/constant_keys.dart';
import '../../providers/dng_date_picker_provider.dart';
import '../../../injection_container.dart';
import '../../extensions/build_context_extensions.dart';
import '../../theme/colors.dart';
import '../../theme/dimensions.dart';
import '../../theme/styles.dart';

class SelectedDate {
  final DateTime date;
  final String formattedDate;
  final String dateFormat;

  const SelectedDate({
    required this.date,
    required this.formattedDate,
    required this.dateFormat,
  });
}

Future<SelectedDate?> showDNGDatePicker({
  required BuildContext context,
  String? initial,
}) async {
  return await showModalBottomSheet<SelectedDate>(
    context: context,
    backgroundColor: context.scaffoldBackgroundColor,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(
        AppDimensions.radius_24,
      ),
    ),
    builder: (ctx) {
      final dngDatePickerProvider = servLocator<DNGDatePickerProvider>();
      dngDatePickerProvider.initDatePicker(initial: initial);

      return ChangeNotifierProvider.value(
        value: dngDatePickerProvider,
        child: Builder(
          key: ConstantKeys.dngDatePickerViewKey,
          builder: (context) {
            return Consumer<DNGDatePickerProvider>(
              builder: (ctx, provider, child) {
                return SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 40,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Flexible(
                          // height: 300,
                          child: Row(
                            children: [
                              Expanded(
                                child: CupertinoPicker.builder(
                                  scrollController: provider.dayController,
                                  itemExtent: 50,
                                  backgroundColor: context.scaffoldBackgroundColor,
                                  onSelectedItemChanged: (i) {
                                    provider.onDayUpdated(
                                      provider.days[i],
                                    );
                                  },
                                  selectionOverlay: Container(),
                                  childCount: provider.days.length,
                                  itemBuilder: (ctx, index) {
                                    return Text(
                                      provider.days[index],
                                      style: AppStyles.header1(color: context.textColor).copyWith(
                                        fontSize: 23,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    );
                                  },
                                ),
                              ),
                              Expanded(
                                child: CupertinoPicker.builder(
                                  scrollController: provider.monthController,
                                  itemExtent: 50,
                                  backgroundColor: context.scaffoldBackgroundColor,
                                  onSelectedItemChanged:
                                      provider.onMonthUpdated,
                                  selectionOverlay: Container(),
                                  childCount: provider.months.length,
                                  itemBuilder: (ctx, index) {
                                    return Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          child: Text(
                                            provider.months[index],
                                            maxLines: 1,
                                            style: AppStyles.header1(color: context.textColor).copyWith(
                                              fontSize: 23,
                                              fontWeight: FontWeight.w400,
                                            ),
                                          ),
                                        ),
                                      ],
                                    );
                                  },
                                ),
                              ),
                              Expanded(
                                child: CupertinoPicker.builder(
                                  scrollController: provider.yearController,
                                  itemExtent: 50,
                                  backgroundColor: context.scaffoldBackgroundColor,
                                  selectionOverlay: Container(),
                                  onSelectedItemChanged: provider.onYearUpdated,
                                  childCount: provider.years.length,
                                  itemBuilder: (ctx, index) {
                                    return Text(
                                      provider.years[index],
                                      style: AppStyles.header1(color: context.textColor).copyWith(
                                        fontSize: 23,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 40),
                        Row(
                          children: [
                            Flexible(
                              flex: 1,
                              child: AppActionButton.submitWithBorder(
                                text: 'Cancel',
                                backgroundColor: Colors.transparent,
                                borderColor: AppColors.primaryColor,
                                actionTextColor: AppColors.primaryColor,
                                actionTextSize: 18,
                                actionTextWeight: FontWeight.w600,
                                onPressed: ctx.pop,
                              ),
                            ),
                            const SizedBox(width: 15),
                            Flexible(
                              flex: 2,
                              child: AppActionButton.submit(
                                text: 'Confirm',
                                actionTextSize: 18,
                                actionTextWeight: FontWeight.w600,
                                onPressed: () => ctx.pop(
                                  SelectedDate(
                                    date: provider.selectedDateTime,
                                    formattedDate: provider.selectedDate,
                                    dateFormat: provider.dateFormat,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      );
    },
  );
}
