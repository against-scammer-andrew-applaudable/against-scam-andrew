import 'package:flutter/material.dart';

import '../../features/post/domain/entities/post_entities.dart';
import '../mixins/mentions_mixin.dart';
import '../utils/emoji.dart';

class AppRichText extends StatelessWidget with MentionsMixin {
  final bool enableMentions;
  final String text;
  final int maxLines;
  final TextStyle? style;
  final TextOverflow overflow;
  final List<PostElement> elements;
  final List<PostMention> mentions;
  final EmojiHandler? emoji;

  const AppRichText({
    super.key,
    this.enableMentions = false,
    required this.text,
    this.maxLines = 2,
    this.style,
    this.overflow = TextOverflow.clip,
    this.elements = const [],
    this.mentions = const [],
    this.emoji,
  });

  const AppRichText.enableMentions({
    super.key,
    this.enableMentions = true,
    required this.text,
    this.maxLines = 2,
    this.style,
    this.overflow = TextOverflow.clip,
    this.elements = const [],
    this.mentions = const [],
    this.emoji,
  });

  @override
  Widget build(BuildContext context) {
    /// TODO: Review
    return SizedBox(
      height: 44,
      child: RichText(
        text: enableMentions
            ? handleMentionsInText(
                text,
                context,
                elements: elements,
                mentions: mentions,
                emoji: emoji,
                style: style,
              )
            : TextSpan(text: text, style: style),
        maxLines: maxLines,
        overflow: overflow,
      ),
    );
  }
}
