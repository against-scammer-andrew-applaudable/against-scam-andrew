import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:applaudable/core/theme/styles.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../generated/l10n.dart';
import '../theme/colors.dart';
import '../../features/auth/presentation/widgets/buttons/action_button.dart';
import '../theme/dimensions.dart';

class AppPermissionDeniedView extends StatelessWidget {
  final Function()? onOpeningSettings;

  const AppPermissionDeniedView({super.key, this.onOpeningSettings});

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          translations.permissions_denied_text,
          textAlign: TextAlign.center,
          style: AppStyles.text2(color: context.textColor).copyWith(fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: AppDimensions.largeSidePadding),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AppActionButton.submitWithBorder(
              text: translations.go_to_settings_text,
              fitsFullWidth: false,
              backgroundColor: AppColors.transparent,
              // borderColor: AppColors.transparent,
              actionTextWeight: FontWeight.w400,
              actionTextColor: AppColors.darkGrey,
              onPressed: () {
                openAppSettings();

                if (onOpeningSettings != null) onOpeningSettings!();
              },
            ),
          ],
        ),
      ],
    );
  }
}
