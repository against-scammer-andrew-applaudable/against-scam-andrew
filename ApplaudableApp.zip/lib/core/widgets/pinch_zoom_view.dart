// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
//
// import '../controllers/scroll_gesture_controller.dart';
//
// class PinchZoomView extends StatefulWidget {
//   final Widget child;
//   final bool disable;
//
//   const PinchZoomView({super.key, required this.child, this.disable = false});
//
//   @override
//   State<PinchZoomView> createState() => _PinchZoomViewState();
// }
//
// class _PinchZoomViewState extends State<PinchZoomView>
//     with SingleTickerProviderStateMixin {
//   late final TransformationController _controller;
//   late final AnimationController _animationController;
//   Animation<Matrix4>? _animation;
//   OverlayEntry? _entry;
//   List<PointerEvent> events = [];
//
//   @override
//   void initState() {
//     super.initState();
//
//     _controller = TransformationController();
//     _animationController = AnimationController(
//       duration: const Duration(milliseconds: 200),
//       vsync: this,
//     );
//
//     _animationController.addListener(_onAnimationChanged);
//     _animationController.addStatusListener(_onAnimationStatusChanged);
//   }
//
//   void _onAnimationStatusChanged(status) {
//     if (status == AnimationStatus.completed) {
//       _removeOverlay();
//     }
//   }
//
//   void _onAnimationChanged() => _controller.value = _animation!.value;
//
//   @override
//   void dispose() {
//     _animationController.removeListener(_onAnimationChanged);
//     _animationController.removeStatusListener(_onAnimationStatusChanged);
//
//     _controller.dispose();
//     _animationController.dispose();
//
//     super.dispose();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     if (widget.disable) return widget.child;
//
//     final gestureController = context.read<ScrollGestureController>();
//
//     return Listener(
//       onPointerDown: (event) {
//         events.add(event);
//
//         final pointers = events.length;
//
//         if (pointers >= 2) gestureController.allowScrollGesture = false;
//       },
//       onPointerUp: (event) {
//         events.clear();
//
//         gestureController.allowScrollGesture = true;
//       },
//       child: _buildInteractiveView(),
//     );
//   }
//
//   InteractiveViewer _buildInteractiveView() {
//     return InteractiveViewer(
//       transformationController: _controller,
//       maxScale: 3.0,
//       minScale: 1.0,
//       panEnabled: false,
//       clipBehavior: Clip.none,
//       onInteractionStart: (details) {
//         if (details.pointerCount < 2) return;
//
//         _showOverlay(context);
//       },
//       onInteractionEnd: (_) {
//         _resetAnimation();
//       },
//       child: widget.child,
//     );
//   }
//
//   void _resetAnimation() {
//     _animation = Matrix4Tween(
//       begin: _controller.value,
//       end: Matrix4.identity(),
//     ).animate(
//       CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
//     );
//
//     _animationController.forward(from: 0);
//   }
//
//   void _showOverlay(BuildContext context) {
//     final renderBox = context.findRenderObject() as RenderBox;
//     final offset = renderBox.localToGlobal(Offset.zero);
//     final size = MediaQuery.of(context).size;
//
//     _entry = OverlayEntry(
//       builder: (ctx) => Positioned(
//         left: offset.dx,
//         top: offset.dy,
//         width: size.width,
//         child: _buildInteractiveView(),
//       ),
//     );
//
//     final overlay = Overlay.of(context);
//     overlay.insert(_entry!);
//   }
//
//   void _removeOverlay() {
//     _entry?.remove();
//     _entry = null;
//   }
// }
