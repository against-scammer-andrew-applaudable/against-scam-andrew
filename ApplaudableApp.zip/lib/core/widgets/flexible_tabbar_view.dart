import 'package:flutter/material.dart';

class FlexibleTabBarView extends StatelessWidget {
  final Key? focusableKey;
  final TabController? controller;
  final List<Widget> children;

  const FlexibleTabBarView({
    super.key,
    this.focusableKey,
    this.controller,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    final tabController = controller ?? DefaultTabController.of(context);

    // ignore: unnecessary_null_comparison
    if (tabController == null) {
      throw FlutterError(
        """No TabController for FlexibleTabBarView. 

When creating a FlexibleTabBarView, you must either provide an explicit TabController using the "controller" property, or you must ensure that there is a DefaultTabController above the FlexibleTabBarView.
        In this case, there was neither an explicit controller nor a default controller.
        """,
      );
    }

    if (tabController.length != children.length) {
      throw FlutterError(
        """(${tabController.length}) children must be provided to match the tabController length(${tabController.length}).
        
Currently, (${children.length}) ${children.length > 1 ? "children are" : "child is"} passed to the FlexibleTabBarView.
        """,
      );
    }

    final animation = tabController.animation;

    return AnimatedBuilder(
      animation: animation!,
      builder: (context, child) {
        final children = (child as Column).children;

        return IndexedStack(
          index: tabController.index,
          children: List.generate(
            children.length,
            (index) => Visibility(
              key: index == tabController.index ? focusableKey : null,
              visible: tabController.index == index,
              child: children[index],
            ),
          ),
        );
      },
      child: Column(children: children),
    );
  }
}
