import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

import '../theme/colors.dart';
import 'svg_icons.dart';

class MediaAvatarPlaceholder extends StatelessWidget {
  final BoxShape shape;
  final bool isLoading;
  final double? iconHeight;
  final Color? backgroundColor;
  final Color? iconColor;

  const MediaAvatarPlaceholder({
    super.key,
    this.shape = BoxShape.circle,
    this.isLoading = false,
    this.iconHeight,
    this.backgroundColor,
    this.iconColor,
  });

  @override
  Widget build(BuildContext context) {
    return MediaAvatarContainer(
      shape: shape,
      color: backgroundColor ?? Colors.white60,
      child: isLoading
          ? Shimmer.fromColors(
              baseColor: AppColors.darkPeach,
              highlightColor: AppColors.darkPeach2,
              child: MediaPlaceholderIcon(iconHeight: iconHeight),
            )
          : MediaPlaceholderIcon(iconHeight: iconHeight, iconColor: iconColor),
    );
  }
}

class MediaAvatarContainer extends StatelessWidget {
  final DecorationImage? image;
  final BoxShape shape;
  final Color? color;
  final Widget? child;

  const MediaAvatarContainer({
    super.key,
    this.image,
    this.shape = BoxShape.rectangle,
    this.color,
    this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        shape: shape,
        color: color,
        image: image,
      ),
      child: child,
    );
  }
}

class MediaPlaceholderIcon extends StatelessWidget {
  final double? iconHeight;
  final Color? iconColor;

  const MediaPlaceholderIcon({super.key, this.iconHeight, this.iconColor});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SvgIcons.applaudRatingFilled(
        height: iconHeight,
        color: iconColor ?? AppColors.darkPeach2,
      ),
    );
  }
}
