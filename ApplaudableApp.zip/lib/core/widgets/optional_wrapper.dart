import 'package:flutter/material.dart';

class OptionalWrapper extends StatelessWidget {
  final Widget Function(Widget) wrapper;
  final Widget child;
  final bool showWrapper;

  const OptionalWrapper({
    super.key,
    required this.wrapper,
    required this.child,
    this.showWrapper = true,
  });

  @override
  Widget build(BuildContext context) {
    return showWrapper ? wrapper(child) : child;
  }
}
