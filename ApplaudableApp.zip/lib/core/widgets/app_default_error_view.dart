import 'package:flutter/material.dart';

import '../../../../core/theme/colors.dart';
import '../../../../core/theme/dimensions.dart';
import '../../features/auth/presentation/widgets/buttons/action_button.dart';
import '../../generated/l10n.dart';

class AppDefaultErrorView extends StatelessWidget {
  final String message;
  final String? refreshBtnText;
  final Function()? onRefresh;

  const AppDefaultErrorView({
    super.key,
    required this.message,
    this.refreshBtnText,
    this.onRefresh,
  });

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return Padding(
      padding: const EdgeInsets.all(35),
      child: Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              message,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: AppDimensions.defaultSideMargin),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AppActionButton.submitWithBorder(
                  text: translations.try_again,
                  fitsFullWidth: false,
                  backgroundColor: Colors.transparent,
                  borderColor: AppColors.primaryColor,
                  actionTextColor: AppColors.primaryColor,
                  height: 50,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                  ),
                  onPressed: onRefresh,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
