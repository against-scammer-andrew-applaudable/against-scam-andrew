import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'media_avatar_placeholder.dart';

class OptimizedCachedNetworkImage extends StatefulWidget {
  final String? imageUrl;
  final double? height;
  final double? width;
  final BoxFit? fit;
  final Color? color;
  final ImageRepeat repeat;
  final Widget? errorWidget;
  final Widget Function(BuildContext, ImageProvider)? imageBuilder;
  final Widget Function(BuildContext, String, DownloadProgress)?
      progressIndicatorBuilder;
  final double? defaultProgressIconHeight;
  final BoxShape defaultProgressViewShape;
  final Color? placeholderBackgroundColor;
  final BorderRadius radius;

  const OptimizedCachedNetworkImage({
    Key? key,
    this.imageUrl,
    this.height,
    this.width,
    this.fit,
    this.color,
    this.repeat = ImageRepeat.noRepeat,
    this.errorWidget,
    this.imageBuilder,
    this.progressIndicatorBuilder,
    this.defaultProgressIconHeight,
    this.defaultProgressViewShape = BoxShape.circle,
    this.placeholderBackgroundColor,
    this.radius = BorderRadius.zero,
  }) : super(key: key);

  @override
  State<OptimizedCachedNetworkImage> createState() =>
      _OptimizedCachedNetworkImageState();
}

class _OptimizedCachedNetworkImageState
    extends State<OptimizedCachedNetworkImage>
    with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => false;

  @override
  Widget build(BuildContext context) {
    super.build(context);

    try {
      if (widget.imageUrl == null || widget.imageUrl!.trim().isEmpty
          // ||
          // widget.imageUrl!.endsWith('/')
          ) {
        return SizedBox(
          height: widget.height,
          width: widget.width,
          child: _defaultErrorWidgetBuilder(),
        );
      }

      return
          // Uncomment this to controll cache image size to reduce memory usage.
          // LayoutBuilder(
          //   builder: (context, constraints) {
          // double? cacheWidth = widget.width == null
          //     ? constraints.maxWidth * 1.3
          //     : (widget.width == double.infinity
          //         ? constraints.maxWidth * 1.3
          //         : widget.width);

          // if (cacheWidth == double.infinity) {
          //   cacheWidth = null;
          // }

          // return
          ClipRRect(
        borderRadius: widget.radius,
        child: kIsWeb
            ? Image.network(
                widget.imageUrl!,
                height: widget.height,
                width: widget.width,
                fit: widget.fit,
                color: widget.color,
                repeat: widget.repeat,
                // cacheWidth: cacheWidth?.round(),
                errorBuilder: (_, __, ___) => _defaultErrorWidgetBuilder(),
                loadingBuilder: widget.progressIndicatorBuilder == null
                    ? (_, child, progress) {
                        if (progress == null) return child;

                        return _defaultPtogressIndicatorBuilder(
                          _,
                          child,
                          progress,
                        );
                      }
                    : (ctx, child, progress) =>
                        widget.progressIndicatorBuilder!(
                          ctx,
                          '',
                          DownloadProgress(
                            widget.imageUrl!,
                            progress?.expectedTotalBytes,
                            progress?.cumulativeBytesLoaded ?? 0,
                          ),
                        ),
              )
            : CachedNetworkImage(
                imageUrl: widget.imageUrl!,
                height: widget.height,
                width: widget.width,
                fit: widget.fit,
                color: widget.color,
                repeat: widget.repeat,
                imageBuilder: widget.imageBuilder,
                // maxWidthDiskCache: cacheWidth?.round(),
                progressIndicatorBuilder: widget.progressIndicatorBuilder ??
                    _defaultPtogressIndicatorBuilder,
                errorWidget: (_, __, ___) => _defaultErrorWidgetBuilder(),
              ),
      );
      //   },
      // );
    } catch (err) {
      log(err.toString());

      return SizedBox(
        height: widget.height,
        width: widget.width,
        child: _defaultErrorWidgetBuilder(),
      );
    }
  }

  Widget _defaultErrorWidgetBuilder() {
    if (widget.errorWidget != null) return widget.errorWidget!;

    return MediaAvatarPlaceholder(
      iconHeight: widget.defaultProgressIconHeight,
      shape: widget.defaultProgressViewShape,
      backgroundColor: widget.placeholderBackgroundColor,
    );
  }

  Widget _defaultPtogressIndicatorBuilder(_, __, ___) {
    return MediaAvatarPlaceholder(
      isLoading: true,
      iconHeight: widget.defaultProgressIconHeight,
      shape: widget.defaultProgressViewShape,
      backgroundColor: widget.placeholderBackgroundColor,
    );
  }
}
