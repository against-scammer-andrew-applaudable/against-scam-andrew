import 'package:flutter/material.dart';

import '../../theme/dimensions.dart';

class AppIconButton extends StatelessWidget {
  final Widget icon;
  final EdgeInsetsGeometry? padding;
  final Color backgroundColor;
  final BorderRadius? borderRadius;
  final Color highlightColor;
  final Function()? onTap;

  const AppIconButton({
    super.key,
    required this.icon,
    this.padding,
    this.backgroundColor = Colors.white,
    this.borderRadius,
    this.highlightColor = Colors.black12,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: borderRadius ?? BorderRadius.circular(30),
      child: Material(
        color: backgroundColor,
        child: InkWell(
          onTap: onTap,
          highlightColor: highlightColor,
          child: Padding(
            padding: padding ??
                const EdgeInsets.all(AppDimensions.mediumSidePadding),
            child: icon,
          ),
        ),
      ),
    );
  }
}
