import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';

class AppIconButton extends StatelessWidget {
  const AppIconButton({
    Key? key,
    required this.icon,
    this.onTap,
    this.iconSize = 16,
  }) : super(key: key);

  final VoidCallback? onTap;
  final Widget icon;
  final double iconSize;

  const AppIconButton.feed({
    Key? key,
    required this.icon,
    this.onTap,
  })  : iconSize = 24,
        super(key: key);

  const AppIconButton.tabBar({
    Key? key,
    required this.icon,
    this.onTap,
  })  : iconSize = 24,
        super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      type: MaterialType.transparency,
      child: IconButton(
        //alignment: Alignment.centerLeft,
        onPressed: onTap,
        iconSize: iconSize,
        splashRadius: iconSize,
        highlightColor: context.borderColor,
        splashColor: context.borderColor,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        padding: EdgeInsets.zero,
        icon: icon,
      ),
    );
  }
}
