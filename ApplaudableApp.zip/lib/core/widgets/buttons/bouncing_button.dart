import 'package:flutter/material.dart';

class BouncingButton extends StatefulWidget {
  final Widget? child;
  final Function()? onTap;

  const BouncingButton({super.key, this.child, this.onTap});

  @override
  State<BouncingButton> createState() => _BouncingButtonState();
}

class _BouncingButtonState extends State<BouncingButton>
    with SingleTickerProviderStateMixin {
  double _scale = 1;
  late AnimationController _controller;

  @override
  void initState() {
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 250),
      lowerBound: 0.0,
      upperBound: 0.3,
    );

    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        _scale = 1 - _controller.value;

        return GestureDetector(
          onTap: _onTap,
          onTapDown: _tapDown,
          onTapUp: _tapUp,
          onTapCancel: _tapCancel,
          child: Transform.scale(scale: _scale, child: widget.child),
        );
      },
    );
  }

  void _onTap() {
    _controller.forward();

    if (widget.onTap != null) widget.onTap!();

    Future(() => _tapCancel());
  }

  void _tapDown(TapDownDetails details) {
    _controller.forward();
  }

  void _tapUp(TapUpDetails details) {
    _controller.reverse();
  }

  void _tapCancel() {
    _controller.reverse();
  }
}
