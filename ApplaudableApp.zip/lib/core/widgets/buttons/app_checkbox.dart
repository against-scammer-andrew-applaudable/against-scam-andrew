import 'package:flutter/material.dart';

import '../../theme/colors.dart';
import '../../theme/dimensions.dart';

class AppCheckbox extends StatelessWidget {
  final Widget? label;
  final bool value;
  final Function(bool)? onChanged;
  final Color checkColor;
  final Color activeColor;
  final Color fillColor;
  final Color borderColor;
  final Border? border;
  final BorderRadius? radius;
  final IconData icon;
  final double width;
  final double height;
  final BoxShape shape;
  final EdgeInsets checkIconPadding;
  final EdgeInsets? margin;

  const AppCheckbox({
    super.key,
    this.label,
    required this.value,
    this.onChanged,
    this.checkColor = AppColors.white,
    this.activeColor = AppColors.primaryColor,
    this.fillColor = AppColors.white,
    this.borderColor = AppColors.mediumGrey,
    this.border,
    this.radius,
    this.icon = Icons.check,
    this.width = 20,
    this.height = 20,
    this.shape = BoxShape.rectangle,
    this.checkIconPadding = const EdgeInsets.all(2),
    this.margin,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onChanged != null ? () => onChanged!(!value) : null,
      child: Container(
        width: label == null ? width : null,
        height: label == null ? height : null,
        margin: margin,
        color: AppColors.transparent,
        child: Row(
          children: [
            Container(
              width: width,
              height: height,
              decoration: BoxDecoration(
                color: value ? activeColor : fillColor,
                border: border ??
                    Border.all(color: value ? activeColor : borderColor),
                borderRadius: shape == BoxShape.circle
                    ? null
                    : radius ?? BorderRadius.circular(5),
                shape: shape,
              ),
              child: Padding(
                padding: checkIconPadding,
                child: FittedBox(
                  child: Icon(icon, color: checkColor),
                ),
              ),
            ),
            if (label != null) ...[
              const SizedBox(width: AppDimensions.mediumSidePadding),
              Flexible(child: label!),
            ],
          ],
        ),
      ),
    );
  }
}
