import 'dart:math';

import 'package:flutter/material.dart';

import '../../../../features/auth/presentation/callbacks.dart';
import '../../animations/wiggle.dart';
import '../app_icon_buttom.dart';

enum AppAnimatedButtonIconTypes { none, fade, overflow }

class AppAnimatedButtonIcon extends StatefulWidget {
  final bool state;
  final OnTapCallback<bool> onTap;

  final Widget icon;
  final Widget selectedIcon;

  final double iconSize;
  final double selectedIconSize;

  final AppAnimatedButtonIconTypes animationType;

  const AppAnimatedButtonIcon(
      {Key? key,
      required this.onTap,
      required this.icon,
      required this.selectedIcon,
      this.iconSize = 24,
      this.selectedIconSize = 24,
      this.state = false,
      this.animationType = AppAnimatedButtonIconTypes.fade})
      : super(key: key);

  @override
  State createState() => _AppAnimatedButtonIconState();
}

class _AppAnimatedButtonIconState extends State<AppAnimatedButtonIcon>
    with TickerProviderStateMixin {
  final GlobalKey<WiggleState> _wiggleKey = GlobalKey<WiggleState>();

  late AnimationController _animationController;
  late AnimationController _animationController2;

  /// Create animation values
  late Animation<double> _animation;
  late Animation<double> _opacity, _opacity2;

  double get iconSize {
    return widget.iconSize;
  }

  Widget get selectedIcon {
    return AppIconButton(icon: widget.selectedIcon);
  }

  Widget get unselectedIcon {
    return AppIconButton(icon: widget.icon);
  }

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
        vsync: this,
        duration: const Duration(milliseconds: 500),
        reverseDuration: const Duration(milliseconds: 500));

    _animationController2 = AnimationController(
        vsync: this,
        duration: const Duration(milliseconds: 500),
        reverseDuration: const Duration(milliseconds: 500));

    _animation = Tween<double>(begin: 0, end: 60).animate(CurvedAnimation(
      parent: _animationController2,
      curve: const Interval(
        0.0,
        1.0,
        curve: Curves.fastLinearToSlowEaseIn,
      ),
    ))
      ..addListener(() {
        setState(() {});
      });

    _opacity = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: const Interval(
          0.0,
          1.0,
          curve: Curves.ease,
        ),
      ),
    );

    _opacity2 = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(
      CurvedAnimation(
          parent: _animationController2,
          curve: const Interval(
            0.0,
            1.0,
            curve: Curves.ease,
          )),
    );

    if (widget.state) {
      _animationController.forward();
    } else {
      _animationController.reset();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
          //padding: const EdgeInsets.all(0),
          splashColor: Colors.transparent,
          highlightColor: Colors.transparent,
          onTap: () async {
            _wiggleKey.currentState?.wiggle();

            if (!widget.state) {
              _animationController.forward();
              _animationController2.forward();
            } else {
              _animationController.reset();
              _animationController2.reset();
            }

            widget.onTap(widget.state);
          },
          child: Container(
            width: 50,
            padding: const EdgeInsets.symmetric(
              vertical: 12,
              horizontal: 4,
            ),
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                if (widget.animationType ==
                    AppAnimatedButtonIconTypes.none) ...[
                  Opacity(
                    opacity: 1 - _opacity.value,
                    child: widget.state ? selectedIcon : unselectedIcon,
                  ),
                  Opacity(
                    opacity: _opacity.value,
                    child: widget.state ? selectedIcon : unselectedIcon,
                  ),
                ],
                if (widget.animationType ==
                    AppAnimatedButtonIconTypes.overflow) ...[
                  Positioned(
                    bottom: _animation.value,
                    child: Opacity(
                      opacity: _opacity2.value,
                      child: Opacity(
                          opacity: 1 - _opacity2.value, child: selectedIcon),
                    ),
                  ),
                  Positioned(
                    bottom: _animation.value,
                    child: Opacity(
                      opacity: _opacity2.value,
                      child: Opacity(
                          opacity: 1 - _opacity2.value,
                          child: Transform.translate(
                              offset: Offset(-Random().nextInt(10).toDouble(),
                                  Random().nextInt(10).toDouble()),
                              child: selectedIcon)),
                    ),
                  ),
                  Wiggle(
                    key: _wiggleKey,
                    scale: 2.0,
                    child: Opacity(
                      opacity: 1 - _opacity.value,
                      child: widget.state ? selectedIcon : unselectedIcon,
                    ),
                  ),
                  Opacity(
                    opacity: _opacity.value,
                    child: widget.state ? selectedIcon : unselectedIcon,
                  ),
                ],
              ],
            ),
          )),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    _animationController2.dispose();
    super.dispose();
  }
}
