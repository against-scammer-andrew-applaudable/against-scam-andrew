import 'package:flutter/material.dart';

import '../../../../features/auth/presentation/callbacks.dart';
import '../../../../features/feed/domain/entities/post_response.dart';
import '../../../bloc/dng_base_bloc.dart';
import '../../../bloc/widgets/base_statefull_page.dart';
import '../../../bloc/widgets/dng_bloc_builder.dart';
import 'app_animated_button_icon.dart';

abstract class AppAnimatedButton<M extends Post, Bloc extends DNGBaseBloc, S>
    extends BasePage {
  final String id;
  final OnTapCallback<bool>? onTap;
  final bool? status;

  AppAnimatedButtonIconTypes get animationType =>
      AppAnimatedButtonIconTypes.none;

  bool resolveWhen(S state);

  Widget get icon;

  Widget get selectedIcon;

  double get iconSize => 24;

  double get selectedIconSize => 24;

  const AppAnimatedButton(
      {super.key, required this.id, this.onTap, this.status});
}

abstract class AppAnimatedButtonStreamState<
    M extends Post,
    Bloc extends DNGBaseBloc<S>,
    S> extends BaseSingleChildStatefulState<AppAnimatedButton, Bloc, S> {
  M? _item;
  bool _status = false;

  bool get requestState => false;

  bool resolveStateFromItem(M? item);

  bool resolveOnState(S state);

  M? item(S state);

  getModel(String id);

  setModel(String id);

  unSetModel(String id);

  @override
  void initState() {
    super.initState();
    _status = widget.status ?? false;
  }

  @override
  Widget build(BuildContext context) {
    return DNGBlocBuilder<Bloc, S>(
        buildWhen: (state) => widget.resolveWhen(state),
        builder: (BuildContext context, S state) {
          if (resolveOnState(state) && item(state) != null) {
            _item = item(state);
            _status = resolveStateFromItem(_item);
            isRequesting = false;
          }
          return AppAnimatedButtonIcon(
            state: _status,
            icon: widget.icon,
            iconSize: widget.iconSize,
            selectedIcon: widget.selectedIcon,
            selectedIconSize: widget.selectedIconSize,
            animationType: widget.animationType,
            onTap: (value) {
              if (isRequesting) {
                return;
              }

              if (value) {
                isRequesting = true;
                unSetModel(widget.id);
              } else {
                isRequesting = true;
                setModel(widget.id);
              }
            },
          );
          /*if (isRequesting) {
            return Shimmer.fromColors(
              baseColor: Colors.white,
              highlightColor: AppColors.lightGrey,
              child: ApplaudIcon(
                state: false,
                onTap: (_) {},
              ),
            );
          }*/
        });
  }

  onTap() {
    if (widget.onTap != null) {
      widget.onTap!(_status);
    }
  }
}
