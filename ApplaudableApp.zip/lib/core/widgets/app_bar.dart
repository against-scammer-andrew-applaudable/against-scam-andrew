import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';

import '../../app_module.dart';
import '../theme/styles.dart';
import '../extensions/app_module_extensions.dart';
import 'svg_icons.dart';

abstract class AppBarWidget extends StatelessWidget {
  const AppBarWidget({super.key});

  @override
  Widget build(BuildContext context);
}

class NavigationPageBar extends AppBarWidget implements PreferredSizeWidget {
  final Key? leadingWidgetKey;
  final String? title;
  final TextStyle? style;
  final List<Widget>? actions;
  final PreferredSizeWidget? bottom;
  final Widget? leading;
  final double? leadingWidth;
  final bool centerTitle;

  const NavigationPageBar({
    super.key,
    this.leadingWidgetKey,
    this.title,
    this.style,
    this.actions,
    this.bottom,
    this.leading,
    this.leadingWidth,
    this.centerTitle = true,
  });

  @override
  Widget build(BuildContext context) {
    return AppBar(
      automaticallyImplyLeading: false,
      leadingWidth: leadingWidth,
      scrolledUnderElevation: 0,
      leading: leading ??
          IconButton(
            key: leadingWidgetKey,
            icon: SvgIcons.backArrow(color: context.textColor),
            onPressed: () {
              if (AppModule.I.canPop) {
                AppModule.I.pop();
              } else {
                context.pop();
              }
            },
          ),
      centerTitle: centerTitle,
      title: title != null && title!.isNotEmpty
          ? Text(
              title!,
              style: style ??
                  AppStyles.header2(color: context.textColor).copyWith(
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                  ),
            )
          : null,
      actions: [
        if (actions != null) ...[...actions!]
      ],
      bottom: bottom,
    );
  }

  @override
  Size get preferredSize {
    if (bottom != null) {
      var bottomHeight = bottom?.preferredSize.height ?? 0.0;
      return Size.fromHeight(56.0 + bottomHeight);
    }

    return const Size.fromHeight(56.0);
  }
}
