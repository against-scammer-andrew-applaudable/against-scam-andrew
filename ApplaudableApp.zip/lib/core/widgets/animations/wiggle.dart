import 'dart:math';

import 'package:flutter/material.dart';

class Wiggle extends StatefulWidget {
  final Widget child;
  final bool shouldAutoAnimate;
  final double scale;

  const Wiggle(
      {Key? key,
      required this.child,
      this.shouldAutoAnimate = false,
      this.scale = 2.0})
      : super(key: key);

  static WiggleState? of(BuildContext context, {bool nullOk = false}) {
    final WiggleState result = context.findAncestorStateOfType<WiggleState>()!;
    if (nullOk) {
      return result;
    }
    return null;
  }

  @override
  WiggleState createState() => WiggleState();
}

class WiggleState extends State<Wiggle> with SingleTickerProviderStateMixin {
  late AnimationController controller;
  late Animation<double> animation;
  late Animation<double> animation2;

  @override
  void initState() {
    super.initState();

    controller = AnimationController(
        duration: const Duration(milliseconds: 500),
        reverseDuration: const Duration(milliseconds: 200),
        vsync: this)
      ..addListener(() {
        setState(() {});
      });

    animation = Tween<double>(begin: 1.0, end: 100.0).animate(CurvedAnimation(
      parent: controller,
      curve: const Interval(
        0.0,
        1.0,
        curve: Curves.fastOutSlowIn,
      ),
    ));
    animation2 =
        Tween<double>(begin: 1.0, end: widget.scale).animate(CurvedAnimation(
      parent: controller,
      curve: const Interval(
        0.0,
        1.0,
        curve: Curves.fastOutSlowIn,
      ),
    ));

    if (widget.shouldAutoAnimate) {
      Future.delayed(const Duration(milliseconds: 200), () {
        if (!controller.isDismissed) {
          controller.forward();
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Transform(
      transform: Matrix4.identity()..translate(sin(animation.value * pi) * 2),
      child: Transform.scale(
          scale: animation2.status == AnimationStatus.forward
              ? sin(animation2.value)
              : 1,
          child: widget.child),
    );
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  wiggle() {
    controller.forward(from: 0.0);
  }
}
