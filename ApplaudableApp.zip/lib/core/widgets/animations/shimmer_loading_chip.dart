import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

import '../../theme/colors.dart';
import '../app_chip.dart';

class ShimmerLoadingChip extends StatelessWidget {
  final String? label;

  const ShimmerLoadingChip({super.key, this.label});

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: AppColors.lightPeach,
      highlightColor: AppColors.darkPeach,
      child: AppChip(
        title: label ?? 'p tag',
        titleColor: AppColors.transparent,
        padding: EdgeInsets.zero,
        borderColor: AppColors.darkPeach2,
      ),
    );
  }
}
