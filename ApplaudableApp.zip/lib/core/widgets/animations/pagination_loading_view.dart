import 'package:flutter/material.dart';

import '../../theme/colors.dart';
import '../../theme/dimensions.dart';

class PaginationLoadingView extends StatelessWidget {
  final double minHeight;
  final double radius;

  const PaginationLoadingView({
    super.key,
    this.minHeight = 15,
    this.radius = AppDimensions.smallRadius,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 5,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: LinearProgressIndicator(
          backgroundColor: AppColors.white,
          color: AppColors.peach,
          minHeight: minHeight,
        ),
      ),
    );
  }
}
