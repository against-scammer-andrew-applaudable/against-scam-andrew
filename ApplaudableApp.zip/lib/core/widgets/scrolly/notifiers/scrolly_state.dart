import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

import '../../../../features/influence/presetation/controllers/influence_analytics.dart';
import '../../../entities/item.dart';
import '../entities/scrolly_widget_data_holder.dart';

class ScrollyState<T extends Item> extends ChangeNotifier {
  static const auditTime = 200;

  late final Set<ScrollyWidgetDataHolder> _contexts;

  final List<String> _currentVisibleIds = [];

  ScrollyState() : _contexts = <ScrollyWidgetDataHolder>{};

  set initialVisibleItems(List<String>? initialVisibleItems) {
    if (initialVisibleItems == null) {
      return;
    }

    if (initialVisibleItems.isEmpty) {
      return;
    }

    _currentVisibleIds
      ..clear()
      ..addAll(initialVisibleItems);
    notifyListeners();
  }

  bool isVisible(String id) => _currentVisibleIds.contains(id);

  void addContext(
      {required BuildContext? context, required String id, T? item}) {
    _contexts
      ..removeWhere((value) => value.id == id)
      ..add(ScrollyWidgetDataHolder(context: context, id: id, item: item));
  }

  void removeContext({required BuildContext context, required String id}) {
    _contexts.removeWhere((value) => value.context == context);
    if (isVisible(id)) {
      _currentVisibleIds.remove(id);
    }
  }

  void onScroll(ScrollNotification notification) {
    //log("ScrollyState: ${_contexts.length} ${_currentVisibleIds.length} $_currentVisibleIds");
    for (ScrollyWidgetDataHolder item in _contexts) {
      //print("WidgetDataHolder [${item.id}] item ${item.visibility}");
      /*if (!item.visibility) {
        continue;
      }*/

      final RenderObject? renderObject = item.context!.findRenderObject();
      if (renderObject == null || !renderObject.attached) {
        continue;
      }

      //Retrieve the viewport related to the scroll area
      final RenderAbstractViewport viewport =
          RenderAbstractViewport.of(renderObject);
      final double vpHeight = notification.metrics.viewportDimension;
      final RevealedOffset vpOffset =
          viewport.getOffsetToReveal(renderObject, 0.0);
      //print("vpOffset: $vpOffset ${notification.metrics.pixels}");

      // Retrieve the dimensions of the item
      final Size size = renderObject.semanticBounds.size;

      //distance from top of the widget to top of the viewport
      final double deltaTop = vpOffset.offset - notification.metrics.pixels;

      //distance from bottom of the widget to top of the viewport
      final double deltaBottom = deltaTop + size.height;
      //bool isInViewport = false;

      //log("[${item.id}] size: $size | vpHeight: $vpHeight | deltaTop: $deltaTop | deltaBottom: $deltaBottom");

      bool isInViewport =
          deltaTop < (0.5 * vpHeight) && deltaBottom > (0.5 * vpHeight);
      //log("[${item.id}] isInViewport: $isInViewport");

      //print("[${item.id}] SSS: ${deltaBottom - deltaTop.abs()}");
      if (isInViewport) {
        if (!_currentVisibleIds.contains(item.id)) {
          _currentVisibleIds.add(item.id);
          notifyListeners();
        }
      } else {
        if (_currentVisibleIds.contains(item.id)) {
          _currentVisibleIds.remove(item.id);
          notifyListeners();
        }
      }
    }
  }

  void setVisibility({required String id, required bool visible}) {
    var list = _contexts.where((value) => value.id == id).toList();
    if (list.isEmpty) {
      return;
    }

    ScrollyWidgetDataHolder item = list.first;
    item.visibility = visible;
  }

  void stateChanged(AppLifecycleState state) {
    switch (state) {
      case AppLifecycleState.resumed:
        // TODO: Handle this case.
        break;
      case AppLifecycleState.inactive:
        // TODO: Handle this case.
        break;
      case AppLifecycleState.paused:
        if (_currentVisibleIds.isNotEmpty) {
          String id = _currentVisibleIds.first;
          _currentVisibleIds.remove(id);
          notifyListeners();
        }

        break;
      case AppLifecycleState.detached:
        // TODO: Handle this case.
        break;
      case AppLifecycleState.hidden:
        // TODO: Handle this case.
        break;
    }

    InfluencesPosts.I.stateChange(state);
  }
}
