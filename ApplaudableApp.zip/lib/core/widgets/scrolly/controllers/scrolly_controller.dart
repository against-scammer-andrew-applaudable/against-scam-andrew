import 'package:flutter/material.dart';

class ScrollyController {
  const ScrollyController({this.scrollController});

  //final Map<int, BuildContext> contexts = {};
  final ScrollController? scrollController;

  /*void attach({required BuildContext context, required int index}) {
    contexts.update(index, (value) => context, ifAbsent: () => context);
  }*/

  void animateToTop() {
    if (scrollController?.hasClients ?? false) {
      scrollController?.animateTo(0,
          duration: const Duration(milliseconds: 250),
          curve: Curves.fastLinearToSlowEaseIn);
    }
  }

  dispose() {
    //contexts.clear();
  }
}
