import 'dart:async';

import 'package:flutter/material.dart';
import 'package:stream_transform/stream_transform.dart';

import '../notifiers/scrolly_state.dart';

mixin ScrollyStreamsMixin {
  StreamController<ScrollNotification>? _streamController;
  StreamSubscription<ScrollNotification>? _stream;

  get scrollyState;

  bool get isClosed => _streamController != null && _streamController!.isClosed;

  void startListening() {
    _stream?.cancel();
    _streamController?.close();

    _streamController = StreamController<ScrollNotification>();

    _stream = _streamController!.stream
        .audit(const Duration(milliseconds: ScrollyState.auditTime))
        .listen(scrollyState?.onScroll);
  }

  void addToStream(ScrollNotification notification, bool isScrollDirection) {
    if (!isClosed && isScrollDirection) {
      _streamController?.add(notification);
    }
  }

  void disposeStreams() {
    _stream?.cancel();
    _streamController?.close();
  }
}
