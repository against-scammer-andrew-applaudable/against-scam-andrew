import '../notifiers/scrolly_state.dart';

mixin ScrollyMixin {
  ScrollyState? scrollyState;

  List<String> get initialVisibleItems;

  initScrollyState() {
    scrollyState = ScrollyState()..initialVisibleItems = initialVisibleItems;
  }
}
