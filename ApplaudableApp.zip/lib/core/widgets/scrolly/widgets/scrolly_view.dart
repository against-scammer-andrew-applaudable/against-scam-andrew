import 'package:flutter/material.dart';

import '../notifiers/scrolly_state.dart';

class ScrollyView extends InheritedWidget {
  final ScrollyState? state;
  @override
  final Widget child;
  final ScrollController? controller;

  const ScrollyView({
    Key? key,
    this.state,
    required this.child,
    this.controller,
  }) : super(key: key, child: child);

  @override
  bool updateShouldNotify(ScrollyView oldWidget) => false;

  void animateToTop() {
    if (controller?.hasClients ?? false) {
      controller?.animateTo(0,
          duration: const Duration(milliseconds: 250),
          curve: Curves.fastLinearToSlowEaseIn);
    }
  }
}
