import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

/// Callback for handle tap from the top of screen
typedef OnTapScrollToTopCallback = Future<void> Function(
    ScrollToTopEvent event);

class ScrollToTopEvent {
  final double to;
  final Duration duration;
  final Curve curve;

  ScrollToTopEvent({
    required this.to,
    required this.duration,
    required this.curve,
  });
}

class ScrollyScaffold extends StatefulWidget {
  final Widget child;
  final BuildContext? parentContext;
  final OnTapScrollToTopCallback onTapScrollToTopCallback;

  /// Creates new ScrollsToTop widget
  const ScrollyScaffold({
    Key? key,
    required this.child,
    required this.onTapScrollToTopCallback,
    BuildContext? context,
  })  : parentContext = context,
        super(key: key);

  @override
  State<ScrollyScaffold> createState() => _ScrollyScaffoldState();
}

class _ScrollyScaffoldState extends State<ScrollyScaffold> {
  ScrollController? _scrollController;
  ScrollPositionWithSingleContext? _scrollPositionContext;
  bool _attached = false;

  @override
  Widget build(BuildContext context) {
    _initController(context);
    return widget.child;
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _dispose();
    _initController(widget.parentContext ?? context);
  }

  void _initController(BuildContext context) {
    if (!_attached) {
      _attach(context);
      _attached = true;
    }
  }

  void _attach(BuildContext context) {
    /// Scroll to tops only works with the primary scroll controller
    /// Try to get it from navigator context first
    _scrollController = PrimaryScrollController.of(context);

    if (_scrollController == null) return;

    /// Creates a fake scroll context based on the scroll view
    /// that we want to use for scroll
    _scrollPositionContext = _FakeScrollPositionWithSingleContext(
      context: context,
      callback: widget.onTapScrollToTopCallback,
    );

    _scrollController?.attach(_scrollPositionContext!);
  }

  void _dispose() {
    if (_scrollPositionContext != null) {
      _scrollController?.detach(_scrollPositionContext!);
    }
    _scrollPositionContext?.dispose();

    _scrollPositionContext = null;
    _scrollController = null;
    _attached = false;
  }

  @override
  void dispose() {
    _dispose();
    super.dispose();
  }
}

class _FakeScrollPositionWithSingleContext
    extends ScrollPositionWithSingleContext {
  _FakeScrollPositionWithSingleContext({
    required BuildContext context,
    required OnTapScrollToTopCallback callback,
  })  : _callback = callback,
        super(
          physics: const NeverScrollableScrollPhysics(),
          context: _FakeScrollContext(context),
        );

  final OnTapScrollToTopCallback _callback;

  @override
  Future<void> animateTo(
    double to, {
    required Duration duration,
    required Curve curve,
  }) =>
      _callback(
        ScrollToTopEvent(to: to, duration: duration, curve: curve),
      );
}

class _FakeScrollContext extends ScrollContext {
  _FakeScrollContext(this._context);

  final BuildContext _context;

  @override
  AxisDirection get axisDirection => AxisDirection.down;

  @override
  BuildContext get notificationContext => _context;

  @override
  void saveOffset(double offset) {}

  @override
  void setCanDrag(bool value) {}

  @override
  void setIgnorePointer(bool value) {}

  @override
  void setSemanticsActions(Set<SemanticsAction> actions) {}

  @override
  BuildContext get storageContext => _context;

  @override
  TickerProvider get vsync => _FakeTickerProvider();

  @override
  double get devicePixelRatio => 1.0;
}

class _FakeTickerProvider extends TickerProvider {
  @override
  Ticker createTicker(TickerCallback onTick) {
    return Ticker(onTick);
  }
}
