import 'package:flutter/material.dart';

import '../../../../features/influence/presetation/controllers/influence_analytics.dart';
import '../../../entities/item.dart';
import '../../app_scroller_view.dart';
import '../entities/scrolly_widget_data_holder.dart';
import '../notifiers/scrolly_state.dart';

class ScrollyNotifierWidget<T extends Item> extends StatefulWidget {
  final ScrollyNotifierWidgetBuilder builder;
  final Widget child;
  final T item;

  const ScrollyNotifierWidget(
      {super.key,
      required this.builder,
      required this.child,
      required this.item});

  String get id => item.id;

  @override
  State<ScrollyNotifierWidget> createState() => _ScrollyNotifierWidgetState();
}

class _ScrollyNotifierWidgetState extends State<ScrollyNotifierWidget>
    with WidgetsBindingObserver {
  late final ScrollyState state;

  Stopwatch? stopwatch;

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addObserver(this);

    state = AppScrollerView.stateOf(context)!;
    state.addContext(context: context, id: widget.item.id);
  }

  @override
  void didUpdateWidget(ScrollyNotifierWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.id != widget.id) {
      state
        ..removeContext(context: context, id: widget.id)
        ..addContext(context: context, id: widget.id);
    }
  }

  @override
  Widget build(BuildContext context) {
    /*return VisibilityDetector(
      key: Key(widget.item.id),
      onVisibilityChanged: (visibilityInfo) {
        print(
            "[${widget.item.id}] visibilityInfo: ${visibilityInfo.visibleFraction}");
        bool isVisible = state.isVisible(widget.item.id);
        print("[${widget.item.id}] visibilityInfo: $isVisible");

        if (isVisible && visibilityInfo.visibleFraction < 0.3) {
          state.setVisibility(id: widget.item.id, visible: false);
        } else {
          state.setVisibility(id: widget.item.id, visible: true);
        }
      },
      child: ,
    );*/

    return AnimatedBuilder(
      animation: state,
      child: widget.child,
      builder: (BuildContext context, Widget? child) {
        bool isVisible = state.isVisible(widget.item.id);

        if (isVisible) {
          startTimer();
        }

        if (!isVisible) {
          final time = stopTimer();

          InfluencesPosts.I.update(widget.item, time: time);
        }

        return widget.builder(context, isVisible, child);
      },
    );
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    switch (state) {
      case AppLifecycleState.resumed:
        InfluencesPosts.I.stateChange(state);
        break;
      case AppLifecycleState.inactive:
        // TODO: Handle this case.
        break;
      case AppLifecycleState.paused:
        if (stopwatch != null && stopwatch!.isRunning) {
          stopwatch!.stop();

          int time = stopwatch?.elapsedMilliseconds ?? 0;

          InfluencesPosts.I.update(widget.item, time: time, onDone: () {
            InfluencesPosts.I.stateChange(state);
          });
        }
        break;
      case AppLifecycleState.detached:
        // TODO: Handle this case.
        break;
      case AppLifecycleState.hidden:
        // TODO: Handle this case.
        break;
    }
  }

  void startTimer() {
    stopwatch ??= Stopwatch()..start();
    stopwatch
      ?..stop()
      ..reset()
      ..start();
  }

  int stopTimer() {
    stopwatch?.stop();
    return stopwatch?.elapsedMilliseconds ?? 0;
  }

  @override
  void dispose() {
    state.removeContext(context: context, id: widget.item.id);

    WidgetsBinding.instance.removeObserver(this);

    super.dispose();
  }
}
