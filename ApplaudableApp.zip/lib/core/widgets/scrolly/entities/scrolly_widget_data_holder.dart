import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

import '../../../entities/item.dart';

typedef ScrollyNotifierWidgetBuilder = Widget Function(
    BuildContext context, bool isVisible, Widget? child);

class ScrollyWidgetDataHolder<T extends Item> with EquatableMixin {
  final BuildContext? context;
  final String id;
  final T? item;

  bool visible = false;

  ScrollyWidgetDataHolder({required this.context, required this.id, this.item});

  @override
  List<Object?> get props => [id, context, item];

  set visibility(bool visibility) {
    visible = visibility;
  }

  bool get visibility => visible;
}
