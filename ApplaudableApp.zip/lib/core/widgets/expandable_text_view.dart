import 'package:flutter/material.dart';

import 'expandable_text.dart';

class ExpandableTextView extends ExpandableText {
  final Function()? onTap;

  const ExpandableTextView({
    super.key,
    required super.text,
    super.maxLines = 2,
    super.style,
    super.enableGestureRecognizer = true,
    this.onTap,
  });

  @override
  State<ExpandableText> createState() => ExpandableTextViewState();
}

class ExpandableTextViewState extends ExpandableTextState<ExpandableTextView> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      child: super.build(context),
    );
  }
}
