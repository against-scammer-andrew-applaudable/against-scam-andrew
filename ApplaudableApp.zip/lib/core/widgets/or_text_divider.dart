import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';

import '../../generated/l10n.dart';
import '../theme/colors.dart';
import '../theme/styles.dart';

class OrTextDivider extends StatelessWidget {
  const OrTextDivider({super.key});

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return Container(
      height: 30,
      alignment: Alignment.center,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const SizedBox(
            width: 80,
            child: Divider(
              color: AppColors.lightGrey,
              height: 1.0,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 9.0),
            child: Text(
              translations.or,
              style: AppStyles.text2(color: context.textColor).copyWith(height: 16 / 30),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(
            width: 80,
            child: Divider(
              color: AppColors.lightGrey,
              height: 1.0,
            ),
          ),
        ],
      ),
    );
  }
}
