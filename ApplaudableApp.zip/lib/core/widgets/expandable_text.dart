import 'package:flutter/material.dart';

import '../../generated/l10n.dart';
import '../theme/colors.dart';
import '../theme/styles.dart';
import '../utils/emoji.dart';

/// Implement own widget
abstract class ExpandableText extends StatefulWidget {
  final String text;
  final TextStyle? style;
  final BoxConstraints? viewportConstraints;
  final int? maxLines;
  final bool enableGestureRecognizer;

  const ExpandableText({
    Key? key,
    required this.text,
    this.style,
    this.viewportConstraints,
    this.maxLines = 5,
    this.enableGestureRecognizer = true,
  }) : super(key: key);

  @override
  State<ExpandableText> createState();
}

abstract class ExpandableTextState<ViewState extends ExpandableText>
    extends State<ViewState> {
  late final translations = S.of(context);
  final EmojiHandler emojiHandler = EmojiHandler();

  TextStyle get descriptionTextStyle =>
      AppStyles.text2(color: AppColors.darkGrey);

  TextStyle get style => widget.style ?? descriptionTextStyle;

  int? _maxLines;

  @override
  void initState() {
    _maxLines = widget.maxLines;

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedSize(
      alignment: Alignment.topCenter,
      duration: const Duration(milliseconds: 150),
      reverseDuration: const Duration(milliseconds: 150),
      child: widget.viewportConstraints == null
          ? LayoutBuilder(
              builder: (context, size) {
                return _buildExpandableText(context, size);
              },
            )
          : _buildExpandableText(context, widget.viewportConstraints!),
    );
  }

  buildInlineSpan(ViewState widget, String text,
      {TextStyle? style, EmojiHandler? emoji}) {
    return TextSpan(
      text: text,
      style: style,
    );
  }

  buildSpanChildren(
    ViewState widget,
    String text, {
    TextStyle? style,
    EmojiHandler? emoji,
  }) {
    return TextSpan(text: text, style: style);
  }

  Widget _buildExpandableText(BuildContext context, BoxConstraints size) {
    /// Calculate height based on maxLines
    TextPainter tp = getTextSize(size, widget.maxLines);

    /// If [didExceedMaxLines] is True then
    /// calculate the max text height
    TextPainter? tpMaxHeight;
    if (tp.didExceedMaxLines) {
      tpMaxHeight = getTextSize(size, null);
    }

    return GestureDetector(
      onTap: widget.enableGestureRecognizer
          ? () {
              if (tp.didExceedMaxLines) {
                if (_maxLines == null) {
                  _maxLines = widget.maxLines;
                } else {
                  _maxLines = null;
                }

                setState(() {});
              }
            }
          : null,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(
            height: _maxLines == null
                ? (tpMaxHeight?.height ?? tp.height)
                : tp.height,
            child: RichText(
              text: buildSpanChildren(widget, widget.text.trim(),
                  style: style, emoji: emojiHandler),
              maxLines: _maxLines,
              textDirection: TextDirection.ltr,
              overflow:
                  _maxLines == null ? TextOverflow.clip : TextOverflow.ellipsis,
            ),
          ),
          if (tp.didExceedMaxLines &&
              _maxLines != null &&
              widget.enableGestureRecognizer)
            Text(
              translations.show_more_label,
              style: (widget.style ?? descriptionTextStyle)
                  .copyWith(color: AppColors.mediumGrey),
            ),
        ],
      ),
    );
  }

  TextPainter getTextSize(BoxConstraints size, int? maxLines) {
    final tp = TextPainter(
      text: buildInlineSpan(widget, widget.text.trim(),
          style: style, emoji: emojiHandler),
      maxLines: maxLines,
      textDirection: TextDirection.ltr,
    );
    tp.layout(maxWidth: size.maxWidth);

    return tp;
  }
}
