import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../theme/colors.dart';
import '../theme/styles.dart';

class CurvedTextField extends StatelessWidget {
  final TextEditingController? controller;
  final FocusNode? focusNode;
  final void Function()? onEditingComplete;
  final InputBorder? focusedBorder;
  final InputBorder? border;
  final InputBorder? enabledBorder;
  final InputBorder? disabledBorder;
  final String? hintText;
  final TextStyle? hintStyle;
  final bool filled;
  final Color? fillColor;
  final Widget? prefixIcon;
  final void Function(String)? onChanged;

  const CurvedTextField({
    super.key,
    this.controller,
    this.focusNode,
    this.onEditingComplete,
    this.focusedBorder,
    this.border,
    this.enabledBorder,
    this.disabledBorder,
    this.hintText,
    this.hintStyle,
    this.filled = false,
    this.fillColor,
    this.prefixIcon,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      focusNode: focusNode,
      onEditingComplete: onEditingComplete,
      onChanged: onChanged,
      autocorrect: false,
      enableSuggestions: false,
      decoration: InputDecoration(
        focusedBorder: focusedBorder ?? buildOutlineInputBorder(context),
        border: border ?? buildOutlineInputBorder(context, bordered: false),
        enabledBorder:
            enabledBorder ?? buildOutlineInputBorder(context, bordered: false),
        disabledBorder:
            disabledBorder ?? buildOutlineInputBorder(context, bordered: false),
        hintText: hintText,
        hintStyle: hintStyle ??
            AppStyles.text1(
              color: AppColors.darkGrey,
            ),
        filled: filled,
        fillColor: fillColor ?? AppColors.white,
        prefixIcon: prefixIcon,
      ),
    );
  }

  InputBorder buildOutlineInputBorder(BuildContext context, {bool bordered = true}) {
    return OutlineInputBorder(
      borderSide: BorderSide(
        color: bordered ? context.borderColor : Colors.transparent,
        width: 2,
      ),
      borderRadius: BorderRadius.circular(40),
    );
  }
}

class SearchFieldPrefix extends StatelessWidget {
  const SearchFieldPrefix({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 60,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            SvgPicture.asset('assets/icons/ic_search.svg'),
          ],
        ),
      ),
    );
  }
}
