import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../../constants/constant_values.dart';
import '../optimized_cached_network_image.dart';
import '../svg_icons.dart';

class ItemImage extends StatefulWidget {
  const ItemImage({
    super.key,
    required this.source,
    this.height = 70,
    this.width = 70,
    this.enableRoundCorners = true,
    this.boxFit = BoxFit.cover,
    this.margin = EdgeInsets.zero,
    this.borderRadius,
    this.shape = BoxShape.rectangle,
    this.onTap,
    this.autoAspectRatio = false,
    this.disableAspectRatio = false,
    this.shouldResizeImageOnHeight = false,
  });

  const ItemImage.square(
      {super.key,
      required this.source,
      required double size,
      this.onTap,
      this.autoAspectRatio = false,
      this.disableAspectRatio = false,
      this.shouldResizeImageOnHeight = false})
      : height = size,
        width = size,
        enableRoundCorners = false,
        boxFit = BoxFit.cover,
        margin = EdgeInsets.zero,
        borderRadius = null,
        shape = BoxShape.rectangle;

  const ItemImage.profile({
    super.key,
    required this.source,
    required double size,
    this.onTap,
  })  : height = size,
        width = size,
        enableRoundCorners = false,
        boxFit = BoxFit.cover,
        margin = EdgeInsets.zero,
        borderRadius = null,
        shape = BoxShape.circle,
        autoAspectRatio = false,
        disableAspectRatio = false,
        shouldResizeImageOnHeight = false;

  const ItemImage.taller(
      {super.key,
      required this.source,
      required this.height,
      required double size,
      this.onTap,
      this.autoAspectRatio = false,
      this.disableAspectRatio = false,
      this.shouldResizeImageOnHeight = false,
      this.boxFit = BoxFit.cover,
      })
      : width = size,
        enableRoundCorners = false,
        margin = EdgeInsets.zero,
        borderRadius = null,
        shape = BoxShape.rectangle;

  final String source;
  final double height;
  final double width;

  final bool enableRoundCorners;
  final BoxFit? boxFit;
  final EdgeInsets margin;
  final BorderRadius? borderRadius;

  final BoxShape? shape;
  final Function()? onTap;

  final bool autoAspectRatio;
  final bool disableAspectRatio;
  final bool shouldResizeImageOnHeight;

  @override
  State createState() => _ItemImageState();

  static get defaultPlaceholder => SvgIcons.appLogoHomeFeed;
}

class _ItemImageState extends State<ItemImage> {
  // Widget? image;
  // String imageSource = "";

  // @override
  // void initState() {
  //   super.initState();

  //   if (widget.source.isNotEmpty) {
  //     imageSource = widget.source;
  //     image = _buildImage(imageSource);
  //   } else if (widget.source != imageSource) {
  //     imageSource = widget.source;
  //     image = _buildImage(imageSource);
  //   } else {
  //     image = ItemImage.defaultPlaceholder;
  //   }
  // }

  // @override
  // void didChangeDependencies() {
  //   super.didChangeDependencies();
  //   if (widget.source.isNotEmpty) {
  //     imageSource = widget.source;
  //     image = _buildImage(imageSource);
  //   } else if (widget.source != imageSource) {
  //     imageSource = widget.source;
  //     image = _buildImage(imageSource);
  //   } else {
  //     image = ItemImage.defaultPlaceholder;
  //   }

  //   if (image != null) {
  //     precacheImage(image!.image, context);
  //   }
  // }

  bool get autoAspectRatio => widget.autoAspectRatio;

  String path = "";
  double height = ConstantValues.feedPostHeight;

  @override
  void initState() {
    super.initState();

    height = widget.height;
    if (widget.shouldResizeImageOnHeight) {
      height = height * 1.5;
    }

    if (autoAspectRatio) {
      CachedNetworkImageProvider(widget.source)
          .resolve(const ImageConfiguration())
          .addListener(ImageStreamListener(imageListener));
    }
  }

  @override
  Widget build(BuildContext context) {
    // if (widget.source != imageSource) {
    //   imageSource = widget.source;
    //   image = _buildImage(imageSource);
    // } else if (widget.source.isNotEmpty) {
    //   image = _buildImage(imageSource);
    // }

    /*if (imageCache!.containsKey(widget.key!)) {
      imageCache!.evict(widget.key!, includeLive: true);
      precacheImage(image!.image, context);
    }*/

    switch (widget.shape) {
      case BoxShape.circle:
        return GestureDetector(
          onTap: widget.onTap,
          child: ClipOval(
            child: Container(
              margin: widget.margin,
              height: widget.height,
              width: widget.width,
              decoration: BoxDecoration(
                shape: widget.shape ?? BoxShape.rectangle,
                borderRadius: widget.borderRadius ??
                    (widget.enableRoundCorners
                        ? const BorderRadius.all(
                            Radius.circular(10.0),
                          )
                        : null),
              ),
              child: OptimizedCachedNetworkImage(
                imageUrl: widget.source,
                height: widget.height,
                width: widget.width,
                fit: BoxFit.cover,
                defaultProgressViewShape: widget.shape ?? BoxShape.rectangle,
              ),
            ),
          ),
        );
      case BoxShape.rectangle:
      default:
        final child = OptimizedCachedNetworkImage(
          imageUrl: autoAspectRatio ? path : widget.source,
          //height: widget.height,
          width: widget.width,
          fit: widget.boxFit,// BoxFit.cover,
          defaultProgressViewShape: widget.shape ?? BoxShape.rectangle,
        );
        return GestureDetector(
          onTap: widget.onTap,
          child: Container(
            constraints: widget.disableAspectRatio ? null : BoxConstraints(maxHeight: height),
            margin: widget.margin,
            //height: widget.height,
            width: widget.width,
            decoration: BoxDecoration(
              shape: widget.shape ?? BoxShape.rectangle,
              borderRadius: widget.borderRadius ??
                  (widget.enableRoundCorners
                      ? const BorderRadius.all(
                          Radius.circular(10.0),
                        )
                      : null),
            ),
            child: widget.disableAspectRatio ? child : AspectRatio(
              aspectRatio: widget.width / height,
              child: child,
            ),
          ),
        );
    }
  }

  imageListener(ImageInfo image, bool synchronousCall) {
    var myImage = image.image;
    Size size = Size(myImage.width.toDouble(), myImage.height.toDouble());
    if (size.height > size.width) {
      height = height * 1.5;
    }

    path = widget.source;
    if (mounted) {
      setState(() {});
    }
  }
}
