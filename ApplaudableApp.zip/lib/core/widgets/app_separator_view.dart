import 'package:flutter/material.dart';

import '../theme/colors.dart';

class AppSeparatorView extends StatelessWidget {
  const AppSeparatorView({
    super.key,
    this.size = 16,
    this.color = AppColors.pink,
    this.height = 1.0,
  });

  final double size;
  final Color color;
  final double height;

  const AppSeparatorView.pinkBig({super.key})
      : size = 19,
        height = 2.0,
        color = AppColors.pink;

  const AppSeparatorView.pink({super.key})
      : size = 16,
        height = 1.0,
        color = AppColors.pink;

  const AppSeparatorView.grey({super.key})
      : size = 7,
        height = 1.0,
        color = AppColors.lightGrey;

  const AppSeparatorView.darkGrey({super.key})
      : size = 7,
        height = 1.0,
        color = AppColors.darkGrey;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: height,
      color: color,
    );
  }
}
