import 'package:flutter/material.dart';
import 'package:gradient_like_css/gradient_like_css.dart';

import '../theme/colors.dart';
import '../theme/styles.dart';

class AppCustomTab extends StatelessWidget {
  final String label;
  final bool isSelected;
  final Function()? onTap;

  const AppCustomTab({
    super.key,
    this.label = '',
    this.isSelected = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(50),
          color: isSelected ? AppColors.primaryColor : AppColors.dark,
          gradient: isSelected
              ? linearGradient(137.2, ['#E73D5F 35.06%', '#FE5B7C 92.93%'])
              : null,
        ),
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(
          vertical: 18,
          horizontal: 25,
        ),
        child: Text(
          label,
          style: AppStyles.text1(
            color: isSelected ? AppColors.white : AppColors.mediumGrey,
          ).copyWith(
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}
