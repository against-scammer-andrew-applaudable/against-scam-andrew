// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../theme/colors.dart';
import '../enums/category_icon_enums.dart';

class SvgIcons {
  static final SvgPicture topLogo = SvgPicture.asset(
    'assets/icons/top_logo.svg',
  );

  static final SvgPicture bottomLogo = SvgPicture.asset(
    'assets/icons/bottom_logo.svg',
  );

  static final SvgPicture homeFeed = SvgPicture.asset(
    'assets/icons/ic_home_feed.svg',
  );

  static final SvgPicture dropdownArrow = SvgPicture.asset(
    'assets/icons/dropdown_arrow.svg',
  );

  static final SvgPicture appLogoDarkSmall = SvgPicture.asset(
    'assets/icons/ic_dark_applaud.svg',
  );

  static final SvgPicture appLogoHomeFeed = SvgPicture.asset(
    'assets/icons/app_logo_home_feed.svg',
  );

  static final SvgPicture appLogoStroke = SvgPicture.asset(
    'assets/icons/app_logo_stroke.svg',
  );

  static final SvgPicture notificationsBig = SvgPicture.asset(
    'assets/icons/ic_notifications_big.svg',
  );

  static SvgPicture feedFilters({Color? color, double? height}) => SvgPicture.asset(
    'assets/icons/ic_feed_filters.svg',
    color: color,
  );

  static final SvgPicture feedNotifications = SvgPicture.asset(
    'assets/icons/ic_feed_notifications.svg',
  );

  static final SvgPicture email = SvgPicture.asset(
    'assets/icons/ic_email.svg',
  );

  static SvgPicture close({Color? color, double? height}) => SvgPicture.asset(
        'assets/icons/ic_close.svg',
        color: color,
        height: height,
      );

  static SvgPicture backArrow({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_step_arrow.svg',
        color: color,
        height: height,
      );

  static SvgPicture plus({Color? color, double? height}) => SvgPicture.asset(
        'assets/icons/ic_plus.svg',
        color: color,
        height: height,
      );

  static SvgPicture forwardArrow({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_forward_arrow.svg',
        color: color,
        height: height,
      );

  static SvgPicture applaudRating({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/app_logo_rating.svg',
        color: color,
        height: height,
      );

  static SvgPicture applaudRatingFilled({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/app_logo_rating_filled.svg',
        color: color,
        height: height,
      );

  static SvgPicture checkConfirm({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_check_confirm.svg',
        color: color,
        height: height,
      );

  static SvgPicture flash({Color? color, double? height}) => SvgPicture.asset(
        'assets/icons/ic_flash.svg',
        color: color,
        height: height,
      );

  static SvgPicture videoCamera({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_video.svg',
        color: color,
        height: height,
      );

  static SvgPicture swipeCamera({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_swipe_camera.svg',
        color: color,
        height: height,
      );

  static SvgPicture horizontalMenu({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_horizontal_menu.svg',
        color: color,
        height: height,
      );

  static SvgPicture blockUser({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_block_user.svg',
        color: color,
        height: height,
      );

  static SvgPicture person({Color? color, double? height}) => SvgPicture.asset(
        'assets/icons/ic_person.svg',
        color: color,
        height: height,
      );

  static SvgPicture grid({Color? color, double? height}) => SvgPicture.asset(
        'assets/icons/ic_grid.svg',
        color: color,
        height: height,
      );

  static SvgPicture someone({Color? color, double? height}) => SvgPicture.asset(
        'assets/icons/ic_someone.svg',
        color: color,
        height: height,
      );

  static SvgPicture something({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_something.svg',
        color: color,
        height: height,
      );

  static SvgPicture somewhere({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_somewhere.svg',
        color: color,
        height: height,
      );

  static SvgPicture postConfirmLogo({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_post_confirm_logo.svg',
        color: color,
        height: height,
      );

  static SvgPicture centerBGLogo({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_post_confirm_bg_logo.svg',
        color: color,
        height: height,
      );

  static SvgPicture downArrow({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_down_arrow.svg',
        color: color,
        height: height,
      );

  static SvgPicture mediaErrorLogo({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_media_upload_error.svg',
        color: color,
        height: height,
      );

  static SvgPicture star({Color? color, double? height}) => SvgPicture.asset(
        'assets/icons/ic_star.svg',
        color: color,
        height: height,
      );

  static SvgPicture mention({Color? color, double? height}) => SvgPicture.asset(
        'assets/icons/ic_mention.svg',
        color: color,
        height: height,
      );

  static SvgPicture location({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_location.svg',
        color: color,
        height: height,
      );

  static SvgPicture camera({
    Color? color = AppColors.primaryColor,
    double? height,
  }) =>
      SvgPicture.asset(
        'assets/icons/ic_camera.svg',
        color: color,
        height: height,
      );

  static SvgPicture gallery({
    Color? color = AppColors.primaryColor,
    double? height,
  }) =>
      SvgPicture.asset(
        'assets/icons/ic_gallery.svg',
        color: color,
        height: height,
      );

  static SvgPicture quote({
    Color? color = AppColors.primaryColor,
    double? height,
  }) =>
      SvgPicture.asset(
        'assets/icons/ic_quote.svg',
        color: color,
        height: height,
      );
}

class SvgFeedIcons {
  static SvgPicture applaud({Color? color}) => SvgPicture.asset(
    'assets/icons/post/ic_post_applaud.svg',
    color: color,
  );
  static final SvgPicture applauded = SvgPicture.asset(
    'assets/icons/post/ic_post_applauded.svg',
    width: 31,
    height: 32,
  );

  static SvgPicture bookmark({Color? color}) => SvgPicture.asset(
    'assets/icons/post/ic_post_bookmark.svg',
    color: color,
  );
  static SvgPicture bookmarked({Color? color}) => SvgPicture.asset(
    'assets/icons/post/ic_post_bookmarked.svg',
    color: color,
  );

  static final SvgPicture comments = SvgPicture.asset(
    'assets/icons/post/ic_post_comments.svg',
  );
  static SvgPicture highlights({Color? color}) => SvgPicture.asset(
    'assets/icons/post/ic_post_highlights.svg',
    color: color,
  );
  static SvgPicture share({Color? color}) => SvgPicture.asset(
    'assets/icons/post/ic_post_share.svg',
    color: color,
  );

  static final SvgPicture applaudRankFill = SvgPicture.asset(
    'assets/icons/post/ic_post_applaud_rank_fill.svg',
  );
  static final SvgPicture applaudRankStroke = SvgPicture.asset(
    'assets/icons/post/ic_post_applaud_rank_stroke.svg',
  );

  static SvgPicture moreOptions({Color? color}) => SvgPicture.asset(
    'assets/icons/post/ic_post_more.svg',
    color: color,
  );
}

class SvgHomeIcons {
  static SvgPicture home({Color? color}) => SvgPicture.asset(
    'assets/icons/tabbar/home.svg',
    color: color,
  );
  static SvgPicture navBarSearch({Color? color}) => SvgPicture.asset(
    'assets/icons/tabbar/search.svg',
    color: color,
  );
  static SvgPicture createPost({Color? color, double? size}) => SvgPicture.asset(
    'assets/icons/tabbar/create.svg',
    color: color,
    width: size,
  );
  static SvgPicture navBarNotifications({Color? color, double? width}) => SvgPicture.asset(
    'assets/icons/tabbar/notification.svg',
    color: color,
    width: width,
  );
}

class SvgBackgrounds {
  static final SvgPicture mediaText = SvgPicture.asset(
    'assets/icons/bg_media_text.svg',
  );
}

class SvgCategoryIcon {
  static SvgPicture load(String slug) => SvgPicture.asset(
        'assets/icons/category/${SvgCategoryIcons.getIconBySlug(slug)}.svg',
        color: const Color(0xff202020),
        width: 15,
        height: 15,
      );
}

class SvgSettingsIcons {
  static SvgPicture editProfile({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_setting_edit_profile.svg',
        color: color,
        height: height,
      );

  static SvgPicture myBookmarks({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_setting_my_bookmarks.svg',
        color: color,
        height: height,
      );

  static SvgPicture privateAccount({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_setting_private_account.svg',
        color: color,
        height: height,
      );

  static SvgPicture blockedAccounts({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_setting_blocked_accounts.svg',
        color: color,
        height: height,
      );

  static SvgPicture password({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_setting_password.svg',
        color: color,
        height: height,
      );

  static SvgPicture phoneNumber({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_setting_phone_number.svg',
        color: color,
        height: height,
      );

  static SvgPicture email({Color? color, double? height}) => SvgPicture.asset(
        'assets/icons/ic_setting_email.svg',
        color: color,
        height: height,
      );

  static SvgPicture notifications({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_setting_notifications.svg',
        color: color,
        height: height,
      );

  static SvgPicture geolocation({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_setting_geolocation.svg',
        color: color,
        height: height,
      );

  static SvgPicture help({Color? color, double? height}) => SvgPicture.asset(
        'assets/icons/ic_setting_help.svg',
        color: color,
        height: height,
      );

  static SvgPicture deleteAccount({Color? color, double? height = 23}) =>
      SvgPicture.asset(
        'assets/icons/ic_setting_delete_account.svg',
        color: color,
        height: height,
      );

  static SvgPicture logout({Color? color, double? height}) => SvgPicture.asset(
        'assets/icons/ic_setting_logout.svg',
        color: color,
        height: height,
      );

  static SvgPicture deleteAccountDialog({Color? color, double? height}) =>
      SvgPicture.asset(
        'assets/icons/ic_setting_delete_account_dialog.svg',
        color: color,
        height: height,
      );
}
