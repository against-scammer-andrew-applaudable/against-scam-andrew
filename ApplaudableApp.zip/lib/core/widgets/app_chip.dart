import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../theme/colors.dart';
import '../theme/styles.dart';

class AppChip extends StatelessWidget {
  final String title;
  final bool isSelected;
  final Function()? onTap;
  final Color? backgroundColor;
  final bool hasBorder;
  final Widget? deleteIcon;
  final Function()? onDelete;
  final bool bolded;
  final EdgeInsetsGeometry? padding;
  final Color? borderColor;
  final Color? titleColor;
  final Color? selectionColor;
  final double? width;

  const AppChip({
    Key? key,
    required this.title,
    this.isSelected = false,
    this.onTap,
    this.backgroundColor,
    this.hasBorder = true,
    this.deleteIcon,
    this.onDelete,
    this.bolded = false,
    this.padding,
    this.titleColor,
    this.borderColor,
    this.selectionColor,
    this.width,
  }) : super(key: key);

  const AppChip.tag({
    super.key,
    required this.title,
    this.width = 90,
    this.hasBorder = false,
    this.backgroundColor = AppColors.primaryColor,
    this.borderColor,
    this.titleColor = AppColors.white,
    this.padding = EdgeInsets.zero,
    this.bolded = true,
  })  : deleteIcon = null,
        isSelected = false,
        onDelete = null,
        onTap = null,
        selectionColor = AppColors.primaryColor;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      child: GestureDetector(
        onTap: onTap,
        child: Chip(
          label: Padding(
            padding: padding ?? const EdgeInsets.all(5.0),
            child: FittedBox(child: Text(title)),
          ),
          backgroundColor: isSelected
              ? (selectionColor ?? AppColors.primaryColor.withOpacity(0.85))
              : backgroundColor ?? Colors.transparent,
          labelStyle: AppStyles.text1(
            color: isSelected ? AppColors.white : (titleColor ?? Colors.black),
          ).copyWith(fontWeight: bolded ? FontWeight.bold : null),
          shape: hasBorder && !isSelected
              ? RoundedRectangleBorder(
                  side: BorderSide(
                    color: borderColor ?? AppColors.darkGrey,
                    width: 0.5,
                  ),
                  borderRadius: BorderRadius.circular(50),
                )
              : null,
          onDeleted: onDelete,
          deleteIcon:
              deleteIcon ?? SvgPicture.asset('assets/icons/ic_chip_delete.svg'),
        ),
      ),
    );
  }
}
