import 'package:flutter/material.dart';

import '../../features/onboarding/presentation/widgets/user_profile_avatar_picker.dart';
import '../../features/profile/presentation/pages/profile_page.dart';
import '../../ui/page/main/profile_settings/profile.dart';
import '../entities/base_user.dart';
import '../extensions/build_context_extensions.dart';
import '../theme/colors.dart';
import '../theme/styles.dart';
import 'items/item_image.dart';

enum AppUserViewTypes {
  feedPost,
}

class AppUserView<T extends BaseUser> extends StatelessWidget {
  const AppUserView({
    Key? key,
    required this.user,
    this.userViewType = AppUserViewTypes.feedPost,
    this.value = "",
    this.id,
  }) : super(key: key);

  final AppUserViewTypes userViewType;
  final T user;
  final String value;
  final String? id;

  const AppUserView.feedPost({
    super.key,
    required this.user,
    this.value = "",
    this.id,
  }) : userViewType = AppUserViewTypes.feedPost;

  @override
  Widget build(BuildContext context) {
    /// case [userViewType] is a [AppUserViewTypes.feedPost]
    /// then shows the user avatar on the left
    /// and the username and value on the right
    switch (userViewType) {
      case AppUserViewTypes.feedPost:
        return InkWell(
          onTap: () {
            context.navigateToNamed(
              AppProfilePage.routeName,
              arguments: {
                "userId": user.id,
              },
            );
          },
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Hero(
                    tag:
                        "user-avatar-${user.id}-${id ?? DateTime.now().microsecondsSinceEpoch}",
                    child: context.currentSessionUserId == user.id
                        ? Padding(
                            padding: const EdgeInsets.only(
                              right: 10,
                            ),
                            child: UserProfileAvatarPicker(
                              key: Key(user.optimizedImage),
                              avatarUrl: user.optimizedImage,
                              size: 32,
                              canPick: false,
                            ),
                          )
                        : Container(
                            padding: const EdgeInsets.only(top: 14, bottom: 15),
                            margin: const EdgeInsets.only(right: 9),
                            child: ItemImage.profile(
                              key: Key("profile-${user.id}"),
                              source: user.optimizedImage,
                              size: 32,
                            ),
                          ),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    user.formattedName,
                    maxLines: 1,
                    style: AppStyles.text2(color: context.textColor),
                  ),
                  if (value.isNotEmpty)
                    Text(value,
                        style: AppStyles.textSmall(
                                color: AppColors.mediumGrey.shade90)
                            .copyWith(height: 0.95)),
                ],
              )
            ],
          ),
        );
    }
  }
}
