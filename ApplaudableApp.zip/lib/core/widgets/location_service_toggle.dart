import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart' as geo;
import 'package:location/location.dart';

import '../../features/profile_settings/presentation/pages/profile_settings_page.dart';
import '../../generated/l10n.dart';
import 'svg_icons.dart';

class GeolocationServiceToggle extends StatefulWidget {
  const GeolocationServiceToggle({super.key});

  @override
  State<GeolocationServiceToggle> createState() =>
      _GeolocationServiceToggleState();
}

class _GeolocationServiceToggleState extends State<GeolocationServiceToggle>
    with WidgetsBindingObserver {
  final location = Location();

  @override
  void initState() {
    WidgetsBinding.instance.addObserver(this);

    super.initState();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return FutureBuilder<PermissionStatus>(
      future: location.hasPermission(),
      builder: (context, snapshot) {
        return SettingsTile(
          title: translations.geolocation,
          leading: SvgSettingsIcons.geolocation(color: context.textColor),
          trailing: (!snapshot.hasData || snapshot.data == null)
              ? const SizedBox(
                  height: 15,
                  width: 15,
                  child: CircularProgressIndicator(),
                )
              : SettingTileSwitch(
                  value: snapshot.data == PermissionStatus.granted,
                  onChanged: (_) =>
                      _handleToggleLocationPermission(snapshot.data),
                ),
          onTap: () => _handleToggleLocationPermission(snapshot.data),
        );
      },
    );
  }

  Future<void> _requestLocationPermission() async {
    final status = await location.requestPermission();

    if (status == PermissionStatus.deniedForever) {
      geo.Geolocator.openAppSettings();
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);

    switch (state) {
      case AppLifecycleState.resumed:
        setState(() {});
        break;
      default:
    }
  }

  void _handleToggleLocationPermission(PermissionStatus? status) async {
    if (status != PermissionStatus.granted) {
      await _requestLocationPermission();
    } else {
      geo.Geolocator.openAppSettings();
    }
  }
}
