import 'package:flutter/cupertino.dart';
import 'package:flutter/rendering.dart';
import 'package:provider/provider.dart';

import '../../features/feed/presentation/widgets/feed_bar.dart';
import '../controllers/scroll_gesture_controller.dart';
import '../utils/debouncer.dart';
import 'scrolly/mixins/scrolly_mixin.dart';
import 'scrolly/mixins/scrolly_stream_mixin.dart';
import 'scrolly/notifiers/scrolly_state.dart';
import 'scrolly/widgets/scrolly_scaffold.dart';
import 'scrolly/widgets/scrolly_view.dart';

class AppScrollerView extends StatefulWidget {
  final List<Widget> slivers;
  final ScrollController? scrollController;

  final Function()? onPaginate;
  final VoidCallback? onRefresh;

  final bool allowPaginationHandling;
  final double paginationThreshold;
  final bool enableOnScrollVisibleItemsNotifier;
  final bool useDebouncerToNotifyPagination;

  final bool shrinkWrap;

  final List<String>? initialVisibleItems;

  const AppScrollerView(
      {super.key,
      required this.slivers,
      this.scrollController,
      this.onPaginate,
      this.onRefresh,
      this.allowPaginationHandling = true,
      this.paginationThreshold = 250,
      this.enableOnScrollVisibleItemsNotifier = true,
      this.useDebouncerToNotifyPagination = false,
      this.shrinkWrap = false,
      this.initialVisibleItems});

  const AppScrollerView.shrink(
      {super.key,
      required this.slivers,
      this.scrollController,
      this.onPaginate,
      this.onRefresh,
      this.allowPaginationHandling = true,
      this.paginationThreshold = 250,

      /// Experimental - enable scroll notifications to find visible items
      this.enableOnScrollVisibleItemsNotifier = true,
      this.useDebouncerToNotifyPagination = false,
      this.initialVisibleItems})
      : shrinkWrap = true;

  @override
  State<AppScrollerView> createState() => _AppScrollerViewState();

  /// Get [ScrollyState] instance
  ///
  /// This instances holds the responsibility to handle
  /// what post is currently visible
  static ScrollyState? stateOf(BuildContext context) {
    final ScrollyView widget = context
        .getElementForInheritedWidgetOfExactType<ScrollyView>()!
        .widget as ScrollyView;
    return widget.state;
  }

  /// Get the [ScrollController] instance attached
  static ScrollyView? viewOf(BuildContext context) {
    final ScrollyView widget = context
        .getElementForInheritedWidgetOfExactType<ScrollyView>()!
        .widget as ScrollyView;
    return widget;
  }
}

class _AppScrollerViewState extends State<AppScrollerView>
    with ScrollyStreamsMixin, ScrollyMixin {
  final _debouncer = Debouncer(milliseconds: 300);

  /// ScrollController Controller
  ScrollController? scrollController;

  bool get enableScrollNotifier => widget.enableOnScrollVisibleItemsNotifier;

  double get paginationThreshold => widget.paginationThreshold;

  bool get allowPaginationHandling => widget.allowPaginationHandling;

  bool _backOffPagination = false;

  bool enablePullToRefresh = true;

  @override
  List<String> get initialVisibleItems => widget.initialVisibleItems ?? [];

  @override
  void initState() {
    super.initState();

    initControllers();

    initScrollyState();

    if (enableScrollNotifier) {
      startListening();
    }

    if (widget.shrinkWrap) {
      scrollController?.addListener(_onScrollListener);
    }
  }

  void initControllers() {
    /// Init ScrollController if not passed
    /// Only associate if null
    scrollController ??= widget.scrollController ?? ScrollController();
  }

  @override
  Widget build(BuildContext context) {
    initControllers();

    return ScrollyScaffold(
      key: Key("scrollController_${scrollController.hashCode}"),
      context: context,
      onTapScrollToTopCallback: (event) async {
        scrollController?.animateTo(event.to,
            duration: event.duration, curve: event.curve);
      },
      child: ScrollyView(
        state: scrollyState,
        controller: scrollController,
        child: NotificationListener<ScrollNotification>(
          onNotification: onNotification,
          child: Consumer<ScrollGestureController>(
            builder: (ctx, controller, child) {
              final appBarIndex = getAppBarIndex();

              return CustomScrollView(
                shrinkWrap: widget.shrinkWrap,
                physics: controller.canScroll
                    ? (widget.shrinkWrap
                        ? const NeverScrollableScrollPhysics()
                        : null)
                    : const NeverScrollableScrollPhysics(),
                controller: widget.shrinkWrap ? null : scrollController,
                slivers: widget.slivers.length > 1 && enablePullToRefresh
                    ? <Widget>[
                        if (appBarIndex != -1)
                          widget.slivers.elementAt(appBarIndex),
                        CupertinoSliverRefreshControl(
                          onRefresh: () async {
                            _debouncer.run(() {
                              if (widget.onRefresh != null) {
                                widget.onRefresh!();
                              }
                            });
                          },
                        ),
                        for (Widget w in getListExcludeAppBar()) ...[w]
                      ]
                    : widget.slivers,
              );
            },
          ),
        ),
      ),
    );
  }

  bool onNotification(ScrollNotification notification) {
    late bool isScrollDirection;
    //the direction of user scroll up, down, left, right.
    final AxisDirection scrollDirection = notification.metrics.axisDirection;

    isScrollDirection = scrollDirection == AxisDirection.down ||
        scrollDirection == AxisDirection.up;
    final double maxScroll = notification.metrics.maxScrollExtent;

    //end of the listview reached
    if (!(maxScroll - notification.metrics.pixels <=
            MediaQuery.of(context).size.height * 3) &&
        _backOffPagination) {
      _backOffPagination = false;
    }

    if (allowPaginationHandling &&
        isScrollDirection &&
        maxScroll - notification.metrics.pixels <=
            MediaQuery.of(context).size.height * 3) {
      if (widget.onPaginate != null) {
        if (widget.useDebouncerToNotifyPagination) {
          _debouncer.run(() {
            widget.onPaginate!();
          });
        } else {
          if (!_backOffPagination) {
            _backOffPagination = true;
            _debouncer.runOnce(() {
              widget.onPaginate!();
            });
          }
        }
      }
    }

    //when user is not scrolling
    if (enableScrollNotifier &&
        notification is UserScrollNotification &&
        notification.direction == ScrollDirection.idle) {
      addToStream(notification, isScrollDirection);
    }

    if (enableScrollNotifier && !isClosed && isScrollDirection) {
      addToStream(notification, isScrollDirection);
    }

    return true;
  }

  int getAppBarIndex() {
    int index = widget.slivers.indexWhere((e) => e is HomeFeedAppBar);
    return index;
  }

  List<Widget> getListExcludeAppBar() {
    return widget.slivers.where((e) => e is! HomeFeedAppBar).toList();
  }

  void _onScrollListener() {
    if (scrollController == null) {
      return;
    }
    final current = scrollController!.position.pixels;
    final maxExtent = scrollController!.position.maxScrollExtent;

    final different = maxExtent - current;
    final isScrollingDown =
        scrollController!.positions.first.userScrollDirection ==
            ScrollDirection.reverse;

    if (widget.onPaginate != null &&
        isScrollingDown &&
        different <= paginationThreshold) {
      if (widget.useDebouncerToNotifyPagination) {
        _debouncer.run(() {
          widget.onPaginate!();
        });
        return;
      }

      _debouncer.runOnce(() {
        widget.onPaginate!();
      });
    }
  }

  @override
  void dispose() {
    disposeStreams();

    if (widget.shrinkWrap) {
      scrollController?.removeListener(_onScrollListener);
    }

    //scrollController?.dispose();
    //scrollController = null;

    super.dispose();
  }
}
