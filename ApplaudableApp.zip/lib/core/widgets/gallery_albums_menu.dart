import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:photo_gallery/photo_gallery.dart';

import '../../features/auth/presentation/widgets/sizing/side_margins.dart';
import '../extensions/build_context_extensions.dart';
import '../theme/colors.dart';
import '../theme/dimensions.dart';
import '../theme/styles.dart';
import 'svg_icons.dart';

class GalleryAlbumsMenu extends StatefulWidget {
  final List<Album> albums;
  final Function(Album)? onAlbumSelected;

  const GalleryAlbumsMenu({
    Key? key,
    required this.albums,
    this.onAlbumSelected,
  }) : super(key: key);

  @override
  State<GalleryAlbumsMenu> createState() => _GalleryAlbumsMenuState();
}

class _GalleryAlbumsMenuState extends State<GalleryAlbumsMenu> {
  late Album _selectedAlbum;

  @override
  void initState() {
    if (widget.albums.isNotEmpty) {
      if (widget.albums.length == 1) {
        _selectedAlbum = widget.albums.first;
      } else {
        _selectedAlbum = widget.albums[1];
      }
    }

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.albums.isEmpty) return Container();

    if (Platform.isIOS) {
      return InkWell(
        onTap: _openCupertinoAlbumsOptions,
        child: defaultView,
      );
    }

    return PopupMenuButton<Album>(
      itemBuilder: (ctx) {
        return widget.albums
            .map(
              (e) => PopupMenuItem<Album>(
                child: Row(
                  children: [
                    Text(e.name ?? ''),
                    const SizedBox(width: 10),
                    Text('(${e.count})'),
                  ],
                ),
                onTap: () => _onAlbumSelected(e),
              ),
            )
            .toList();
      },
      child: defaultView,
    );
  }

  void _openCupertinoAlbumsOptions() async {
    final album = await showCupertinoModalPopup(
      context: context,
      builder: (ctx) {
        return CupertinoActionSheet(
          actions: widget.albums
              .map(
                (e) => CupertinoActionSheetAction(
                  onPressed: () {
                    ctx.pop(e);
                  },
                  child: Text(
                    e.name ?? '',
                    style: AppStyles.text1(color: context.textColor).copyWith(
                      color: e == _selectedAlbum
                          ? AppColors.primaryColor
                          : AppColors.darkGrey,
                      fontWeight: e == _selectedAlbum ? FontWeight.w600 : null,
                    ),
                  ),
                ),
              )
              .toList(),
        );
      },
    );

    if (album != null && album is Album) {
      _onAlbumSelected(album);
    }
  }

  void _onAlbumSelected(Album album) {
    setState(() {
      _selectedAlbum = album;
    });

    if (widget.onAlbumSelected != null) {
      widget.onAlbumSelected!(album);
    }
  }

  Widget get defaultView => AppSideMargins(
        margin: const EdgeInsets.symmetric(
          horizontal: 25,
          vertical: AppDimensions.defaultSidePadding,
        ),
        child: Row(
          children: [
            Text(
              _selectedAlbum.name ?? '',
              style: AppStyles.text1(color: context.textColor)
                  .copyWith(fontSize: 18, fontWeight: FontWeight.w400),
            ),
            const SizedBox(width: 15),
            SvgIcons.downArrow(),
          ],
        ),
      );
}
