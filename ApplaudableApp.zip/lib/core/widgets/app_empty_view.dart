import 'package:flutter/material.dart';

class AppEmptyView extends StatelessWidget {
  const AppEmptyView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => const SizedBox(width: 0, height: 0);
}
