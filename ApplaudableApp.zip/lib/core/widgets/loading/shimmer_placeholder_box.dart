import 'package:flutter/material.dart';

class ShimmerPlaceholderBox extends StatelessWidget {
  final double width;
  final double height;
  final double radius;
  final BorderRadius? borderRadius;
  final Color color;
  final Widget? child;

  const ShimmerPlaceholderBox({
    super.key,
    this.width = 90,
    this.height = 15,
    this.radius = 10,
    this.borderRadius,
    this.color = Colors.white,
    this.child,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: borderRadius ??
          BorderRadius.only(
            topLeft: Radius.circular(radius),
            bottomLeft: Radius.circular(radius),
            topRight: Radius.circular(radius),
            bottomRight: Radius.circular(radius),
          ),
      child: SizedBox(
        height: height,
        width: width,
        child: ColoredBox(color: color, child: child),
      ),
    );
  }
}
