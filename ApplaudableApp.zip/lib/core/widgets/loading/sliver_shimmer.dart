import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

import '../../theme/colors.dart';
import '../media_avatar_placeholder.dart';

enum SliverShimmerType { grid, list }

class SliverShimmer extends StatelessWidget {
  final SliverShimmerType shimmerType;

  const SliverShimmer.list({
    Key? key,
  })  : shimmerType = SliverShimmerType.list,
        super(key: key);

  const SliverShimmer.grid({
    Key? key,
  })  : shimmerType = SliverShimmerType.grid,
        super(key: key);

  @override
  Widget build(BuildContext context) {
    switch (shimmerType) {
      case SliverShimmerType.grid:
        return SliverGrid(
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            childAspectRatio: 0.7,
            crossAxisSpacing: 2,
            mainAxisSpacing: 2,
          ),
          delegate: SliverChildBuilderDelegate(
            (BuildContext context, int index) {
              return Stack(
                children: [
                  Container(
                    color: Colors.white,
                    child: const MediaAvatarPlaceholder(isLoading: true),
                  ),
                ],
              );
            },
            childCount: 15,
          ),
        );
      case SliverShimmerType.list:
        return SliverPadding(
          padding:
              const EdgeInsets.only(top: 10, left: 9, right: 9, bottom: 13),
          sliver: SliverList(
            delegate: SliverChildBuilderDelegate(
              (BuildContext context, int index) {
                return Column(
                  children: [
                    Shimmer.fromColors(
                      baseColor: AppColors.peach,
                      highlightColor: AppColors.lightPeach,
                      child: Container(
                        height: 61,
                        color: Colors.grey,
                      ),
                    ),
                    Shimmer.fromColors(
                      baseColor: AppColors.peach.shade10,
                      highlightColor: AppColors.lightPeach,
                      child: Container(
                        height: MediaQuery.of(context).size.width,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                );
              },
              childCount: 3,
            ),
          ),
        );
    }
  }
}
