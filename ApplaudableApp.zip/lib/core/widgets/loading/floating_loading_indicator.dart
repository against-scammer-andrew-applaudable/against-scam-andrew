import 'package:flutter/material.dart';

import '../../../../core/theme/colors.dart';

class FloatingLoadingIndicator extends StatefulWidget {
  const FloatingLoadingIndicator({super.key});

  @override
  State<FloatingLoadingIndicator> createState() =>
      _FloatingLoadingIndicatorState();
}

class _FloatingLoadingIndicatorState extends State<FloatingLoadingIndicator>
    with SingleTickerProviderStateMixin {
  late final Animation _animation;
  late final AnimationController _controller;

  @override
  void initState() {
    _controller = AnimationController(
      duration: const Duration(milliseconds: 700),
      vsync: this,
    );

    _animation = StepTween(begin: 0, end: 3).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    _controller.addStatusListener(_onAnimationStatusChanged);
    _controller.forward();

    super.initState();
  }

  @override
  void dispose() {
    _controller.removeStatusListener(_onAnimationStatusChanged);
    _controller.dispose();

    super.dispose();
  }

  void _onAnimationStatusChanged(AnimationStatus status) {
    if (status == AnimationStatus.completed) {
      _controller.repeat();
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, snapshot) {
        return Container(
          height: 40,
          decoration: BoxDecoration(
            color: AppColors.darkPeach2,
            borderRadius: BorderRadius.circular(100),
          ),
          padding: const EdgeInsets.symmetric(
            horizontal: 20,
            vertical: 10,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              3,
              (index) => AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                margin: const EdgeInsets.symmetric(
                  horizontal: 2,
                ),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _animation.value == index
                      ? AppColors.lightPeach
                      : AppColors.darkPeach,
                ),
                width: _animation.value == index
                    ? 18
                    : 10,
                height: _animation.value == index
                    ? 18
                    : 10,
              ),
            ),
          ),
        );
      },
    );
  }
}
