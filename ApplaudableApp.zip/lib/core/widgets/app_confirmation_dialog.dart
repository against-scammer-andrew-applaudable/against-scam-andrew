// import 'dart:async';
//
// import 'package:flutter/material.dart';
// import 'package:flutter_svg/flutter_svg.dart';
//
// import '../../features/auth/presentation/widgets/buttons/action_button.dart';
// import '../../features/auth/presentation/widgets/inputs/text_field.dart';
// import '../../generated/l10n.dart';
// import '../constants/constant_keys.dart';
// import '../extensions/build_context_extensions.dart';
// import '../theme/colors.dart';
// import '../theme/dimensions.dart';
// import '../theme/styles.dart';
// import 'app_separator_view.dart';
//
// class AppConfirmationDialog extends StatelessWidget {
//   final String title;
//   final String? description;
//   final String? confirmActionText;
//   final String? cancelActionText;
//   final Widget? icon;
//   final bool showLoading;
//   final String? confirmationText;
//   final VoidCallback? onConfirmTapped;
//   final VoidCallback? onCancelTapped;
//   final VoidCallback? onCloseTapped;
//   final bool hasCloseAction;
//   final BorderRadius radius;
//   final Axis alignment;
//   final bool hasSeparator;
//   final Color? cancelBorderColor;
//   final Color? cancelTextColor;
//   final TextStyle? titleStyle;
//   final EdgeInsetsGeometry? padding;
//   final EdgeInsetsGeometry? titlePadding;
//
//   AppConfirmationDialog({
//     super.key,
//     required this.title,
//     this.description,
//     this.confirmActionText,
//     this.cancelActionText,
//     this.icon,
//     this.showLoading = false,
//     this.confirmationText,
//     this.onConfirmTapped,
//     this.onCancelTapped,
//     this.onCloseTapped,
//     this.hasCloseAction = true,
//     this.radius = BorderRadius.zero,
//     this.alignment = Axis.vertical,
//     this.hasSeparator = false,
//     this.cancelBorderColor,
//     this.cancelTextColor,
//     this.titleStyle,
//     this.padding,
//     this.titlePadding,
//   });
//
//   final StreamController<String> _confirmationTextController =
//       StreamController<String>.broadcast();
//
//   @override
//   Widget build(BuildContext context) {
//     final translations = S.of(context);
//
//     final dialogActions = [
//       StreamBuilder<String>(
//         stream: _confirmationTextController.stream,
//         builder: (context, snapshot) {
//           return AppActionButton.submit(
//             key: ConstantKeys.appConfirmationConfirmBtnKey,
//             text: confirmActionText ?? translations.remove,
//             showLoading: showLoading,
//             onPressed: snapshot.data == confirmationText
//                 ? (onConfirmTapped ?? () => context.pop(true))
//                 : null,
//           );
//         },
//       ),
//       if (alignment == Axis.vertical)
//         const SizedBox(height: AppDimensions.mediumSidePadding),
//       if (alignment == Axis.horizontal)
//         const SizedBox(width: AppDimensions.mediumSidePadding),
//       AppActionButton.submitWithBorder(
//         key: ConstantKeys.appConfirmationCancelBtnKey,
//         text: cancelActionText ?? translations.cancel,
//         actionTextColor: cancelTextColor,
//         borderColor: cancelBorderColor,
//         onPressed: onCancelTapped ?? () => context.pop(),
//       ),
//     ];
//     return GestureDetector(
//       onTap: context.unfocus,
//       child: AlertDialog(
//         shape: RoundedRectangleBorder(borderRadius: radius),
//         title: hasCloseAction
//             ? Row(
//                 mainAxisAlignment: MainAxisAlignment.end,
//                 children: [
//                   GestureDetector(
//                     onTap: onCloseTapped ?? () => context.pop(),
//                     child: SvgPicture.asset('assets/icons/ic_dialog_close.svg'),
//                   ),
//                 ],
//               )
//             : null,
//         insetPadding:
//             const EdgeInsets.symmetric(horizontal: 20),
//         contentPadding: padding,
//         content: Column(
//           crossAxisAlignment: CrossAxisAlignment.stretch,
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             if (icon != null) ...[
//               icon!,
//               const SizedBox(height: 20),
//             ],
//             Padding(
//               padding: titlePadding ?? EdgeInsets.zero,
//               child: Text(
//                 title,
//                 textAlign: TextAlign.center,
//                 style: titleStyle,
//               ),
//             ),
//             if (description != null) ...[
//               const SizedBox(height: AppDimensions.smallSidePadding),
//               Text(
//                 description!,
//                 textAlign: TextAlign.center,
//                 style: AppStyles.text2(color: AppColors.darkGrey)
//                     .copyWith(fontSize: 14),
//               ),
//             ],
//             const SizedBox(height: AppDimensions.defaultSidePadding),
//             if (confirmationText != null) ...[
//               AppTextField(
//                 hintText: confirmationText,
//                 hintColor: AppColors.mediumGrey,
//                 autoCorrect: false,
//                 textCapitalization: TextCapitalization.none,
//                 border: AppStyles.outlinedFocusedBorder,
//                 onChanged: _confirmationTextController.sink.add,
//               ),
//               const SizedBox(height: 4),
//             ],
//             if (hasSeparator) ...[
//               const Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   AppSeparatorView.pink(),
//                 ],
//               ),
//               const SizedBox(height: 20),
//             ],
//             (alignment == Axis.vertical)
//                 ? Column(children: dialogActions)
//                 : SizedBox(
//                     width: double.maxFinite,
//                     child: Row(
//                       children: dialogActions
//                           .map(
//                             (e) => e is SizedBox
//                                 ? e
//                                 : Expanded(
//                                     flex: dialogActions.length -
//                                         dialogActions.indexOf(e) +
//                                         1,
//                                     child: e,
//                                   ),
//                           )
//                           .toList()
//                           .reversed
//                           .toList(),
//                     ),
//                   ),
//           ],
//         ),
//       ),
//     );
//   }
// }
