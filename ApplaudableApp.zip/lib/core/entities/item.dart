abstract class Item<T> {
  final String id;
  final String name;

  Item({required this.id, required this.name});

  T copyWith();

  String get value => "";
}
