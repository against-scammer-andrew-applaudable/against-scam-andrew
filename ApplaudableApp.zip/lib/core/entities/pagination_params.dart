import 'package:equatable/equatable.dart';

class PaginationParams extends Equatable {
  final int pageNo;
  final int pageSize;

  const PaginationParams({this.pageNo = 1, this.pageSize = 10});

  @override
  List<Object?> get props => [pageNo, pageSize];
}
