class BaseHiveTypeIds {
  /// 0 - 10 Session and User namespace
  static const int sessionModel = 0;
  static const int userModel = 1;
  static const int tokenModel = 2;
  static const int avatarModel = 3;
  static const int userProfileModel = 4;
  static const int simpleUser = 5;

  /// 11 - 20 Influences
  static const int influencePostImpressionModel = 11;

  /// 21 - 30 ** namespace

  /// 31 - 40

  /// 41 - 50 Notifications
  static const int notification = 41;
  static const int notificationType = 42;
  static const int notificationActor = 43;
  static const int notificationTarget = 44;
  static const int notificationActorType = 45;
  static const int notificationTargetType = 46;
}
