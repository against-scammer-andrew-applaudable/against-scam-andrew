import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../errors/failures.dart';

typedef PaginatedResults<T> = Future<Either<Failure, PaginationResponse<T>>>;

abstract class PaginationResponse<Type> extends Equatable {
  final int count;
  final String? next;
  final String? previous;
  final List<Type> results;

  const PaginationResponse({
    required this.count,
    required this.next,
    required this.previous,
    required this.results,
  });

  Map<String, dynamic> toMap() {
    return {
      'count': count,
      'next': next,
      'previous': previous,
      'results': results,
    };
  }

  @override
  List<Object?> get props => [count, next, previous, results];
}
