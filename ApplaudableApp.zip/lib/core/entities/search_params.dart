import 'package:equatable/equatable.dart';

import 'pagination_params.dart';

class SearchParams extends Equatable {
  final String query;
  final PaginationParams pageInfo;

  const SearchParams({required this.query, required this.pageInfo});

  @override
  List<Object?> get props => [query, pageInfo];
}
