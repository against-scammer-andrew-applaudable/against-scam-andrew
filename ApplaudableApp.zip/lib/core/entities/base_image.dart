enum ImageOptimizationSizes {
  q60("q_60"),
  qAutoBest("c_scale,q_auto:best,w_1080"),
  profile("c_limit,h_150,w_150"),
  qScale300("c_scale,w_300"),
  qColorSaturationScale300("b_rgb:e4cfbe,c_scale,e_saturation:-100,o_56,w_300");

  final String size;
  const ImageOptimizationSizes(this.size);
}

mixin BaseImage {
  ImageOptimizationSizes get defaultSize => ImageOptimizationSizes.q60;

  String get defaultImage;

  String get optimizedImage {
    if (defaultImage.isEmpty) {
      return "";
    }
    var split = defaultImage.split("/image/upload/");

    if (split.length < 2) return defaultImage;

    return "${split[0]}/image/upload/${defaultSize.size}/${split[1]}";
  }

  String getImageBySize(ImageOptimizationSizes size) {
    if (defaultImage.isEmpty) {
      return "";
    }

    final split = defaultImage.split("/image/upload/");

    if (split.length < 2) return defaultImage;

    return "${split[0]}/image/upload/${size.size}/${split[1]}";
  }

  String transform({ImageOptimizationSizes size = ImageOptimizationSizes.q60}) {
    if (defaultImage.isEmpty) {
      return "";
    }
    var split = defaultImage.split("/image/upload/");
    return "${split[0]}/image/upload/${size.size}/${split[1]}";
  }
}
