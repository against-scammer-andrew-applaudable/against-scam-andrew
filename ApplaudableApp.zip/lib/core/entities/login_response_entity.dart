class LoginResponseEntity {
  LoginResponseEntity({this.token, this.user});

  final String? token;

  //TODO: Change it for a UserEntity class when it's ready to be used
  final String? user;
}
