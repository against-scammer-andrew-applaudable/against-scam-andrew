import 'base_image.dart';

abstract class BaseUser implements BaseImage {
  final String id;

  final String username;

  final String name;

  final String? avatar;

  BaseUser({
    required this.id,
    required this.username,
    required this.name,
    this.avatar = "",
  });

  String get formattedName => name;
}
