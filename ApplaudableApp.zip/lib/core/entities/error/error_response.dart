import 'package:equatable/equatable.dart';

class ErrorResponse extends Equatable {
  final String? message;
  final String? code;

  final Object? fields;
  final List<String?>? missingFields;

  const ErrorResponse({
    this.message,
    this.code,
    this.fields,
    this.missingFields,
  });

  @override
  List<Object?> get props => [message, code];
}

class SignInInCompleteErrorResponse extends ErrorResponse {
  const SignInInCompleteErrorResponse(
      {String? code, Object? fields, List<String?>? missingFields})
      : super(code: code, fields: fields, missingFields: missingFields);
}
