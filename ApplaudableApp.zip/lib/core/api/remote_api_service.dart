import 'dart:io';

import 'package:applaudable/core/mappers/errors_mapper.dart';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:logger/logger.dart';
import 'package:path/path.dart';

import '../../app_module.dart';

import '../../features/auth/data/models/activate_account_error_response_model.dart';
import '../../features/auth/data/models/default_error_response_model.dart';
import '../../features/auth/data/models/signup_error_response_model.dart';
import '../../generated/l10n.dart';
import '../errors/exeptions.dart';
import 'api_env.dart';
import 'api_service.dart';

class RemoteApiService implements ApiService {
  static const String _tag = '.APIService';
  static RemoteApiService _apiService = RemoteApiService._();
  static late Dio _client;
  static late Dio _clientToken;
  static bool _initialized = false;

  static RemoteApiService get api => _apiService;
  static ApiEnv? _configApi;

  /// Handle Locale
  String? _locale = "en";

  get locale => _locale;

  set locale(locale) {
    _locale = locale;
  }

  /// Handle Authorization headers
  ///
  /// Set token session
  /// 'Authorization': 'Bearer $token'
  final Map<String, String> _sessionHeaders = {};

  @override
  set token(token) {
    _sessionHeaders.update(
        HttpHeaders.authorizationHeader, (value) => "Bearer $token",
        ifAbsent: () => "Bearer $token");
  }

  @override
  set date(DateTime date) {
    final parts = date.timeZoneOffset.toString().split(':');
    parts[0] = parts[0].replaceAll(RegExp(r'[+-]'), '').padLeft(2, '0');

    final formattedDate =
        '${date.toIso8601String()}Z${date.timeZoneOffset.isNegative ? '-' : '+'}${parts.join(':')}';

    _sessionHeaders.update(
      HttpHeaders.dateHeader,
      (value) => formattedDate,
      ifAbsent: () => formattedDate,
    );
  }

  RemoteApiService._();

  Logger get logger => AppModule.instance.logger;

  @visibleForTesting
  set setMockInstance(RemoteApiService instance) => _apiService = instance;

  @override
  void setApi({ApiEnv? api}) {
    _configApi = api ?? DevApi();
  }

  void init([Dio? client, ApiEnv? api]) async {
    if (!_initialized) {
      _configApi = _configApi ?? api;
      _client = client ?? Dio();
      _client.options.baseUrl = _configApi!();
      _client.options.connectTimeout = const Duration(seconds: 30);
      logger.i("$_tag Connnecting to: ${_client.options.baseUrl}");

      /// TODO: setup interceptor for token refresh

      //Create a new instance to request the token.
      _clientToken = Dio();
      _clientToken.options.baseUrl = _configApi!();
      _clientToken.options = _client.options;
      _clientToken.options.connectTimeout = const Duration(seconds: 30);
      _client.interceptors.clear();

      _initialized = true;
    }
  }

  @override
  Future<dynamic> get({
    String? url,
    Map<String, Object>? query,
    Map<String, String>? headers,
    CancelToken? cancelToken,
  }) async {
    if (!_initialized) {
      init();
    }
    try {
      final Map<String, Object> builtHeaders = _headerBuilder(headers);
      _client.options.headers.addAll(builtHeaders);

      logger.i(
          '[$_tag] Requesting: $url | QueryParams: $query | Headers: ${_client.options.headers} | Method: GET}');
      logger.i("$_tag Connnecting to: ${_client.options.baseUrl}");

      final response = await _client.get(
        _queryBuilder(url, query),
        cancelToken: cancelToken,
      );
      logger.i(
          '[$_tag] Response:  ${response.data} | Method: ${response.statusCode}');
      return _returnResponse(response);
    } on DioException catch (e) {
      logger.e("ERROR<Requesting: $url | QueryParams: $query>: $e");
      return _returnResponse(e.response, exception: e);
    }
  }

  @override
  Future<dynamic> post({
    String? url,
    Map<String, Object?>? body,
    Map<String, Object>? query,
    Map<String, String>? headers,
    CancelToken? cancelToken,
  }) async {
    if (!_initialized) {
      init();
    }
    try {
      var builtHeaders = _headerBuilder(headers);

      _client.options.headers.addAll(builtHeaders);

      logger.i(
          '[$_tag] Requesting: $url | QueryParams: $query | Body: $body | Headers: ${_client.options.headers} | Method: POST}');
      logger.i("$_tag Connnecting to: ${_client.options.baseUrl}");

      final response = await _client.post(
        _queryBuilder(url, query),
        data: body,
        cancelToken: cancelToken,
      );
      logger.i(
          '[$_tag] Response:  ${response.data} | Method: ${response.statusCode}');
      return _returnResponse(response);
    } on DioException catch (e) {
      logger.e("ERROR: ${e.response}");
      return _returnResponse(e.response, exception: e);
    }
  }

  @override
  Future<dynamic> postRaw({
    String? url,
    Object? body,
    Map<String, Object>? query,
    Map<String, String>? headers,
    CancelToken? cancelToken,
  }) async {
    if (!_initialized) {
      init();
    }
    try {
      var builtHeaders = _headerBuilder(headers);

      _client.options.headers.addAll(builtHeaders);

      logger.i(
          '[$_tag] Requesting: $url | QueryParams: $query | Body: $body | Headers: ${_client.options.headers} | Method: POST}');
      logger.i("$_tag Connnecting to: ${_client.options.baseUrl}");

      final response = await _client.post(
        _queryBuilder(url, query),
        data: body,
        cancelToken: cancelToken,
      );
      logger.i(
          '[$_tag] Response:  ${response.data} | Method: ${response.statusCode}');
      return _returnResponse(response);
    } on DioException catch (e) {
      logger.e("ERROR: ${e.response}");
      return _returnResponse(e.response, exception: e);
    }
  }

  @override
  Future<dynamic> put({
    String? url,
    Map<String, Object?>? body,
    Map<String, Object>? query,
    Map<String, String>? headers,
    CancelToken? cancelToken,
  }) async {
    if (!_initialized) {
      init();
    }
    try {
      var builtHeaders = _headerBuilder(headers);
      _client.options.headers.addAll(builtHeaders);

      logger.i(
          '[$_tag] Requesting: $url | QueryParams: $query | Body: $body | Headers: ${_client.options.headers} | Method: PUT}');
      logger.i("$_tag Connnecting to: ${_client.options.baseUrl}");

      final response = await _client.put(
        _queryBuilder(url, query),
        data: body,
        cancelToken: cancelToken,
      );
      logger.i(
          '[$_tag] Response:  ${response.data} | Method: ${response.statusCode}');
      return _returnResponse(response);
    } on DioException catch (e) {
      logger.e("ERROR: ${e.message}");
      return _returnResponse(e.response, exception: e);
    }
  }

  @override
  Future<dynamic> patch({
    String? url,
    Map<String, Object?>? body,
    Map<String, Object>? query,
    Map<String, Object>? headers,
    CancelToken? cancelToken,
  }) async {
    if (!_initialized) {
      init();
    }
    try {
      var builtHeaders = _headerBuilder(headers);
      _client.options.headers.addAll(builtHeaders);

      logger.i(
          '[$_tag] Requesting: $url | QueryParams: $query | Body: $body | Headers: ${_client.options.headers} | Method: PATCH}');
      logger.i("$_tag Connnecting to: ${_client.options.baseUrl}");

      final response = await _client.patch(
        _queryBuilder(url, query),
        data: body,
        cancelToken: cancelToken,
      );
      logger.i(
          '[$_tag] Response:  ${response.data} | Method: ${response.statusCode}');
      return _returnResponse(response);
    } on DioException catch (e) {
      logger.e("DioError ERROR: ${e.message}");
      logger.e("DioError ERROR: ${e.response!.statusCode}");
      logger.e("DioError ERROR: ${e.response!.data}");
      return _returnResponse(e.response, exception: e);
    }
  }

  @override
  Future<dynamic> delete({
    String? url,
    Map<String, Object>? query,
    Map<String, String>? headers,
    Map<String, Object?>? body,
    CancelToken? cancelToken,
  }) async {
    if (!_initialized) {
      init();
    }
    try {
      var builtHeaders = _headerBuilder(headers);
      _client.options.headers.addAll(builtHeaders);

      logger.i(
          '[$_tag] Requesting: $url | QueryParams: $query | Body: $body | Headers: ${_client.options.headers} | Method: DELETE}');
      logger.i("$_tag Connnecting to: ${_client.options.baseUrl}");

      final response = await _client.delete(
        _queryBuilder(url, query),
        data: body != null ? FormData.fromMap(body) : null,
        cancelToken: cancelToken,
      );
      logger.i(
          '[$_tag] Response:  ${response.data} | Method: ${response.statusCode}');
      return _returnResponse(response);
    } on DioException catch (e) {
      logger.e("DioError ERROR: ${e.message}");
      logger.e("DioError ERROR: ${e.response!.statusCode}");
      logger.e("DioError ERROR: ${e.response!.data}");
      return _returnResponse(e.response, exception: e);
    }
  }

  @override
  Future<dynamic> download({
    required String url,
    required String filePath,
    CancelToken? cancelToken,
  }) async {
    if (!_initialized) {
      init();
    }
    try {
      logger.i(
          '[$_tag] Requesting: $url | Headers: ${_client.options.headers} | Method: DOWNLOAD}');
      logger.i("$_tag Connnecting to: ${_client.options.baseUrl}");

      final response = await _client.download(
        _queryBuilder(url, null),
        filePath,
        cancelToken: cancelToken,
      );
      logger.i('[$_tag] Response:  ${response.data} | Method: ${response.statusCode}');
      return _returnResponse(response);
    } on DioException catch (e) {
      logger.e("DioError ERROR: ${e.message}");
      logger.e("DioError ERROR: ${e.response!.statusCode}");
      logger.e("DioError ERROR: ${e.response!.data}");
      return _returnResponse(e.response, exception: e);
    }
  }

  @override
  Future<dynamic> multiPartRequest({
    String? url,
    Map<String, Object?>? body,
    Map<String, Object>? query,
    Map<String, String>? headers,
    List<MapEntry<String, File>> filesToUpload = const [],
    void Function(int, int)? onSendProgress,
    void Function(int, int)? onReceiveProgress,
    CancelToken? cancelToken,
  }) async {
    if (!_initialized) {
      init();
    }

    try {
      var builtHeaders = _headerBuilder(headers);
      _client.options.headers.addAll(builtHeaders);

      logger.i(
          '[$_tag] Requesting: $url | QueryParams: $query | Body: $body | Headers: ${_client.options.headers} | Method: POST}');
      logger.i("$_tag Connnecting to: ${_client.options.baseUrl}");

      final formBody = FormData();

      body?.forEach((key, value) {
        formBody.fields.add(MapEntry(key, value.toString()));
      });

      for (var entry in filesToUpload) {
        final multiPartFile = await MultipartFile.fromFile(
          entry.value.path,
          filename: basename(entry.value.path),
        );

        formBody.files.add(MapEntry(entry.key, multiPartFile));
      }

      final response = await _client.post(
        _queryBuilder(url, query),
        data: formBody,
        onSendProgress: onSendProgress,
        onReceiveProgress: onReceiveProgress,
        cancelToken: cancelToken
      );

      logger.i(
          '[$_tag] Response:  ${response.data} | Method: ${response.statusCode}');

      return _returnResponse(response);
    } on DioException catch (e) {
      logger.e("ERROR: ${e.response}");
      return _returnResponse(e.response, exception: e);
    }
  }

  @override
  Future uploadMediaRequest({
    String? url,
    String? file,
    Uint8List? bytes,
    Map<String, Object?>? body,
    Map<String, Object>? query,
    Map<String, String>? headers,
    void Function(int, int)? onSendProgress,
    void Function(int, int)? onReceiveProgress,
    String mediaKey = 'source',
    bool isPost = true,
    CancelToken? cancelToken,
  }) async {
    if (!_initialized) {
      init();
    }

    try {
      var builtHeaders = _headerBuilder(headers);
      _client.options.headers.addAll(builtHeaders);

      logger.i('[$_tag] Requesting: $url | QueryParams: $query | Body: $body | Headers: ${_client.options.headers} | Method: POST}');
      debugPrint('[$_tag] Requesting: $url | QueryParams: $query | Body: $body | Headers: ${_client.options.headers} | Method: POST}');
      logger.i("$_tag Connnecting to: ${_client.options.baseUrl}");
      debugPrint("$_tag Connnecting to: ${_client.options.baseUrl}");

      final formBody = FormData();

      body?.forEach((key, value) {
        formBody.fields.add(MapEntry(key, value.toString()));
      });

      if (file != null) {
        final multiPartFile = await MultipartFile.fromFile(
          file,
          filename: basename(file),
        );
        formBody.files.add(MapEntry(mediaKey, multiPartFile));
      } else if (bytes != null) {
        final multiPartFile = MultipartFile.fromBytes(
          bytes,
          filename: basename(DateTime.now().microsecondsSinceEpoch.toString()),
        );
        formBody.files.add(MapEntry(mediaKey, multiPartFile));
      }

      dynamic response;
      if (isPost) {
        response = await _client.post(
            _queryBuilder(url, query),
            data: formBody,
            onSendProgress: onSendProgress,
            onReceiveProgress: onReceiveProgress,
            cancelToken: cancelToken
        );
      } else {
        response = await _client.patch(
            _queryBuilder(url, query),
            data: formBody,
            onSendProgress: onSendProgress,
            onReceiveProgress: onReceiveProgress,
            cancelToken: cancelToken
        );
      }

      logger.i(
          '[$_tag] Response:  ${response.data} | Method: ${response.statusCode}');

      return _returnResponse(response);
    } on DioException catch (e) {
      logger.e("ERROR: ${e.response}");
      return _returnResponse(e.response, exception: e);
    }
  }

  Map<String, Object> _headerBuilder(Map<String, Object>? extraHeaders) {
    final headers = <String, Object>{};

    /// Updates and adds the current session token and build the headers
    if (_sessionHeaders.isNotEmpty) {
      headers.addAll(_sessionHeaders);
    }

    headers[HttpHeaders.acceptHeader] = 'application/json';
    headers[HttpHeaders.contentTypeHeader] = 'application/json';

    if (extraHeaders != null && extraHeaders.isNotEmpty) {
      extraHeaders.forEach((key, value) {
        headers[key] = value;
      });
    }
    return headers;
  }

  String _queryBuilder(String? path, Map<String, Object>? query) {
    final buffer = StringBuffer();
    bool removeLastChar = false;
    buffer.write(path);
    if (query != null) {
      if (query.isNotEmpty) {
        buffer.write('?');
      }
      query.forEach((key, value) {
        buffer.write('$key=$value&');
        removeLastChar = true;
      });

      if (removeLastChar) {
        /// REMOVE LAST &
        String result = buffer.toString();
        //return result.substring(0, result.length - 1);
        return result;
      }
    }

    return buffer.toString();
  }

  Object _returnResponse(Response? response, {DioException? exception}) {
    if (response == null) {
      throw ServerException(message: exception?.message ?? S.current.unable_to_get_response_msg, statusCode: response?.statusCode);
    }

    final responseJson = response.data;

    if (response.statusCode! >= 200 && response.statusCode! <= 299) {
      return responseJson;
    }

    final errorFromResponse = responseJson is String
        ? responseJson
        : _extractErrorFromResponse(responseJson, response.statusCode);

    switch (response.statusCode) {
      case 400:
        throw ServerException(message: errorFromResponse, statusCode: response.statusCode);
      case 401:
      case 403:
        throw UnauthorizedUserException(message: errorFromResponse);
      case 422:
        throw SignInIncompleteException(response.data);
      case 426:
        throw ForceUpdateException(message: errorFromResponse);
      case 503:
        throw MaintenanceModeException(message: errorFromResponse);
      case 500:
      default:
        throw ServerException(message: exception?.message ?? S.current.unable_to_get_response_msg, statusCode: response.statusCode);
    }
  }

  String _extractErrorFromResponse(
    Map<String, dynamic> parsedJson,
    int? statusCode,
  ) {
    if (parsedJson.containsKey('details') && parsedJson['details'] != null) {
      return parsedJson['details'].toString();
    }

    if (parsedJson.containsKey('credentials') &&
        parsedJson['credentials'] != null) {
      return parsedJson['credentials'].toString();
    }

    final validatedErrorMSg =
        _checkAccountActivationErrorResponse(parsedJson) ??
            _checkSignUpErrorResponse(parsedJson) ??
            _checkDefaultErrorResponse(parsedJson);

    if (validatedErrorMSg != null) return validatedErrorMSg;

    if (parsedJson.containsKey('error') && parsedJson['error'] != null) {
      return parsedJson['error'].toString();
    }

    String errorMsg = '';

    parsedJson.forEach((key, value) {
      if (value is List ||
          value.runtimeType.toString() == '_GrowableList<dynamic>') {
        if (value.isNotEmpty) errorMsg += '$key: ';

        for (final msg in value) {
          errorMsg += msg + '\n';
        }
      }
    });

    if (errorMsg.trim().isNotEmpty) return errorMsg.trim();

    var elementsKey = parsedJson['elements'];
    if (elementsKey != null && elementsKey is Map && elementsKey.isNotEmpty) {
      elementsKey.forEach((key, value) {
        errorMsg += '$key: $value\n';
      });
    }

    if (errorMsg.trim().isNotEmpty) return errorMsg.trim();

    for (final value in parsedJson.values) {
      if (value is String) {
        errorMsg = value;
        break;
      }
    }

    if (errorMsg.trim().isNotEmpty) return errorMsg.trim();

    String? errorCode;

    if (parsedJson.containsKey('error_code') &&
        parsedJson['error_code'] != null) {
      errorCode = parsedJson['error_code'].toString();
    }

    if (parsedJson.containsKey('code') && parsedJson['code'] != null) {
      errorCode ??= parsedJson['code'].toString();
    }

    return 'Server Error with StatusCode : ${errorCode ?? statusCode}';
  }

  String? _checkSignUpErrorResponse(Map<String, dynamic> parsedJson) {
    try {
      final errorMsg =
          SignUpErrorResponseModel.fromJson(parsedJson).toEntity().message;

      return errorMsg;
    } catch (_) {}
    return null;
  }

  String? _checkAccountActivationErrorResponse(
    Map<String, dynamic> parsedJson,
  ) {
    try {
      final errorMsg = ActivateAccountErrorResponseModel.fromJson(parsedJson)
          .toEntity()
          .message;

      return errorMsg;
    } catch (_) {}
    return null;
  }

  String? _checkDefaultErrorResponse(Map<String, dynamic> parsedJson) {
    try {
      final errorMsg =
          DefaultErrorResponseModel.fromJson(parsedJson).toEntity().message;

      return errorMsg;
    } catch (_) {}
    return null;
  }

  void clearSession() {
    _sessionHeaders.clear();
    if (_initialized) {
      _client.options.headers.remove(HttpHeaders.authorizationHeader);
    }
  }
}
