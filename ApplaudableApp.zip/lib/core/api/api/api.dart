import 'package:applaudable/core/api/remote_api_service.dart';

export 'package:applaudable/core/api/api/sub/auth.dart';
export 'package:applaudable/core/api/api/sub/onboard.dart';
export 'package:applaudable/core/api/api/sub/user.dart';
export 'package:applaudable/core/api/api/sub/post.dart';
export 'package:applaudable/core/api/api/sub/feed.dart';
export 'package:applaudable/core/api/api/sub/user_feed.dart';
export 'package:applaudable/core/api/api/sub/notification.dart';
export 'package:applaudable/core/api/api/sub/prompt.dart';
export 'package:applaudable/core/api/api/sub/circle.dart';
export 'package:applaudable/core/api/api/sub/glimpse.dart';
export 'package:applaudable/core/api/api/sub/highlight.dart';

class APIs {
  static final APIs _singleton = APIs._internal();
  factory APIs() {
    return _singleton;
  }

  APIs._internal() {
  }

  final httpConnector = RemoteApiService.api;

}