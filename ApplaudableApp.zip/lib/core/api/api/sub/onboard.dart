import 'package:applaudable/core/api/api/api.dart';
import 'package:flutter/cupertino.dart';

import '../../../../features/onboarding/data/models/interests_response_model.dart';
import '../../../../model/user/contact.dart';
import '../../api_config.dart';

extension OnboardAPIs on APIs {
  Future getAllAvailableInterests({
    int pageNo = 1,
    int pageSize = 30,
    String query = "",
  }) async {
    try  {
      final parsedJson = await httpConnector.get(
        url: ApiResource.availableInterests(pageNo: pageNo, pageSize: pageSize, query: query),
      );

      return InterestsResponseModel.fromJson(parsedJson);
    } catch(e) {
      debugPrint("======= getAllAvailableInterests ex : $e");
      return e;
    }
  }
  Future addInterest({required List<int> ids}) async {
    try  {
      final parsedJson = await httpConnector.patch(url: ApiResource.addUserInterests, body: {'interests': ids});

      return InterestsResponseModel.fromJson(parsedJson);
    } catch(e) {
      debugPrint("======= addInterest ex : $e");
      return e;
    }
  }
  Future uploadContacts({required List<UserContactModel> contacts}) async {
    try  {
      debugPrint("======= uploadContacts contacts : ${contacts.map((e) => e.toJSONForUpload).toList()}");
      final parsedJson = await httpConnector.post(url: ApiResource.uploadContacts, body: {'addresses': contacts.map((e) => e.toJSONForUpload).toList()});
      return UserContactsResponse.fromJson(parsedJson is List ? {'results': parsedJson} : parsedJson).results;
    } catch(e) {
      debugPrint("======= uploadContacts ex : $e");
      return e;
    }
  }
  Future preFollow({required List<UserContactModel> contacts}) async {
    try  {
      final parsedJson = await httpConnector.post(url: ApiResource.preFollow, body: {'invites': contacts.where((element) => element.inviteId != null).map((e) => e.inviteId ?? "").toList()});
      return parsedJson["success"] ?? false;
    } catch(e) {
      debugPrint("======= preFollow ex : $e");
      return e;
    }
  }

}