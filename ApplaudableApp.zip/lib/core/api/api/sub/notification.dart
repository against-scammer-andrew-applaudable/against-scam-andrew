import 'package:flutter/cupertino.dart';

import '../../../../features/notifications/data/models/in_app_notification_model.dart';
import '../../../entities/pagination_params.dart';
import '../../api_config.dart';
import '../api.dart';

extension NotificationAPI on APIs {
  Future getMyNotifications({
    int pageNo = 1,
    int pageSize = 20,
  }) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.inAppNotificationsEndpoint(PaginationParams(pageNo: pageNo, pageSize: pageSize)),
      );
      return InAppNotificationsResponse.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= getMyNotifications ex : $e");
      return e;
    }
  }
  Future viewedNotification({required String id,}) async {
    try {
      final parsedJson = await httpConnector.patch(
        url: ApiResource.markNotificationAsViewedEndpoint(id),
      );
      return InAppNotificationModel.fromJson(parsedJson);
    } catch (e) {
      debugPrint("======= viewedNotification ex : $e");
      return e;
    }
  }
  Future deleteNotification({required String id,}) async {
    try {
      final parsedJson = await httpConnector.delete(
        url: ApiResource.deleteNotification(id),
      );
      return parsedJson["success"];
    } catch (e) {
      debugPrint("======= deleteNotification ex : $e");
      return e;
    }
  }

}