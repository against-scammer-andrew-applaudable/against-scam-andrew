import 'package:applaudable/features/feed/domain/enums/posts_enum.dart';
import 'package:applaudable/features/feed/domain/enums/highlights_enum.dart';
import 'package:flutter/cupertino.dart';

import '../../../../app_module.dart';
import '../../../../model/post/feed.dart';
import '../../../../model/post/highlight/highlight.dart';
import '../../api_config.dart';
import '../api.dart';

extension UserFeedAPI on APIs {
  Future userPosts({
    String? owner,
    int pageNo = 1,
    int pageSize = 20,
    bool glimpse = false,
  }) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.userFeedPosts(
          pageNo: pageNo,
          pageSize: pageSize,
          owner: AppModule.I.controller.currentUser?.id == owner ? null : owner,
          glimpse: glimpse,
        ),
      );

      return FeedPostsResponseModel.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= userPosts ex : $e");
      return e;
    }
  }

  Future userTagPosts({
    String? owner,
    int pageNo = 1,
    int pageSize = 20,
    bool glimpse = false,
  }) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.userTagFeedPosts(
          pageNo: pageNo,
          pageSize: pageSize,
          owner: AppModule.I.controller.currentUser?.id == owner ? null : owner,
          glimpse: glimpse,
        ),
      );
      return FeedPostsResponseModel.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= userTagPosts ex : $e");
      return e;
    }
  }

  Future userPrivatePosts({
    int pageNo = 1,
    int pageSize = 20,
    bool glimpse = false,
  }) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.userPrivateFeedPosts(
          pageNo: pageNo,
          pageSize: pageSize,
          glimpse: glimpse,
        ),
      );
      return FeedPostsResponseModel.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= userPrivatePosts ex : $e");
      return e;
    }
  }

  Future userBookmarkedPosts({
    int pageNo = 1,
    int pageSize = 20,
  }) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.getPosts(
          pageNo: pageNo,
          pageSize: pageSize,
          type: PostsFilterByType.bookmark,
          // owner: AppModule.I.controller.currentUser?.id,
        ),
      );
      return FeedPostsResponseModel.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= userBookmarkedPosts ex : $e");
      return e;
    }
  }
  Future userBookmarkedHighlights({
    int pageNo = 1,
    int pageSize = 20,
  }) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.getHighlights(
          pageNo: pageNo,
          pageSize: pageSize,
          // type: HighlightsFilterByType.bookmark,
          // owner: AppModule.I.controller.currentUser?.id,
        ),
      );
      return FeedHighlightsResponseModel.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= userBookmarkedHighlights ex : $e");
      return e;
    }
  }

}
