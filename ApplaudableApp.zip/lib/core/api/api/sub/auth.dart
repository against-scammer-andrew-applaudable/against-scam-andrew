import 'package:applaudable/core/api/api/api.dart';
import 'package:applaudable/core/mappers/auth_mappers.dart';
import 'package:applaudable/features/auth/data/datasources/local_source.dart';
import 'package:applaudable/model/other/app_version.dart';
import 'package:flutter/widgets.dart';

import '../../../../app_module.dart';
import '../../../../features/auth/data/models/requests/login_request_model.dart';
import '../../../../features/auth/data/models/session_response_model.dart';
import '../../../../features/auth/domain/entities/session.dart';
import '../../../serializers/date_serializer.dart';
import '../../api_config.dart';

class RegisterRequestModel {
  late String inviteCode;
  late String name;
  late String phoneNumber;
  late String username;
  String? email;
  late String password;
  DateTime? birthDate;
  String? bio;
  String? location;
  String? instagramHandler;

  String _tempEmail = "";
  RegisterRequestModel({required this.inviteCode, required this.name, required this.phoneNumber, required this.username}) {
    _tempEmail = "${phoneNumber.replaceAll("+", "")}@email.com";
    password = _tempEmail;
  }

  Map<String, dynamic> toJson() => {
    "invite_code": inviteCode,
    "name": name,
    "phone_number": phoneNumber,
    "username": username,
    "email": email ?? _tempEmail,
    "password": password,
    "birth_date": const MandatoryDateSerializer().toJson(birthDate ?? DateTime(1900)),
    if (bio != null) "bio" : bio,
    if (location != null) "location" : location,
    if (instagramHandler != null) "instagram_handler" : instagramHandler,
  };
}

extension AuthAPI on APIs {
  Future<bool> validateInviteCode({required String inviteCode}) async {
    try {
      final parsedJson = await  httpConnector.get(url: ApiResource.validateInviteCode(inviteCode));
      return parsedJson['success'];
    } catch (e) {
      debugPrint("======= validateInviteCode ex : $e");
      return false;
    }
  }
  Future<bool> validateSMSCode({required String phoneNumber, required String smsCode}) async {
    try {
      await httpConnector.post(
        url: ApiResource.smsValidateInSignup,
        body: {
          "phone_number": phoneNumber,
          "pin_code": smsCode,
        },
      );
      return true;
    } catch (e) {
      debugPrint("======= validateSMSCode ex : $e");
      return false;
    }
  }
  Future<bool> checkExists({String? phoneNumber, String? email, String? username}) async {
    try {
      final parsedJson = await httpConnector.post(
        url: ApiResource.checkExistsInSignup,
        body: {
          "phone_number": phoneNumber,
          "email": email,
          "username": username,
        },
      );
      return parsedJson["success"] ?? false;
    } catch (e) {
      debugPrint("======= checkExists ex : $e");
      return false;
    }
  }
  Future register({required RegisterRequestModel model}) async {
    try {
      final response = await httpConnector.post(
        url: ApiResource.signup,
        body: model.toJson(),
      );

      final sessionResponseModel = SessionResponseModel.fromJson(response);

      final session = sessionResponseModel.toEntity();
      await _handleSessionToken(session);
      return session;
    } catch (e) {
      debugPrint("======= signUp ex : $e");
      return e;
    }
  }

  Future<dynamic> signInWithEmailPassword({
    required LoginRequestModel model,
  }) async {
    try {
      final response = await httpConnector.post(
        url: ApiResource.loginUserAndPassword,
        body: model.toJson(),
      );
      final sessionResponseModel = SessionResponseModel.fromJson(response);
      final session = sessionResponseModel.toEntity();
      await _handleSessionToken(session);
      return session;
    } catch(e) {
      debugPrint("======= signInWithEmailPassword ex : $e");
      return e;
    }
  }
  Future smsRequest({required String phoneNumber}) async {
    try {
      return httpConnector.post(
        url: ApiResource.loginWithPhoneRequest,
        body: {
          "phone_number" : phoneNumber
        },
      );
    } catch (e) {
      debugPrint("======= smsRequest ex : $e");
      return e;
    }
  }
  Future<dynamic> signInConfirmCode({required String phoneNumber, required String pinCode}) async {
    try {
      final response = await httpConnector.post(
        url: ApiResource.loginWithPhoneConfirmPin,
        body: {
          'phone_number': phoneNumber,
          'pin_code': pinCode,
        },
      );
      final sessionResponseModel = SessionResponseModel.fromJson(response);
      final session = sessionResponseModel.toEntity();
      await _handleSessionToken(session);
      return session;
    } catch(e) {
      debugPrint("======= signInConfirmCode ex : $e");
      return e;
    }
  }
  Future recoverPassword({required String email}) async {
    try {
      await httpConnector.post(
        url: ApiResource.recoverPassword,
        body: {
          "email": email,
        },
      );
    } catch(e) {
      debugPrint("======= recoverPassword ex : $e");
      return e;
    }
  }
  Future checkAppVersion() async {
    try {
      final response = await httpConnector.get(
        url: ApiResource.checkAppVersion,
      );
      return AppVersionModel.dic(response);
    } catch(e) {
      debugPrint("======= checkAppVersion ex : $e");
      return e;
    }
  }
  Future changeMyPassword({required String oldPassword, required String newPassword}) async {
    try {
      await httpConnector.patch(
        url: ApiResource.changePassword,
        body: {
          "old_password": oldPassword,
          "password": newPassword,
          "confirm_password": newPassword
        },
      );
      return true;
    } catch(e) {
      debugPrint("======= changeMyPassword ex : $e");
      return e;
    }
  }

  Future deleteAccount() async {
    try {
      await httpConnector.delete(
        url: ApiResource.deleteUserAccount(userId: AppModule.I.controller.currentUser?.id ?? ""),
      );
      AppLocalDataSource.instance.clear();

      AppModule.I.controller.clear();
      return true;
    } catch(e) {
      debugPrint("======= deleteAccount ex : $e");
      return e;
    }
  }

  Future _handleSessionToken(Session session) async {
    /// Save Session into cache
    await AppLocalDataSource.instance.saveSession(session);
    /// Update API Service to use latest token
    httpConnector.token = session.token.access;
  }

  Future _handleUpdateToken(String token) async {
    /// Updates with new token
    await AppLocalDataSource.instance.updateSessionToken(token);

    /// Update API Service to use latest token
    httpConnector.token = token;
  }

  void _clearSession() {
    AppLocalDataSource.instance.clear();
    httpConnector.clearSession();
  }

}