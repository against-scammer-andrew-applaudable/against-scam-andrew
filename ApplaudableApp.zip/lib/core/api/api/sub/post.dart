import 'package:applaudable/core/api/api/api.dart';
import 'package:applaudable/core/utils/app_utils.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';

import '../../../../features/create_post/data/models/nupps_response_model.dart';
import '../../../../features/create_post/data/models/post_feed_model.dart';
import '../../../../features/feed/data/models/post_action_response_model.dart';
import '../../../../features/post_categories/data/models/post_categories_response_model.dart';
import '../../../../model/post/experience.dart';
import '../../../../model/post/feed.dart';
import '../../../../model/post/feed_sub/media.dart';
import '../../../../model/post/place.dart';
import '../../../../model/post/request.dart';
import '../../../entities/pagination_params.dart';
import '../../../enums/post.dart';
import '../../api_config.dart';

extension PostAPI on APIs {
  Future getPostFeedSegments({PaginationParams pageInfo = const PaginationParams()}) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.getPostSegments(pageInfo: pageInfo),
      );
      return PostSegmentsResponse.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= getPostFeedSegments ex : $e");
      return e;
    }
  }
  Future getAutocompletePlaces({
    String? query,
    PaginationParams pageInfo = const PaginationParams(),
    String? location,
  }) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.getAutocompletePlaces(
          query: query,
          pageInfo: pageInfo,
          location: location,
        ),
      );
      if (parsedJson is List) {
        return parsedJson.map((e) => ExperiencePlaceModel.fromJson(e)).toList();
      }
      return ExperiencePlacesResponseModel.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= getAutocompletePlaces ex : $e");
      return e;
    }
  }

  Future getElementTagDetail({required String id,}) async {
    try {
      final parsedJson = await httpConnector.get(
        url: "/experience/element/$id/",
      );
      debugPrint("======= getTagsForExperienceElement parsedJson : $parsedJson");
      return PostExperienceElementModel.fromJson(parsedJson);
    } catch (e) {
      debugPrint("======= getTagsForExperienceElement ex : $e");
      return e;
    }
    // final res = experienceElementsJSON[experienceElementId];
    // if (res is List) {
    //   var models = res.map((e) => PostExperienceElementModel.fromJson(e)).toList();
    //   if (query?.isNotEmpty ?? false) {
    //     models = models.where((element) => element.name.toLowerCase().startsWith(query!.toLowerCase().trim())).toList();
    //   }
    //   return models;
    // } else if (query?.isNotEmpty ?? false) {
    //   final random = Random();
    //   var models = List<PostExperienceElementModel>.generate(30, (index) => PostExperienceElementModel(id: random.nextInt(10000).toString(), name: "${query!.toLowerCase().trim()} temp ${random.nextInt(10000)}"));
    //   return models;
    // }
    // return null;
  }

  Future getExperienceElements() async {
    try {
      final parsedJson = await httpConnector.get(
        url: "/experience/?limit=200",
      );
      return PostExperiencesResponse.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= getExperienceElements ex : $e");
      return e;
    }
  }
  Future getTagsForExperienceElement({
    required String experienceElementId,
    String? query,
    PaginationParams pageInfo = const PaginationParams(pageSize: 50),
  }) async {
    try {
      final parsedJson = await httpConnector.get(
        url: "/experience/$experienceElementId/elements/?offset=${(pageInfo.pageNo - 1) * pageInfo.pageSize}&limit=${pageInfo.pageSize}${(query?.isNotEmpty ?? false) ? "&name=$query" : "&published=true"}",
      );
      if (parsedJson is List) {
        return parsedJson.map((e) => PostExperienceElementModel.fromJson(e, fromSearch: true)).toList();
      }
      // return PostExperienceElementsResponse.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= getTagsForExperienceElement ex : $e");
      return e;
    }
    // final res = experienceElementsJSON[experienceElementId];
    // if (res is List) {
    //   var models = res.map((e) => PostExperienceElementModel.fromJson(e)).toList();
    //   if (query?.isNotEmpty ?? false) {
    //     models = models.where((element) => element.name.toLowerCase().startsWith(query!.toLowerCase().trim())).toList();
    //   }
    //   return models;
    // } else if (query?.isNotEmpty ?? false) {
    //   final random = Random();
    //   var models = List<PostExperienceElementModel>.generate(30, (index) => PostExperienceElementModel(id: random.nextInt(10000).toString(), name: "${query!.toLowerCase().trim()} temp ${random.nextInt(10000)}"));
    //   return models;
    // }
    // return null;
  }
  Future uploadMedia({
    required FeedPostMediaModel media,
  }) async {
    if (media.localMedia?.cancelToken != null || media.id.isNotEmpty) {
      return;
    }
    if (media.localMedia?.file.value == null) {
      return;
    }
    media.localMedia?.cancelToken = CancelToken();
    try {
      final parsedJson = await httpConnector.uploadMediaRequest(
        url: ApiResource.uploadMedia,
        file: media.localMedia?.file.value!,
        body: {
          'type': media.type.name,
          if (media.localMedia?.quote != null) 'text': media.localMedia?.quote,
        },
        onSendProgress: (count, total) {
          media.localMedia?.uploadProgress.value = count.toDouble() / total.toDouble();
        },
        cancelToken: media.localMedia?.cancelToken,
      );
      media.localMedia?.uploadProgress.value = 1;
      media.localMedia?.cancelToken = null;
      final postMedia = PostMediaModel.fromJson(parsedJson);
      media.id = postMedia.id;
      return postMedia;
    } catch (e) {
      media.localMedia?.uploadProgress.value = 0;
      media.localMedia?.cancelToken = null;
      media.localMedia?.failedUpload = true;
      debugPrint("======= uploadMedia ex : $e");
      return e;
    }
  }
  Future uploadQuoteMedia({
    required FeedPostMediaModel media,
  }) async {
    if (media.localMedia?.cancelToken != null || media.id.isNotEmpty || media.localMedia?.quote == null) {
      return;
    }
    media.localMedia?.cancelToken = CancelToken();
    try {
      final parsedJson = await httpConnector.uploadMediaRequest(
        url: ApiResource.uploadMedia,
        body: {
          'type': media.type.name,
          'text': media.localMedia?.quote,
        },
        onSendProgress: (count, total) {
          media.localMedia?.uploadProgress.value = count.toDouble() / total.toDouble();
        },
        cancelToken: media.localMedia?.cancelToken,
      );
      media.localMedia?.uploadProgress.value = 1;
      media.localMedia?.cancelToken = null;
      final postMedia = PostMediaModel.fromJson(parsedJson);
      media.id = postMedia.id;
      return postMedia;
    } catch (e) {
      media.localMedia?.uploadProgress.value = 0;
      media.localMedia?.cancelToken = null;
      debugPrint("======= uploadQuoteMedia ex : $e");
      return e;
    }
  }
  Future deleteMedia({
    required FeedPostMediaModel media,
  }) async {
    final mediaId = media.id;
    if (mediaId.isEmpty) {
      return;
    }
    try {
      media.id = "";
      final parsedJson = await httpConnector.delete(
        url: ApiResource.uploadMedia,
        body: {
          "media_ids": [mediaId],
        }
      );
      return parsedJson["success"] ?? false;
    } catch (e) {
      media.localMedia?.uploadProgress.value = 0;
      media.localMedia?.cancelToken = null;
      debugPrint("======= deleteMedia ex : $e");
      return e;
    }
  }

  Future createPost({
    required CreatePostRequestModel postRequest,
  }) async {
    try {
      final parsedJson = await httpConnector.post(
        url: ApiResource.createPostFeed,
        body: postRequest.toJSONForCreate,
      );
      return FeedPostModel.dic(parsedJson);
    } catch (e) {
      debugPrint("======= createPost ex : $e");
      return e;
    }
  }

  Future editPost({
    required CreatePostRequestModel postRequest,
  }) async {
    try {
      final parsedJson = await httpConnector.patch(
        url: ApiResource.editPost(postId: postRequest.originalPost?.id ?? ""),
        body: postRequest.toJSONForEdit,
      );
      return FeedPostModel.dic(parsedJson);
    } catch (e) {
      debugPrint("======= editPost ex : $e");
      return e;
    }
  }
  Future deletePost({
    required String id,
  }) async {
    try {
      await httpConnector.delete(
        url: ApiResource.deletePost(id),
      );
      return true;
    } catch (e) {
      debugPrint("======= deletePost ex : $e");
      return e;
    }
  }
  Future updatePostExperienceLevel({
    required String postId,
    required PostExperienceLevel level,
    bool forceUpdate = false,
  }) async {
    try {
      await httpConnector.patch(
        url: ApiResource.updatePostLevel(postId),
        body: {
          "level": level.value,
          "force_disappear": forceUpdate,
        },
      );
      return true;
    } catch (e) {
      debugPrint("======= updatePostExperienceLevel ex : $e");
      return e;
    }
  }

}
