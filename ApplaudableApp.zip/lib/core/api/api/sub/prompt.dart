import 'package:flutter/cupertino.dart';

import '../../api_config.dart';
import '../api.dart';

extension PromptAPI on APIs {
  Future savePromptAction({required String promptId}) async {
    try {
      await httpConnector.post(
        url: ApiResource.prompt,
        body: {
          "prompt_id": promptId,
        },
      );
    } catch (e) {
      debugPrint("======= savePromptAction ex : $e");
      return e;
    }
  }
}