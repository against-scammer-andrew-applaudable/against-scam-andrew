import 'package:applaudable/core/enums/circle.dart';
import 'package:applaudable/core/errors/exeptions.dart';
import 'package:applaudable/model/circle/circle.dart';
import 'package:applaudable/model/circle/sub/media.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';

import '../../../../model/circle/sub/member.dart';
import '../../../entities/pagination_params.dart';
import '../../../../model/post/feed.dart';
import '../../api_config.dart';
import '../api.dart';

extension CircleAPI on APIs {
  Future createCircle({required CircleModel circle,}) async {
    try {
      final parsedJson = await httpConnector.post(
        url: ApiResource.createCircle,
        body: circle.toJSONCreate,
      );
      final createdCircle = CircleModel.dic(parsedJson);
      circle.id = createdCircle.id;
      return createdCircle;
    } catch (e) {
      debugPrint("======= createCircle ex : $e");
      if (e is ServerException) {
        return e.errorMessage;
      }
      return e;
    }
  }
  Future editCircle({required CircleModel circle, required bool needMediaId,}) async {
    try {
      final parsedJson = await httpConnector.patch(
        url: ApiResource.editCircle(circle.id),
        body: circle.toJSONEdit(needMediaId),
      );
      final createdCircle = CircleModel.dic(parsedJson);
      return createdCircle;
    } catch (e) {
      debugPrint("======= editCircle ex : $e");
      if (e is ServerException) {
        return e.errorMessage;
      }
      return e;
    }
  }
  Future myCircles({int pageNo = 1, int pageSize = 20,}) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.myCircles(
          pageNo: pageNo,
          pageSize: pageSize,
        ),
      );

      return FeedCirclesResponseModel.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= myCircles ex : $e");
      return e;
    }
  }
  Future circleMembers(String circleId, {int pageNo = 1, int pageSize = 10,}) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.circleMembers(
          circleId,
          pageNo: pageNo,
          pageSize: pageSize,
        ),
      );

      return FeedCircleMembersResponseModel.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= circleMembers ex : $e");
      return e;
    }
  }
  Future circleMemberRequests(String circleId, {int pageNo = 1, int pageSize = 10,}) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.circleMemberRequests(
          circleId,
          pageNo: pageNo,
          pageSize: pageSize,
        ),
      );

      return FeedCircleMemberRequestsResponseModel.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= circleMemberRequests ex : $e");
      return e;
    }
  }
  Future subCircles(String circleId, {int pageNo = 1, int pageSize = 10,}) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.subCircles(
          circleId,
          pageNo: pageNo,
          pageSize: pageSize,
        ),
      );

      return FeedCirclesResponseModel.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= subCircles ex : $e");
      return e;
    }
  }

  Future uploadCircleMedia({required CircleMediaModel media,}) async {
    if (media.cancelToken != null || media.id.isNotEmpty) {
      return;
    }
    if (media.filePath == null) {
      return;
    }
    media.cancelToken = CancelToken();
    try {
      final parsedJson = await httpConnector.uploadMediaRequest(
        url: ApiResource.uploadCircleMedia,
        file: media.filePath!,
        mediaKey: "media",
        onSendProgress: (count, total) {
          media.uploadProgress.value = count.toDouble() / total.toDouble();
        },
        cancelToken: media.cancelToken,
      );
      media.uploadProgress.value = 1;
      media.cancelToken = null;
      final circleMedia = CircleMediaModel.dic(parsedJson);
      media.update(circleMedia);
      return circleMedia;
    } catch (e) {
      media.uploadProgress.value = 0;
      media.cancelToken = null;
      media.failedUpload = true;
      debugPrint("======= uploadCircleMedia ex : $e");
      if (e is ServerException) {
        return e.errorMessage;
      }
      return e;
    }
  }
  Future updateCircleMedia({required CircleModel circle, required CircleMediaModel media,}) async {
    if (media.cancelToken != null) {
      return;
    }
    if (media.filePath == null) {
      return;
    }
    media.cancelToken = CancelToken();
    try {
      final parsedJson = await httpConnector.uploadMediaRequest(
        url: ApiResource.updateCircleMedia(media.id),
        file: media.filePath!,
        mediaKey: "media",
        isPost: false,
        onSendProgress: (count, total) {
          media.uploadProgress.value = count.toDouble() / total.toDouble();
        },
        cancelToken: media.cancelToken,
      );
      media.uploadProgress.value = 1;
      media.cancelToken = null;
      final circleMedia = CircleMediaModel.dic(parsedJson);
      media.update(circleMedia);
      circle.media = circleMedia;
      return circleMedia;
    } catch (e) {
      media.uploadProgress.value = 0;
      media.cancelToken = null;
      media.failedUpload = true;
      debugPrint("======= updateCircleMedia ex : $e");
      if (e is ServerException) {
        return e.errorMessage;
      }
      return e;
    }
  }
  Future deleteCircleMedia({required CircleMediaModel media,}) async {
    final mediaId = media.id;
    if (mediaId.isEmpty) {
      return;
    }
    try {
      media.id = "";
      final parsedJson = await httpConnector.delete(
        url: ApiResource.deleteCircleMedia(mediaId),
      );
      return parsedJson["success"] ?? false;
    } catch (e) {
      media.uploadProgress.value = 0;
      media.cancelToken = null;
      debugPrint("======= deleteCircleMedia ex : $e");
      if (e is ServerException) {
        return e.errorMessage;
      }
      return e;
    }
  }
  Future getSimpleCircles({
    int pageNo = 1,
    int pageSize = 20,
  }) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.getSimpleCircles(pageInfo: PaginationParams(pageNo: pageNo, pageSize: pageSize)),
      );
      return FeedCirclesResponseModel.fromJson(parsedJson is List ? {'results': parsedJson} : parsedJson).results;
    } catch (e) {
      debugPrint("======= getSimpleCircles ex : $e");
    }
  }
  Future getCircleDetail({required String circleId,}) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.getCircleDetail(circleId),
      );
      return CircleModel.dic(parsedJson);
    } catch (e) {
      debugPrint("======= getCircleDetail ex : $e");
      return e;
    }
  }
  Future acceptCircleInvitation({required CircleModel circle, bool force = false, bool forNotification = false,}) async {
    if (circle.membership != CircleMembership.invited && !force) return;
    try {
      final parsedJson = await httpConnector.patch(
        url: ApiResource.acceptCircleInvitation(circle.id),
        body: {
          "accepted": true,
        },
      );
      if (parsedJson["success"] == true) {
        final newCircle = await getCircleDetail(circleId: circle.id);
        if (newCircle is CircleModel) {
          circle.membership = newCircle.membership;
        }
        return true;
      }
    } catch (e) {
      debugPrint("======= acceptCircleInvitation ex : $e");
      if (e is ServerException) {
        if (forNotification && e.statusCode == 400) {
          return true;
        }
        return e.errorMessage;
      }
      return e;
    }
  }
  Future rejectCircleInvitation({required CircleModel circle, bool force = false, bool forNotification = false,}) async {
    if (circle.membership != CircleMembership.invited && !force) return;
    try {
      final parsedJson = await httpConnector.patch(
        url: ApiResource.acceptCircleInvitation(circle.id),
        body: {
          "accepted": false,
        },
      );
      if (parsedJson["success"] == true) {
        circle.membership = CircleMembership.notYet;
        return true;
      }
    } catch (e) {
      debugPrint("======= rejectCircleInvitation ex : $e");
      if (e is ServerException) {
        if (forNotification && e.statusCode == 400) {
          return true;
        }
        return e.errorMessage;
      }
      return e;
    }
  }
  Future requestJoinToCircle({required CircleModel circle,}) async {
    if (circle.membership != CircleMembership.notYet) return;
    try {
      final parsedJson = await httpConnector.patch(
        url: ApiResource.requestJoinToCircle(circle.id),
      );
      if (parsedJson["success"] == true) {
        circle.membership = CircleMembership.requested;
        return true;
      }
    } catch (e) {
      debugPrint("======= requestJoinToCircle ex : $e");
      if (e is ServerException) {
        return e.errorMessage;
      }
      return e;
    }
  }
  Future approveJoinToCircle({required CircleModel circle, required String userId, bool forNotification = false}) async {
    if (circle.membership != CircleMembership.admin) return;
    try {
      final parsedJson = await httpConnector.patch(
        url: ApiResource.approveCircleJoinRequest(circle.id),
        body: {
          "user_id": userId,
          "accept": true,
        },
      );
      if (parsedJson["success"] == true) {
        circle.counters.requestedMembers --;
        circle.counters.allMembers ++;
        return true;
      }
    } catch (e) {
      debugPrint("======= approveJoinToCircle ex : $e");
      if (e is ServerException) {
        if (forNotification && e.statusCode == 400) {
          return true;
        }
        return e.errorMessage;
      }
      return e;
    }
  }
  Future rejectJoinToCircle({required CircleModel circle, required String userId, bool forNotification = false}) async {
    if (circle.membership != CircleMembership.admin) return;
    try {
      final parsedJson = await httpConnector.patch(
        url: ApiResource.approveCircleJoinRequest(circle.id),
        body: {
          "user_id": userId,
          "accept": false,
        },
      );
      if (parsedJson["success"] == true) {
        circle.counters.requestedMembers --;
        return true;
      }
    } catch (e) {
      debugPrint("======= rejectJoinToCircle ex : $e");
      if (e is ServerException) {
        if (forNotification && e.statusCode == 400) {
          return true;
        }
        return e.errorMessage;
      }
      return e;
    }
  }
  Future leaveCircle({required CircleModel circle,}) async {
    if (circle.membership != CircleMembership.admin && circle.membership != CircleMembership.member) return;
    try {
      final parsedJson = await httpConnector.patch(
        url: ApiResource.leaveCircle(circle.id),
      );
      if (parsedJson["success"] == true) {
        circle.membership = CircleMembership.notYet;
        return true;
      }
    } catch (e) {
      debugPrint("======= leaveCircle ex : $e");
      if (e is ServerException) {
        return e.errorMessage;
      }
      return e;
    }
  }
  Future addSubCircle({required CircleModel parentCircle, required CircleModel subCircle,}) async {
    try {
      final parsedJson = await httpConnector.patch(
        url: ApiResource.addSubCircle(parentCircle.id),
        body: {
          "add": [subCircle.id],
        }
      );
      if (parsedJson["success"] == true) {
        parentCircle.subCircles.insert(0, subCircle);
        return true;
      }
    } catch (e) {
      debugPrint("======= addSubCircle ex : $e");
      if (e is ServerException) {
        return e.errorMessage;
      }
      return e;
    }
  }
  Future removeSubCircle({required CircleModel parentCircle, required CircleModel subCircle,}) async {
    try {
      final parsedJson = await httpConnector.patch(
        url: ApiResource.addSubCircle(parentCircle.id),
        body: {
          "remove": [subCircle.id],
        }
      );
      if (parsedJson["success"] == true) {
        parentCircle.subCircles.removeWhere((element) => element.id == subCircle.id);
        return true;
      }
    } catch (e) {
      debugPrint("======= addSubCircle ex : $e");
      if (e is ServerException) {
        return e.errorMessage;
      }
      return e;
    }
  }
  Future addCircleMember({required CircleModel parentCircle, required CircleMemberModel member,}) async {
    try {
      final parsedJson = await httpConnector.patch(
        url: ApiResource.updateCircleMember(parentCircle.id),
        body: {
          "add": [member.toJSON],
        }
      );
      if (parsedJson["success"] == true) {
        return true;
      }
    } catch (e) {
      debugPrint("======= addCircleMember ex : $e");
      if (e is ServerException) {
        return e.errorMessage;
      }
      return e;
    }
  }
  Future removeCircleMember({required CircleModel parentCircle, required CircleMemberModel member,}) async {
    try {
      final parsedJson = await httpConnector.patch(
        url: ApiResource.updateCircleMember(parentCircle.id),
        body: {
          "remove": [member.id],
        }
      );
      if (parsedJson["success"] == true) {
        return true;
      }
    } catch (e) {
      debugPrint("======= removeCircleMember ex : $e");
      if (e is ServerException) {
        return e.errorMessage;
      }
      return e;
    }
  }
  Future updateCircleMemberSettings({required CircleModel parentCircle, required CircleMemberModel member, required bool admin,}) async {
    try {
      final parsedJson = await httpConnector.patch(
        url: ApiResource.updateCircleMember(parentCircle.id),
        body: {
          "update": [
            {
              "user_id": member.memberId,
              "setting": {
                "admin": admin,
              }
            }
          ],
        }
      );
      if (parsedJson["success"] == true) {
        return true;
      }
    } catch (e) {
      debugPrint("======= updateCircleMemberSettings ex : $e");
      if (e is ServerException) {
        return e.errorMessage;
      }
      return e;
    }
  }

  Future circleFeedPosts({
    required String circleId,
    int pageNo = 1,
    int pageSize = 15,
    bool glimpse = false,
  }) async {
    try {
      debugPrint("======= circleFeedPosts circleId : $circleId");
      final parsedJson = await httpConnector.get(
        url: ApiResource.getCirclePosts(
          pageNo: pageNo,
          pageSize: pageSize,
          circleId: circleId,
          glimpse: glimpse,
        ),
      );
      return FeedPostsResponseModel.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= circleFeedPosts ex : $e");
      if (e is ServerException) {
        return e.errorMessage;
      }
      return e;
    }
  }
  Future circleQuestionReplyFeed({
    required String questionId,
    int pageNo = 1,
    int pageSize = 15,
    bool glimpse = false,
  }) async {
    try {
      debugPrint("======= circleQuestionReplyFeed questionId : $questionId");
      final parsedJson = await httpConnector.get(
        url: ApiResource.circleQuestionReplyFeed(
          pageNo: pageNo,
          pageSize: pageSize,
          questionId: questionId,
          glimpse: glimpse,
        ),
      );
      return FeedPostsResponseModel.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= circleQuestionReplyFeed ex : $e");
      if (e is ServerException) {
        return e.errorMessage;
      }
      return e;
    }
  }
  Future postCircleQuestion({required String circleId, String question = "",}) async {
    try {
      final parsedJson = await httpConnector.post(
        url: ApiResource.postCircleQuestion(circleId),
        body: {
          "content": question,
        },
      );
      if (parsedJson["success"] == true) {
        return true;
      }
    } catch (e) {
      debugPrint("======= postCircleQuestion ex : $e");
      if (e is ServerException) {
        return e.errorMessage;
      }
      return e;
    }
  }

}