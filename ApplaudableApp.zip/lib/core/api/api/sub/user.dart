import 'dart:io';
import 'dart:math';

import 'package:applaudable/core/api/api/api.dart';
import 'package:applaudable/core/enums/user.dart';
import 'package:applaudable/core/mappers/auth_mappers.dart';
import 'package:applaudable/features/auth/domain/entities/user.dart';
import 'package:flutter/cupertino.dart';

import '../../../../app_module.dart';
import '../../../../features/app_content/data/models/app_content_response_model.dart';
import '../../../../features/auth/data/datasources/local_source.dart';
import '../../../../features/auth/data/models/user_response_model.dart';
import '../../../../features/feed/data/models/search_result_model.dart';
import '../../../../features/mentions/data/models/friend_invite_model.dart';
import '../../../../features/mentions/data/models/invitations_count_model.dart';
import '../../../../features/profile_settings/domain/usecases/update_user_profile.dart';
import '../../../../model/user/contact.dart';
import '../../../../model/user/simple.dart';
import '../../../entities/pagination_params.dart';
import '../../../errors/exeptions.dart';
import '../../api_config.dart';

extension UserAPI on APIs {
  Future updateUserProfile({
    required UpdateUserProfileParams params,
  }) async {
    try {
      final parsedJson = await httpConnector.patch(
          url: ApiResource.myProfile, body: params.toMap());
      var user = UserResponseModel.fromProfileJson(parsedJson).toEntity();
      if (user.id.isEmpty) {
        var session = await AppLocalDataSource.instance.getSession();
        user = user.copyWith(id: session!.user.id);
      }

      AppLocalDataSource.instance.updateSessionUser(user);
      AppModule.I.controller.updateCurrentUser(user: user);
      return user;
    } catch (e) {
      debugPrint("======= updateUserProfile ex : $e");
      return e;
    }
  }
  Future updateUsername({
    required String username,
  }) async {
    try {
      await httpConnector.patch(
        url: ApiResource.updateUsername,
        body: {
          "username": username,
        },
      );
      AppLocalDataSource.instance.updateUsername(username);
      AppModule.I.controller.updateUsername(username: username);
      return true;
    } catch (e) {
      debugPrint("======= updateUsername ex : $e");
      return e;
    }
  }
  Future getUserInvitationCode() async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.getUserInvitationsCount,
      );
      final model = InvitationsCountModel.fromJson(parsedJson);
      AppLocalDataSource.instance.updateInvitationCode(model.invitationCode);
      AppModule.I.controller.updateInvitationCode(invitationCode: model.invitationCode);
      return model.invitationCode;
    } catch (e) {
      debugPrint("======= getUserInvitationCode ex : $e");
    }
  }
  Future uploadUserAvatar({required File avatar}) async {
    try {
      final response = await httpConnector.multiPartRequest(
        url: ApiResource.profileAvatarUpload,
        filesToUpload: [MapEntry('avatar', avatar)],
        // onSendProgress: params.onSendProgress,
      );

      final avatarUrl = response['avatar']['avatar'] ?? '';
      await AppLocalDataSource.instance.updateUserAvatarUrl(avatarUrl);
      AppModule.I.controller.updateAvatar(avatar: avatarUrl);
      return avatarUrl;
    } catch (e) {
      debugPrint("======= uploadUserAvatar ex : $e");
      return e;
    }
  }
  Future searchForNuppsAndUsers({
    required String query,
    PaginationParams pageInfo = const PaginationParams(pageSize: 15),
  }) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.searchForNuppsAndUsersEndpoint(query, pageInfo),
      );

      return SearchResultResponse.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= searchForNuppsAndUsers ex : $e");
      return e;
    }
  }
  Future searchUsers({
    required String query,
    PaginationParams pageInfo = const PaginationParams(pageSize: 15),
  }) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.searchUsersEndpoint(query, pageInfo),
      );

      return SearchUserResultResponse.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= searchUsers ex : $e");
      return e;
    }
  }
  Future inviteUser({required String name, String? email, String? phone, bool notify = false}) async {
    try {
      final parsedJson = await httpConnector.post(
        url: ApiResource.inviteUserEndpoint,
        body: {
          'name': name,
          if (email != null) 'email': email,
          if (phone != null) 'phone_number': phone,
          'notify': notify
        },
      );
      return FriendInviteModel.fromJson(parsedJson);
    } catch (e) {
      debugPrint("======= inviteUser ex : $e");
      if (e is ServerException) {
        // if (e.statusCode == 400 && e.errorMessage.contains("already exists")) {
        //   return "A user using this phone number already exists";
        // }
        return e.errorMessage;
      }
      return e;
    }
  }
  Future getMyProfile() async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.myProfile,
      );
      var user = UserResponseModel.fromProfileJson(parsedJson).toEntity();
      if (user.id.isEmpty) {
        var session = await AppLocalDataSource.instance.getSession();
        user = user.copyWith(id: session!.user.id);
      }

      AppLocalDataSource.instance.updateSessionUser(user);
      AppModule.I.controller.updateCurrentUser(user: user);
      return user;
    } catch (e) {
      debugPrint("======= getMyProfile ex : $e");
      return e;
    }
  }
  Future getUserProfile(String userId) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.getProfileData(userId: userId),
      );
      var user = UserResponseModel.fromProfileJson(parsedJson).toEntity();
      return user;
    } catch (e) {
      debugPrint("======= getUserProfile($userId) ex : $e");
      return e;
    }
  }
  Future followUser({HiveUser? user, SimpleUserModel? simpleUser, UserContactModel? contact}) async {
    try {
      simpleUser?.following?.value = true;
      contact?.following.value = true;
      user?.engagement?.followingNotifier.value = true;
      user?.counters?.followersNotifier.value = (user.counters?.followersNotifier.value ?? 0) + 1;
      AppModule.I.controller.currentUser?.counters?.followingNotifier.value = (AppModule.I.controller.currentUser?.counters?.followingNotifier.value ?? 0) + 1;
      await httpConnector.post(
        url: ApiResource.follow(userId: user?.id ?? simpleUser?.id ?? contact?.user?.id ?? ""),
      );
      return true;
    } catch (e) {
      simpleUser?.following?.value = false;
      contact?.following.value = false;
      user?.engagement?.followingNotifier.value = false;
      user?.counters?.followersNotifier.value = max(0, (user.counters?.followersNotifier.value ?? 0) - 1);
      AppModule.I.controller.currentUser?.counters?.followingNotifier.value = max(0, (AppModule.I.controller.currentUser?.counters?.followingNotifier.value ?? 0) - 1);
      debugPrint("======= followUser ex : $e");
      return e;
    }
  }

  Future unFollowUser({HiveUser? user, SimpleUserModel? simpleUser, UserContactModel? contact}) async {
    try {
      simpleUser?.following?.value = false;
      contact?.following.value = false;
      user?.engagement?.followingNotifier.value = false;
      user?.counters?.followersNotifier.value = max(0, (user.counters?.followersNotifier.value ?? 0) - 1);
      AppModule.I.controller.currentUser?.counters?.followingNotifier.value = max(0, (AppModule.I.controller.currentUser?.counters?.followingNotifier.value ?? 0) - 1);
      await httpConnector.delete(
        url: ApiResource.follow(userId: user?.id ?? simpleUser?.id ?? contact?.user?.id ?? ""),
      );
      return true;
    } catch (e) {
      simpleUser?.following?.value = true;
      contact?.following.value = true;
      user?.engagement?.followingNotifier.value = true;
      user?.counters?.followersNotifier.value = (user.counters?.followersNotifier.value ?? 0) + 1;
      AppModule.I.controller.currentUser?.counters?.followingNotifier.value = (AppModule.I.controller.currentUser?.counters?.followingNotifier.value ?? 0) + 1;
      debugPrint("======= unFollowUser ex : $e");
      return e;
    }
  }
  Future getFollowers({
    required String userId,
    int pageNo = 1,
    int pageSize = 20,
  }) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.getFollowers(userId: userId, pageInfo: PaginationParams(pageNo: pageNo, pageSize: pageSize)),
      );
      return SimpleUsersResponse.fromJson(parsedJson is List ? {'results': parsedJson} : parsedJson).results;
    } catch (e) {
      debugPrint("======= getFollowers ex : $e");
      return e;
    }
  }
  Future getFollowings({
    required String userId,
    int pageNo = 1,
    int pageSize = 20,
  }) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.getFollowing(userId: userId, pageInfo: PaginationParams(pageNo: pageNo, pageSize: pageSize)),
      );
      return SimpleUsersResponse.fromJson(parsedJson is List ? {'results': parsedJson} : parsedJson).results;
    } catch (e) {
      debugPrint("======= getFollowings ex : $e");
      return e;
    }
  }
  Future blockUser(HiveUser user) async {
    try {
      await httpConnector.post(
        url: ApiResource.blockUser(userId: user.id),
      );
      return true;
    } catch (e) {
      debugPrint("======= blockUser ex : $e");
      return e;
    }
  }
  Future settingsContent(AppSettingsContentType type) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.appContentEndpoint(type.paramForAPI),
      );

      return AppContentResponseModel.fromJson(parsedJson);
    } catch (e) {
      debugPrint("======= settingsContent ex : $e");
      return e;
    }
  }

}