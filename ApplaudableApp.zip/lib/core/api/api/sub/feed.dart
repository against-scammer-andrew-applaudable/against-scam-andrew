import 'dart:math';

import 'package:flutter/cupertino.dart';

import '../../../../app_module.dart';
import '../../../../features/auth/data/datasources/local_source.dart';
import '../../../../features/feed/data/models/post_action_response_model.dart';
import '../../../../features/feed/domain/enums/posts_enum.dart';
import '../../../../model/post/feed.dart';
import '../../../../model/user/simple.dart';
import '../../../entities/pagination_params.dart';
import '../../api_config.dart';
import '../api.dart';

extension FeedAPI on APIs {
  Future feedPosts({
    PostsFilterByType type = PostsFilterByType.suggested,
    int pageNo = 1,
    int pageSize = 20,
    bool glimpse = false,
  }) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.feedPosts(
          pageNo: pageNo,
          pageSize: pageSize,
          glimpse: glimpse,
        ),
      );

      return FeedPostsResponseModel.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= feedPosts ex : $e");
      return e;
    }
  }

  Future disappearingFeedPosts({
    int pageNo = 1,
    int pageSize = 10,
  }) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.disappearingFeedPosts(
          pageNo: pageNo,
          pageSize: pageSize,
        ),
      );

      return FeedPostsResponseModel.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= disappearingFeedPosts ex : $e");
      return e;
    }
  }

  Future elementFeedPosts({
    required String elementId,
    int pageNo = 1,
    int pageSize = 15,
    bool glimpse = false,
  }) async {
    try {
      debugPrint("======= elementFeedPosts elementId : $elementId");
      final parsedJson = await httpConnector.get(
        url: ApiResource.getElementsPosts(
          pageNo: pageNo,
          pageSize: pageSize,
          elementId: elementId,
          glimpse: glimpse,
        ),
      );
      return FeedPostsResponseModel.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= elementFeedPosts ex : $e");
      return e;
    }
  }
  Future getPostDetail({required String postId}) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.postById(id: postId),
      );

      return FeedPostModel.dic(parsedJson);
    } catch (e) {
      debugPrint("======= getPostDetail ex : $e");
      return e;
    }
  }

  Future getPostLikes({
    required String postId,
    int pageNo = 1,
    int pageSize = 20,
  }) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.postApplauds(postId, pageInfo: PaginationParams(pageNo: pageNo, pageSize: pageSize)),
      );

      return SimpleUsersResponse.fromJson(
        parsedJson is List ? {'results': parsedJson} : parsedJson,
      ).results;
    } catch (e) {
      debugPrint("======= getPostLikes ex : $e");
      return e;
    }
  }

  void _addMeToPostLikes(FeedPostModel post) async {
    final session = await AppLocalDataSource.instance.getSession();
    if (session != null) {
      final likes = [...post.postLikes.value];
      final index = likes.indexWhere((element) => element.id == session.user.id);
      if (index < 0) {
        likes.insert(0, SimpleUserModel(id: session.user.id, name: session.user.name, avatar: session.user.avatar, username: session.user.username));
        post.postLikes.value = likes;
      }
    }
  }
  void _removeMeFromPostLikes(FeedPostModel post) async {
    final session = await AppLocalDataSource.instance.getSession();
    if (session != null) {
      final likes = [...post.postLikes.value];
      likes.removeWhere((element) => element.id == session.user.id);
      post.postLikes.value = likes;
    }
  }
  Future likePost(FeedPostModel post) async {
    try {
      post.engagement.applauds.value = true;
      post.counters.applauds.value = post.counters.applauds.value + 1;
      AppModule.I.controller.currentUser?.counters?.applauseGivenNotifier.value = (AppModule.I.controller.currentUser?.counters?.applauseGivenNotifier.value ?? 0) + 1;
      _addMeToPostLikes(post);
      final parsedJson = await httpConnector.patch(
        url: ApiResource.applaudPost(post.id),
      );
      final response = PostActionResponseModel.fromJson(parsedJson);
      post.counters.applauds.value = response.counters?.applauds ?? post.counters.applauds.value;
      return true;
    } catch (e) {
      post.engagement.applauds.value = false;
      post.counters.applauds.value = max(0, post.counters.applauds.value - 1);
      AppModule.I.controller.currentUser?.counters?.applauseGivenNotifier.value = max(0, (AppModule.I.controller.currentUser?.counters?.applauseGivenNotifier.value ?? 0) - 1);
      _removeMeFromPostLikes(post);
      debugPrint("======= likePost ex : $e");
      return e;
    }
  }

  Future unlikePost(FeedPostModel post) async {
    try {
      post.engagement.applauds.value = false;
      post.counters.applauds.value = max(0, post.counters.applauds.value - 1);
      AppModule.I.controller.currentUser?.counters?.applauseGivenNotifier.value = max(0, (AppModule.I.controller.currentUser?.counters?.applauseGivenNotifier.value ?? 0) - 1);
      _removeMeFromPostLikes(post);
      final parsedJson = await httpConnector.delete(
        url: ApiResource.applaudPost(post.id),
      );
      final response = PostActionResponseModel.fromJson(parsedJson);
      post.counters.applauds.value = response.counters?.applauds ?? post.counters.applauds.value;
      return true;
    } catch (e) {
      post.engagement.applauds.value = true;
      post.counters.applauds.value = post.counters.applauds.value + 1;
      AppModule.I.controller.currentUser?.counters?.applauseGivenNotifier.value = (AppModule.I.controller.currentUser?.counters?.applauseGivenNotifier.value ?? 0) + 1;
      _addMeToPostLikes(post);
      debugPrint("======= unlikePost ex : $e");
      return e;
    }
  }

  Future savePost(FeedPostModel post) async {
    try {
      post.engagement.bookmarked.value = true;
      final parsedJson = await httpConnector.patch(
        url: ApiResource.bookmarkPost(post.id),
      );
      final _ = PostActionResponseModel.fromJson(parsedJson);
    } catch (e) {
      post.engagement.bookmarked.value = false;
      debugPrint("======= savePost ex : $e");
      return e;
    }
  }

  Future unsavePost(FeedPostModel post) async {
    try {
      post.engagement.bookmarked.value = false;
      final parsedJson = await httpConnector.delete(
        url: ApiResource.bookmarkPost(post.id),
      );
      final _ = PostActionResponseModel.fromJson(parsedJson);
    } catch (e) {
      post.engagement.bookmarked.value = true;
      debugPrint("======= unsavePost ex : $e");
      return e;
    }
  }
  Future reportPost(FeedPostModel post) async {
    try {
      await httpConnector.post(
        url: ApiResource.flagPost(post.id),
      );
      // final _ = PostActionResponseModel.fromJson(parsedJson);
      return true;
    } catch (e) {
      debugPrint("======= reportPost ex : $e");
      return e;
    }
  }
}