import 'dart:math';

import 'package:flutter/cupertino.dart';

import '../../../../app_module.dart';
import '../../../../features/auth/data/datasources/local_source.dart';
import '../../../../features/feed/data/models/post_action_response_model.dart';
import '../../../../model/post/highlight/create.dart';
import '../../../../model/post/highlight/highlight.dart';
import '../../../../model/user/simple.dart';
import '../../api_config.dart';
import '../api.dart';

extension HighlightAPI on APIs {
  Future createHighlight({
    required CreateHighlightRequestModel highlight,
  }) async {
    try {
      final parsedJson = await httpConnector.post(
        url: ApiResource.createHighlight,
        body: highlight.toJSONForCreate,
      );
      return FeedHighlightModel.dic(parsedJson);
    } catch (e) {
      debugPrint("======= createHighlight ex : $e");
      return e;
    }
  }
  Future feedHighlights({
    int pageNo = 1,
    int pageSize = 10,
  }) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.feedHighlights(
          pageNo: pageNo,
          pageSize: pageSize,
        ),
      );

      return FeedHighlightsResponseModel.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= feedHighlights ex : $e");
      return e;
    }
  }

  Future deleteHighlight({
    required String id,
  }) async {
    try {
      await httpConnector.delete(
        url: ApiResource.deleteHighlight(id),
      );
      return true;
    } catch (e) {
      debugPrint("======= deleteHighlight ex : $e");
      return e;
    }
  }

  Future likeHighlight(FeedHighlightModel highlight) async {
    try {
      highlight.engagement.applauds.value = true;
      highlight.counters.applauds.value = highlight.counters.applauds.value + 1;
      AppModule.I.controller.currentUser?.counters?.applauseGivenNotifier.value = (AppModule.I.controller.currentUser?.counters?.applauseGivenNotifier.value ?? 0) + 1;
      _addMeToHighlightLikes(highlight);
      final parsedJson = await httpConnector.patch(
        url: ApiResource.applaudHighlight(highlight.id),
      );
      final response = PostActionResponseModel.fromJson(parsedJson);
      highlight.counters.applauds.value = response.counters?.applauds ?? highlight.counters.applauds.value;
      return true;
    } catch (e) {
      highlight.engagement.applauds.value = false;
      highlight.counters.applauds.value = max(0, highlight.counters.applauds.value - 1);
      AppModule.I.controller.currentUser?.counters?.applauseGivenNotifier.value = max(0, (AppModule.I.controller.currentUser?.counters?.applauseGivenNotifier.value ?? 0) - 1);
      _removeMeFromHighlightLikes(highlight);
      debugPrint("======= likeHighlight ex : $e");
      return e;
    }
  }

  Future unlikeHighlight(FeedHighlightModel highlight) async {
    try {
      highlight.engagement.applauds.value = false;
      highlight.counters.applauds.value = max(0, highlight.counters.applauds.value - 1);
      AppModule.I.controller.currentUser?.counters?.applauseGivenNotifier.value = max(0, (AppModule.I.controller.currentUser?.counters?.applauseGivenNotifier.value ?? 0) - 1);
      _removeMeFromHighlightLikes(highlight);
      final parsedJson = await httpConnector.delete(
        url: ApiResource.applaudHighlight(highlight.id),
      );
      final response = PostActionResponseModel.fromJson(parsedJson);
      highlight.counters.applauds.value = response.counters?.applauds ?? highlight.counters.applauds.value;
      return true;
    } catch (e) {
      highlight.engagement.applauds.value = true;
      highlight.counters.applauds.value = highlight.counters.applauds.value + 1;
      AppModule.I.controller.currentUser?.counters?.applauseGivenNotifier.value = (AppModule.I.controller.currentUser?.counters?.applauseGivenNotifier.value ?? 0) + 1;
      _addMeToHighlightLikes(highlight);
      debugPrint("======= unlikeHighlight ex : $e");
      return e;
    }
  }

  Future saveHighlight(FeedHighlightModel highlight) async {
    try {
      highlight.engagement.bookmarked.value = true;
      final parsedJson = await httpConnector.patch(
        url: ApiResource.bookmarkHighlight(highlight.id),
      );
      final _ = PostActionResponseModel.fromJson(parsedJson);
    } catch (e) {
      highlight.engagement.bookmarked.value = false;
      debugPrint("======= saveHighlight ex : $e");
      return e;
    }
  }

  Future unsaveHighlight(FeedHighlightModel highlight) async {
    try {
      highlight.engagement.bookmarked.value = false;
      final parsedJson = await httpConnector.delete(
        url: ApiResource.bookmarkHighlight(highlight.id),
      );
      final _ = PostActionResponseModel.fromJson(parsedJson);
    } catch (e) {
      highlight.engagement.bookmarked.value = true;
      debugPrint("======= unsaveHighlight ex : $e");
      return e;
    }
  }
  Future reportHighlight(FeedHighlightModel highlight) async {
    try {
      await httpConnector.post(
        url: ApiResource.flagHighlight(highlight.id),
      );
      return true;
    } catch (e) {
      debugPrint("======= reportHighlight ex : $e");
      return e;
    }
  }

  void _addMeToHighlightLikes(FeedHighlightModel highlight) async {
    final session = await AppLocalDataSource.instance.getSession();
    if (session != null) {
      final likes = [...highlight.highlightLikes.value];
      final index = likes.indexWhere((element) => element.id == session.user.id);
      if (index < 0) {
        likes.insert(0, SimpleUserModel(id: session.user.id, name: session.user.name, avatar: session.user.avatar, username: session.user.username));
        highlight.highlightLikes.value = likes;
      }
    }
  }
  void _removeMeFromHighlightLikes(FeedHighlightModel highlight) async {
    final session = await AppLocalDataSource.instance.getSession();
    if (session != null) {
      final likes = [...highlight.highlightLikes.value];
      likes.removeWhere((element) => element.id == session.user.id);
      highlight.highlightLikes.value = likes;
    }
  }
}
