import 'dart:convert';
import 'dart:io';

import 'package:applaudable/core/api/api/api.dart';
import 'package:applaudable/core/constants/constant_values.dart';
import 'package:applaudable/core/mixins/location_mixin.dart';
import 'package:applaudable/model/post/request.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:geolocator/geolocator.dart';
import 'package:path_provider/path_provider.dart';

import '../../../../app_module.dart';
import '../../../../features/create_post/data/models/post_feed_model.dart';
import '../../../../model/circle/circle.dart';
import '../../../../model/post/feed.dart';
import '../../../../model/post/glimpse/media.dart';
import '../../../../model/post/place.dart';
import '../../../enums/glimpse.dart';
import '../../../enums/post.dart';
import '../../api_config.dart';

extension GlimpseAPI on APIs {
  Future saveGlimpseToCircle({
    required FeedPostModel glimpse,
    required CircleModel circle,
  }) async {
    try {
      var visibility = glimpse.visibility;
      if (visibility == PostVisibilityType.public) {
        visibility = PostVisibilityType.onlyme;
      }
      final parsedJson = await httpConnector.patch(
        url: ApiResource.editPost(postId: glimpse.id),
        body: {
          "visibility": visibility.name,
          "circles": {
            "add": [
              circle.id,
            ],
            if (glimpse.circle != null) "remove": [
              glimpse.circle!.id,
            ]
          }
        },
      );
      return FeedPostModel.dic(parsedJson);
    } catch (e) {
      debugPrint("======= editPost ex : $e");
      return e;
    }
  }
  Future getPlaceDetail({required ExperiencePlaceModel place}) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.placeDetail(placeId: place.placeId),
      );
      if (place.updateFromJson(parsedJson)) {
        return place;
      }
    } catch (e) {
      debugPrint("======= getPlaceDetail ex : $e");
      return e;
    }
  }
  Future _getPlaceDetailFromLocationInBackend({required ExperiencePlaceModel? place}) async {
    if (place?.location == null) return;
    try {
      debugPrint("nearby search is called.........");
      final parsedJson = await httpConnector.get(
        url: ApiResource.placeDetailFromLocation(location: place?.location?.asParamValue() ?? ""),
      );
      if (parsedJson is List) {
        final places = parsedJson.map((e) => ExperiencePlaceModel.fromLocationJson(e)).toList();
        places.sort((m1, m2) => Geolocator.distanceBetween(place?.location?.latitude ?? 0, place?.location?.longitude ?? 0, m1.location?.latitude ?? 0, m1.location?.longitude ?? 0).compareTo(Geolocator.distanceBetween(place?.location?.latitude ?? 0, place?.location?.longitude ?? 0, m2.location?.latitude ?? 0, m2.location?.longitude ?? 0)));
        // final validPlaces = places.where((e) => e.photos.isNotEmpty).toList();
        // if (validPlaces.isNotEmpty) {
        //   return validPlaces.first;
        // }
        debugPrint("====== distance : ${places.map((e) => "${Geolocator.distanceBetween(place?.location?.latitude ?? 0, place?.location?.longitude ?? 0, e.location?.latitude ?? 0, e.location?.longitude ?? 0)}, ${e.photos.length}").toList()}");
        if (places.isNotEmpty) {
          return places.first;
        }
      }
    } catch (e) {
      debugPrint("======= _getPlaceDetailFromLocationInBackend ex : $e");
      return e;
    }
  }
  Future getPlaceDetailFromLocation({required ExperiencePlaceModel? place}) async {
    if (place == null || place.location == null) return;
    try {
      final parsedJson = await httpConnector.get(
        url: "https://maps.googleapis.com/maps/api/geocode/json?latlng=${(place.location?.asParamValue() ?? "").replaceAll(" ", "")}&key=${ConstantValues.GOOGLE_PLACES_MAP_GEOCODE_API}&extra_computations=ADDRESS_DESCRIPTORS",
      );
      String? placeId = parsedJson["results"].first["place_id"];
      if ((parsedJson["address_descriptor"]?["areas"] is List) && parsedJson["address_descriptor"]?["areas"].isNotEmpty) {
        final area = parsedJson["address_descriptor"]?["areas"].first;
        if (area["place_id"] is String) {
          placeId = area["place_id"];
        }
      }
      if (placeId == null && (parsedJson["address_descriptor"]?["landmarks"] is List) && parsedJson["address_descriptor"]?["landmarks"].isNotEmpty) {
        final area = parsedJson["address_descriptor"]?["landmarks"].first;
        if (area["place_id"] is String) {
          placeId = area["place_id"];
        }
      }
      if (placeId == null && (parsedJson["results"] is List) && parsedJson["results"].isNotEmpty) {
        final area = parsedJson["results"].first;
        if (area["place_id"] is String) {
          placeId = area["place_id"];
        }
      }
      if (placeId != null) {
        place.placeId = placeId;
        return getPlaceDetail(place: place);
      }
      return _getPlaceDetailFromLocationInBackend(place: place);
    } catch (e) {
      debugPrint("======= getPlaceDetailFromLocation ex : $e");
      return e;
    }
  }
  Future aiConvertText({required AIOption option, required String content}) async {
    try {
      final parsedJson = await httpConnector.post(
        url: ApiResource.aiConvertText,
        body: {
          "prompt": option.name,
          "content": content,
        }
      );
      if (parsedJson["text"] is String) {
        return AITextModel.fromJason(parsedJson);
      }
    } catch (e) {
      debugPrint("======= aiConvertText ex : $e");
      return e;
    }
  }
  Future aiConvertTitle({required String content}) async {
    try {
      final parsedJson = await httpConnector.post(
        url: ApiResource.aiConvertText,
        body: {
          "prompt": "highlight_title",
          "content": content,
        }
      );
      if (parsedJson["text"] is String) {
        return AITextModel.fromJason(parsedJson);
      }
    } catch (e) {
      debugPrint("======= aiConvertText ex : $e");
      return e;
    }
  }
  Future downloadGooglePhoto({required PlacePhotoModel photo}) async {
    try {
      final filePath = '${(await getTemporaryDirectory()).path}/${photo.photoReference}.jpg';
      await httpConnector.download(
        url: photo.url,
        filePath: filePath,
      );
      debugPrint("======= downloadGooglePhoto filePath : $filePath");
      return File(filePath);
    } catch (e) {
      debugPrint("======= downloadGooglePhoto ex : $e");
      return e;
    }
  }
  Future downloadServerImage({required String url}) async {
    try {
      final filePath = '${(await getTemporaryDirectory()).path}/${DateTime.now().microsecondsSinceEpoch}.jpg';
      await httpConnector.download(
        url: url,
        filePath: filePath,
      );
      debugPrint("======= downloadServerImage filePath : $filePath");
      return File(filePath);
    } catch (e) {
      debugPrint("======= downloadServerImage ex : $e");
      return e;
    }
  }
  Future uploadGlimpseMedia({
    required CreateGlimpseMediaModel media,
  }) async {
    if (media.cancelToken != null || media.mediaId != null) {
      return;
    }
    if (media.filePath == null && media.mapSnapshot == null && media.text == null) {
      return;
    }
    media.cancelToken = CancelToken();
    try {
      final parsedJson = await httpConnector.uploadMediaRequest(
        url: ApiResource.uploadMedia,
        file: media.filePath,
        bytes: media.mapSnapshot,
        body: {
          'type': (media.type == AppMediaType.map ? AppMediaType.image : media.type).name,
          if (media.type == AppMediaType.text) 'text': media.text ?? "",
        },
        onSendProgress: (count, total) {
          media.uploadProgress.value = count.toDouble() / total.toDouble();
        },
        cancelToken: media.cancelToken,
      );
      media.uploadProgress.value = 1;
      media.cancelToken = null;
      final postMedia = PostMediaModel.fromJson(parsedJson);
      media.mediaId = postMedia.id;
      return postMedia;
    } catch (e) {
      media.uploadProgress.value = 0;
      media.cancelToken = null;
      media.failedUpload = true;
      debugPrint("======= uploadMedia ex : $e");
      return e;
    }
  }

  Future deleteGlimpseMedia({
    required CreateGlimpseMediaModel media,
  }) async {
    final mediaId = media.mediaId;
    if (mediaId == null) {
      return;
    }
    try {
      media.mediaId = null;
      final parsedJson = await httpConnector.delete(
          url: ApiResource.uploadMedia,
          body: {
            "media_ids": [mediaId],
          }
      );
      return parsedJson["success"] ?? false;
    } catch (e) {
      media.uploadProgress.value = 0;
      media.cancelToken = null;
      debugPrint("======= deleteGlimpseMedia ex : $e");
      return e;
    }
  }
  Future createGlimpsePost({
    required CreateGlimpseMediaModel media,
  }) async {
    try {
      final parsedJson = await httpConnector.post(
        url: ApiResource.createPostFeed,
        body: media.toJSONForCreate,
      );
      return FeedPostModel.dic(parsedJson);
    } catch (e) {
      debugPrint("======= createGlimpsePost ex : $e");
      return e;
    }
  }
  Future userGlimpses({
    required String userId,
    int pageNo = 1,
    int pageSize = 20,
  }) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.userGlimpses(
          pageNo: pageNo,
          pageSize: pageSize,
          userId: userId,
        ),
      );

      return FeedPostsResponseModel.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= userGlimpses ex : $e");
      return e;
    }
  }

  Future myGlimpses({
    int pageNo = 1,
    int pageSize = 20,
  }) async {
    try {
      final parsedJson = await httpConnector.get(
        url: ApiResource.myGlimpses(
          pageNo: pageNo,
          pageSize: pageSize,
        ),
      );

      return FeedPostsResponseModel.fromJson(parsedJson).results;
    } catch (e) {
      debugPrint("======= myGlimpses ex : $e");
      return e;
    }
  }


}

class AITextModel {
  late String text;

  AITextModel.fromJason(Map<String, dynamic> map) {
    text = map["text"] ?? "";
  }
}