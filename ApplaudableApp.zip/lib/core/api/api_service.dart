import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/services.dart';

import '../../../core/api/api_env.dart';

abstract class ApiService {
  void setApi({ApiEnv? api});

  /// Sets the current session token
  set token(String token);

  /// Sets the current date header
  set date(DateTime date);

  Future<dynamic> get({
    String? url,
    Map<String, Object>? query,
    Map<String, String>? headers,
    CancelToken? cancelToken,
  });

  Future<dynamic> post({
    String? url,
    Map<String, Object?>? body,
    Map<String, Object>? query,
    Map<String, String>? headers,
    CancelToken? cancelToken,
  });

  Future<dynamic> postRaw({
    String? url,
    Object? body,
    Map<String, Object>? query,
    Map<String, String>? headers,
    CancelToken? cancelToken,
  });

  Future<dynamic> put({
    String? url,
    Map<String, Object?>? body,
    Map<String, Object>? query,
    Map<String, String>? headers,
    CancelToken? cancelToken,
  });
  Future<dynamic> patch({
    String? url,
    Map<String, Object?>? body,
    Map<String, Object>? query,
    Map<String, String>? headers,
    CancelToken? cancelToken,
  });
  Future<dynamic> delete({
    String? url,
    Map<String, Object>? query,
    Map<String, String>? headers,
    CancelToken? cancelToken,
  });
  Future<dynamic> download({
    required String url,
    required String filePath,
    CancelToken? cancelToken,
  });

  Future<dynamic> multiPartRequest({
    String? url,
    Map<String, Object?>? body,
    Map<String, Object>? query,
    Map<String, String>? headers,
    List<MapEntry<String, File>> filesToUpload = const [],
    void Function(int, int)? onSendProgress,
    void Function(int, int)? onReceiveProgress,
    CancelToken? cancelToken,
  });
  Future uploadMediaRequest({
    String? url,
    String? file,
    Uint8List? bytes,
    Map<String, Object?>? body,
    Map<String, Object>? query,
    Map<String, String>? headers,
    void Function(int, int)? onSendProgress,
    void Function(int, int)? onReceiveProgress,
    CancelToken? cancelToken,
  });
}
