import '../../../features/auth/data/models/requests/activate_account_request_model.dart';
import '../../../features/auth/data/models/requests/login_request_model.dart';
import '../../../features/auth/data/models/requests/login_with_phone_number_request_model.dart';
import '../../../features/auth/data/models/requests/recover_password_request_model.dart';
import '../../../features/auth/data/models/requests/reset_password_request_model.dart';
import '../../../features/auth/data/models/requests/signin_confirm_code_request_model.dart';
import '../../../features/auth/data/models/requests/signup_request_model.dart';
import '../../../features/auth/data/models/requests/token_refresh_request_model.dart';
import '../../../features/auth/data/models/requests/token_verify_request_model.dart';
import '../api_config.dart';
import '../remote_api_service.dart';

abstract class RemoteAuthService {
  Future<dynamic> signUp({
    required SignUpRequestModel model,
  });

  Future<dynamic> signIn({
    required LoginRequestModel model,
  });

  Future<dynamic> signInWithPhoneNumber({
    required LoginWithPhoneNumberRequestModel model,
  });

  Future<dynamic> signInConfirmCode({
    required SignInConfirmCodeRequestModel model,
  });

  Future<dynamic> recoverPassword({
    required RecoverPasswordRequestModel model,
  });

  Future<dynamic> tokenVerify({
    required TokenVerifyRequestModel model,
  });

  Future<dynamic> tokenRefresh({
    required TokenRefreshRequestModel model,
  });

  Future<dynamic> activateAccount({
    required String uuid,
    required ActivateAccountRequestModel model,
  });

  Future<dynamic> resetPassword({
    required ResetPasswordRequestModel model,
  });

  Future<dynamic> validateInviteCode({required String inviteCode});
}

class AppRemoteAuthService implements RemoteAuthService {
  static final httpConnector = RemoteApiService.api;

  @override
  Future<dynamic> signUp({
    required SignUpRequestModel model,
  }) =>
      httpConnector.post(
        url: ApiResource.signup,
        body: model.toJson(),
      );

  @override
  Future<dynamic> signIn({
    required LoginRequestModel model,
  }) =>
      httpConnector.post(
        url: ApiResource.loginUserAndPassword,
        body: model.toJson(),
      );

  @override
  Future<dynamic> signInWithPhoneNumber(
          {required LoginWithPhoneNumberRequestModel model}) =>
      httpConnector.post(
        url: ApiResource.loginWithPhoneRequest,
        body: model.toJson(),
      );

  @override
  Future<dynamic> signInConfirmCode(
          {required SignInConfirmCodeRequestModel model}) =>
      httpConnector.post(
        url: ApiResource.loginWithPhoneConfirmPin,
        body: model.toJson(),
      );

  @override
  Future<dynamic> recoverPassword({
    required RecoverPasswordRequestModel model,
  }) =>
      httpConnector.post(
        url: ApiResource.recoverPassword,
        body: model.toJson(),
      );

  @override
  Future<dynamic> tokenVerify({
    required TokenVerifyRequestModel model,
  }) =>
      httpConnector.post(
        url: ApiResource.tokenVerify,
        body: model.toJson(),
      );

  @override
  Future<dynamic> tokenRefresh({
    required TokenRefreshRequestModel model,
  }) =>
      httpConnector.post(
        url: ApiResource.tokenRefresh,
        body: model.toJson(),
      );

  @override
  Future<dynamic> activateAccount({
    required String uuid,
    required ActivateAccountRequestModel model,
  }) =>
      httpConnector.post(
        url: ApiResource.activateAccount(uuid: uuid),
        body: model.toJson(),
      );

  @override
  Future<dynamic> resetPassword({
    required ResetPasswordRequestModel model,
  }) =>
      httpConnector.patch(
        url: ApiResource.resetPassword,
        body: model.toJson(),
      );

  @override
  Future validateInviteCode({required String inviteCode}) {
    return httpConnector.get(url: ApiResource.validateInviteCode(inviteCode));
  }
}
