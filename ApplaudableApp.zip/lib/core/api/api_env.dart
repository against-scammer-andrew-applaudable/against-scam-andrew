abstract class ApiEnv {
  /// Scheme request format
  String get scheme => "https";

  /// Base API version
  String get apiVersion => "api/v1";

  /// Hostname
  String host = "";

  /// building the path
  String call({String hostname = '', String path = ""}) {
    String base = "$scheme://${hostname == '' ? host : hostname}/$apiVersion";
    if (path.isNotEmpty) {
      base = "$base/$path";
    }
    return base;
  }

  /// build media path
  String media(String imageName) => "$scheme://$host$imageName";

  ApiEnv({String hostname = '', String path = ""}) {
    host = hostname;
  }
}

/// Production API Configuration
class ProductionApi extends ApiEnv {
  @override
  String get scheme => "https";

  @override
  String get host => "api.applaudable.com";
}

/// Staging API Configuration
class StagingApi extends ApiEnv {
  @override
  String get scheme => "https";

  @override
  String get host => "api-dev.applaudable.com";
}

/// Develop API Configuration
class DevApi extends ApiEnv {
  @override
  String get scheme => "https";

  @override
  String get host => "api-dev.applaudable.com";
}

