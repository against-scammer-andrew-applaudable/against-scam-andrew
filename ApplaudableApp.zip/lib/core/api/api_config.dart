import '../../../core/entities/pagination_params.dart';
import '../../../features/feed/domain/enums/posts_enum.dart';

class ApiResource {
  /// *** Auth namespace
  static const String _auth = "/auth/";

  /// *** Auth Login namespace
  static const String _login = "/login/";

  /// *** User namespace
  static const String _user = '/user/';

  /// *** Posts namespace
  static const String _posts = '/posts/';

  /// *** Collections namespace
  static const String _collections = '/collections/';

  static String loginUserAndPassword = "${_login}email/";
  static String loginWithPhoneRequest = "${_login}sms/request/";
  static String loginWithPhoneConfirmPin = "${_login}sms/";

  static String signup = "/signup/";

  static String smsValidateInSignup = '${signup}sms/validate/';
  static String checkExistsInSignup = '${signup}info/validate/';

  /// Auth Session Token Verify
  static const String tokenVerify = "${_auth}token/verify/";

  /// Auth Session Token Refresh
  static const String tokenRefresh = "${_auth}token/refresh/";

  /// Auth Recover Password
  static const String recoverPassword = "${_auth}password/reset/email/";

  /// Auth Reset Password
  static const String resetPassword = "${_auth}change-password/email/";

  /// Auth Recover Password
  static const String changePassword = "${_auth}change-password/";

  /// User Activate Account
  static String activateAccount({required String uuid}) =>
      "$signup$uuid/activate/";

  /// *** Notifications namespace
  static const String notification = '/notification/';

  static const String registerDevice = '/devices/';

  /// App version
  static const String checkAppVersion = "/version/latest/";


  /// Available Interests Endpoint
  static String availableInterests({
    String query = '',
    int pageNo = 1,
    int pageSize = 10,
  }) {
    return '/interest/interest/?${query.isEmpty ? '' : 'name=$query&'}offset=${(pageNo - 1) * pageSize}&limit=$pageSize';
  }

  /// Profile Avatar Upload Endpoint
  static const String profileAvatarUpload = '${_user}avatar/upload/';

  /// Available Life Makeup Categories Endpoint
  static String availableLifeCategories({
    String query = '',
    int pageNo = 1,
    int pageSize = 10,
  }) {
    return '/life-makeup/?${query.isEmpty ? '' : 'name=$query&'}offset=${(pageNo - 1) * pageSize}&limit=$pageSize';
  }

  /// Add User Interests Endpoint
  static const String addUserInterests = '/profile/interests/';

  /// Add User Life Categories Endpoint
  static const String addUserLifeCategories = '/profile/life-makeup/';

  /// Upload Contacts
  static const String uploadContacts = '/user/address-book/';

  /// Pre-Follow
  static const String preFollow = '/user/pre-follow/';

  /// Feed

  static String feedPosts({int pageNo = 1, int pageSize = 10, bool glimpse = false,}) => "${_posts}feeds/?glimpse_enabled=$glimpse&offset=${(pageNo - 1) * pageSize}&limit=$pageSize";
  static String feedHighlights({int pageNo = 1, int pageSize = 10,}) => "/highlights/feeds/?offset=${(pageNo - 1) * pageSize}&limit=$pageSize";
  static String userGlimpses({int pageNo = 1, int pageSize = 10, required String userId,}) => "${_posts}glimpse-user/$userId/?offset=${(pageNo - 1) * pageSize}&limit=$pageSize";
  static String myGlimpses({int pageNo = 1, int pageSize = 10,}) => "${_posts}glimpses/?offset=${(pageNo - 1) * pageSize}&limit=$pageSize";
  static String disappearingFeedPosts({int pageNo = 1, int pageSize = 10, bool glimpse = false}) => "${_posts}disappear-feeds/?glimpse_enabled=$glimpse&offset=${(pageNo - 1) * pageSize}&limit=$pageSize";
  static String userFeedPosts({String? owner, int pageNo = 1, int pageSize = 10, bool glimpse = false}) => "${_posts}profile/?glimpse_enabled=$glimpse&offset=${(pageNo - 1) * pageSize}&limit=$pageSize${owner != null ? "&user_id=$owner" : ""}";
  static String userTagFeedPosts({String? owner, int pageNo = 1, int pageSize = 10, bool glimpse = false}) => "${_posts}profile-tag/?glimpse_enabled=$glimpse&offset=${(pageNo - 1) * pageSize}&limit=$pageSize${owner != null ? "&user_id=$owner" : ""}";
  static String userPrivateFeedPosts({int pageNo = 1, int pageSize = 10, bool glimpse = false}) => "${_posts}private/?glimpse_enabled=$glimpse&offset=${(pageNo - 1) * pageSize}&limit=$pageSize";
  static String getHighlights({int pageNo = 1, int pageSize = 10}) => "/highlights/bookmark/?offset=${(pageNo - 1) * pageSize}&limit=$pageSize";

  static String getPosts(
      {int pageNo = 1,
      int pageSize = 10,
      PostsFilterByType type = PostsFilterByType.suggested,
      List<String>? categories,
      String? owner,
      String? id}) {
    String uri = "$_posts?";

    /// Adds the categories
    if (categories != null && categories.isNotEmpty) {
      uri = "${Uri(path: _posts, queryParameters: {"category": categories})}&";
    }

    /// Adds pagination
    uri = '${uri}offset=${(pageNo - 1) * pageSize}&limit=$pageSize';

    /// Adds owner or type
    if (owner != null && owner.isNotEmpty) {
      uri = "$uri&owner=$owner&type=${type.name == PostsFilterByType.suggested.name ? "suggestion" : type.name}";
    } else if (type == PostsFilterByType.collection) {
      uri = "$uri&collections=$id";
    } else if (type == PostsFilterByType.nupp) {
      uri += "&nupp=$id";
    } else {
      uri = "$uri&type=${type.name == PostsFilterByType.suggested.name ? "suggestion" : type.name}";
    }
    return uri;
  }

  /// Element Feed

  static String getElementsPosts({
    int pageNo = 1,
    int pageSize = 10,
    required String elementId,
    bool glimpse = false,
  }) => "$_posts$elementId/element/?glimpse_enabled=$glimpse&offset=${(pageNo - 1) * pageSize}&limit=$pageSize";

  /// Circle Feed

  static String getCirclePosts({
    int pageNo = 1,
    int pageSize = 10,
    required String circleId,
    bool glimpse = false,
  }) => "/circles/posts/$circleId/?glimpse_enabled=$glimpse&offset=${(pageNo - 1) * pageSize}&limit=$pageSize";

  static String circleQuestionReplyFeed({
    int pageNo = 1,
    int pageSize = 10,
    required String questionId,
    bool glimpse = false,
      }) => "/posts/$questionId/circle-questions/?glimpse_enabled=$glimpse&offset=${(pageNo - 1) * pageSize}&limit=$pageSize";

  static String postCircleQuestion(String id) => '/circles/$id/question/';

  static String postById({required String id}) => '$_posts$id/';

  static String applaudPost(String id) => '$_posts$id/applaud/';

  static String bookmarkPost(String id) => '$_posts$id/bookmark/';

  static String deletePost(String id) => '$_posts$id/';

  static String flagPost(String id) => '$_posts$id/flag/';

  static String getPostHighlights(
    String id, {
    int pageNo = 1,
    int pageSize = 10,
  }) =>
      '$_posts$id/highlights/?offset=${(pageNo - 1) * pageSize}&limit=$pageSize';

  static String getPostsCategories({
    int pageNo = 1,
    int pageSize = 10,
    PostsFilterByType? type,
  }) {
    if (type != null) {
      return '${_posts}categories/?type=${type.name == PostsFilterByType.suggested.name ? "suggestion" : type.name}&offset=${(pageNo - 1) * pageSize}&limit=$pageSize';
    }
    return '${_posts}categories/?offset=${(pageNo - 1) * pageSize}&limit=$pageSize';
  }

  static String getPostsCollectionTypes({
    bool isCustom = false,
    int pageNo = 1,
    int pageSize = 10,
  }) {
    return '${_collections}types/?offset=${(pageNo - 1) * pageSize}&limit=$pageSize&is_custom=$isCustom';
  }

  static String getPostsCollections({
    int pageNo = 1,
    int pageSize = 10,
  }) {
    return '$_collections?offset=${(pageNo - 1) * pageSize}&limit=$pageSize';
  }

  /// Prompts
  static const String prompt = "/prompt/";

  /// Create Post Endpoint
  static const String createPostFeed = _posts;

  /// Create Post Endpoint
  static String updatePostFeed(String id) => "$_posts$id/";

  /// Update post level
  static String updatePostLevel(String id) => "$_posts$id/level/";

  /// Add Post Media Endpoint
  static String addPostMedia(String id) => '$_posts$id/media/';

  /// Add Post Media Endpoint
  static String get uploadMedia => '${_posts}media/';

  /// Delete Post Media Endpoint
  static String deletePostMedia(String id) => '${_posts}media/$id';

  /// Create Circle Endpoint
  static const String createCircle = "/circles/";

  /// Edit Circle Endpoint
  static String editCircle(String id) => "/circles/$id/";

  /// My Circles Endpoint
  static String myCircles({int pageNo = 1, int pageSize = 10}) => "/circles/lists/?offset=${(pageNo - 1) * pageSize}&limit=$pageSize";

  /// Circle members Endpoint
  static String circleMembers(String id, {int pageNo = 1, int pageSize = 10}) => "/circles/members/$id/?offset=${(pageNo - 1) * pageSize}&limit=$pageSize";

  /// Circle member requests Endpoint
  static String circleMemberRequests(String id, {int pageNo = 1, int pageSize = 10}) => "/circles/requests/$id/?offset=${(pageNo - 1) * pageSize}&limit=$pageSize";

  /// Sub Circles Endpoint
  static String subCircles(String id, {int pageNo = 1, int pageSize = 10}) => "/circles/sub-circles/$id/?offset=${(pageNo - 1) * pageSize}&limit=$pageSize";

  /// Add Circle Avatar Endpoint
  static String get uploadCircleMedia => '/circles/media/upload/';

  /// Update Circle Avatar Endpoint
  static String updateCircleMedia(String id) => '/circles/media/$id/';

  /// Delete Circle Avatar Endpoint
  static String deleteCircleMedia(String id) => '/circles/media/$id';

  /// Get Simple Circles Endpoint
  static String getSimpleCircles({PaginationParams pageInfo = const PaginationParams(),}) => '/circles/simples/?limit=${pageInfo.pageSize}&offset=${(pageInfo.pageNo - 1) * pageInfo.pageSize}';

  /// Get Circle Detail
  static String getCircleDetail(String id) => "/circles/$id/";

  /// Accept Circle Invitation
  static String acceptCircleInvitation(String id) => "/circles/$id/accept/";

  /// Approve Circle join request
  static String approveCircleJoinRequest(String id) => "/circles/$id/approve/";

  /// Request Join Circle
  static String requestJoinToCircle(String id) => "/circles/$id/join/";

  /// Leave Circle
  static String leaveCircle(String id) => "/circles/$id/leave/";

  /// Add sub Circle
  static String addSubCircle(String id) => "/circles/$id/nested/";

  /// Update circle member
  static String updateCircleMember(String id) => "/circles/$id/members/";


  /// Create Highlight Endpoint
  static const String createHighlight = "/highlights/";

  static String applaudHighlight(String id) => '/highlights/$id/applaud/';

  static String bookmarkHighlight(String id) => '/highlights/$id/bookmark/';

  static String flagHighlight(String id) => '/highlights/$id/flag/';

  static String deleteHighlight(String id) => '/highlights/$id/';

  /// Get Post Segments Endpoint
  static String getPostSegments({
    PaginationParams pageInfo = const PaginationParams(),
  }) {
    final String baseUri =
        '${_posts}categories/?offset=${(pageInfo.pageNo - 1) * pageInfo.pageSize}&limit=${pageInfo.pageSize}';

    return baseUri;
  }

  /// Get Post Categories Endpoint
  static String getPostCategories({
    String segment = '',
    int pageNo = 1,
    int pageSize = 10,
    PostsFilterByType? type,
  }) {
    final String baseUri =
        '${_posts}categories/?${segment.isNotEmpty ? 'segment=$segment&' : ''}offset=${(pageNo - 1) * pageSize}&limit=$pageSize';
    if (type != null) {
      return '$baseUri&type=${type.name == PostsFilterByType.suggested.name ? "suggestion" : type.name}';
    }
    return baseUri;
  }

  /// Get Post Categories Endpoint
  static String getPostTags({
    String categoryId = '',
    int pageNo = 1,
    int pageSize = 10,
  }) {
    return '${_posts}tags/?${categoryId.isEmpty ? '' : 'category=$categoryId&'}&offset=${(pageNo - 1) * pageSize}&limit=$pageSize';
  }

  /// Get User Profile Endpoint
  static getProfileData({String userId = ''}) => '/user/$userId/';

  /// Update User Profile Endpoint
  static String get myProfile => '/profile/';
  static String get updateUsername => '/user/update/username/';

  /// Follow user
  static follow({String userId = ''}) => '/user/$userId/follow/';

  /// Get Followers
  static getFollowers({
    String userId = '',
    PaginationParams pageInfo = const PaginationParams(),
  }) =>
      '/user/$userId/followers/?limit=${pageInfo.pageSize}&offset=${(pageInfo.pageNo - 1) * pageInfo.pageSize}';

  /// Get Following
  static getFollowing({
    String userId = '',
    PaginationParams pageInfo = const PaginationParams(),
  }) =>
      '/user/$userId/following/?limit=${pageInfo.pageSize}&offset=${(pageInfo.pageNo - 1) * pageInfo.pageSize}';

  /// Get Autocomplete Nupps Endpoint
  static getAutocompleteNupps({
    String segment = '',
    String query = '',
    String? categoryId,
    String? location,
    PaginationParams pageInfo = const PaginationParams(),
  }) {
    return '/nupp/autocomplete/?segment=$segment&q=$query${location != null ? '&location=$location' : ''}${categoryId != null ? '&category=$categoryId' : ''}&offset=${(pageInfo.pageNo - 1) * pageInfo.pageSize}&limit=${pageInfo.pageSize}';
  }

  /// Get Autocomplete places Endpoint
  static getAutocompletePlaces({
    String? query,
    PaginationParams pageInfo = const PaginationParams(),
    String? location,
  }) {
    return '/experience/autocomplete/?${(query?.isNotEmpty ?? false) ? "query=$query&" : ""}offset=${(pageInfo.pageNo - 1) * pageInfo.pageSize}&limit=${pageInfo.pageSize}${location != null ? '&location=$location' : ''}';
  }

  /// Get Place Detail
  static placeDetail({required String placeId}) => '/location/detail/?place_id=$placeId';
  static placeDetailFromLocation({required String location}) => '/location/nearbysearch/?location=$location';

  /// User Profile Story
  static getProfileUserStory({String userId = ''}) => '/user/$userId/stories/';

  /// Edit Post Endpoint
  static editPost({required String postId}) => '$_posts$postId/edit/';

  /// Create Post Collection
  static String get createPostCollection => _collections;

  /// Manage Post Collection
  static postCollection({required String id}) => '$_collections$id/';

  /// Search For Mentions
  static searchForMentions({
    required String query,
    PaginationParams pageInfo = const PaginationParams(),
  }) {
    return '/mention/search/?q=$query&offset=${(pageInfo.pageNo - 1) * pageInfo.pageSize}&limit=${pageInfo.pageSize}';
  }

  /// Invite User Endpoint
  static const String inviteUserEndpoint = '/user/invite/';

  /// Posts Influences
  static const String influencesPosts = '/influences/posts/';

  /// Nupp Details Endpoint
  static String nuppDetailsEndpoint(String nuppId) => '/nupp/$nuppId/';

  /// App Content Endpoint
  static String appContentEndpoint(String type) => '/content/$type/';

  /// Search Nupps and Users endpoint
  static String searchForNuppsAndUsersEndpoint(
    String query,
    PaginationParams pageInfo,
  ) {
    return '/search/?q=$query&limit=${pageInfo.pageSize}&&offset=${(pageInfo.pageNo - 1) * pageInfo.pageSize}';
  }

  /// Search Users endpoint
  static String searchUsersEndpoint(
    String query,
    PaginationParams pageInfo,
  ) {
    return '/user/search/?username=$query&limit=${pageInfo.pageSize}&&offset=${(pageInfo.pageNo - 1) * pageInfo.pageSize}';
  }

  /// In-App Notifications Endpoint
  static String inAppNotificationsEndpoint(PaginationParams pageInfo) {
    return '/notifications/?limit=${pageInfo.pageSize}&offset=${(pageInfo.pageNo - 1) * pageInfo.pageSize}';
  }

  /// Mark Notification As Viewed Endpoint
  static String markNotificationAsViewedEndpoint(String id) {
    return '/notifications/$id/viewed/';
  }
  /// Delete Notification Endpoint
  static String deleteNotification(String id) {
    return '/notifications/$id/';
  }

  /// Get Life Story Questions Endpoint
  static String lifeStoryQuestionsEndpoint(
    PaginationParams pageInfo, {
    String? collection,
  }) {
    if (collection != null) {
      return '/story/questions/?collection=$collection&limit=${pageInfo.pageSize}&offset=${(pageInfo.pageNo - 1) * pageInfo.pageSize}';
    }
    return '/story/questions/?limit=${pageInfo.pageSize}&offset=${(pageInfo.pageNo - 1) * pageInfo.pageSize}';
  }

  /// Improve Text with AI Endpoint
  static const String improveStoryTextWithAIEnpoint = '/story/comppletion/';
  static const String aiConvertText = '/story/improve-text/';

  /// Get Post Applauds list Endpoint
  static String postApplauds(
    String postId, {
    PaginationParams pageInfo = const PaginationParams(),
  }) => '/posts/$postId/applaud/?limit=${pageInfo.pageSize}&offset=${(pageInfo.pageNo - 1) * pageInfo.pageSize}';

  /// Delete User Account Endpoint
  static String deleteUserAccount({required String userId}) =>
      '/user/delete-account/$userId/';

  static const String getUserInvitationsCount = '/user/invite/count/';

  static String validateInviteCode(String inviteCode) {
    return '/user/invite/valid/$inviteCode/';
  }

  static String blockUser({required String userId}) => '/user/$userId/block/';
}
