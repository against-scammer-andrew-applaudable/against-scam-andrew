import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart' as geo;
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import 'package:permission_handler/permission_handler.dart' as perm_handler;

mixin LocationMixin {
  Future<LatLng?> getLocationOnlyIfPermissionAccepted({
    bool isFirstFetch = false,
    bool openSettingsIfDenied = false,
  }) async {
    Location location = Location();

    bool serviceEnabled;
    PermissionStatus permissionStatus;

    serviceEnabled = await location.serviceEnabled();
    if (!serviceEnabled) {
      serviceEnabled = await location.requestService();
      if (!serviceEnabled) {
        return null;
      }
    }

    permissionStatus = await location.hasPermission();
    if (permissionStatus == PermissionStatus.denied) {
      permissionStatus = await location.requestPermission();
      if (permissionStatus != PermissionStatus.granted) {
        if (openSettingsIfDenied) perm_handler.openAppSettings();
        return null;
      }
    }

    debugPrint('Getting User Location...');
    final userLocation = await geo.Geolocator.getCurrentPosition(
      desiredAccuracy: geo.LocationAccuracy.high,
    );

    return LatLng(userLocation.latitude, userLocation.longitude);
  }
}

extension LatLngExstensions on LatLng? {
  String? asParamValue() =>
      this == null ? null : '${this!.latitude}, ${this!.longitude}';
}
