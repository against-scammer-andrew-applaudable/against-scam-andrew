mixin Pagination<T> {
  int pageNo = 1;
  int currentPageNo = 1;

  bool allowNewPaginationRequests = true;
  bool isRefetchingSamePage = false;

  void verifyAllowNewPaginationRequests(List<T> items) {
    if (items.isEmpty) {
      allowNewPaginationRequests = false;
    }
  }

  void resetPagination() {
    pageNo = 1;
    currentPageNo = pageNo;
    allowNewPaginationRequests = true;
    isRefetchingSamePage = false;
  }
}
