import 'package:flutter/material.dart';

import '../../features/post/domain/entities/post_entities.dart';
import '../../features/post/domain/enums/post_enums.dart';
import '../../features/post/presentation/widgets/mention_view.dart';
import '../extensions/list_extensions.dart';
import '../utils/emoji.dart';

mixin MentionsMixin {
  handleMentionsInText(
    String text,
    BuildContext context, {
    TextStyle? style,
    List<PostMention> mentions = const [],
    List<PostElement> elements = const [],
    EmojiHandler? emoji,
  }) {
    return TextSpan(
      style: style,
      children: elements.map<InlineSpan>(
        (e) {
          String textToRender = "";

          switch (e.type) {
            case PostElementType.user:
              textToRender = getLabel(
                id: e.userId!,
                type: PostElementType.user,
                mentions: mentions,
              );

              return TextSpan(children: <InlineSpan>[
                WidgetSpan(child: MentionView.atSign(style, context)),
                WidgetSpan(
                  child: MentionView.user(
                    text: textToRender,
                    id: e.userId,
                  ),
                )
              ]);
            case PostElementType.nupp:
              textToRender = getLabel(
                id: e.nuppId!,
                type: PostElementType.nupp,
                mentions: mentions,
              );

              return TextSpan(children: <InlineSpan>[
                WidgetSpan(child: MentionView.hashSign(style, context)),
                WidgetSpan(
                  child: MentionView.nupp(
                    text: textToRender,
                    id: e.userId,
                  ),
                )
              ]);
            case PostElementType.invite:
              textToRender = getLabel(
                id: e.inviteId!,
                type: PostElementType.invite,
                mentions: mentions,
              );
              break;
            case PostElementType.emoji:
              textToRender = e.text != null
                  ? emoji?.parse(e.text!, unicode: e.unicode) ?? ""
                  : "";
              break;
            case PostElementType.text:
              textToRender = e.text ?? "";
              break;
            case PostElementType.richText:
              break;
          }

          return WidgetSpan(child: Text(textToRender, style: style));
        },
      ).toList(),
    );
  }

  String getLabel({
    required String id,
    required PostElementType type,
    List<PostMention> mentions = const [],
  }) {
    return mentions
            .firstWhereOrNull(
                (mention) => mention.id == id && mention.type.name == type.name)
            ?.label ??
        "";
  }
}
