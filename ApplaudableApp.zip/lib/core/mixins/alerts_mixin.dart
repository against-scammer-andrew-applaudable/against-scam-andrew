// ignore_for_file: use_build_context_synchronously

import 'dart:io';

import 'package:applaudable/core/constants/constant_values.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

import '../../app_module.dart';
import '../../generated/l10n.dart';
import '../theme/colors.dart';
import '../theme/dimensions.dart';
import '../theme/styles.dart';
import '../../features/auth/presentation/widgets/buttons/action_button.dart';
import '../constants/constant_keys.dart';
import '../extensions/app_module_extensions.dart';
import '../extensions/build_context_extensions.dart';
import '../widgets/toast/app_toast.dart';

mixin AlertsMixin {
  Future<File?> showImagePickerSheet(BuildContext context) async {
    final translations = S.of(context);

    final source = await showCupertinoModalPopup<ImageSource?>(
      context: context,
      barrierColor: AppColors.dark.withOpacity(0.7),
      builder: (BuildContext context) {
        return SafeArea(
          key: ConstantKeys.avatarImageSourceKey,
          child: Padding(
            padding: const EdgeInsets.all(
              AppDimensions.defaultSidePadding,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                AppActionButton.submit(
                  key: ConstantKeys.chooseFromLibraryKey,
                  backgroundColor: Colors.white,
                  enableGradient: false,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(24),
                    topRight: Radius.circular(24),
                  ),
                  text: translations.photo_gallery,
                  actionTextColor: Colors.blue,
                  actionTextWeight: FontWeight.w500,
                  onPressed: () {
                    context.pop(ImageSource.gallery);
                  },
                ),
                const Divider(
                  height: 1,
                  color: AppColors.lightGrey,
                  thickness: 1,
                ),
                AppActionButton.submit(
                  key: ConstantKeys.takePhotoKey,
                  backgroundColor: Colors.white,
                  enableGradient: false,
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(24),
                    bottomRight: Radius.circular(24),
                  ),
                  text: translations.camera,
                  actionTextColor: Colors.blue,
                  actionTextWeight: FontWeight.w500,
                  onPressed: () {
                    context.pop(ImageSource.camera);
                  },
                ),
                const SizedBox(height: AppDimensions.mediumSidePadding),
                AppActionButton.submit(
                  key: ConstantKeys.cancelKey,
                  backgroundColor: Colors.white,
                  enableGradient: false,
                  onPressed: () {
                    // AppModule.I.pop();
                    Navigator.of(context).pop();
                  },
                  text: translations.cancel,
                  actionTextColor: Colors.blue,
                  actionTextWeight: FontWeight.w700,
                ),
              ],
            ),
          ),
        );
      },
    );

    if (source != null) {
      return pickImageFromSource(context, source);
    }

    return null;
  }
  Future<PickedSourceModel?> showCameraPickerSheet(BuildContext context) async {
    final translations = S.of(context);

    final source = await showCupertinoModalPopup<bool?>(
      context: context,
      barrierColor: AppColors.dark.withOpacity(0.7),
      builder: (BuildContext context) {
        return SafeArea(
          key: ConstantKeys.avatarImageSourceKey,
          child: Padding(
            padding: const EdgeInsets.all(
              AppDimensions.defaultSidePadding,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                AppActionButton.submit(
                  key: ConstantKeys.chooseFromLibraryKey,
                  backgroundColor: Colors.white,
                  enableGradient: false,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(24),
                    topRight: Radius.circular(24),
                  ),
                  text: "Take a photo",
                  actionTextColor: Colors.blue,
                  actionTextWeight: FontWeight.w500,
                  onPressed: () {
                    context.pop(false);
                  },
                ),
                const Divider(
                  height: 1,
                  color: AppColors.lightGrey,
                  thickness: 1,
                ),
                AppActionButton.submit(
                  key: ConstantKeys.takePhotoKey,
                  backgroundColor: Colors.white,
                  enableGradient: false,
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(24),
                    bottomRight: Radius.circular(24),
                  ),
                  text: "Take a video",
                  actionTextColor: Colors.blue,
                  actionTextWeight: FontWeight.w500,
                  onPressed: () {
                    context.pop(true);
                  },
                ),
                const SizedBox(height: AppDimensions.mediumSidePadding),
                AppActionButton.submit(
                  key: ConstantKeys.cancelKey,
                  backgroundColor: Colors.white,
                  enableGradient: false,
                  onPressed: () {
                    // AppModule.I.pop();
                    Navigator.of(context).pop();
                  },
                  text: translations.cancel,
                  actionTextColor: Colors.blue,
                  actionTextWeight: FontWeight.w700,
                ),
              ],
            ),
          ),
        );
      },
    );

    if (source != null) {
      return pickAssetFromCamera(context, source);
    }

    return null;
  }

  Future<PickedSourceModel?> pickAssetFromCamera(
    BuildContext context,
    bool isVideo,
  ) async {
    try {
      XFile? pickedImage;
      if (!isVideo) {
        pickedImage = await ImagePicker().pickImage(source: ImageSource.camera);
      } else {
        pickedImage = await ImagePicker().pickVideo(source: ImageSource.camera, maxDuration: const Duration(seconds: ConstantValues.maxVideoLengthInSec));
      }

      if (pickedImage != null) return PickedSourceModel(File(pickedImage.path), isVideo);
    } on PlatformException catch (err) {
      debugPrint('Failed to pick an image: $err}');

      AppModule.I.notify(
        context,
        err.message ?? 'Failed to pick an image: $err',
        mode: AppToastMode.error,
      );
    } catch (err) {
      debugPrint(err.runtimeType.toString());
      debugPrint('Failed to pick an image: $err');

      AppModule.I.notify(
        context,
        'Failed to pick an image: $err',
        mode: AppToastMode.error,
      );
    }

    return null;
  }
  Future<PickedSourceModel?> pickAssetFromLibrary(
    BuildContext context,
    bool isVideo,
  ) async {
    try {
      XFile? pickedImage;
      if (!isVideo) {
        pickedImage = await ImagePicker().pickImage(source: ImageSource.gallery);
      } else {
        pickedImage = await ImagePicker().pickVideo(source: ImageSource.gallery, maxDuration: const Duration(seconds: ConstantValues.maxVideoLengthInSec));
      }

      if (pickedImage != null) return PickedSourceModel(File(pickedImage.path), isVideo);
    } on PlatformException catch (err) {
      debugPrint('Failed to pick an image: $err}');

      AppModule.I.notify(
        context,
        err.message ?? 'Failed to pick an image: $err',
        mode: AppToastMode.error,
      );
    } catch (err) {
      debugPrint(err.runtimeType.toString());
      debugPrint('Failed to pick an image: $err');

      AppModule.I.notify(
        context,
        'Failed to pick an image: $err',
        mode: AppToastMode.error,
      );
    }

    return null;
  }
  Future<File?> pickImageFromSource(
    BuildContext context,
    ImageSource source,
  ) async {
    try {
      final pickedImage = await ImagePicker().pickImage(source: source);

      if (pickedImage != null) return File(pickedImage.path);
    } on PlatformException catch (err) {
      debugPrint('Failed to pick an image: $err}');

      AppModule.I.notify(
        context,
        err.message ?? 'Failed to pick an image: $err',
        mode: AppToastMode.error,
      );
    } catch (err) {
      debugPrint(err.runtimeType.toString());
      debugPrint('Failed to pick an image: $err');

      AppModule.I.notify(
        context,
        'Failed to pick an image: $err',
        mode: AppToastMode.error,
      );
    }

    return null;
  }

  Future<R?> showBottomOptionsSelector<T, R>({
    required BuildContext context,
    required List<T> options,
    required String Function(T) optionFormatter,
    bool hasCancelOption = true,
    TextStyle? optionsStyle,
    TextStyle? cancelOptionStyle,
    Function(T)? onOptionTapped,
    Function()? onCancelTapped,
  }) {
    final translations = S.of(context);

    if (Platform.isIOS) {
      return showCupertinoModalPopup<R?>(
        context: context,
        builder: (ctx) {
          return CupertinoActionSheet(
            actions: options.map(
              (option) {
                return CupertinoActionSheetAction(
                  onPressed: () {
                    ctx.pop();
                    onOptionTapped?.call(option);
                  },
                  child: Text(
                    optionFormatter(option),
                    style: optionsStyle ?? AppStyles.text2(color: context.textColor),
                  ),
                );
              },
            ).toList(),
            cancelButton: hasCancelOption
                ? CupertinoActionSheetAction(
                    onPressed: () {
                      ctx.pop();
                      onCancelTapped?.call();
                    },
                    child: Text(
                      translations.cancel,
                      style: cancelOptionStyle ??
                          AppStyles.text2(color: AppColors.primaryColor)
                              .copyWith(fontWeight: FontWeight.w700),
                    ),
                  )
                : null,
          );
        },
      );
    }

    return showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppDimensions.radius_20),
      ),
      builder: (ctx) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ...options.map(
                (option) {
                  return CupertinoActionSheetAction(
                    onPressed: () {
                      ctx.pop();
                      onOptionTapped?.call(option);
                    },
                    child: Row(
                      children: [
                        Text(
                          optionFormatter(option),
                          style: optionsStyle ?? AppStyles.text2(color: context.textColor),
                        ),
                      ],
                    ),
                  );
                },
              ).toList(),
              if (hasCancelOption)
                CupertinoActionSheetAction(
                  onPressed: () {
                    ctx.pop();
                    onCancelTapped?.call();
                  },
                  child: Row(
                    children: [
                      Text(
                        translations.cancel,
                        style: cancelOptionStyle ??
                            AppStyles.text2(color: AppColors.primaryColor)
                                .copyWith(fontWeight: FontWeight.w700),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class PickedSourceModel {
  File file;
  late bool isVideo;
  PickedSourceModel(this.file, this.isVideo);
}