import 'dart:developer';
import 'dart:io';

import 'package:applaudable/core/extensions/app_module_extensions.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app_module.dart';
import '../../features/onboarding/domain/usecases/upload_user_avatar.dart';
import '../../features/onboarding/presentation/blocs/user_avatar_cubit/user_avatar_cubit.dart';
import '../pages/image_preview_page.dart';

mixin ProfileAvatarMixin {
  Future<void> openProfileAvatarPreview(
    BuildContext context,
    File imageToPreview, {
    String title = '',
    Function()? onUploadComplete,
  }) async {
    AppModule.I.navigateToNamed(
      ImagePreviewPage.routeName,
      arguments: ImagePreviewArgs(
        image: imageToPreview,
        imageTitle: title,
        uploadImageCallback: (File image) async {
          final bloc = context.read<UserAvatarCubit>();

          return await bloc.uploadUserAvatarToServer(
            avatar: AvatarParams(
              mediaFile: image,
              onSendProgress: (current, total) {
                log('Current: $current, Total: $total');
              },
            ),
          );
        },
        onUploadComplete: onUploadComplete,
      ),
    );
  }
}
