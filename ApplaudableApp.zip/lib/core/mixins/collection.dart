import 'package:flutter/widgets.dart';

import '../entities/item.dart';

mixin CollectionListMixin<T extends Item<T>> {
  final List<T> _items = [];

  List<T> get items => _items.toSet().toList();

  T? _currentItem;
  T? get currentItem => _currentItem;
  set currentItem(T? value) {
    _currentItem = value;
  }

  bool get hasItems => _items.isNotEmpty;

  T? item(String id) {
    List<T> listItems = _items.where((element) => element.id == id).toList();
    if (listItems.isEmpty) {
      return null;
    }
    return listItems.first;
  }

  void addItem(T item, {int position = 0}) => _items.insert(position, item);

  void updateItems(List<T> items) {
    _items.addAll(items);
  }

  void deleteItem(String id) => _items.removeWhere((element) {
        debugPrint("E ${element.id} ${element.name} $id");

        return (element.id == id);
      });

  void replaceItem(String id, T Function(T element) copy) {
    List<T> listItems = _items.where((element) => element.id == id).toList();
    if (listItems.isEmpty) {
      return;
    }

    T first = listItems.first;

    T updatedItem = copy(first);

    _items[_items.indexOf(first)] = updatedItem;
  }

  bool containsId(String id) {
    int index = _items.indexWhere((element) => element.id == id);
    if (index == -1) {
      return false;
    }
    return true;
  }

  void clearItems() => _items.clear();
}

class CollectionList<T extends Item<T>> with CollectionListMixin<T> {}
