import '../../model/post/experience.dart';
import '../api/api/api.dart';
import '../enums/post.dart';

class AppExperienceElementsManager {
  static final AppExperienceElementsManager _singleton = AppExperienceElementsManager._internal();
  factory AppExperienceElementsManager() {
    return _singleton;
  }
  AppExperienceElementsManager._internal();

  List<PostExperienceModel> experiences = [];

  List<PostExperienceModel> get personExperiences => experiences.where((element) => element.type == PostExperienceType.person).toList();
  List<PostExperienceModel> get experienceExperiences => experiences.where((element) => element.type != PostExperienceType.person).toList();

  Future loadExperiences() async {
    final res = await APIs().getExperienceElements();
    if (res is List<PostExperienceModel>) {
      experiences = res;
      experiences.sort((m1, m2) => m2.rate.compareTo(m1.rate));
    }
  }
  List<PostExperienceModel> sortExperienceElements() {
    final experienceElements = experiences.where((element) => element.type != PostExperienceType.person).toList();
    experienceElements.sort((m1, m2) => m2.rate.compareTo(m1.rate));

    final bigElements = experienceElements.sublist(0, 5);
    final smallElements = experienceElements.sublist(5, experienceElements.length);
    bigElements.shuffle();
    smallElements.shuffle();
    return [...bigElements, ...smallElements];
  }
}