import 'package:flutter/cupertino.dart';

import '../../features/notifications/data/models/in_app_notification_model.dart';
import '../api/api/api.dart';

class AppNotificationsManager {
  static final AppNotificationsManager _singleton = AppNotificationsManager._internal();
  factory AppNotificationsManager() {
    return _singleton;
  }
  AppNotificationsManager._internal();

  List<InAppNotificationModel>? inAppNotifications;

  final cntNewNotifications = ValueNotifier(0);

  Future loadInAppNotifications() async {
    final res = await APIs().getMyNotifications();
    if (res is List<InAppNotificationModel>) {
      calculateNewNotifications(res);
    }
  }
  void calculateNewNotifications(List<InAppNotificationModel> notifications) {
    inAppNotifications = notifications;
    cntNewNotifications.value = notifications.where((element) => !element.viewed).length;
  }
}