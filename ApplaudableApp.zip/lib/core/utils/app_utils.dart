// ignore_for_file: use_build_context_synchronously

import 'dart:async';

import 'package:applaudable/app_module.dart';
import 'package:applaudable/core/api/api/api.dart';
import 'package:applaudable/core/enums/tab.dart';
import 'package:applaudable/core/extensions/app_module_extensions.dart';
import 'package:applaudable/model/other/app_version.dart';
import 'package:applaudable/model/post/feed.dart';
import 'package:applaudable/ui/widget/dialog/center/update/app_update.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:phone_number/phone_number.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../features/feed/domain/entities/post_response.dart';
import '../../generated/l10n.dart';
import '../../model/action/user_action.dart';
import '../controllers/dng_links_controller.dart';

class AppUtils {
  static final AppUtils _singleton = AppUtils._internal();
  factory AppUtils() {
    return _singleton;
  }

  static String fontFamily = "Inter";

  AppUtils._internal();

  BuildContext? tabContext;
  CupertinoTabController? tabBarController;
  final Map<TabBarType, GlobalKey<NavigatorState>> tabBarNavKeys = {};
  final loadingIndicator = ValueNotifier(false);
  final loadingIndicatorInPage = ValueNotifier(false);
  final ValueNotifier<bool> scrollEnabledByZooming = ValueNotifier(true);
  final appUserActionStream = StreamController<AppUserActionModel>.broadcast();
  final addedNewPostStream = StreamController<FeedPostModel>.broadcast();

  String? sharedCircleIdFromAuthentication;

  EdgeInsets safeArea(BuildContext context) =>
      MediaQuery
          .of(context)
          .padding;

  double safePaddingTop(BuildContext context) =>
      MediaQuery
          .of(context)
          .padding
          .top;

  double safePaddingBottom(BuildContext context) =>
      MediaQuery
          .of(context)
          .padding
          .bottom;

  Size screenSize(BuildContext context) =>
      MediaQuery
          .of(context)
          .size;
  double screenWidth = 300;

  Future initializeConfiguration() async {
    await Future.delayed(const Duration(seconds: 1));
    final appVersion = await APIs().checkAppVersion();
    if (appVersion is AppVersionModel) {
      final versionInfo = await PackageInfo.fromPlatform();
      final currentVersion = versionInfo.version;
      final mode = appVersion.checkUpdateNeeded(currentVersion);
      if (AppModule.instance.navigatorKey.currentContext != null && mode != UpdateType.none) {
        AppUpdateDialog.showDialog(AppModule.instance.navigatorKey.currentContext!, updateMode: UpdateType.force);
      }
    }
  }
  Future sharePost(BuildContext context, Post item) async {
    var generateLink = await DngLinksController.I.generateLink({"id": item.id});
    debugPrint("LINK: $generateLink");

    if (generateLink.toString().isNotEmpty && context.mounted) {
      HapticFeedback.lightImpact();
      await Share.share('Check out this applause $generateLink', subject: item.name);
    }
  }
  static TextPainter getTextSize({
    required String text,
    required double maxWidth,
    int? maxLines,
    TextStyle? style,
  }) {
    final tp = TextPainter(
      text: TextSpan(text: text.trim(), style: style),
      maxLines: maxLines,
      textDirection: TextDirection.ltr,
    );

    tp.layout(maxWidth: maxWidth);

    return tp;
  }
  Future<bool> validatePhoneNumber(String? phone, {String? regionCode}) async {
    if (phone == null) return false;
    try {
      final res = await PhoneNumberUtil().validate(phone, regionCode: regionCode);
      return res;
    } catch(e) {
      return false;
    }
  }
}
class BlankTabBar extends CupertinoTabBar {
  static double tabBarHeight = 50;
  BlankTabBar({
    key,
    items,
  }) : super(
      key: key,
      items: items,
      currentIndex: 0,
      backgroundColor: Colors.transparent,
      activeColor: Colors.transparent,
      inactiveColor: Colors.transparent,
      iconSize: 0,
      border: const Border(),
      height: BlankTabBar.tabBarHeight,
  );

  @override
  Size get preferredSize => Size.fromHeight(BlankTabBar.tabBarHeight);
}
double getDouble(dynamic value) {
  if (value is double) {
    return value;
  }
  if (value is int) {
    return value.toDouble();
  }
  if (value is String) {
    try {
      return double.parse(value);
    } catch(e) {
      return 0.0;
    }
  }
  return 0.0;
}
double? getDoubleNullable(dynamic value) {
  if (value is double) {
    return value;
  }
  if (value is int) {
    return value.toDouble();
  }
  if (value is String) {
    try {
      return double.parse(value);
    } catch(_) {}
  }
  return null;
}
String? getNullableString(dynamic value) {
  if (value is double) {
    return value.toString();
  }
  if (value is int) {
    return value.toString();
  }
  if (value is String) {
    return value;
  }
  if (value != null) {
    return value.toString();
  }
  return null;
}
int getInt(dynamic value) {
  if (value is double) {
    return value.toInt();
  }
  if (value is int) {
    return value;
  }
  if (value is String) {
    try {
      return int.parse(value);
    } catch(e) {
      return 0;
    }
  }
  return 0;
}
DateTime? getDateNullable(dynamic data) {
  if (data is String && data.isNotEmpty) {
    try {
      return DateTime.parse(data);
    } catch(_) {}
  }
  return null;
}
