import 'package:get_time_ago/get_time_ago.dart';

String getTimeAgo(DateTime? dateTime) {
  if (dateTime == null) {
    return "";
  }

  final yearDifference = DateTime.now().year - dateTime.year;

  String pattern = "MMM dd yyyy hh:mm a";
  if (yearDifference < 1) {
    pattern = "MMM dd hh:mm a";
  }

  /// TODO: review timezone aware
  return GetTimeAgo.parse(dateTime.add(dateTime.timeZoneOffset),
      locale: "en", pattern: pattern);
}
