import 'package:flutter/cupertino.dart';

class AutoPlayManager {
  static final AutoPlayManager _singleton = AutoPlayManager._internal();
  factory AutoPlayManager() {
    return _singleton;
  }
  AutoPlayManager._internal();

  final scrollingOnListView = ValueNotifier(false);
}