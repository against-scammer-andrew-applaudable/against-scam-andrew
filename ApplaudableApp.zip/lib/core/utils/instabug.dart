import 'package:applaudable/core/constants/constant_values.dart';
import 'package:applaudable/features/auth/domain/entities/user.dart';
import 'package:instabug_flutter/instabug_flutter.dart';

class InstabugManager {
  final _userIdKey = "user_id";
  final _nameKey = "name";
  final _emailKey = "email";
  final _usernameKey = "username";
  final _userPhoneKey = "phone";
  final _envKey = "environment";

  Future setUserAttribute(HiveUser user) async {
    Instabug.setUserAttribute(user.id, _userIdKey);
    Instabug.setUserAttribute(ConstantValues.environment.title, _envKey);
    Instabug.removeUserAttribute(_nameKey);
    Instabug.removeUserAttribute(_usernameKey);
    Instabug.removeUserAttribute(_userPhoneKey);
    Instabug.removeUserAttribute(_emailKey);

    // Instabug.setUserAttribute(user.name, _nameKey);
    // Instabug.setUserAttribute(user.username, _usernameKey);
    // Instabug.setUserAttribute(user.phoneNumber ?? "None", _userPhoneKey);
    // Instabug.setUserAttribute(user.email ?? "None", _emailKey);
  }
  Future removeUserAttribute() async {
    Instabug.removeUserAttribute(_userIdKey);
    // Instabug.removeUserAttribute(_nameKey);
    // Instabug.removeUserAttribute(_usernameKey);
    // Instabug.removeUserAttribute(_userPhoneKey);
    // Instabug.removeUserAttribute(_emailKey);
  }
}