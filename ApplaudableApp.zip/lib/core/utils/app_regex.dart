class AppRegex {
  static RegExp mentionRegex =
      RegExp(r"(([@]{1}|[#]{1})[\w\d_À-ž,\.’' \-\(\)]+)");
}
