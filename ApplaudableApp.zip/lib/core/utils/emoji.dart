import 'package:dart_emoji/dart_emoji.dart';

class EmojiHandler {
  final emojiParser = EmojiParser();

  String parse(String name, {String? unicode}) {
    Emoji emoji = emojiParser.info(name);

    /// If cannot find the emoji and if [unicode] is not null
    /// then tries to render using unicode sequence
    ///
    /// First it needs to be parsed into int with base 16
    /// then creates a new string based on the code points
    if (emoji == Emoji.None) {
      if (unicode != null && unicode.isNotEmpty) {
        var codePointValue = int.parse(unicode, radix: 16);
        return String.fromCharCode(codePointValue);
      }
      return "";
    }
    return emoji.code;
  }
}
