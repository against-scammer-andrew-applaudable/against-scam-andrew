import 'package:flutter/services.dart';

import '../../extensions/string_extensions.dart';

class CapitalizeTextFormatter extends TextInputFormatter {
  final TextCapitalization capitalization;

  CapitalizeTextFormatter({this.capitalization = TextCapitalization.sentences});

  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    String formattedText = '';

    switch (capitalization) {
      case TextCapitalization.words:
        formattedText =
            newValue.text.split(' ').map((e) => e.capitalize()).join(' ');
        break;
      case TextCapitalization.sentences:
        formattedText = newValue.text
            .split('. ')
            .map((e) => e.capitalize())
            .join('. ')
            .split('? ')
            .map((e) => e.capitalize())
            .join('? ');

        // final sentenceRegex = RegExp(r'(\. |\? )');
        // String currentText = newValue.text;

        // while (currentText.isNotEmpty) {
        //   final match = sentenceRegex.firstMatch(currentText);

        //   if (match != null) {
        //     final range = TextRange(start: match.start, end: match.end);

        //     formattedText +=
        //         range.textBefore(currentText) + range.textInside(currentText);

        //     currentText = currentText.substring(match.end).capitalize();
        //   } else {
        //     formattedText += currentText;
        //     currentText = '';
        //   }
        // }
        // formattedText = formattedText.capitalize();

        break;
      case TextCapitalization.characters:
        formattedText = newValue.text.toUpperCase();
        break;
      case TextCapitalization.none:
        formattedText = newValue.text;
        break;
    }

    return TextEditingValue(
      text: formattedText,
      selection: newValue.selection,
    );
  }
}
