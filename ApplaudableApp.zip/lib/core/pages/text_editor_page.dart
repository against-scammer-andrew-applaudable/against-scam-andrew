import 'dart:async';
import 'dart:io';

import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:flutter/material.dart';

import '../../features/auth/presentation/widgets/buttons/action_button.dart';
import '../../features/create_post/presentation/pages/create_post_media_selector.dart';
import '../../features/create_post/presentation/widgets/post_text_editor.dart';
import '../../generated/l10n.dart';
import '../theme/colors.dart';
import '../widgets/app_bar.dart';
import '../widgets/app_scaffold.dart';
import 'image_gallery/camera_view.dart';

class TextEditorPageArgs {
  final TextEditingController controller;
  final SelectedMedia? selectedMedia;

  const TextEditorPageArgs({
    required this.controller,
    this.selectedMedia,
  });
}

// ignore: must_be_immutable
class TextEditorPage extends StatelessWidget {
  static const String routeName = '/text-editor-page';

  final TextEditorPageArgs args;

  TextEditorPage({super.key, required this.args});

  final _textEditorKey = GlobalKey<PostTextEditorState>();
  final _statusController = StreamController<MediaStatus>();

  late S translations;

  @override
  Widget build(BuildContext context) {
    translations = S.of(context);

    return AppScaffold(
      appBar: NavigationPageBar(
        actions: [
          StreamBuilder<MediaStatus>(
            initialData: MediaStatus.typing,
            stream: _statusController.stream,
            builder: (context, snapshot) {
              return AppActionButton.submit(
                text: _getMediaSelectorActionText(snapshot.data!),
                fitsFullWidth: false,
                padding: EdgeInsets.zero,
                backgroundColor: Colors.transparent,
                actionTextColor: enableAction(snapshot.data!)
                    ? AppColors.primaryColor
                    : AppColors.primaryColor.withOpacity(0.4),
                onPressed: enableAction(snapshot.data!)
                    ? () => _onAddActionPressed(context, snapshot.data!)
                    : null,
              );
            },
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(
            vertical: 20,
          ),
          child: PostTextEditor(
            key: _textEditorKey,
            controller: args.controller,
            selectedMedia: args.selectedMedia,
            onMediaStatusChanged: (status) {
              _statusController.sink.add(status);
            },
          ),
        ),
      ),
    );
  }

  bool enableAction(MediaStatus status) {
    switch (status) {
      case MediaStatus.error:
        return false;
      case MediaStatus.typing:
        return true;
      case MediaStatus.galleryPreview:
      case MediaStatus.textOrCameraPreview:
      case MediaStatus.editingMedia:
        return true;
      case MediaStatus.picking:
        return false;
    }
  }

  String _getMediaSelectorActionText(MediaStatus status) {
    switch (status) {
      case MediaStatus.typing:
      case MediaStatus.picking:
        return translations.next;
      case MediaStatus.error:
      case MediaStatus.galleryPreview:
      case MediaStatus.textOrCameraPreview:
      case MediaStatus.editingMedia:
        return translations.add;
    }
  }

  void _onAddActionPressed(BuildContext context, MediaStatus status) {
    switch (status) {
      case MediaStatus.picking:
      case MediaStatus.error:
      case MediaStatus.galleryPreview:
        break;
      case MediaStatus.textOrCameraPreview:
        context.pop(
          SelectedMedia(
            file: File('Temp'),
            text: args.controller.text,
            type: MediaType.text,
            source: MediaSource.textEditor,
          ),
        );
        break;
      case MediaStatus.typing:
        _textEditorKey.currentState?.onCanvasTapped();
        break;
      case MediaStatus.editingMedia:
        context.pop();
        break;
    }
  }
}
