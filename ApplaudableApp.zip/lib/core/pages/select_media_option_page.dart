import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:image_picker/image_picker.dart';

import '../../app_module.dart';
import '../../features/auth/presentation/widgets/background.dart';
import '../../features/auth/presentation/widgets/buttons/action_button.dart';
import '../../features/auth/presentation/widgets/sizing/side_margins.dart';
import '../../features/create_post/presentation/pages/create_post_media_selector.dart';
import '../../generated/l10n.dart';
import '../extensions/app_module_extensions.dart';
import '../extensions/build_context_extensions.dart';
import '../mixins/alerts_mixin.dart';
import '../theme/colors.dart';
import '../theme/dimensions.dart';
import '../theme/styles.dart';
import '../widgets/app_bar.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/svg_icons.dart';
import 'image_gallery/camera_view.dart';
import 'text_editor_page.dart';

class SelectMediaOptionPage extends StatelessWidget with AlertsMixin {
  static const routeName = '/select-media-option-page';

  final MediaSelectorArgs args;

  SelectMediaOptionPage({
    super.key,
    this.args = const MediaSelectorArgs(),
  });

  final _textController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return AppScaffold(
      appBar: NavigationPageBar(
        leading: IconButton(
          icon: SvgIcons.close(),
          onPressed: context.pop,
        ),
      ),
      body: SafeArea(
        bottom: false,
        child: SingleChildScrollView(
          child: SizedBox(
            height: context.screenHeight - context.paddingTop,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(
                  height: AppDimensions.defaultSidePadding,
                ),
                const Spacer(flex: 1),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // Text(
                      //   translations.select_media_for_post_msg,
                      //   style: AppStyles.header1(
                      //     color: AppColors.darkGrey,
                      //   ).copyWith(
                      //     fontWeight: FontWeight.bold,
                      //     fontSize: 18,
                      //   ),
                      // ),
                      // const SizedBox(height: 5),
                      Text(
                        translations.select_media_for_post_msg,
                        style: AppStyles.header1(
                          color: AppColors.buttonBGColor,
                        ).copyWith(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 5),
                Expanded(
                  flex: 6,
                  child: AppBackground(
                    showTopLogo: false,
                    fitBottomWidth: true,
                    bottomLogo: SvgPicture.asset(
                      'assets/images/post_segments_bg_logo.svg',
                    ),
                    child: SafeArea(
                      bottom: false,
                      child: AppSideMargins(
                        margin: const EdgeInsets.all(
                          AppDimensions.largeSidePadding,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const SizedBox(
                              height: AppDimensions.largeSidePadding,
                            ),
                            if (args.options.contains(MediaOption.camera)) ...[
                              AppActionButton.submit(
                                text: translations.camera,
                                leadingIcon: SvgIcons.camera(),
                                backgroundColor: Colors.white,
                                enableGradient: false,
                                actionTextColor: Colors.black,
                                padding: const EdgeInsets.symmetric(
                                  vertical: AppDimensions.largeSidePadding,
                                ),
                                onPressed: () => _selectMediaOption(
                                    context, MediaOption.camera),
                                boxShadow: [AppShadows.createPostSegmentShadow],
                              ),
                              const SizedBox(
                                height: AppDimensions.largeSidePadding,
                              ),
                            ],
                            if (args.options.contains(MediaOption.gallery)) ...[
                              AppActionButton.submit(
                                text: translations.library,
                                leadingIcon: SvgIcons.gallery(),
                                backgroundColor: Colors.white,
                                enableGradient: false,
                                actionTextColor: Colors.black,
                                padding: const EdgeInsets.symmetric(
                                  vertical: AppDimensions.largeSidePadding,
                                ),
                                onPressed: () => _selectMediaOption(
                                    context, MediaOption.gallery),
                                boxShadow: [AppShadows.createPostSegmentShadow],
                              ),
                              const SizedBox(
                                height: AppDimensions.largeSidePadding,
                              ),
                            ],
                            if (args.options.contains(MediaOption.text))
                              AppActionButton.submit(
                                text: translations.write_a_quote,
                                leadingIcon: SvgIcons.quote(),
                                backgroundColor: Colors.white,
                                enableGradient: false,
                                actionTextColor: Colors.black,
                                padding: const EdgeInsets.symmetric(
                                  vertical: AppDimensions.largeSidePadding,
                                ),
                                onPressed: () => _selectMediaOption(
                                    context, MediaOption.text),
                                boxShadow: [AppShadows.createPostSegmentShadow],
                              ),
                            const Spacer(flex: 4),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _selectMediaOption(BuildContext context, MediaOption type) async {
    switch (type) {
      case MediaOption.gallery:
        final image = await pickImageFromSource(context, ImageSource.gallery);
        if (image != null) {
          final media = SelectedMedia(
            file: image,
            type: MediaType.image,
            source: MediaSource.gallery,
          );
          context.pop(media);
        }

        break;
      case MediaOption.camera:
        final image = await pickImageFromSource(context, ImageSource.camera);
        if (image != null) {
          final media = SelectedMedia(
            file: image,
            type: MediaType.image,
            source: MediaSource.camera,
          );
          context.pop(media);
        }

        break;
      case MediaOption.text:
        final media = await AppModule.I.navigateToNamed(
          TextEditorPage.routeName,
          arguments: TextEditorPageArgs(
            controller: _textController,
            selectedMedia: args.selectedMedia,
          ),
        );

        context.pop(media);
        break;
    }
  }
}
