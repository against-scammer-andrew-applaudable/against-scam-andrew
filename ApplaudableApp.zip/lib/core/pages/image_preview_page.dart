import 'dart:async';
import 'dart:io';
import 'dart:math';

import 'package:crop_your_image/crop_your_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart';
import 'package:logger/logger.dart';

import '../../app_module.dart';
import '../../generated/l10n.dart';
import '../theme/colors.dart';
import '../theme/dimensions.dart';
import '../../features/auth/presentation/widgets/buttons/action_button.dart';
import '../extensions/app_module_extensions.dart';
import '../extensions/build_context_extensions.dart';

class ImagePreviewArgs {
  final String imageTitle;
  final File image;
  final Future<bool> Function(File)? uploadImageCallback;
  final Function()? onUploadComplete;

  ImagePreviewArgs({
    required this.image,
    this.imageTitle = '',
    this.onUploadComplete,
    this.uploadImageCallback,
  });
}

class ImagePreviewPage extends StatefulWidget {
  static const String routeName = '/image-preview-page';

  final ImagePreviewArgs args;

  const ImagePreviewPage({super.key, required this.args});

  @override
  State<ImagePreviewPage> createState() => _ImagePreviewPageState();
}

class _ImagePreviewPageState extends State<ImagePreviewPage>
    with TickerProviderStateMixin {
  late File _image;
  final StreamController<bool> _loadingController =
      StreamController<bool>.broadcast();

  // Editor properties
  bool _isEditingImage = false;
  final _cropController = CropController();
  bool _preparingForUpload = false;

  late final S translations = S.of(context);

  @override
  void initState() {
    _image = widget.args.image;

    super.initState();
  }

  @override
  void dispose() {
    _loadingController.close();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(AppDimensions.smallSidePadding),
          child: Column(
            children: [
              Text(
                _isEditingImage
                    ? translations.editPhoto
                    : widget.args.imageTitle,
                style: context.body1TextTheme?.copyWith(color: Colors.white),
              ),
              const SizedBox(height: AppDimensions.defaultSidePadding),
              Flexible(
                child: Center(
                  child: Stack(
                    children: [
                      Crop(
                        image: widget.args.image.readAsBytesSync(),
                        controller: _cropController,
                        onCropped: (croppedImage) async {
                          // if (!_isFirstEdit) await _deleteTempImage();

                          var filePath =
                              '${_image.parent.path}/IMG_${Random().nextInt(545345345)}.png';

                          _image = File(filePath)
                            ..writeAsBytesSync(croppedImage);

                          // _isEditingImage = false;
                          // _isFirstEdit = false;

                          // if (!_preparingForUpload) setState(() {});

                          Logger().i('Editing image completed');
                        },
                        onStatusChanged: _onListeningToCoppingStatus,
                        withCircleUi: true,
                        baseColor: Colors.black,
                        maskColor: _isEditingImage
                            ? Colors.black.withOpacity(0.55)
                            : Colors.black,
                        cornerDotBuilder: (size, edgeAlignment) =>
                            const DotControl(color: Colors.transparent),
                        interactive: _isEditingImage,
                        fixCropRect: true,
                      ),
                      if (_isEditingImage)
                        IgnorePointer(
                          ignoring: true,
                          child: Container(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white, width: 3),
                              image: const DecorationImage(
                                image: Svg('assets/icons/image_grid.svg'),
                              ),
                            ),
                          ),
                        ),
                      _buildCircleLoader(),
                    ],
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  AppActionButton.submit(
                    fitsFullWidth: false,
                    backgroundColor: Colors.transparent,
                    actionTextColor: Colors.white,
                    text: translations.cancel,
                    padding: const EdgeInsets.symmetric(
                      horizontal: AppDimensions.defaultSidePadding,
                      vertical: AppDimensions.mediumSidePadding,
                    ),
                    onPressed: () {
                      if (_isEditingImage) {
                        _cropController.image =
                            widget.args.image.readAsBytesSync();
                        setState(() {
                          _isEditingImage = false;
                        });
                      } else {
                        _deleteTempImage();

                        AppModule.I.pop();
                      }
                    },
                  ),
                  if (!_isEditingImage)
                    AppActionButton.submit(
                      fitsFullWidth: false,
                      backgroundColor: Colors.transparent,
                      actionTextColor: Colors.white,
                      text: translations.edit,
                      padding: const EdgeInsets.symmetric(
                        horizontal: AppDimensions.defaultSidePadding,
                        vertical: AppDimensions.mediumSidePadding,
                      ),
                      onPressed: () async {
                        setState(() {
                          _isEditingImage = true;
                        });
                      },
                    ),
                  AppActionButton.submit(
                    fitsFullWidth: false,
                    backgroundColor: Colors.transparent,
                    actionTextColor: Colors.white,
                    text: translations.save,
                    padding: const EdgeInsets.symmetric(
                        horizontal: AppDimensions.defaultSidePadding,
                        vertical: AppDimensions.mediumSidePadding),
                    onPressed: () =>
                        _cropImage(isPreparingForUpload: !_isEditingImage),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _onListeningToCoppingStatus(status) {
    if (_loadingController.isClosed) return;

    switch (status) {
      case CropStatus.nothing:
        _loadingController.sink.add(false);
        break;

      case CropStatus.ready:
        if (_preparingForUpload) {
          _uploadImageToServer();
          _preparingForUpload = false;
        } else {
          _loadingController.sink.add(false);
        }
        break;

      case CropStatus.cropping:
        _loadingController.sink.add(true);
    }
  }

  Positioned _buildCircleLoader() {
    return Positioned.fill(
      child: StreamBuilder<bool>(
        initialData: false,
        stream: _loadingController.stream,
        builder: (ctx, snapshot) {
          return snapshot.data!
              ? const Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    AspectRatio(
                      aspectRatio: 1,
                      child: CircularProgressIndicator(
                        strokeWidth: 5,
                        valueColor: AlwaysStoppedAnimation(
                          AppColors.primaryColor,
                        ),
                      ),
                    ),
                  ],
                )
              : Container();
        },
      ),
    );
  }

  void _cropImage({bool isPreparingForUpload = false}) async {
    _preparingForUpload = isPreparingForUpload;

    if (isPreparingForUpload) {
      _cropController.cropCircle();
    } else {
      setState(() {
        _isEditingImage = false;
      });
    }
  }

  void _uploadImageToServer() async {
    // if (!_loadingController.isClosed) _loadingController.sink.add(true);

    // wait for the image to be uploaded
    bool isUploadSucess = false;
    if (widget.args.uploadImageCallback != null) {
      isUploadSucess = await widget.args.uploadImageCallback!(_image);
    }

    if (!_loadingController.isClosed) _loadingController.sink.add(false);

    if (isUploadSucess) {
      // execute onUploadComplete callback after uploading image
      if (widget.args.onUploadComplete != null) {
        _deleteTempImage();
        widget.args.onUploadComplete!();
      } else {
        // else return back the image to the previous screen
        context.pop(_image);
      }
    }
  }

  Future<void> _deleteTempImage() async {
    try {
      await _image.delete();
    } catch (e) {
      Logger().e('Failed to delete temp image: ${e.toString()}');
    }
  }
}
