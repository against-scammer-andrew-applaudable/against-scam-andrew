// ignore_for_file: deprecated_member_use

import 'dart:async';
import 'dart:developer';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as svgp;
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:photo_gallery/photo_gallery.dart';
import 'package:video_player/video_player.dart';

import '../../../features/create_post/presentation/pages/create_post_media_selector.dart';
import '../../../generated/l10n.dart';
import '../../theme/colors.dart';
import '../../theme/dimensions.dart';
import '../../theme/styles.dart';
import '../../../features/auth/presentation/widgets/sizing/side_margins.dart';
import '../../extensions/build_context_extensions.dart';
import '../../mixins/alerts_mixin.dart';
import '../../widgets/app_permissions_denied_view.dart';
import '../../widgets/gallery_albums_menu.dart';
import 'camera_view.dart';

class MediaGalleryPage extends StatefulWidget {
  static const String routeName = '/media-gallery-page';

  final Function(SelectedMedia image)? onImageSelected;
  final Function(MediaStatus)? onMediaStatusChanged;
  final bool useNative;
  final SelectedMedia? selectedMedia;

  const MediaGalleryPage({
    super.key,
    this.onImageSelected,
    this.onMediaStatusChanged,
    this.useNative = false,
    this.selectedMedia,
  });

  @override
  State<MediaGalleryPage> createState() => MediaGalleryPageState();
}

class MediaGalleryPageState extends State<MediaGalleryPage>
    with AutomaticKeepAliveClientMixin, AlertsMixin {
  final StreamController<Medium> _previewController =
      StreamController<Medium>.broadcast();

  List<Album> _albums = [];
  bool _isLoaded = false;
  Album? _selectedAlbum;

  File? _selectedImage;

  @override
  void initState() {
    if (widget.useNative) {
      if (widget.selectedMedia != null &&
          widget.selectedMedia!.source == MediaSource.gallery) {
        _selectedImage = widget.selectedMedia!.file;

        if (widget.onMediaStatusChanged != null) {
          widget.onMediaStatusChanged!(MediaStatus.editingMedia);
        }
      } else {
        /// Comment to not load it automatically
        // pickImageFromSource(ImageSource.gallery).then((value) {
        //   if (value == null) return;
        //   _selectedImage = value;
        //   if (widget.onImageSelected != null) {
        //     widget.onImageSelected!(
        //       SelectedMedia(
        //         file: value,
        //         type: MediaType.image,
        //         source: MediaSource.gallery,
        //       ),
        //     );
        //   }
        //   if (widget.onMediaStatusChanged != null) {
        //     widget.onMediaStatusChanged!(MediaStatus.galleryPreview);
        //   }
        //   setState(() {});
        // });
      }
    } else {
      _loadAlbumsFromDevice();
    }

    _isLoaded = widget.useNative;

    super.initState();
  }

  Future<List<Album>> _loadAlbumsFromDevice() async {
    if (await _promptPermissionSetting()) {
      List<Album> fetchedAlbums = await PhotoGallery.listAlbums(
        mediumType: MediumType.image,
        hideIfEmpty: true,
      );

      _albums = fetchedAlbums.where((album) => album.count > 0).toList();

      if (_albums.isNotEmpty) {
        // if (_albums.length == 1) {
        _selectedAlbum = _albums.first;
        // } else {
        //   _selectedAlbum = _albums[1];
        // }
      }

      _isLoaded = true;

      setState(() {});

      return _albums;
    } else {
      if (widget.onMediaStatusChanged != null) {
        widget.onMediaStatusChanged!(MediaStatus.error);
      }
      return Future.error('permission');
    }
  }

  Future<List<Medium>> _loadImagesFromAlbum() async {
    if (_selectedAlbum == null) return [];

    List<Medium> images = [];

    images.addAll((await _selectedAlbum!.listMedia()).items);

    return images
        .toSet()
        .where(
            (element) => (element.width ?? 0) > 0 && (element.height ?? 0) > 0)
        .toList()
      ..sort(
        ((a, b) {
          if (a.creationDate == null || b.creationDate == null) return 0;

          final isBefore = a.creationDate!.isBefore(b.creationDate!);
          return isBefore ? 1 : -1;
        }),
      );
  }

  Future<bool> _promptPermissionSetting() async {
    if (Platform.isIOS &&
            await Permission.storage.request().isGranted &&
            await Permission.photos.request().isGranted ||
        Platform.isAndroid && await Permission.storage.request().isGranted) {
      return true;
    }
    return false;
  }

  @override
  void dispose() {
    _previewController.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    if (!_isLoaded) return const Center(child: CircularProgressIndicator());

    return FutureBuilder<List<Medium>>(
      future: _loadImagesFromAlbum(),
      builder: (context, snapshot) {
        if (snapshot.hasError && snapshot.error == 'permission') {
          return const Scaffold(body: AppPermissionDeniedView());
        }

        if (snapshot.hasError && snapshot.error != null) {
          return Scaffold(
            body: Center(child: Text(snapshot.error!.toString())),
          );
        }

        if (!snapshot.hasData) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        final imagesData = snapshot.data ?? [];

        return Column(
          children: [
            Flexible(
              child: AppSideMargins(
                margin: const EdgeInsets.symmetric(
                  horizontal: 25,
                ),
                child: GestureDetector(
                  onTap: openImageGalleryToSelectImage,
                  child: StreamBuilder<Medium>(
                    stream: _previewController.stream,
                    builder: (context, snapshot) {
                      log(widget.selectedMedia.toString());
                      if (widget.useNative && _selectedImage == null ||
                          (!widget.useNative && snapshot.data == null)) {
                        return Container(
                          color: _selectedImage == null
                              ? AppColors.darkPeach2
                              : AppColors.peach,
                          child: const Center(
                            child: NoImageSelectedView(),
                          ),
                        );
                      }

                      return Container(
                        color: _selectedImage == null && snapshot.data == null
                            ? AppColors.darkPeach2
                            : AppColors.peach,
                        child: Center(
                          child: FadeInImage(
                            fit: BoxFit.cover,
                            // width: double.infinity,
                            // height: double.infinity,
                            placeholder: const svgp.Svg(
                              'assets/icons/app_logo_rating.svg',
                              color: AppColors.peach,
                            ),
                            image: widget.useNative
                                ? MemoryImage(_selectedImage!.readAsBytesSync())
                                    as ImageProvider
                                : ThumbnailProvider(
                                    mediumId: snapshot.data!.id,
                                    mediumType: snapshot.data!.mediumType,
                                    highQuality: true,
                                  ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
            GalleryAlbumsMenu(
              albums: _albums,
              onAlbumSelected: (album) {
                setState(() {
                  _selectedAlbum = album;
                });
              },
            ),
            ConstrainedBox(
              constraints: BoxConstraints(
                maxHeight: context.screenHeight * 0.35,
              ),
              child: LayoutBuilder(
                builder: (context, constraints) {
                  double gridWidth = (constraints.maxWidth - 20) / 4;
                  double gridHeight = gridWidth;
                  double ratio = gridWidth / gridHeight;
                  return GridView.count(
                    shrinkWrap: true,
                    physics: const BouncingScrollPhysics(),
                    padding: EdgeInsets.only(bottom: context.paddingBottom),
                    childAspectRatio: ratio,
                    crossAxisCount: 4,
                    mainAxisSpacing: 1,
                    crossAxisSpacing: 1,
                    children: <Widget>[
                      ...imagesData.map(
                        (medium) => GestureDetector(
                          onTap: () async {
                            if (widget.onImageSelected != null) {
                              widget.onImageSelected!(
                                SelectedMedia(
                                  file: await PhotoGallery.getFile(
                                    mediumId: medium.id,
                                  ),
                                  type: MediaType.image,
                                  source: MediaSource.gallery,
                                ),
                              );
                            }

                            if (widget.onMediaStatusChanged != null) {
                              widget.onMediaStatusChanged!(
                                MediaStatus.galleryPreview,
                              );
                            }

                            _previewController.sink.add(medium);
                          },
                          child: Container(
                            color: Colors.grey[300],
                            height: gridWidth,
                            width: gridWidth,
                            child: FadeInImage(
                              fit: BoxFit.cover,
                              placeholder: const svgp.Svg(
                                'assets/icons/app_logo_rating_filled.svg',
                                color: AppColors.darkPeach2,
                              ),
                              image: ThumbnailProvider(
                                mediumId: medium.id,
                                mediumType: medium.mediumType,
                                // width: medium.width != null
                                //     ? medium.width! ~/ 3
                                //     : gridWidth.toInt(),
                                // height: medium.height != null
                                //     ? medium.height! ~/ 3
                                //     : gridHeight.toInt(),
                                highQuality: true,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  void openImageGalleryToSelectImage() async {
    if (!widget.useNative) return;

    final image = await pickImageFromSource(context, ImageSource.gallery);

    if (image != null) {
      if (widget.onImageSelected != null) {
        widget.onImageSelected!(
          SelectedMedia(
            file: image,
            type: MediaType.image,
            source: MediaSource.gallery,
          ),
        );
      }

      if (widget.onMediaStatusChanged != null) {
        widget.onMediaStatusChanged!(MediaStatus.galleryPreview);
      }

      setState(() {
        _selectedImage = image;
      });
    }
  }

  @override
  bool get wantKeepAlive => true;
}

class NoImageSelectedView extends StatelessWidget {
  const NoImageSelectedView({super.key});

  @override
  Widget build(BuildContext context) {
    final translations = S.of(context);

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SvgPicture.asset(
          'assets/icons/app_logo_rating.svg',
          color: AppColors.peach,
          height: 60,
        ),
        const SizedBox(
          height: AppDimensions.smallSidePadding,
        ),
        Text(
          translations.tap_to_select_image,
          style: AppStyles.text2(color: AppColors.peach)
              .copyWith(fontWeight: FontWeight.w600),
        ),
      ],
    );
  }
}

class VideoProvider extends StatefulWidget {
  final String mediumId;

  const VideoProvider({super.key, required this.mediumId});

  @override
  State<VideoProvider> createState() => _VideoProviderState();
}

class _VideoProviderState extends State<VideoProvider> {
  VideoPlayerController? _controller;
  File? _file;

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      initAsync();
    });
    super.initState();
  }

  Future<void> initAsync() async {
    try {
      _file = await PhotoGallery.getFile(mediumId: widget.mediumId);
      _controller = VideoPlayerController.file(_file!);
      _controller?.initialize().then((_) {
        /// Ensure the first frame is shown after the video is initialized,
        /// even before the play button has been pressed.
        setState(() {});
      });
    } catch (e) {
      debugPrint("Failed : $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_controller == null || !_controller!.value.isInitialized) {
      return Container();
    }

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        ),
        TextButton(
          onPressed: _playOrPauseVideo,
          child: Icon(
            _controller!.value.isPlaying ? Icons.pause : Icons.play_arrow,
          ),
        ),
      ],
    );
  }

  void _playOrPauseVideo() {
    setState(() {
      _controller!.value.isPlaying ? _controller!.pause() : _controller!.play();
    });
  }
}
