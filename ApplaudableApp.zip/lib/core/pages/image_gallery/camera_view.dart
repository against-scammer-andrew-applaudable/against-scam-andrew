import 'dart:async';
import 'dart:developer';
import 'dart:io';
import 'dart:ui';

import 'package:camera/camera.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../../../features/create_post/presentation/pages/create_post_media_selector.dart';
import '../../../generated/l10n.dart';
import '../../mixins/alerts_mixin.dart';
import '../../theme/colors.dart';
import '../../theme/dimensions.dart';
import '../../../features/auth/presentation/widgets/buttons/action_button.dart';
import '../../widgets/app_permissions_denied_view.dart';
import '../../widgets/buttons/bouncing_button.dart';
import '../../widgets/svg_icons.dart';

enum MediaType { image, video, text }

enum MediaSource { gallery, camera, textEditor }

class SelectedMedia extends Equatable {
  final File file;
  final MediaType type;
  final String text;
  final MediaSource source;

  const SelectedMedia({
    required this.file,
    required this.type,
    required this.source,
    this.text = '',
  });

  @override
  List<Object?> get props => [file, type, source, text];
}

class CameraViewState extends Equatable {
  final bool isRecordingVideo;
  final bool isOnBackCamera;
  final bool enableFlash;

  const CameraViewState({
    this.isRecordingVideo = false,
    this.isOnBackCamera = true,
    this.enableFlash = false,
  });

  CameraViewState copyWith({
    bool? isRecordingVideo,
    bool? isOnBackCamera,
    bool? enableFlash,
  }) =>
      CameraViewState(
        isRecordingVideo: isRecordingVideo ?? this.isRecordingVideo,
        isOnBackCamera: isOnBackCamera ?? this.isOnBackCamera,
        enableFlash: enableFlash ?? this.enableFlash,
      );

  @override
  List<Object?> get props => [isRecordingVideo, isOnBackCamera, enableFlash];
}

/// CameraApp is the Main Application.
class AppCameraView extends StatefulWidget {
  static const String routeName = "/camera-app";

  final Function(SelectedMedia)? onImageCaptured;
  final Function(MediaStatus)? onMediaStatusChanged;
  final Widget? navigatorWidget;
  final SelectedMedia? selectedMedia;
  final bool useNative;

  /// Default Constructor
  const AppCameraView({
    super.key,
    this.onImageCaptured,
    this.onMediaStatusChanged,
    this.navigatorWidget,
    this.selectedMedia,
    this.useNative = true,
  });

  @override
  State<AppCameraView> createState() => AppCameraViewState();
}

class AppCameraViewState extends State<AppCameraView>
    with AutomaticKeepAliveClientMixin, AlertsMixin {
  CameraController? controller;
  late List<CameraDescription> _cameras;

  CameraViewState _cameraState = const CameraViewState();
  final StreamController<CameraViewState> _stateController =
      StreamController<CameraViewState>.broadcast();

  SelectedMedia? _selectedImageOrVideo;
  late S translations;

  @override
  void initState() {
    if (widget.selectedMedia != null &&
        widget.selectedMedia!.source == MediaSource.camera) {
      _selectedImageOrVideo = widget.selectedMedia;

      if (widget.onMediaStatusChanged != null) {
        widget.onMediaStatusChanged!(MediaStatus.editingMedia);
      }
    }

    super.initState();
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  void openCameraToCaptureAnImage() async {
    final image = await pickImageFromSource(context, ImageSource.camera);

    if (image != null) {
      if (widget.onImageCaptured != null) {
        widget.onImageCaptured!(
          SelectedMedia(
            file: image,
            type: MediaType.image,
            source: MediaSource.camera,
          ),
        );
      }

      if (widget.onMediaStatusChanged != null) {
        widget.onMediaStatusChanged!(MediaStatus.galleryPreview);
      }

      setState(() {
        _selectedImageOrVideo = SelectedMedia(
          file: image,
          type: MediaType.image,
          source: MediaSource.camera,
        );
      });
    }
  }

  Future<bool> _loadCamera({CameraViewState? newState}) async {
    final cameraState = newState ?? _cameraState;

    _cameras = await availableCameras();

    if (_cameras.isEmpty) {
      if (widget.onMediaStatusChanged != null) {
        widget.onMediaStatusChanged!(MediaStatus.error);
      }
      return Future.error('no_camera');
    }

    debugPrint(_cameras.toString());

    final error = await _initializeCameraController(
      cameraState.isOnBackCamera
          ? _cameras.firstWhere(
              (element) => element.lensDirection == CameraLensDirection.back)
          : _cameras.firstWhere(
              (element) => element.lensDirection == CameraLensDirection.front),
    );

    if (error != null) return Future.error(error);

    return true;
  }

  Future<String?> _initializeCameraController(CameraDescription camera) async {
    controller = CameraController(camera, ResolutionPreset.max);

    try {
      await controller!.initialize();
      return null;
    } catch (e) {
      if (widget.onMediaStatusChanged != null) {
        widget.onMediaStatusChanged!(MediaStatus.error);
      }

      if (e is CameraException) {
        switch (e.code) {
          case 'CameraAccessDenied':
            debugPrint('User denied camera access.');

            return 'permission';
          default:
            debugPrint('Handle other errors.');

            return e.description ?? '';
        }
      }
    }

    return null;
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    translations = S.of(context);

    if (_selectedImageOrVideo != null) {
      return WillPopScope(
        onWillPop: closePreview,
        child: _selectedImageOrVideo!.type == MediaType.image
            ? Image.file(_selectedImageOrVideo!.file, fit: BoxFit.fitWidth)
            : Container(),
      );
    }

    if (widget.useNative) {
      return GestureDetector(
        onTap: openCameraToCaptureAnImage,
        child: Container(
          color: Colors.transparent,
          child: const Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'Tap to open Camera.',
                textAlign: TextAlign.center,
              )
            ],
          ),
        ),
      );
    }

    return FutureBuilder<bool>(
      future: _loadCamera(),
      builder: (context, snapshot) {
        if (snapshot.hasError && snapshot.error == 'no_camera') {
          return Center(child: Text(translations.no_cameras_error_msg));
        }

        if (snapshot.hasError && snapshot.error == 'permission') {
          return const AppPermissionDeniedView();
        }

        if (!snapshot.hasData ||
            snapshot.data == null ||
            !controller!.value.isInitialized) {
          return Container();
        }

        if (!snapshot.data!) {
          return Center(
            child: Text(translations.unable_to_load_camera_err_msg),
          );
        }

        return ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: LayoutBuilder(
            builder: (context, constraints) {
              return Column(
                children: [
                  Expanded(
                    child: Stack(
                      children: [
                        Container(
                          color: AppColors.lightGrey,
                          child: Center(
                            child: CameraPreview(controller!),
                          ),
                        ),
                        StreamBuilder<CameraViewState>(
                          initialData: _cameraState,
                          stream: _stateController.stream,
                          builder: (context, snapshot) {
                            final cameraState = snapshot.data!;

                            return CameraViewControllersView(
                              controller: controller!,
                              navigatorWidget: widget.navigatorWidget,
                              isRecordingVideo: cameraState.isRecordingVideo,
                              onTakePictureTap: () =>
                                  pickImage(state: cameraState),
                              onSwipeCameraTap: () async {
                                if (_cameras.length > 1) {
                                  setState(() {
                                    _cameraState = cameraState.copyWith(
                                      isOnBackCamera:
                                          !_cameraState.isOnBackCamera,
                                    );
                                  });
                                }
                              },
                              onVideoTap: () =>
                                  onVideoRecordButtonPressed(cameraState),
                              onFlashTap: () {
                                _cameraState = cameraState.copyWith(
                                  enableFlash: !_cameraState.enableFlash,
                                );

                                return setFlashMode(
                                  _cameraState.enableFlash
                                      ? FlashMode.torch
                                      : FlashMode.off,
                                );
                              },
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }

  Future<bool> closePreview() {
    setState(() {
      _selectedImageOrVideo = null;
    });

    if (widget.onMediaStatusChanged != null) {
      widget.onMediaStatusChanged!(MediaStatus.picking);
    }

    return Future.value(false);
  }

  Future<void> pickImage({CameraViewState? state}) async {
    state ??= _cameraState;

    if (state.isRecordingVideo) {
      // handle video file

      final video = await stopVideoRecording(state);

      if (video != null) {
        _selectedImageOrVideo = SelectedMedia(
          file: video,
          type: MediaType.video,
          source: MediaSource.camera,
        );
      }
    } else {
      // handle image file
      final image = await takePicture();

      if (image != null) {
        _selectedImageOrVideo = SelectedMedia(
          file: image,
          type: MediaType.image,
          source: MediaSource.camera,
        );
      }
    }

    if (widget.onImageCaptured != null) {
      widget.onImageCaptured!(_selectedImageOrVideo!);
    }

    if (widget.onMediaStatusChanged != null) {
      widget.onMediaStatusChanged!(MediaStatus.textOrCameraPreview);
    }

    setState(() {});
  }

  Future<void> setFlashMode(FlashMode mode) async {
    if (controller == null) {
      return;
    }

    log('Setting Flash: $mode');

    try {
      await controller?.setFlashMode(mode);
    } on CameraException catch (e) {
      log(e.description ?? e.toString());
      rethrow;
    }
  }

  void onVideoRecordButtonPressed(CameraViewState state) async {
    await startVideoRecording();

    if (mounted) {
      _stateController.sink.add(state.copyWith(isRecordingVideo: true));
    }
  }

  Future<void> onPausePreviewButtonPressed() async {
    final cameraController = controller;

    if (cameraController == null || !cameraController.value.isInitialized) {
      log('Error: select a camera first.');
      return;
    }

    if (cameraController.value.isPreviewPaused) {
      await cameraController.resumePreview();
    } else {
      await cameraController.pausePreview();
    }

    if (mounted) {
      setState(() {});
    }
  }

  Future<void> startVideoRecording() async {
    final cameraController = controller;

    if (cameraController == null || !cameraController.value.isInitialized) {
      log('Error: select a camera first.');
      return;
    }

    if (cameraController.value.isRecordingVideo) {
      // A recording is already started, do nothing.
      return;
    }

    try {
      await cameraController.startVideoRecording();
    } on CameraException catch (e) {
      log(e.description ?? e.toString());

      return;
    }
  }

  Future<File?> stopVideoRecording(CameraViewState state) async {
    final cameraController = controller;

    if (cameraController == null || !cameraController.value.isRecordingVideo) {
      return null;
    }

    try {
      var videoFile = await cameraController.stopVideoRecording();

      _stateController.sink.add(state.copyWith(isRecordingVideo: false));

      return File(videoFile.path);
    } on CameraException catch (e) {
      log(e.description ?? e.toString());

      return null;
    }
  }

  Future<File?> takePicture() async {
    final cameraController = controller;

    if (cameraController == null || !cameraController.value.isInitialized) {
      log('Error: select a camera first.');
      return null;
    }

    if (cameraController.value.isTakingPicture) {
      // A capture is already pending, do nothing.
      return null;
    }

    try {
      final XFile file = await cameraController.takePicture();

      return File(file.path);
    } on CameraException catch (e) {
      log(e.description ?? e.toString());
      return null;
    }
  }

  @override
  bool get wantKeepAlive => true;
}

class CameraViewControllersView extends StatelessWidget {
  final CameraController controller;
  final Function()? onTakePictureTap;
  final Function()? onSwipeCameraTap;
  final Function()? onFlashTap;
  final Function()? onVideoTap;
  final bool isRecordingVideo;
  final Widget? navigatorWidget;

  const CameraViewControllersView({
    super.key,
    required this.controller,
    this.onTakePictureTap,
    this.onSwipeCameraTap,
    this.onFlashTap,
    this.onVideoTap,
    this.isRecordingVideo = false,
    this.navigatorWidget,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        ClipRect(
          child: Container(
            color: AppColors.dark.withOpacity(0.4),
            padding: const EdgeInsets.all(AppDimensions.smallSidePadding),
            alignment: Alignment.center,
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 7.5, sigmaY: 7.5),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  AppActionButton(
                    text: '',
                    backgroundColor: Colors.transparent,
                    leadingIcon: SvgIcons.flash(height: 24),
                    fitsFullWidth: false,
                    onPressed: onFlashTap,
                  ),
                ],
              ),
            ),
          ),
        ),
        ClipRect(
          child: Container(
            color: AppColors.dark.withOpacity(0.4),
            padding: const EdgeInsets.all(AppDimensions.smallSidePadding),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 7.5, sigmaY: 7.5),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      AppActionButton(
                          text: '',
                          backgroundColor: Colors.transparent,
                          leadingIcon: SvgIcons.videoCamera(
                              color:
                                  //  isRecordingVideo ?
                                  Colors.transparent
                              // : null
                              ),
                          fitsFullWidth: false,
                          onPressed:
                              // isRecordingVideo ?
                              null
                          // : onVideoTap,
                          ),
                      BouncingButton(
                        onTap: onTakePictureTap,
                        child: Container(
                          height: 80,
                          width: 80,
                          decoration: BoxDecoration(
                            // color: AppColors.white,
                            shape: BoxShape.circle,
                            border: Border.all(
                              width: 5,
                              color: AppColors.white,
                            ),
                          ),
                          margin: const EdgeInsets.all(
                            AppDimensions.smallSidePadding,
                          ),
                          child: Center(
                            child: isRecordingVideo
                                ? FractionallySizedBox(
                                    heightFactor: 0.5,
                                    widthFactor: 0.5,
                                    child: Container(
                                      decoration: const BoxDecoration(
                                        color: AppColors.primaryColor,
                                        shape: BoxShape.circle,
                                      ),
                                    ),
                                  )
                                : FractionallySizedBox(
                                    heightFactor: 0.9,
                                    widthFactor: 0.9,
                                    child: Container(
                                      decoration: const BoxDecoration(
                                        color: AppColors.white,
                                        shape: BoxShape.circle,
                                      ),
                                    ),
                                  ),
                          ),
                        ),
                      ),
                      AppActionButton(
                        text: '',
                        backgroundColor: Colors.transparent,
                        leadingIcon: SvgIcons.swipeCamera(),
                        fitsFullWidth: false,
                        onPressed: onSwipeCameraTap,
                      ),
                    ],
                  ),
                  if (navigatorWidget != null)
                    SafeArea(top: false, child: navigatorWidget!),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
