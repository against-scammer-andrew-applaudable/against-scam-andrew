import 'package:flutter/material.dart';

import '../../theme/colors.dart';
import '../../theme/styles.dart';
import '../../utils/app_regex.dart';

class PostDescriptionTextController extends TextEditingController {
  PostDescriptionTextController({super.text});

  @override
  TextSpan buildTextSpan({
    required BuildContext context,
    TextStyle? style,
    required bool withComposing,
  }) {
    final regex = AppRegex.mentionRegex;
    final spans = <TextSpan>[];

    String currentText = text;

    while (currentText.isNotEmpty) {
      final match = regex.firstMatch(currentText);

      if (match != null) {
        final range = TextRange(start: match.start, end: match.end);

        spans.add(
          TextSpan(
            children: [
              TextSpan(text: range.textBefore(currentText)),
              TextSpan(
                text: range.textInside(currentText),
                style: AppStyles.text2(color: AppColors.dark)
                    .copyWith(fontWeight: FontWeight.bold),
              ),
            ],
          ),
        );

        currentText = currentText.substring(match.end);
      } else {
        spans.add(TextSpan(text: currentText));
        currentText = '';
      }
    }

    return TextSpan(
      style: style,
      text: spans.isEmpty ? currentText : null,
      children: spans,
    );
  }
}
