import 'package:flutter/material.dart';

class ScrollGestureController with ChangeNotifier {
  bool _canScroll = true;

  set allowScrollGesture(bool canScroll) {
    if (_canScroll != canScroll) {
      _canScroll = canScroll;
      notifyListeners();
    }
  }

  bool get canScroll => _canScroll;
}
