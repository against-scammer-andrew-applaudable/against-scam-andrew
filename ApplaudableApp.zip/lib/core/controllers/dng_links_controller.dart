// ignore_for_file: use_build_context_synchronously

import 'package:applaudable/core/api/api/api.dart';
import 'package:applaudable/model/circle/circle.dart';
import 'package:dismissible_page/dismissible_page.dart';
import 'package:equatable/equatable.dart';
import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:flutter/widgets.dart';

import '../../app_module.dart';
import '../../features/auth/presentation/ui/auth/recover_password/recover_password_page.dart';
import '../../features/post/presentation/pages/post_page.dart';
import '../../features/profile/presentation/pages/profile_page.dart';
import '../../ui/page/auth/signup/main_flow/register.dart';
import '../../ui/page/circle/feed/circle.dart';
import '../../ui/page/main/feed/sub/preview.dart';
import '../../ui/page/main/profile_settings/profile.dart';
import '../../ui/widget/dialog/center/confirm.dart';
import '../constants/constant_values.dart';
import '../enums/circle.dart';
import '../extensions/app_module_extensions.dart';
import '../extensions/list_extensions.dart';
import '../utils/app_utils.dart';
import '../widgets/toast/app_toast.dart';

enum DngLinkType {
  none("none"),
  invite("invite"),
  reset("deeplink"),
  resetPassword("reset-password"),
  post("post"),
  circle("circle"),
  user("user");

  final String segment;

  const DngLinkType(this.segment);

  static DngLinkType getByName(String? name) =>
      values.firstWhereOrNull((e) => e.segment == name?.trim()) ??
      DngLinkType.none;
}

class DngLinkObject with EquatableMixin {
  final DngLinkType type;
  final String pathSegment;
  final Map? queryParams;

  const DngLinkObject.none()
      : type = DngLinkType.none,
        pathSegment = "",
        queryParams = null;

  const DngLinkObject(
      {this.type = DngLinkType.none, this.pathSegment = "", this.queryParams});

  @override
  List<Object?> get props => [type, pathSegment, queryParams];
}

class DngLinksController {
  static const String _tag = '.DNGLinksController';
  static final DngLinksController _controller = DngLinksController._();

  static DngLinksController get I => _controller;

  DngLinksController._() {
    init();
  }

  bool _initialized = false;

  /// FirebaseDynamicLinks instance
  final _instance = FirebaseDynamicLinks.instance;

  Map<String, PendingDynamicLinkData> links = {};

  String _path(String link) => link.replaceAll("/", "");

  init() {
    if (_initialized) {
      return;
    }
    debugPrint("$_tag INIT");
    _instance.onLink.listen((dynamicLinkData) async {
      debugPrint("dynamicLinkData.link: ${dynamicLinkData.link}");

      final linkType = DngLinkType.getByName(dynamicLinkData.link.path.replaceAll('/', ''));
      debugPrint("dynamicLinkData.linkType: $linkType");
      final res = await _processDeepLink(type: linkType, queryParams: dynamicLinkData.link.queryParameters);
      if (!res) {
        save(dynamicLinkData);
      }
    }).onError((error) {
      // Handle errors
    });

    _initialized = true;
  }

  Future<void> handleLinks() async {
    final DngLinkObject link = await validateLinkForRedirect();
    debugPrint("====== handleLinks: ${link.props}");

    _processDeepLink(type: link.type, queryParams: link.queryParams);
  }
  Future<bool> _processDeepLink({required DngLinkType type, Map? queryParams}) async {
    switch (type) {
      case DngLinkType.invite:
        if (!AppModule.I.hasSession && (queryParams?.containsKey("code") ?? false)) {
          AppModule.I.navigateToNamed(RegisterPage.routeName, arguments: {
            "invitationCode" : queryParams?["code"] ?? "",
            "phone" : queryParams?["phone"],
          });
          return true;
        }
        break;
      case DngLinkType.reset:
      case DngLinkType.resetPassword:
      if (!AppModule.I.hasSession && (queryParams?.containsKey("code") ?? false) && (queryParams?.containsKey("email") ?? false)) {
        ResetPasswordPage.push(
          queryParams!["code"],
          queryParams["email"],
        );
      }
        break;
      case DngLinkType.none:
      case DngLinkType.post:
        if (AppModule.I.hasSession && (queryParams?.containsKey("id") ?? false)) {
          final String postId = queryParams!["id"];
          if ((AppUtils().tabContext) != null) {
            await (AppUtils().tabContext!).pushTransparentRoute(PostPreviewPage(postId: postId,));
          }
          return true;
        }
        break;
      case DngLinkType.user:
        if (AppModule.I.hasSession && (queryParams?.containsKey("id") ?? false)) {
          final String userId = queryParams!["id"];
          AppModule.I.navigateToNamed(
            AppProfilePage.routeName,
            arguments: {
              "userId": userId,
            },
          );
          return true;
        }
      case DngLinkType.circle:
        if ((queryParams?.containsKey("code") ?? false) && (queryParams?.containsKey("circle_id") ?? false)) {
          _circleShare(queryParams!["code"], queryParams["circle_id"]);
          return true;
        }
        break;
    }
    return false;
  }
  Future _circleShare(String code, String circleId) async {
    if (AppModule.I.hasSession) {
      if (AppUtils().tabContext != null) {
        processCircleShareFromCircleId(AppUtils().tabContext!, circleId);
      }
    } else {
      AppModule.I.navigateToNamed(RegisterPage.routeName, arguments: {
        "invitationCode" : code,
        "circleId" : circleId,
      });
    }
  }
  Future processCircleShareFromCircleId(BuildContext context, String circleId) async {
    final circle = await APIs().getCircleDetail(circleId: circleId);
    if (circle is CircleModel) {
      if (circle.membership == CircleMembership.notYet) {
        if ((await AppConfirmationDialog.showDialog(
          context,
          title: "Request to join?",
          message: "You are not an active member\nof ${circle.name}.",
          cancelButtonTitle: "No",
          buttonTitle: "Yes",
          dialogHeight: 230,
        )) == true) {
          final res = await APIs().requestJoinToCircle(circle: circle);
          if (res == true) {
            AppToast().build(context, "Please wait until the admin approve your request.", mode: AppToastMode.info);
          } else {
            AppToast().build(context, (res is String) ? res : "Failed to request to join to this circle.", mode: AppToastMode.info);
          }
        }
      } else if (circle.membership == CircleMembership.invited) {
        final response = await AppConfirmationDialog.showDialog(
          context,
          barrierDismissible: false,
          title: "Circle Invitation",
          message: "${circle.inviter?.name ?? "Someone"} invited to ${circle.name}",
          cancelButtonTitle: "Reject",
          buttonTitle: "Accept",
        );
        if (response == true) {
          final response = await APIs().acceptCircleInvitation(circle: circle, force: true);
          if (response != true) {
            AppToast().build(context, "Failed to accept to the circle invitation.", mode: AppToastMode.info);
          } else {
            AppModule.I.navigateToNamed(
              CirclePostsFeedPage.routeName,
              arguments: {
                "circle": circle,
              },
            );
          }
        } else if (response == false) {
          final response = await APIs().rejectCircleInvitation(circle: circle, force: true);
          if (response != true) {
            AppToast().build(context, "Failed to reject to the circle invitation.", mode: AppToastMode.info);
          }
        }
      } else if (circle.membership == CircleMembership.admin || circle.membership == CircleMembership.member) {
        AppModule.I.navigateToNamed(
          CirclePostsFeedPage.routeName,
          arguments: {
            "circle": circle,
          },
        );
      }
    }
  }

  Future<PendingDynamicLinkData?> _getLatest() async =>
      await _instance.getInitialLink();

  Future<Uri?> _getLatestPending(DngLinkType linkType) async {
    final PendingDynamicLinkData? data = await _getLatest() ??
        (links.containsKey(linkType.name) ? links[linkType.name] : null);

    if (data == null) {
      return null;
    }

    if (_path(data.link.path) != linkType.name) {
      return null;
    }

    return data.link;
  }

  Future<String> checkInviteCode() async {
    final Uri? link = await _getLatestPending(DngLinkType.invite);
    if (link == null) {
      return "";
    }
    return link.queryParameters["code"] ?? "";
  }

  Future<bool> openedViaInviteCode() async {
    final Uri? link = await _getLatestPending(DngLinkType.invite);
    return link != null;
  }

  Future<String> checkPostRedirect() async {
    final Uri? link = await _getLatestPending(DngLinkType.post);
    if (link == null) {
      return "";
    }

    remove(type: DngLinkType.post);

    return link.queryParameters["id"] ?? "";
  }

  Future<Uri> generateLink(Map<String, String> payload, {String? path}) async {
    final uri = Uri.https('www.applaudable.com', (path?.isNotEmpty ?? false) ? "/$path" : "/", payload);
    ShortDynamicLink shortDynamicLink = await _instance.buildShortLink(
      DynamicLinkParameters(
        uriPrefix: 'https://applaudable${ConstantValues.environment.isStaging ? "stage" : ""}.page.link',
        link: uri,
        androidParameters: AndroidParameters(
          packageName: 'com.applaudable.applaudable${ConstantValues.environment.isStaging ? ".stage" : ""}',
          minimumVersion: 0,
          // fallbackUrl: Uri.parse("https://www.applaudable.com/"), /// https://www.applaudable.com/post
        ),
        iosParameters: IOSParameters(
          bundleId: 'com.applaudable.applaudable${ConstantValues.environment.isStaging ? ".stage" : ""}',
          minimumVersion: '1.1.3',
          appStoreId: ConstantValues.environment.isStaging ? "6477883329" : '6443599864',
          // fallbackUrl: Uri.parse("https://www.applaudable.com/"), /// https://www.applaudable.com/post
        ),
        navigationInfoParameters: const NavigationInfoParameters(forcedRedirectEnabled: false),
      ),
    );

    return shortDynamicLink.shortUrl;
  }

  void save(PendingDynamicLinkData dynamicLinkData) {
    links.update(_path(dynamicLinkData.link.path), (value) => dynamicLinkData,
        ifAbsent: () => dynamicLinkData);
  }

  void remove({String? link, DngLinkType? type}) {
    if (link != null && link.isNotEmpty && links.containsKey(link)) {
      links.remove(link);
    }

    if (type != null && links.containsKey(type.name)) {
      links.remove(type.name);
    }
  }

  Future<DngLinkObject> validateLinkForRedirect() async {
    final PendingDynamicLinkData? data =
        await _getLatest() ?? (links.isNotEmpty ? links.values.last : null);

    if (data == null) {
      return const DngLinkObject.none();
    }

    final String pathSegment = _path(data.link.path);
    final Map<String, String> queryParams = data.link.queryParameters;
    DngLinkType type = DngLinkType.getByName(pathSegment);

    if (type == DngLinkType.none &&
        queryParams.containsKey("code") &&
        queryParams["code"]!.isNotEmpty &&
        queryParams.containsKey("email") &&
        queryParams["email"]!.isNotEmpty) {
      type = DngLinkType.reset;
    }

    links.removeWhere((key, value) => key != DngLinkType.invite.segment);

    return DngLinkObject(
        type: type, pathSegment: pathSegment, queryParams: queryParams);
  }

  dispose() {
    links.clear();
  }
}
