import '../../model/user/user.dart';

class AuthStateManager {
  static final AuthStateManager _singleton = AuthStateManager._internal();
  factory AuthStateManager() {
    return _singleton;
  }
  AuthStateManager._internal();

  UserProfileModel? currentUser;

}