import 'dart:developer';

import 'package:flutter/material.dart';

import '../../generated/l10n.dart';

class DNGDatePickerProvider with ChangeNotifier {
  int _currentYear = DateTime.now().year;
  int _currentMonth = -1; //DateTime.now().month;
  int _currentDay = -1; //DateTime.now().day;
  String _dateFormat = 'DMY';

  List<String> _years = [];
  List<String> _months = [];
  List<String> _days = [];

  int _firstYear = DateTime.now().year;
  int _lastYear = DateTime.now().year;

  late FixedExtentScrollController yearController;
  late FixedExtentScrollController monthController;
  late FixedExtentScrollController dayController;

  void initDatePicker({String? initial, int? firstYear, int? lastYear}) {
    final translations = S.current;

    if (initial != null && initial.isNotEmpty) {
      _initializePickerValuesFromInitial(initial);
    }


    monthController = FixedExtentScrollController(initialItem: _currentMonth);
    dayController = FixedExtentScrollController(initialItem: _currentDay);

    _months = [
      'none',
      translations.january,
      translations.february,
      translations.march,
      translations.april,
      translations.may,
      translations.june,
      translations.july,
      translations.august,
      translations.september,
      translations.october,
      translations.november,
      translations.december,
    ];

    if (firstYear != null) {
      _firstYear = firstYear;
    } else {
      _firstYear = 1900;
    }

    if (lastYear != null) {
      _lastYear = lastYear;
    } else {
      lastYear = DateTime.now().year;
    }

    /// Generate Picker Values
    _generateYearsList();
    _generateDaysForCurrentMonth();

    final initialYear = _years.indexWhere((e) => e == _currentYear.toString());

    yearController = FixedExtentScrollController(initialItem: initialYear);
  }

  void _initializePickerValuesFromInitial(String initial) {
    try {
      if (initial.toLowerCase() == S.current.today.toLowerCase()) return;

      final parts = initial.split(' ');

      if (parts.length == 3) {
        _currentDay = int.parse(parts.first);
        _currentYear = int.parse(parts.last);

        _currentMonth = months.indexWhere((element) =>
            element.substring(0, 3).toLowerCase() ==
            parts[1].toLowerCase().replaceFirst(',', ''));
      } else {
        _currentDay = -1;
        _currentYear = int.parse(parts.last);

        _currentMonth = months.indexWhere((element) =>
            element.substring(0, 3).toLowerCase() ==
            parts.first.toLowerCase().replaceFirst(',', ''));
      }
    } catch (_) {}
  }

  void _generateYearsList() {
    final numberOfYears = _lastYear - _firstYear;

    _years = List.generate(
      numberOfYears + 1,
      (i) => (_firstYear + i).toString(),
    );
  }

  void onYearUpdated(int index) {
    _currentYear = int.parse(_years[index]);

    // notifyListeners();
  }

  void onMonthUpdated(int index) {
    if (index == 0) {
      _currentDay = -1;
      _days = ['none'];
      _currentMonth = index;
    } else {
      _currentMonth = index;
      _generateDaysForCurrentMonth();
    }

    notifyListeners();
  }

  void onDayUpdated(String day) {
    if (day == 'none') {
      _currentDay = -1;
    } else {
      _currentDay = int.parse(day);
    }
  }

  void _generateDaysForCurrentMonth() {
    final numberOfDays = _getDaysInMonth(DateTime(_currentYear, _currentMonth));
    _days = List.generate(numberOfDays, (index) => (index + 1).toString());
    _days.insert(0, 'none');
  }

  int _getDaysInMonth(DateTime date) {
    var daysInMonth = _getLastDay(date);

    return daysInMonth;
  }

  int _getLastDay(DateTime date) {
    return DateTime(date.year, date.month + 1, 0).day;
  }

  void reset() {
    _currentMonth = -1;
    _currentDay = -1;
  }

  String get currentDay => _currentDay == -1 ? 'none' : _currentDay.toString();
  String get currentMonth => _currentMonth.toString();
  String get currentYear => _currentYear.toString();
  List<String> get years => _years;
  List<String> get months => _months;
  List<String> get days => _days;
  DateTime get selectedDateTime => DateTime(
        _currentYear,
        _currentMonth == 0 ? 1 : _currentMonth,
        _currentDay == -1 ? 1 : _currentDay,
      );
  String get selectedDate {
    log(_currentMonth.toString());
    if (_currentMonth == 0) {
      _dateFormat = 'Y';
      return currentYear;
    }

    if (_currentDay == -1) {
      _dateFormat = 'MY';
      return '${months[_currentMonth].substring(0, 3)}, $currentYear';
    }

    _dateFormat = 'DMY';
    return '$_currentDay ${months[_currentMonth].substring(0, 3)}, $_currentYear';
  }

  String get dateFormat => _dateFormat;
}
