import 'dart:io';

import 'package:logger/logger.dart';

abstract class NetworkInfo {
  Future<bool> get isConnected;
}

class AppNetworkInfo extends NetworkInfo {
  @override
  Future<bool> get isConnected async {
    try {
      final result = await InternetAddress.lookup('google.com');

      if (result.isNotEmpty && result.first.rawAddress.isNotEmpty) {
        //* Device is not connected to internet [√]
        return true;
      }
    } on SocketException catch (e) {
      //! Device is not connected to internet [x]
      Logger().e(e.message);
    }

    //! Device is not connected to internet [x]
    return false;
  }
}
