class ServerException implements Exception {
  final String message;
  final int? statusCode;

  String get errorMessage => message.split(":").lastOrNull ?? message;
  ServerException({required this.message, this.statusCode});

  @override
  String toString() {
    return "ServerException(statusCode: $statusCode, message: $message)";
  }
}

class NetworkException implements Exception {
  final String message;

  NetworkException({required this.message});

  @override
  String toString() {
    return "NetworkException(message: $message)";
  }
}

/// Exception which will be thrown when server is under maintenance mode
class MaintenanceModeException implements Exception {
  final String message;

  MaintenanceModeException({required this.message});

  @override
  String toString() {
    return "MaintenanceModeException(message: $message)";
  }
}

/// Exception which will be thrown when new app version is available and user
/// must download the update to use the app (Status Code can be set accordingly).
class ForceUpdateException implements Exception {
  final String message;

  ForceUpdateException({required this.message});

  @override
  String toString() {
    return "ForceUpdateException(message: $message)";
  }
}

/// Exception which will be thrown when user is logged out or token is revoked
class UnauthorizedUserException implements Exception {
  final String message;

  UnauthorizedUserException({required this.message});

  @override
  String toString() {
    return "UnauthorizedUserException(message: $message)";
  }
}

class SignInIncompleteException implements Exception {
  final dynamic message;
  final String label;

  SignInIncompleteException([this.message, this.label = ""]);

  @override
  String toString() {
    return "$label$message";
  }
}

/// Exception which will be thrown when user denied a device permission.
class DevicePermissionDeniedException implements Exception {
  final String message;

  const DevicePermissionDeniedException({required this.message});

  @override
  String toString() {
    return "DevicePermissionDeniedException(message: $message)";
  }
}
