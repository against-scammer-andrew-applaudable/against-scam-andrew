import 'package:equatable/equatable.dart';

import '../entities/error/error_response.dart';

abstract class Failure extends Equatable {
  final String message;

  const Failure({required this.message});

  @override
  List<Object?> get props => [message];
}

/// Failure which will be returned when device has no internet connection.
class NetworkFailure extends Failure {
  const NetworkFailure({required super.message});
}

/// Failure which will be returned for normal errors that is coming form the API
/// for example (Status Code 400 or 404).
class ServerFailure extends Failure {
  const ServerFailure({required super.message});
}

/// Failure which will be returned when server is under maintenance mode
/// for example (Status Code 503).
class MaintenanceModeFailure extends Failure {
  const MaintenanceModeFailure({required super.message});
}

/// Failure which will be returned when new app version is available and user
/// must download the update to use the app (Status Code can be set accordingly).
class ForceUpdateFailure extends Failure {
  const ForceUpdateFailure({required super.message});
}

/// Failure which will be returned when user is logged out or token is revoked
/// for example (Status Code 401).
class UnauthorizedUserFailure extends Failure {
  const UnauthorizedUserFailure({required super.message});
}

class SignInIncompleteFailure extends Failure {
  final SignInInCompleteErrorResponse? error;

  const SignInIncompleteFailure({this.error, super.message = ""});

  @override
  String toString() {
    return "$error$message";
  }

  @override
  List<Object?> get props => [error, message];
}

/// Failure which will be returned when denied a device access permission.
/// for example Location or Contacts permissions
class DevicePermissionDeniedFailure extends Failure {
  const DevicePermissionDeniedFailure({required super.message});
}

/// TODO: Add other types of failurs here if any
