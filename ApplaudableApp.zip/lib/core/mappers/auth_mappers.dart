import '../../features/auth/data/models/requests/activate_account_request_model.dart';
import '../../features/auth/data/models/requests/login_request_model.dart';
import '../../features/auth/data/models/requests/login_with_phone_number_request_model.dart';
import '../../features/auth/data/models/requests/recover_password_request_model.dart';
import '../../features/auth/data/models/requests/reset_password_request_model.dart';
import '../../features/auth/data/models/requests/signin_confirm_code_request_model.dart';
import '../../features/auth/data/models/requests/signup_request_model.dart';
import '../../features/auth/data/models/session_response_model.dart';
import '../../features/auth/data/models/token_response_model.dart';
import '../../features/auth/data/models/user_response_model.dart';
import '../../features/auth/domain/entities/activate_account_request.dart';
import '../../features/auth/domain/entities/login_request.dart';
import '../../features/auth/domain/entities/recover_password_request.dart';
import '../../features/auth/domain/entities/reset_password_request.dart';
import '../../features/auth/domain/entities/session.dart';
import '../../features/auth/domain/entities/signup_request.dart';
import '../../features/auth/domain/entities/token.dart';
import '../../features/auth/domain/entities/user.dart';

extension UserMapperExtension on UserResponseModel {
  HiveUser toEntity() => HiveUser(
        id: id,
        name: name,
        username: username ?? name,
        email: email,
        phoneNumber: phoneNumber ?? "",
        avatar: avatar,
        birthDate: birthDate,
        yearOnly: yearOnly,
        location: location,
        instagramHandler: instagramHandler,
        bio: bio,
        isActive: isActive,
        hasProfile: hasProfile,
        counters: counters,
        engagement: engagement,
        collections: collections ?? [],
        isFollowing: isFollowing,
        invitationsCount: invitationsCount,
        invitationCode: invitationCode,
      );
}

extension TokenMapperExtension on TokenResponseModel {
  Token toEntity() => Token(
        refresh: refresh,
        access: access,
      );
}

extension SessionMapperExtension on SessionResponseModel {
  Session toEntity() => Session(
        token: token.toEntity(),
        user: user.toEntity(),
      );
}

extension SignupMapperExtension on SignUpRequest {
  SignUpRequestModel toRequestModel() => SignUpRequestModel(
      username: username!,
      email: email!,
      name: name!,
      birthDate: birthDate!,
      phoneNumber: phoneNumber!,
      password: password!,
      location: '',
      bio: "",
      code: code ?? "",
      instagramHandler: instagramHandler ?? "",
      inviteCode: inviteCode ?? "");
}

extension LoginMapperExtension on LoginRequest {
  LoginRequestModel toRequestModel() => LoginRequestModel(
        email: email!,
        password: password!,
      );
}

extension LoginWithPhoneNumberMapperExtension on LoginWithPhoneNumberRequest {
  LoginWithPhoneNumberRequestModel toRequestModel() =>
      LoginWithPhoneNumberRequestModel(
          phoneNumber: "${country!}${phoneNumber!}");
}

extension SignInConfirmCodeMapperExtension on SignInConfirmCodeRequest {
  SignInConfirmCodeRequestModel toRequestModel() =>
      SignInConfirmCodeRequestModel(pinCode: code!, phoneNumber: phoneNumber!);
}

extension RecoverPasswordMapperExtension on RecoverPasswordRequest {
  RecoverPasswordRequestModel toRequestModel() => RecoverPasswordRequestModel(
        email: email!,
      );
}

extension ActivateAccountMapperExtension on ActivateAccountRequest {
  ActivateAccountRequestModel toRequestModel() =>
      ActivateAccountRequestModel(pinCode: code!, phoneNumber: phoneNumber!);
}

extension ResetPasswordMapperExtension on ResetPasswordRequest {
  ResetPasswordRequestModel toRequestModel() => ResetPasswordRequestModel(
        email: email!,
        code: code!,
        password: password!,
        confirmPassword: password!,
      );
}
