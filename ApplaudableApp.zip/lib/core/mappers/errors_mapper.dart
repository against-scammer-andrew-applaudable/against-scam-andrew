import '../../features/auth/data/models/activate_account_error_response_model.dart';
import '../../features/auth/data/models/default_error_response_model.dart';
import '../../features/auth/data/models/signin_incomplete_error_response_model.dart';
import '../../features/auth/data/models/signup_error_response_model.dart';
import '../entities/error/error_response.dart';

extension ErrorResponseMapperExtension on DefaultErrorResponseModel {
  ErrorResponse toEntity() => ErrorResponse(
      code: code,
      message: detail,
      fields: fields,
      missingFields: [...?missingFields]);
}

extension SignInIncompleteErrorResponseMapperExtension
    on SignInIncompleteErrorResponseModel {
  SignInInCompleteErrorResponse toEntity() => SignInInCompleteErrorResponse(
      code: code, fields: fields, missingFields: [...?missingFields]);
}

extension SignUpErrorResponseMapperExtension on SignUpErrorResponseModel {
  ErrorResponse toEntity() {
    String? message;

    String previousMessage() {
      String prevMessage = message ?? '';
      if (prevMessage.isEmpty) {
        return prevMessage;
      } else {
        return '$prevMessage ';
      }
    }

    if (email != null) {
      message = '${previousMessage()}${email![0]}';
    }

    if (username != null) {
      message = '${previousMessage()}${username![0]}';
    }

    if (phoneNumber != null) {
      message = '${previousMessage()}${phoneNumber![0]}';
    }

    return ErrorResponse(
      message: message,
    );
  }
}

extension ActivateAccountErrorResponseMapperExtension
    on ActivateAccountErrorResponseModel {
  ErrorResponse toEntity() {
    String? message;

    String previousMessage() {
      String prevMessage = message ?? '';
      if (prevMessage.isEmpty) {
        return prevMessage;
      } else {
        return '$prevMessage ';
      }
    }

    if (code != null) {
      message = '${previousMessage()}${code![0]}';
    }

    if (phoneNumber != null) {
      message = '${previousMessage()}${phoneNumber![0]}';
    }

    return ErrorResponse(
      message: message,
    );
  }
}
