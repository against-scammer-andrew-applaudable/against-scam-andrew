import 'package:intl/intl.dart';
import 'package:json_annotation/json_annotation.dart';

class OptionalDateSerializer implements JsonConverter<DateTime?, String?> {
  const OptionalDateSerializer();

  @override
  DateTime? fromJson(String? json) {
    if (json == null) {
      return null;
    }

    if (json.contains(".")) {
      json = json.split(".")[0];
    }
    return DateTime.parse(json);
  }

  @override
  String? toJson(DateTime? date) =>
      date == null ? null : DateFormat('yyyy-MM-ddTHH:mm:ss').format(date);
}

class MandatoryDateSerializer implements JsonConverter<DateTime, String> {
  const MandatoryDateSerializer();

  @override
  DateTime fromJson(String json) {
    if (json.contains(".")) {
      json = json.substring(0, json.length - 1);
    }
    return DateTime.parse(json);
  }

  @override
  String toJson(DateTime date) => DateFormat('yyyy-MM-dd').format(date);
}
