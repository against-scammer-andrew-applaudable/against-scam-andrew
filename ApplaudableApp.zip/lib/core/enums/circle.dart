import 'package:applaudable/core/extensions/list_extensions.dart';

enum CircleMembership {
  admin("admin"),
  member("member"),
  invited("invited"),
  requested("requested"),
  notYet("not_yet");

  final String name;
  const CircleMembership(this.name);

  static CircleMembership from(dynamic value) => values.firstWhereOrNull((e) => e.name == value) ?? CircleMembership.notYet;
}