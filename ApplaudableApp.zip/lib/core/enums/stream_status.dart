enum Status { loading, done, error }
