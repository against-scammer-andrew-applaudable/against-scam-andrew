import 'package:applaudable/core/extensions/list_extensions.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../model/post/feed.dart';
import '../../ui/widget/view/highlight/layout/sub/center.dart';

enum GlimpseMediaType {
  video,
  photo,
  text,
  checkIn;

  static GlimpseMediaType fromIndex(int index) {
    if (index < 0) return GlimpseMediaType.video;
    if (index >= GlimpseMediaType.values.length) return GlimpseMediaType.checkIn;
    return GlimpseMediaType.values[index];
  }
  String get title {
    switch (this) {
      case GlimpseMediaType.video:
        return "VIDEO";
      case GlimpseMediaType.photo:
        return "PHOTO";
      case GlimpseMediaType.text:
        return "TEXT";
      case GlimpseMediaType.checkIn:
        return "CHECK-IN";
    }
  }
  double get width {
    switch (this) {
      case GlimpseMediaType.video:
        return 48;
      case GlimpseMediaType.photo:
        return 52;
      case GlimpseMediaType.text:
        return 44;
      case GlimpseMediaType.checkIn:
        return 80;
    }
  }
}
enum AIOption {
  casual,
  objective,
  witty,
  intelligent;

  String get title {
    switch (this) {
      case AIOption.casual:
        return "Casual";
      case AIOption.objective:
        return "Objective";
      case AIOption.witty:
        return "Witty";
      case AIOption.intelligent:
        return "Intelligent";
    }
  }

}
/// TODO : Add more highlight layout
enum HighlightLayoutType {
  center;

  static HighlightLayoutType from(dynamic value) => values.firstWhereOrNull((e) => e.name == value) ?? HighlightLayoutType.center;

  Widget layout({
    required List<FeedPostModel> glimpses,
    required double height,
    String? title,
    String? description,
    double interval = 30,
    EdgeInsets padding = const EdgeInsets.only(right: 16),
  }) {
    switch (this) {
      case HighlightLayoutType.center:
        return CenterHighlightLayout(
          glimpses: glimpses,
          height: height,
          title: title,
          description: description,
          interval: interval,
          padding: padding,
        );
    }
  }

  Widget get icon {
    switch (this) {
      case HighlightLayoutType.center:
        return const Icon(
          Icons.align_vertical_center_rounded,
          size: 20,
          color: Colors.white,
        );
    }
  }
}