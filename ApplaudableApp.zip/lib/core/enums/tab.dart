// ignore_for_file: deprecated_member_use

import 'package:applaudable/core/extensions/build_context_extensions.dart';
import 'package:applaudable/core/theme/colors.dart';
import 'package:applaudable/ui/widget/view/common/avatar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_svg/svg.dart';

import '../../features/auth/domain/entities/session.dart';
import '../../ui/page/circle/my_circles.dart';
import '../../ui/page/main/feed/home_feed.dart';
import '../../ui/page/main/profile_settings/profile.dart';
import '../../ui/page/main/search/search.dart';
import '../theme/styles.dart';
import '../widgets/svg_icons.dart';

enum TabBarType {
  home,
  search,
  add,
  circles,
  profile;

  Widget icon(BuildContext context, Color color, {bool selected = false, String? url, String? name}) {
    switch (this) {
      case TabBarType.home:
        return SvgHomeIcons.home(color: color);
      case TabBarType.search:
        return SvgHomeIcons.navBarSearch(color: color);
      case TabBarType.add:
        return Container(
          width: 70,
          height: 40,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: AppColors.primaryColor,
            borderRadius: BorderRadius.circular(40),
          ),
          child: SvgHomeIcons.createPost(),
        );
      case TabBarType.circles:
        return SvgPicture.asset('assets/icons/circle/circle.svg', color: color,);
      case TabBarType.profile:
        return Container(
          width: 24,
          height: 24,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            color: color,
            border: Border.all(color: context.textColor, width: selected ? 1 : 0, strokeAlign: 1),
          ),
          child: UserAvatarView(
            size: 24,
            url: url,
            name: name,
            fontSize: 12,
          ),
        );
    }
  }
  Widget page(Session? session, {HomeFeedPageController? feedPageController}) {
    switch (this) {
      case TabBarType.home:
        return HomeFeedPage(controller: feedPageController, homeFeed: true,);
        // return const MainFeedPage();
      case TabBarType.search:
        return const AppSearchPage();
      case TabBarType.add:
        return Container();
      case TabBarType.circles:
        return const MyCirclesPage();
      case TabBarType.profile:
        return const AppProfilePage(isOnTabBar: true,);
    }
  }
}

enum FeedTabBarType {
  suggestion;
  // following;

  String get title {
    switch(this) {
      case FeedTabBarType.suggestion:
        return "Preserved Moments";
      // case FeedTabBarType.following:
      //   return "Following";
    }
  }
  Widget icon(BuildContext context, {bool selected = false, VoidCallback? onPressed}) {
    return CupertinoButton(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      onPressed: onPressed,
      pressedOpacity: 1,
      child: Text(
        title,
        style: AppStyles.header1(color: context.textColor.withOpacity(selected ? 1 : 0.5)).copyWith(fontSize: 14, fontWeight: selected ? FontWeight.w700 : FontWeight.w500),
      ),
    );
  }
}
