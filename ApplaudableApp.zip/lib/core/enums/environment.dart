import '../api/api_env.dart';

enum AppEnvironment {
  staging,
  production;

  ApiEnv get apiEnv {
    switch (this) {
      case AppEnvironment.staging:
        return StagingApi();
      case AppEnvironment.production:
        return ProductionApi();
    }
  }
  String get title {
    switch (this) {
      case AppEnvironment.staging:
        return "Staging Environment";
      case AppEnvironment.production:
        return "Production Environment";
    }
  }
  bool get isStaging => this == AppEnvironment.staging;
  bool get isProduction => this == AppEnvironment.production;
}