import '../extensions/list_extensions.dart';

enum SvgCategoryIcons {
  /// All the available icons for each category
  /// every [slug] match the icon that is inside:
  /// lib/icons/category/<slug>.svg
  activity("ic_category_activity"),
  arts("ic_category_arts"),
  brand("ic_category_brand"),
  food("ic_category_food"),
  object("ic_category_object"),
  personal("ic_category_personal"),
  place("ic_category_place"),
  professional("ic_category_professional"),
  publicFigure("ic_category_public_figure"),

  /// Default icon in case its not in this list
  defaultIcon("ic_category_default");

  static String getIconBySlug(String? slug) => (SvgCategoryIcons.values
              .firstWhereOrNull((e) => e.slug == slug?.trim()) ??
          SvgCategoryIcons.defaultIcon)
      .slug;

  final String slug;
  const SvgCategoryIcons(this.slug);
}
