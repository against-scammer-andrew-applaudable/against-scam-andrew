import 'dart:math';

import 'package:applaudable/core/extensions/list_extensions.dart';

enum PostingMode {
  create,
  edit,
}
enum CreatePostType {
  experience("post"),
  person("person"),
  story("story"),
  repost("repost"),
  highlight("highlight"),
  circleQuestion("circle_question"),
  circleQuestionReply("circle_question_reply"),
  glimpse("glimpse"),
  glimpseQuestion("glimpse_question"),
  glimpseQuestionReply("glimpse_question_reply"),
  none("none");

  final String name;
  const CreatePostType(this.name);

  static CreatePostType from(dynamic value) => values.firstWhereOrNull((e) => e.name == value) ?? CreatePostType.none;

  bool get isCircleQuestionRelated => this == CreatePostType.circleQuestion || this == CreatePostType.circleQuestionReply;
  bool get isGlimpseQuestionRelated => this == CreatePostType.glimpseQuestion || this == CreatePostType.glimpseQuestionReply;
  bool get isGlimpseRelated => this == CreatePostType.glimpse;
  bool get needGrayOut => isGlimpseRelated || isGlimpseQuestionRelated;
  bool get isQuestion => this == CreatePostType.circleQuestion || this == CreatePostType.glimpseQuestion;
  bool get isAnswer => this == CreatePostType.circleQuestionReply || this == CreatePostType.glimpseQuestionReply;

  String get title {
    switch (this) {
      case CreatePostType.experience:
        return "An Experience";
      case CreatePostType.person:
        return "A Person";
      default:
        return "";
    }
  }
  String get nameForAPI {
    switch (this) {
      case CreatePostType.experience:
        return "post";
      default:
        return name;
    }
  }
}

enum PostVisibilityType {
  onlyme,
  custom,
  public;

  static PostVisibilityType from(dynamic value) => values.firstWhereOrNull((e) => e.name == value) ?? PostVisibilityType.public;
  String get title {
    switch (this) {
      case PostVisibilityType.onlyme:
        return "Only Me";
      case PostVisibilityType.custom:
        return "Custom";
      case PostVisibilityType.public:
        return "Public";
    }
  }
  String get titleInGlimpse {
    switch (this) {
      case PostVisibilityType.onlyme:
        return "Only You";
      case PostVisibilityType.custom:
        return "Custom";
      case PostVisibilityType.public:
        return "Everyone";
    }
  }
  String get icon {
    switch (this) {
      case PostVisibilityType.onlyme:
        return "assets/icons/glimpse/only_you.svg";
      case PostVisibilityType.custom:
        return "";
      case PostVisibilityType.public:
        return "assets/icons/glimpse/visible.svg";
    }
  }
}
enum PostExperienceType {
  user("user"),
  location("location"),
  date("date"),
  food("food"),
  freeform("freeform"),
  api("other"),
  person("person");

  final String name;
  const PostExperienceType(this.name);

  static PostExperienceType from(dynamic value) => values.firstWhereOrNull((e) => e.name == value) ?? PostExperienceType.freeform;
}
enum PostExperienceLevel {
  l1,
  l2,
  l3,
  l4,
  l5;

  final double delta = 0.05;
  double get interval => 0.4 - delta;
  final double startPosition = 1.5;

  static PostExperienceLevel from(int value) {
    final index = PostExperienceLevel.values.indexWhere((element) => element.value == value);
    if (index >= 0) {
      return PostExperienceLevel.values[index];
    }
    return PostExperienceLevel.l1;
  }
  int get value {
    return index + 1;
  }
  double get startAngle {
    switch(this) {
      case PostExperienceLevel.l1:
        return (startPosition + delta / 2) * pi;
      case PostExperienceLevel.l2:
        return (startPosition + interval + delta * 3 / 2) * pi;
      case PostExperienceLevel.l3:
        return (startPosition + interval * 2 + delta * 5 / 2) * pi;
      case PostExperienceLevel.l4:
        return (startPosition + interval * 3 + delta * 7 / 2) * pi;
      case PostExperienceLevel.l5:
        return (startPosition + interval * 4 + delta * 9 / 2) * pi;
    }
  }
  double get sweepAngle {
    return interval * pi;
  }
}
