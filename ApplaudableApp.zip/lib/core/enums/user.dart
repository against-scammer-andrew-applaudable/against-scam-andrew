import 'package:applaudable/core/extensions/list_extensions.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_svg/svg.dart';

enum UserProfileTabType {
  // story,
  post,
  private,
  tag;

  String get title {
    switch (this) {
      case UserProfileTabType.post:
        return "Posts";
      case UserProfileTabType.private:
        return "Private";
      case UserProfileTabType.tag:
        return "Tags";
    }
  }
  String get blankText {
    switch (this) {
      case UserProfileTabType.post:
        return "No Posts";
      case UserProfileTabType.private:
        return "No Private posts";
      case UserProfileTabType.tag:
        return "No Tags";
    }
  }
  Widget get tabIcon {
    switch (this) {
      case UserProfileTabType.post:
        return SvgPicture.asset("assets/icons/tabbar/profile/post.svg");
      case UserProfileTabType.private:
        return SvgPicture.asset("assets/icons/tabbar/profile/private.svg");
      case UserProfileTabType.tag:
        return SvgPicture.asset("assets/icons/tabbar/profile/tag.svg");
    }
  }
}
enum AddUserType {
  existing,
  invite;

  String get title {
    switch (this) {
      case AddUserType.existing:
        return "Existing User";
      case AddUserType.invite:
        return "New User";
    }
  }
}
enum AppUserActionType {
  create,
  edit,
  delete;
}
enum AppSettingsContentType {
  privacy,
  termsAndConditions,
  faqs,
  aboutUs;

  String get displayName {
    switch(this) {
      case AppSettingsContentType.privacy:
        return "Privacy policy";
      case AppSettingsContentType.termsAndConditions:
        return "Terms and conditions";
      case AppSettingsContentType.faqs:
        return "FAQs";
      case AppSettingsContentType.aboutUs:
        return "About us";
    }
  }
  String get paramForAPI {
    switch(this) {
      case AppSettingsContentType.privacy:
        return "privacy";
      case AppSettingsContentType.termsAndConditions:
        return "terms-and-conditions";
      case AppSettingsContentType.faqs:
        return "faqs";
      case AppSettingsContentType.aboutUs:
        return "about-us";
    }
  }
}

enum UserContactType {
  follow("follow"), /// Who has my number as a contact
  reverseContact("reverse_contact"), /// Who is in my contact
  preFollowHash("pre_follow_hash"), /// Who is in my contact, but not registered yet
  otherwise("otherwise"), /// Not my contacts. Just poster in Feed
  none("none");

  final String name;
  const UserContactType(this.name);

  static UserContactType from(dynamic value) => values.firstWhereOrNull((e) => e.name == value) ?? UserContactType.none;
}